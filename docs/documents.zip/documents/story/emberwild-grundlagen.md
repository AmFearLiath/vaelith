# EMBERWILD
## Lore-, Story- und Gameplay-Grundlagen
**Version 0.1 – Gemeinsames Grundkonzept**

*Ein Fundament für Weltgeschichte, Mythologie, Hauptgeschichte, Questsystem, Spielfunktionen und zukünftige Spielerlebnisse.*

---

# 1. Grundkonzept und erzählerische Ausrichtung

## 1.1 Die zentrale Geschichte

Emberwild erzählt die Geschichte zweier voneinander getrennter Zivilisationen, die einst gemeinsam eine außergewöhnliche Welt erschufen, durch eine Katastrophe getrennt wurden und nun vor einer gemeinsamen Zukunft stehen, die sie allein nicht erreichen können.

Die Oberwelt und die Unterwelt haben sich über Jahrhunderte unabhängig voneinander entwickelt. Beide verfügen über eigene Kulturen, Gesellschaften, Technologien, Traditionen und Lebensweisen.

Doch beide haben ein Problem: Sie benötigen die Ressourcen und das Wissen der jeweils anderen Seite, um ihre Entwicklung fortsetzen zu können.

Der Spieler ist der Schlüssel zur Wiedervereinigung.

Er stammt aus einer Verbindung zwischen einem Herrscher der Unterwelt und einer Bewohnerin der Oberwelt. Seine Existenz war kein Zufall, sondern ein bewusstes Vorhaben seines Vaters. Er sollte die Eigenschaften und Fähigkeiten beider Völker in sich vereinen und eines Tages ermöglichen, was beiden Zivilisationen allein nicht mehr gelingt.

Seine Aufgabe besteht darin, das uralte magische Netzwerk Vaelith wiederherzustellen, die beiden Welten miteinander zu verbinden und eine gemeinsame Zukunft zu ermöglichen.

## 1.2 Erzählerische Grundprinzipien

- Keine klassische Geschichte von Gut gegen Böse.
- Angst, Unsicherheit und Misstrauen statt jahrhundertealter Feindschaft.
- Beide Zivilisationen besitzen nachvollziehbare Interessen und Beweggründe.
- Die Welt soll zunächst friedlich, lebendig und einladend wirken.
- Düsterkeit und Bedrohung nehmen mit zunehmender Entfernung zur Heimatregion zu.
- Die Geschichte wird schrittweise durch Erkundung, Entdeckungen und persönliche Begegnungen erzählt.
- Der Spieler ist ein zentraler Protagonist, aber nicht von Anfang an als solcher erkennbar.
- Entscheidungen und Handlungen des Spielers sollen langfristige Auswirkungen haben.
- Die Welt soll nicht ausschließlich durch Dialoge, sondern durch Architektur, Inschriften, Gegenstände, Umgebungen und Ereignisse erzählen.

## 1.3 Atmosphäre und Weltgestaltung

| Weltbereich | Atmosphäre | Erzählerische Funktion |
|---|---|---|
| Heimatregion | Grün, friedlich, farbenfroh | Heimat, Geborgenheit, Einstieg |
| Bekannte Provinzen | Lebendig, vielfältig | Entdeckung, Handel, Gesellschaft |
| Entfernte Oberwelt | Geheimnisvoll, teilweise düster | Vergessene Geschichte |
| Alte Ruinen | Mystisch, verlassen | Vergangenheitsforschung |
| Unterwelt | Technologisch, magisch, vielfältig | Zweite Zivilisation |
| Vergessene Unterweltgebiete | Düster, gefährlich | Katastrophenfolgen und Geheimnisse |

---

# 2. Die beiden Zivilisationen

## 2.1 Die Oberwelt

Die Oberwelt besteht aus natürlichen Landschaften, Königreichen, Provinzen, Dörfern, Städten und unterschiedlichen Kulturen.

Ihre Bewohner leben von Landwirtschaft, Handwerk, Handel, Jagd, Tierhaltung und natürlichen Ressourcen.

Magie ist bekannt, wird jedoch nicht von jedem Bewohner beherrscht.

**Besondere Eigenschaften:**
- Natürliche Lebensräume und Ökosysteme.
- Landwirtschaft und biologische Ressourcen.
- Holz, Pflanzen, Tiere und natürliche Rohstoffe.
- Natürliche magische Affinitäten.
- Unterschiedliche Königreiche und politische Strukturen.
- Gilden, Clans und unabhängige Siedlungen.

**Erzählerische Bedeutung:**

Die Oberwelt repräsentiert die natürliche Entwicklung der Welt. Ihre Bewohner haben sich an die Bedingungen angepasst und eine eigenständige Gesellschaft aufgebaut.

Ihre Schwäche liegt darin, dass bestimmte Ressourcen und Technologien fehlen, um ihre Entwicklung weiter voranzutreiben.

## 2.2 Die Unterwelt

Die Unterwelt ist eine eigenständige, hochentwickelte Zivilisation unterhalb der Oberfläche.

Sie besitzt eine außergewöhnliche Verbindung aus Technologie und Magie.

Ihre Bewohner haben über Jahrhunderte hinweg Technologien entwickelt, die für die Oberweltbewohner kaum von gewöhnlicher Magie zu unterscheiden wären.

**Besondere Eigenschaften:**
- Gigantische unterirdische Städte.
- Eigenständige Völker und Kulturen.
- Hochentwickelte Energieversorgung.
- Kristall- und Mineraltechnologien.
- Fortschrittliche Maschinen und Transportanlagen.
- Alchemie und energetische Verfahren.
- Eigene politische Strukturen und Herrschaftssysteme.
- Dörfer, Handelsplätze, Werkstätten und Siedlungen.

Die Unterwelt ist nicht grundsätzlich feindselig.

Sie besitzt friedliche Regionen, freundliche Bewohner, Händler, Handwerker, Gasthäuser und eigene gesellschaftliche Probleme.

Auch dort gibt es unterschiedliche Meinungen über die Zukunft und die mögliche Wiedervereinigung mit der Oberwelt.

**Erzählerische Bedeutung:**

Die Unterwelt repräsentiert eine alternative Entwicklung der Zivilisation. Ihre Bewohner verfügen über Wissen und Technologien, die der Oberwelt fehlen.

Allerdings fehlen ihnen zunehmend natürliche Ressourcen und bestimmte Lebensgrundlagen.

## 2.3 Die gegenseitige Abhängigkeit

Beide Zivilisationen sind grundsätzlich lebensfähig, können ihre Entwicklung aber nicht mehr vollständig fortsetzen.

| Oberwelt besitzt | Unterwelt besitzt |
|---|---|
| Landwirtschaftliche Ressourcen | Hochentwickelte Technologien |
| Holz und Pflanzen | Seltene Mineralien |
| Natürliche Rohstoffe | Energieverarbeitung |
| Biologische Ressourcen | Maschinenbau |
| Natürliche Lebensräume | Alchemistische Verfahren |
| Natürliche magische Affinität | Technisches Wissen über Vaelith |

Eine Wiedervereinigung würde beiden Seiten neue Möglichkeiten eröffnen.

**Mögliche Spielfunktionen:**
- Ressourcenhandel zwischen beiden Welten.
- Neue Handwerksrezepte.
- Neue Produktionsmöglichkeiten.
- Technologische Erweiterungen.
- Neue Baumaterialien.
- Gemeinsame Bauprojekte.
- Erweiterte Handelsrouten.
- Neue Siedlungs- und Entwicklungsmöglichkeiten.

---

# 3. Die vergessene Vergangenheit

## 3.1 Das vergessene Zeitalter

Vor vielen Jahrhunderten existierten bereits hochentwickelte Königreiche und Zivilisationen.

Die Oberwelt und die Unterwelt standen miteinander in Verbindung. Sie betrieben Handel, tauschten Wissen aus und entwickelten gemeinsam neue Technologien und magische Verfahren.

In dieser Zeit wurde eine außergewöhnliche Energiequelle entdeckt: Vaelith.

Die Entdeckung ermöglichte enorme Fortschritte in beiden Zivilisationen.

## 3.2 Die Katastrophe

Die damaligen Völker begannen, die Energie von Vaelith gezielt zu nutzen.

Die Unterwelt entwickelte technische Anlagen zur Energiegewinnung und -verarbeitung.

Die Oberwelt entwickelte magische Methoden, um die Energie auf natürliche Weise zu beeinflussen.

Die Nutzung funktionierte zunächst erfolgreich.

Allerdings verstanden beide Zivilisationen nicht vollständig, dass Vaelith Bestandteil eines zusammenhängenden natürlichen Systems war.

Durch Eingriffe in dieses System wurden zahlreiche Verbindungen verändert, überlastet oder unterbrochen.

Die Folgen waren verheerend:

- Magische Knoten wurden instabil.
- Energieversorgungssysteme versagten.
- Unterirdische Ökosysteme wurden verändert.
- Siedlungen und Anlagen mussten aufgegeben werden.
- Auch die Oberwelt war von den Auswirkungen betroffen.
- Die natürliche Energieverteilung geriet aus dem Gleichgewicht.

Die Katastrophe war kein gewöhnlicher technischer Unfall. Sie entstand durch den Eingriff in ein natürliches Gleichgewicht, dessen Zusammenhänge die damaligen Zivilisationen nicht vollständig verstanden.

## 3.3 Die Trennung

Nach der Katastrophe entschieden beide Völker, ihre Verbindungen zu unterbrechen.

Die Unterwelt musste ihre verbliebenen Städte und Bewohner schützen.

Die Oberwelt wollte verhindern, dass weitere Eingriffe in das beschädigte Energiesystem stattfinden.

Die Trennung war ursprünglich als vorübergehende Schutzmaßnahme gedacht.

Doch aus Jahren wurden Jahrzehnte und aus Jahrzehnten Jahrhunderte.

Die Folgen:
- Handelsbeziehungen verschwanden.
- Gemeinsames Wissen ging verloren.
- Sprachen und Kulturen entwickelten sich auseinander.
- Historische Zusammenhänge wurden vergessen.
- Alte Bauwerke wurden zu Ruinen.
- Die ursprünglichen Gründe der Trennung wurden zu Legenden.

Heute kennen die Bewohner beider Welten die tatsächliche Geschichte nicht mehr.

---

# 4. Vaelith – Die ursprüngliche Lebenskraft

## 4.1 Definition

Vaelith ist die ursprüngliche magische Lebenskraft der Welt.

Sie ist kein gewöhnlicher Rohstoff und keine einfache Energiequelle.

Vaelith ist mit einem unsichtbaren, weltumspannenden magischen Netzwerk verbunden, das die gesamte Welt durchzieht.

Dieses Netzwerk existiert überall:
- In Wäldern und Wiesen.
- In Gebirgen und Höhlen.
- In Flüssen und Seen.
- In der Oberwelt und der Unterwelt.
- In natürlichen Lebensräumen.
- In Lebewesen und bestimmten magischen Strukturen.

Die einzelnen Verbindungen sind für gewöhnliche Bewohner unsichtbar.

## 4.2 Begriffsdefinitionen

| Begriff | Bedeutung |
|---|---|
| Vaelith | Die ursprüngliche Lebenskraft |
| Das Geflecht | Das weltumspannende magische Netzwerk |
| Energieknoten | Orte, an denen sich Vaelith sammelt oder verteilt |
| Resonanz | Die Verbindung zwischen einem Lebewesen und Vaelith |
| Resonanzstätte | Ein besonderer Ort zur Untersuchung oder Beeinflussung des Geflechts |

## 4.3 Das Geflecht

Das Geflecht verbindet die verschiedenen Regionen und Lebensräume miteinander.

Es bildet ein zusammenhängendes System, durch das Vaelith fließt.

Einzelne Knoten dienen als Sammel-, Verteilungs- oder Regulierungspunkte.

Das Geflecht ist durch die historische Katastrophe beschädigt worden.

Einige Verbindungen sind unterbrochen, andere instabil. Manche Knoten sind versiegelt oder vollständig in Vergessenheit geraten.

Die Welt funktioniert weiterhin, allerdings nicht mehr unter optimalen Bedingungen.

## 4.4 Bewusstsein von Vaelith

**Konzeptvorschlag – noch nicht endgültig festgelegt:**

Vaelith könnte über eine ursprüngliche Form von Bewusstsein verfügen.

Nicht vergleichbar mit einem gewöhnlichen Lebewesen oder einer Gottheit.

Es handelt sich eher um eine grundlegende Intelligenz, die Veränderungen im Geflecht wahrnimmt und auf bestimmte Ereignisse reagiert.

Mögliche Auswirkungen:
- Reaktionen auf die Anwesenheit des Spielers.
- Veränderungen der sichtbaren Energieverbindungen.
- Wiederkehrende Symbole oder Erscheinungen.
- Resonanzen an besonderen Orten.
- Indirekte Kommunikation über Bilder, Erinnerungen oder Empfindungen.

Vaelith soll nicht einfach als Questgeber auftreten. Seine Kommunikation bleibt zunächst rätselhaft.

---

# 5. Der Spieler – Der Auserwählte

## 5.1 Seine Herkunft

Der Spieler ist das Ergebnis einer bewussten Verbindung zwischen zwei Völkern.

Sein Vater war ein freundlicher Herrscher der Unterwelt.

Seine Mutter stammte aus der Oberwelt.

Beide wussten um die Bedeutung ihrer Verbindung und verfolgten ein gemeinsames Ziel: ein Wesen hervorzubringen, das die Eigenschaften beider Zivilisationen in sich vereint.

Der Spieler sollte eines Tages in der Lage sein, die Verbindung zwischen den beiden Welten wiederherzustellen.

Seine Existenz ist kein Zufall, sondern Teil eines langfristigen Plans.

## 5.2 Seine besonderen Eigenschaften

Der Spieler vereint die natürlichen und magischen Eigenschaften beider Abstammungslinien.

| Unterwelt-Erbe | Oberwelt-Erbe |
|---|---|
| Technologische Resonanz | Natürliche Resonanz |
| Zugang zu alten Anlagen | Natürliche Magie |
| Energetisches Verständnis | Verbindung zum Geflecht |
| Besondere körperliche Eigenschaften | Anpassungsfähigkeit |
| Verständnis unterirdischer Systeme | Verbindung zur Oberfläche |

Die Kombination ermöglicht Fähigkeiten, die keinem gewöhnlichen Bewohner einer der beiden Welten zugänglich sind.

## 5.3 Seine eigentliche Aufgabe

Der Spieler soll:

1. Seine Herkunft entdecken.
2. Das Wissen seiner Vorfahren wiedererlangen.
3. Die Funktionsweise von Vaelith verstehen.
4. Seine besonderen Fähigkeiten entwickeln.
5. Die alten Anlagen und Knoten aktivieren.
6. Das beschädigte Geflecht wiederherstellen.
7. Die Verbindung zwischen beiden Zivilisationen ermöglichen.
8. Eine gemeinsame Zukunft vorbereiten.

Der Spieler soll nicht als Eroberer auftreten.

Seine Aufgabe ist es, die Voraussetzungen für eine friedliche Wiedervereinigung zu schaffen.

## 5.4 Die Mutter und das letzte Vermächtnis

Die Mutter kennt die Herkunft und die Bedeutung des Spielers.

Sie hat das Geheimnis jedoch über sein gesamtes bisheriges Leben bewahrt.

Erst auf ihrem Sterbebett gibt sie ihm den entscheidenden Hinweis, wo seine Suche beginnen soll.

Dies ist der eigentliche Beginn der Hauptgeschichte.

**Gameplay-Funktion:**
- Einführungsquest.
- Persönlicher Handlungsantrieb.
- Erste Begegnung mit der Familiengeschichte.
- Freischaltung der ersten Erkundungsaufgabe.
- Einführung in die Weltgeschichte.

---

# 6. Das Vermächtnis des Vaters

## 6.1 Die Hinterlassenschaften

Der Vater hat über die gesamte Welt hinweg Hinweise und vorbereitete Anlagen hinterlassen.

Diese Hinterlassenschaften wurden gezielt angelegt, um den Spieler auf seine Aufgabe vorzubereiten.

Sie befinden sich beispielsweise in:
- Ruinen.
- Tempeln.
- Höhlen.
- Alten Bibliotheken.
- Unterirdischen Anlagen.
- Vergessenen Städten.
- Transportstationen.
- Verborgenen Kammern.

## 6.2 Die alte Schrift

Die Hinterlassenschaften enthalten Inschriften, Runen und Symbole.

Andere Bewohner können diese Zeichen nicht oder nur teilweise verstehen.

Der Spieler besitzt aufgrund seiner Abstammung eine besondere Resonanz mit diesen Schriften.

Dadurch kann er bestimmte Inhalte unmittelbar verstehen.

Die Fähigkeit entwickelt sich im Verlauf der Geschichte.

## 6.3 Das Trainingsprogramm

Die Hinterlassenschaften sind nicht nur Informationsquellen.

Sie vermitteln dem Spieler schrittweise Fähigkeiten und Wissen.

| Entdeckung | Vermittelte Fähigkeit |
|---|---|
| Erste Inschriften | Erkennen alter Symbole |
| Erste Resonanzstätte | Wahrnehmung von Vaelith |
| Alte Mechanismen | Umgang mit Unterwelttechnologie |
| Verborgene Bibliotheken | Historisches Wissen |
| Prüfkammern | Kontrolle der eigenen Resonanz |
| Energieknoten | Beeinflussung des Geflechts |
| Alte Zentralanlagen | Wiederherstellung von Verbindungen |

## 6.4 Persönliche Botschaften

Der Vater könnte an ausgewählten Orten persönliche Aufzeichnungen hinterlassen haben.

Diese können enthalten:
- Erklärungen seiner Absichten.
- Erinnerungen an die Mutter.
- Hinweise zur Geschichte beider Völker.
- Warnungen vor bestimmten Anlagen.
- Informationen über die Katastrophe.
- Persönliche Gedanken über den Spieler.
- Erklärungen zu dessen eigentlicher Aufgabe.

Die Aufzeichnungen sollen nicht alle Geheimnisse sofort enthüllen.

Sie werden mit fortschreitender Geschichte zunehmend persönlicher und bedeutungsvoller.

---

# 7. Wahrnehmung und Entwicklung der besonderen Fähigkeiten

## 7.1 Das Sichtbarmachen des Geflechts

Der Spieler kann das Geflecht unter bestimmten Voraussetzungen wahrnehmen.

Diese Fähigkeit ist nicht von Anfang an vollständig verfügbar.

Sie entwickelt sich durch Level, Skills, besondere Quests und Resonanzstätten.

## 7.2 Vorgeschlagenes Entwicklungssystem

| Stufe | Fähigkeit | Gameplay-Auswirkung |
|---|---|---|
| 1 | Erste Wahrnehmung | Einzelne Lichtspuren erscheinen |
| 2 | Resonanz | Geflecht wird an besonderen Orten sichtbar |
| 3 | Knotenerkennung | Energieknoten können identifiziert werden |
| 4 | Analyse | Beschädigte Verbindungen werden erkennbar |
| 5 | Beeinflussung | Bestimmte Verbindungen können aktiviert werden |
| 6 | Stabilisierung | Beschädigte Knoten können repariert werden |
| 7 | Meisterschaft | Größere Netzwerkabschnitte können beeinflusst werden |

Die tatsächliche Anzahl der Stufen und die Freischaltbedingungen werden später im Gameplay-Konzept festgelegt.

## 7.3 Mögliche Spielfunktionen

- Besondere Sichtbarkeit magischer Strukturen.
- Aufspüren verborgener Gegenstände.
- Erkennen versteckter Eingänge.
- Auffinden besonderer Ressourcen.
- Analyse alter Anlagen.
- Aktivierung von Mechanismen.
- Erkennen instabiler Bereiche.
- Freischaltung besonderer Reisewege.
- Zugang zu geheimen Quests.

Die Wahrnehmung soll nicht dauerhaft aktiv sein müssen. Sie kann als gezielte Fähigkeit eingesetzt werden.

---

# 8. Das Transport- und Rekonstruktionsnetzwerk

## 8.1 Grundkonzept

Die Unterwelt verfügt über ein uraltes technologisches Netzwerk.

Dieses Netzwerk wurde ursprünglich für den Transport von Personen zwischen weit entfernten Städten entwickelt.

Es besteht aus verschiedenen Stationen, die miteinander verbunden sind.

Zusätzlich besitzt das System eine Funktion zur Speicherung und Rekonstruktion biologischer Signaturen.

## 8.2 Transportfunktion

**Gameplay-Funktion: Schnellreise**

- Aktivierung alter Transportstationen.
- Freischaltung neuer Reiseverbindungen.
- Verbindung zwischen Oberwelt und Unterwelt.
- Nutzung besonderer Reiseziele.
- Wiederherstellung stillgelegter Stationen.

Der Spieler kann aufgrund seiner Abstammung Stationen aktivieren, die anderen Bewohnern nicht zugänglich sind.

## 8.3 Rekonstruktionsfunktion

**Gameplay-Funktion: Respawn**

Das Netzwerk kann die biologische und energetische Signatur eines registrierten Benutzers speichern.

Bei Aktivierung einer Station wird ein gültiger Zustand hinterlegt.

Stirbt der Spieler, kann das System auf diesen Zustand zurückgreifen und ihn rekonstruieren.

Vorgeschlagener Ablauf:

1. Spieler aktiviert eine Registrierungsstation.
2. Das Netzwerk erfasst seine Signatur.
3. Der aktuelle Zustand wird gespeichert.
4. Bei seinem Tod wird die letzte gültige Signatur verwendet.
5. Eine registrierte Station rekonstruiert den Spieler.

Diese Funktion liefert eine Lore-Erklärung für Tod, Wiederkehr und Speicherpunkte.

**Wichtige offene Designfrage:** Die technischen Details müssen später mit dem tatsächlichen Savegame-, Respawn- und Inventarsystem abgestimmt werden.

---

# 9. Die Reaktionen der NPCs

## 9.1 Grundprinzip

Nicht jeder NPC erkennt die besondere Bedeutung des Spielers.

Die Reaktion hängt vom Wissen, der Herkunft, der persönlichen Einstellung und den Erfahrungen des jeweiligen NPCs ab.

Der Spieler wird nicht grundsätzlich als Held behandelt.

## 9.2 NPC-Kategorien

| NPC-Typ | Mögliche Reaktion |
|---|---|
| Gewöhnliche Bewohner | Normale Gespräche |
| Wissende | Erkennen bestimmte Merkmale |
| Gelehrte | Interesse und Nachfragen |
| Eingeweihte | Erkennen die Bedeutung seiner Herkunft |
| Alte Traditionen | Hoffnung und Anerkennung |
| Skeptiker | Zweifel und Misstrauen |
| Konservative | Ablehnung der Veränderung |
| Gegner | Wahrnehmung als Bedrohung |

## 9.3 Dialogsystem

NPCs können abhängig von ihrem Wissensstand unterschiedliche Dialogvarianten besitzen.

Beispiele:

**Gewöhnlicher Bewohner:**

„Guten Morgen! Wenn Ihr zum Markt wollt, nehmt lieber den Weg am Fluss.“

**Wissende Bewohnerin:**

„Wartet ... dieses Zeichen. Wo habt Ihr das gesehen?“

**Gelehrter:**

„Ich hielt diese Schriften für Legenden. Aber Ihr könnt sie tatsächlich lesen?“

**Eingeweihter:**

„Es ist also wahr. Einer der alten Blutlinie ist zurückgekehrt.“

**Skeptischer Bewohner:**

„Nur weil Ihr ein paar alte Runen lesen könnt, bedeutet das noch lange nicht, dass Ihr uns führen solltet.“

## 9.4 Benötigte Spielfunktionen

- NPC-Wissenssystem.
- Questfortschritt als Dialogbedingung.
- Spielerfähigkeiten als Dialogbedingung.
- Fraktionszugehörigkeit.
- Beziehungs- und Vertrauenswerte.
- Unterschiedliche Dialogzustände.
- Bedingte Questfreischaltung.

Die Anerkennung durch NPCs soll nicht nur kosmetisch sein. Sie kann neue Informationen, Aufgaben, Zugänge und Möglichkeiten eröffnen.

---

# 10. Die Hauptgeschichte und ihre Queststruktur

## 10.1 Akt I – Das Vermächtnis

**Ziel:** Den Spieler in die Welt einführen und seine persönliche Geschichte beginnen.

Inhalte:
- Start in einer friedlichen Heimatregion.
- Einführung in die örtliche Bevölkerung.
- Erste alltägliche Aufgaben.
- Tod beziehungsweise Abschied von der Mutter.
- Letzter Hinweis auf die Herkunft.
- Suche nach der ersten Hinterlassenschaft.

Mögliche Aufgaben:
- Besuche einen bestimmten Ort.
- Finde eine alte Inschrift.
- Untersuche ein vergessenes Bauwerk.
- Aktiviere einen ersten Mechanismus.

Belohnungen:
- Erfahrungspunkte.
- Erste besondere Fähigkeit.
- Zugang zu weiteren Hinweisen.
- Freischaltung der persönlichen Hauptgeschichte.

## 10.2 Akt II – Die vergessene Vergangenheit

**Ziel:** Die Geschichte der alten Zivilisationen entdecken.

Inhalte:
- Erkundung alter Ruinen.
- Entdeckung der alten Schrift.
- Erste Resonanzerscheinungen.
- Hinweise auf die Unterwelt.
- Persönliche Aufzeichnungen des Vaters.

Mögliche Aufgaben:
- Sammle Fragmente alter Aufzeichnungen.
- Entschlüssele Inschriften.
- Finde eine verborgene Kammer.
- Löse alte Mechanismen.
- Untersuche eine verlassene Anlage.

Belohnungen:
- Neue Wahrnehmungsfähigkeiten.
- Historische Informationen.
- Besondere Gegenstände.
- Zugang zu neuen Gebieten.

## 10.3 Akt III – Die verborgene Welt

**Ziel:** Die Unterwelt entdecken.

Inhalte:
- Erstmaliger Zugang zur Unterwelt.
- Begegnung mit deren Bewohnern.
- Entdeckung freundlicher Siedlungen.
- Erste Händler und Questgeber.
- Erkennung der besonderen Abstammung durch einzelne Bewohner.

Mögliche Aufgaben:
- Erkunde eine unterirdische Siedlung.
- Hilf einem Händler.
- Repariere eine alte Anlage.
- Suche nach dem Erbe des Vaters.
- Erlange Zugang zu einer vergessenen Station.

Belohnungen:
- Neue Handelsmöglichkeiten.
- Zugang zu Unterweltressourcen.
- Neue Rezepte und Technologien.
- Neue Reiseverbindungen.

## 10.4 Akt IV – Vaelith erwacht

**Ziel:** Das magische Netzwerk verstehen.

Inhalte:
- Erste umfassende Wahrnehmung des Geflechts.
- Entdeckung beschädigter Knoten.
- Untersuchung der ursprünglichen Katastrophe.
- Erkenntnis über die Zusammenhänge beider Welten.

Mögliche Aufgaben:
- Identifiziere beschädigte Knoten.
- Untersuche alte Resonanzstätten.
- Aktiviere vergessene Mechanismen.
- Stelle einzelne Verbindungen wieder her.
- Sammle Wissen über die ursprüngliche Energiequelle.

Belohnungen:
- Erweiterte Resonanzfähigkeiten.
- Zugang zu besonderen Anlagen.
- Neue Handwerks- und Herstellungsmöglichkeiten.
- Fortschritt im Hauptquestbogen.

## 10.5 Akt V – Die Wiederverbindung

**Ziel:** Die beiden Zivilisationen wieder zusammenführen.

Inhalte:
- Diplomatische Begegnungen.
- Wiederherstellung alter Handelswege.
- Gemeinsame Projekte.
- Politische Entscheidungen.
- Stabilisierung wichtiger Knoten.

Mögliche Aufgaben:
- Überzeuge bestimmte Herrscher.
- Unterstütze regionale Gemeinschaften.
- Ermögliche den Austausch von Ressourcen.
- Baue Verbindungen zwischen Siedlungen auf.
- Stabilisiere wichtige Abschnitte des Geflechts.

Belohnungen:
- Neue Handelsrouten.
- Regionale Entwicklungen.
- Neue Technologien.
- Neue Bau- und Produktionsmöglichkeiten.
- Veränderungen der Welt.

## 10.6 Akt VI – Das Vermächtnis

**Ziel:** Die Zukunft beider Welten gestalten.

Inhalte:
- Vollständige Enthüllung des Plans des Vaters.
- Verständnis der ursprünglichen Katastrophe.
- Wiederherstellung zentraler Netzwerkbereiche.
- Entscheidung über die zukünftige Zusammenarbeit.

Die langfristige Entwicklung soll offen bleiben.

Die Vereinigung ist nicht das Ende aller Konflikte. Sie ist der Beginn einer neuen Epoche.

---

# 11. Nebenquests und zusätzliche Questtypen

Neben der Hauptgeschichte benötigt Emberwild ein umfangreiches Netz unabhängiger Geschichten.

| Questtyp | Zweck | Mögliche Belohnung |
|---|---|---|
| Lokale Quests | Geschichten einzelner Bewohner | Erfahrung, Geld, Gegenstände |
| Entdeckungsquests | Erkundung der Welt | Wissen, Artefakte |
| Ruinenquests | Alte Anlagen untersuchen | Technologien, Rezepte |
| Fraktionsquests | Beziehungen verbessern | Ruf, Zugänge |
| Handelsquests | Waren und Ressourcen transportieren | Geld, Handelsvorteile |
| Handwerksquests | Produktion und Herstellung | Rezepte, Materialien |
| Gildenquests | Gemeinschaftliche Aufgaben | Gildenfortschritt |
| Provinzquests | Regionale Entwicklungen | Einfluss, Ressourcen |
| Resonanzquests | Vaelith untersuchen | Fähigkeiten, Resonanzwissen |
| Dynamische Ereignisse | Zeit- oder zustandsabhängige Aufgaben | Variable Belohnungen |
| Langzeitquests | Mehrstufige Handlungsstränge | Besondere Freischaltungen |

## 11.1 Besondere Questidee: Gemeinsame Entdeckungen

Einzelne Spieler können unterschiedliche Hinweise entdecken.

Diese Informationen können später zusammengeführt werden.

Beispiel:

- Ein Spieler entdeckt eine alte Inschrift.
- Ein anderer findet einen passenden Gegenstand.
- Ein dritter aktiviert eine Resonanzstätte.
- Gemeinsam wird ein neuer Zusammenhang sichtbar.

Das bietet Möglichkeiten für kooperative Quests und serverweite Ereignisse.

---

# 12. Fraktionen, Gilden und Provinzen

Die Lore soll das bestehende territoriale und gesellschaftliche Gameplay ergänzen.

## 12.1 Fraktionen

Beide Welten besitzen unterschiedliche Gruppierungen.

Mögliche Interessengruppen:

- Händler und Handelsgemeinschaften.
- Gelehrte und Forscher.
- Technologische Gemeinschaften.
- Traditionelle und konservative Gruppen.
- Magische Orden.
- Regionale Herrschaftshäuser.
- Unabhängige Siedlungen.

Diese Gruppierungen besitzen unterschiedliche Vorstellungen darüber, wie die Zukunft aussehen sollte.

## 12.2 Gilden und Clans

Gilden können eine wichtige Rolle bei der Wiederverbindung der Welten spielen.

Mögliche Aktivitäten:
- Ressourcen bereitstellen.
- Handelsrouten sichern.
- Anlagen wiederherstellen.
- Provinzen entwickeln.
- Gemeinsame Bauprojekte finanzieren.
- Regionale Ereignisse unterstützen.

## 12.3 Provinzen

Die Provinzen können unterschiedliche Ressourcen und historische Hinterlassenschaften besitzen.

Mögliche langfristige Auswirkungen der Hauptgeschichte:

- Neue Handelsverbindungen.
- Neue Rohstoffquellen.
- Technologische Erweiterungen.
- Wiederhergestellte Anlagen.
- Veränderungen regionaler Ressourcenverfügbarkeit.
- Neue Questgeber und Siedlungen.

---

# 13. Weltveränderungen und Konsequenzen

Die Geschichte sollte nicht nur aus abgeschlossenen Aufgaben bestehen.

Bestimmte Quests sollen die Welt dauerhaft verändern.

Mögliche Weltzustände:

| Zustand | Auswirkung |
|---|---|
| Knoten entdeckt | Neue Informationen und Aufgaben |
| Knoten aktiviert | Neue Resonanzmöglichkeiten |
| Knoten stabilisiert | Regionale Veränderungen |
| Transportstation repariert | Neue Reiseverbindung |
| Handelsweg eröffnet | Neue Waren und Ressourcen |
| Diplomatische Verbindung hergestellt | Neue NPCs und Quests |
| Anlage wiederhergestellt | Neue Technologien |
| Region entwickelt | Neue Siedlungs- und Produktionsmöglichkeiten |

Dabei sollten wichtige Weltveränderungen serverweit nachvollziehbar sein.

Persönliche Questfortschritte und gemeinsame Weltzustände müssen technisch sauber voneinander getrennt werden.

---

# 14. Belohnungssystem

Belohnungen sollen nicht ausschließlich aus Erfahrungspunkten und Ausrüstung bestehen.

Die Geschichte bietet die Möglichkeit, Wissen und Zugang als echte Belohnung einzusetzen.

## 14.1 Belohnungskategorien

**Persönliche Belohnungen**
- Erfahrungspunkte.
- Fähigkeiten.
- Neue Resonanzstufen.
- Persönliche Ausrüstung.
- Besondere Titel.

**Wissensbelohnungen**
- Historische Aufzeichnungen.
- Neue Schriftkenntnisse.
- Technologien.
- Herstellungsrezepte.
- Zugang zu Bibliotheken.

**Weltbelohnungen**
- Freigeschaltete Regionen.
- Wiederhergestellte Transportstationen.
- Neue Handelsverbindungen.
- Neue Ressourcen.
- Neue NPCs.

**Gemeinschaftliche Belohnungen**
- Gildenfortschritt.
- Regionale Verbesserungen.
- Gemeinsame Bauprojekte.
- Neue Produktionsmöglichkeiten.
- Serverweite Ereignisse.

---

# 15. Technische und spielmechanische Anforderungen

Die folgenden Systeme werden benötigt oder sollten bei der Entwicklung berücksichtigt werden.

| System | Funktion | Priorität |
|---|---|---|
| Questmanager | Verwaltung aller Questtypen | Sehr hoch |
| Questzustände | Fortschritt und Abschluss | Sehr hoch |
| Dialogsystem | Bedingte NPC-Dialoge | Sehr hoch |
| NPC-Wissenssystem | Erkennung des Spielers | Hoch |
| Skill-System | Entwicklung der Resonanz | Hoch |
| Wahrnehmungssystem | Sichtbarkeit des Geflechts | Hoch |
| Weltzustandssystem | Dauerhafte Veränderungen | Sehr hoch |
| Interaktionssystem | Alte Mechanismen aktivieren | Hoch |
| Transportnetzwerk | Schnellreise | Hoch |
| Respawn-Erklärung | Rekonstruktion durch alte Technologie | Hoch |
| Fraktionssystem | Beziehungen und Ruf | Hoch |
| Handelsintegration | Ressourcen zwischen Welten | Mittel |
| Sammlungs-/Archivsystem | Historische Hinweise speichern | Hoch |
| Ereignissystem | Dynamische Ereignisse | Mittel |
| Mehrspieler-Questzustände | Gemeinsamer Fortschritt | Sehr hoch |

## 15.1 Questdaten

Jede Quest sollte mindestens folgende Informationen besitzen:

- Eindeutige Quest-ID.
- Titel und Beschreibung.
- Questtyp.
- Zugehöriger Handlungsstrang.
- Startbedingungen.
- Voraussetzungen.
- Aufgaben und Teilaufgaben.
- NPC- und Ortsreferenzen.
- Benötigte Fähigkeiten.
- Abhängigkeiten zu anderen Quests.
- Belohnungen.
- Weltzustandsänderungen.
- Dialogvarianten.
- Abschlussbedingungen.
- Optionale Aufgaben.

## 15.2 Trennung persönlicher und gemeinsamer Fortschritte

**Persönlicher Fortschritt:**
- Herkunftsentdeckung.
- Fähigkeiten.
- Eigene Aufzeichnungen.
- Persönliche Hauptquest.
- Individuelle NPC-Beziehungen.

**Gemeinsamer Fortschritt:**
- Wiederhergestellte Anlagen.
- Serverweite Handelsrouten.
- Regionale Entwicklungen.
- Gemeinschaftliche Projekte.
- Weltweite Ereignisse.

Diese Trennung ist besonders wichtig, damit ein Multiplayer-Spieler nicht durch den Fortschritt anderer Spieler seine persönliche Geschichte verliert.

---

# 16. Offene Lore-Entscheidungen

Die folgenden Punkte sind noch nicht endgültig festgelegt und müssen gemeinsam ausgearbeitet werden.

| Thema | Offene Frage |
|---|---|
| Vaelith | Wie genau äußert sich sein ursprüngliches Bewusstsein? |
| Energiequelle | Ist Vaelith selbst die Energiequelle oder gibt es einen zentralen Ursprung? |
| Katastrophe | Welches konkrete Experiment löste sie aus? |
| Geflecht | Wie viele zentrale Knoten existieren? |
| Vater | Wie umfangreich ist sein ursprüngliches Vermächtnis? |
| Mutter | Wie verlief ihre gemeinsame Geschichte mit dem Vater? |
| Spieler | Welche besonderen körperlichen und magischen Eigenschaften besitzt er? |
| Unterwelt | Wie viele Völker und Kulturen existieren dort? |
| Herrscher | Wer regiert die Unterwelt in der Gegenwart? |
| Oberwelt | Welche Königreiche und politischen Strukturen existieren? |
| Wiedervereinigung | Wie reagieren die einzelnen Gesellschaften darauf? |
| Endgame | Wie entwickelt sich Emberwild nach der Hauptgeschichte weiter? |

---

# 17. Zentrale Designregeln für zukünftige Inhalte

Alle zukünftigen Lore-, Quest- und Gameplay-Inhalte sollten folgende Regeln berücksichtigen:

1. **Keine zufällige Auserwähltenrolle:** Die besondere Existenz des Spielers muss nachvollziehbar in die Weltgeschichte eingebettet sein.

2. **Keine sofortige Enthüllung:** Herkunft, Auftrag und Fähigkeiten werden schrittweise entdeckt.

3. **Die Welt erzählt selbst:** Ruinen, Architektur, Runen, Gegenstände und Umgebungen sind wichtige Geschichtenerzähler.

4. **NPCs besitzen eigene Meinungen:** Nicht jeder erkennt oder akzeptiert die Bedeutung des Spielers.

5. **Beide Welten sind eigenständig:** Keine Seite ist grundsätzlich gut oder böse.

6. **Keine künstliche Feindschaft:** Angst, Misstrauen, Unsicherheit und unterschiedliche Interessen bilden die Konflikte.

7. **Gameplay und Lore gehören zusammen:** Jede wichtige Spielfunktion soll eine nachvollziehbare Erklärung innerhalb der Welt besitzen.

8. **Fortschritt soll sichtbar sein:** Entdeckungen und abgeschlossene Quests können die Welt verändern.

9. **Die Geschichte bleibt langfristig erweiterbar:** Die Wiedervereinigung ist kein endgültiger Abschluss aller Konflikte.

10. **Die Heimat bleibt bedeutsam:** Die friedliche Ausgangsregion bildet den emotionalen Bezugspunkt der Geschichte.

---

# 18. Zusammenfassung – Emberwilds zentrale Geschichte

Zwei Zivilisationen, eine gemeinsame Vergangenheit und eine Katastrophe, die das natürliche Gleichgewicht der Welt zerstörte.

Die Oberwelt und die Unterwelt trennten sich, um ihre Bewohner zu schützen. Über Jahrhunderte verschwanden Wissen, Technologien und historische Zusammenhänge.

Doch das magische Netzwerk Vaelith blieb beschädigt zurück.

Ein Herrscher der Unterwelt erkannte, dass beide Zivilisationen langfristig nur gemeinsam eine Zukunft haben würden. Er verband seine Blutlinie mit einer Frau der Oberwelt, um ein Wesen hervorzubringen, das die natürlichen und magischen Eigenschaften beider Völker vereint.

Dieses Wesen ist der Spieler.

Sein Vater hinterließ über die gesamte Welt hinweg Bauwerke, Runen, Inschriften und verborgene Anlagen, die den Spieler auf seine Aufgabe vorbereiten sollten.

Seine Mutter bewahrte das Geheimnis bis zu ihrem Tod und gab ihm den entscheidenden Hinweis, mit dem seine Reise beginnt.

Im Laufe seiner Abenteuer entdeckt der Spieler seine Herkunft, die vergessene Geschichte beider Zivilisationen und das weltumspannende Geflecht Vaelith.

Er lernt, dessen Energie wahrzunehmen, alte Knoten zu aktivieren und beschädigte Verbindungen wiederherzustellen.

Seine eigentliche Aufgabe ist es, die beiden Welten wieder miteinander zu verbinden und eine gemeinsame Zukunft zu ermöglichen.

**Er wurde nicht geboren, um eine Welt zu retten, indem er die andere zerstört. Er wurde geboren, um beiden Welten wieder eine Zukunft zu geben.**

---

*Ende des Grundkonzepts – Version 0.1*

*Dieses Dokument dient als zentrale Referenz für die weitere Ausarbeitung der Emberwild-Lore, der Hauptgeschichte, des Questsystems und der damit verbundenen Gameplay-Systeme.*
# 🗺️ 04. WELTKARTE, EXPANSION & RESSOURCENKREISLAUF

> **Konzept & Spieldesign:** Aktives 3D-Farming, Provinzen als Rohstoff-Monopole, Außenposten-Eroberung, Reittiere & Transportlogistik in *Emberwild*.

---

## 1. Die Philosophie: Warum die Weltkarte bereisen?

In vielen RPGs wird die Weltkarte nach dem ersten Entdecken durch Schnellreise entwertet, oder Ressourcen sind überall gleichförmig verteilt. In *Emberwild* gilt:

> **„Keine Burg überlebt aus eigener Kraft. Wer Reichtum, Meisterwaffen und mächtige Befestigungen will, muss in die gefährliche Wildnis hinausreiten, Ressourcen erobern und Karawanen heimführen.“**

---

## 2. Aktives 3D-Ernten & Sammeln (Haptik & Physik)

Ressourcen werden nicht mehr in passiven Menüs „produziert“, sondern vom Spieler aktiv in der 3D-Welt geschlagen, geschürft und gepflückt.

```
       [BAUM / ERZADER]  ◄──  [SPIELER MIT SPITZHACKE/AXT]
             │
       [Hit-Reaction] ──> Partikel-Splitter + Erschütterungs-Sound
             │
       [Schwächepunkt] ──> Treffer auf leuchtende Bruchstelle = 2x Schaden
             │
       [Fällen / Bruch] ──> Physikalische Baumstamm-Animation / Erz-Splitterung
             │
       [Loot-Drops] ──> 3D-Objekte rollen am Boden (z. B. 4x Eichenstamm, 2x Harz)
```

### 2.1 Die vier aktiven Ernte-Disziplinen:

| Ressource | Werkzeug | 3D-Interaktion | Beute-Varianz & Seltenheit |
| :--- | :--- | :--- | :--- |
| **Holzfällen** | Holzfälleraxt (Kupfer, Eisen, Gehärtet) | Schläge auf Baumstamm mit sichtbaren Kerben. Baum fällt physikalisch um und zerbricht in 3-5 aufnehmbare Stämme. | Weichholz, Kernholz, Uraltes Eichenholz, Bernstein, Baumharz. |
| **Bergbau** | Spitzhacke | Anschlagen von Erzadern an Felswänden. Dynamische Leuchtpunkte (Sweet-Spots) für kritische Treffer. | Bruchstein, Eisenerz, Silbererz, Schwefelkristalle, Obsidian, Rohdiamanten. |
| **Kräuterkunde** | Sichel / Hand | Interaktion `[E]` an leuchtender Flora im Gras. Kurze Erntegeste, kein Werkzeugverschleiß. | Glutblüte, Nachtschatten, Frostwurz, Schilffasern, Bienenwaben. |
| **Jagd & Kürschnerei** | Jagdmesser | Erlegen von Wildtieren (Hirsche, Wildschweine, Bären, Wölfe) + Abhäuten mit Messer. | Rohes Wildbret, Sehnen, Rehkitz-Leder, Wolfsfell, Bärenkrallen, Trophäenknochen. |

---

## 3. Provinzen als Rohstoff-Monopole (Geografische Spezialisierung)

Jede Region der Spielwelt besitzt eine einzigartige geologische und ökologische Identität. Keine Region bietet alles:

```
                          ┌────────────────────────┐
                          │   FROSTSPIERE (NORD)   │
                          │   • Mithril-Erz        │
                          │   • Frostholz          │
                          │   • Weiße Bärenpelze   │
                          └───────────┬────────────┘
                                      │
         ┌────────────────────────────┼────────────────────────────┐
         │                            │                            │
┌────────┴───────────┐      ┌─────────┴──────────┐      ┌──────────┴─────────┐
│ DÜSTERMOOR (WEST)  │      │ EMBERWATCH (MITTE) │      │  FLÜSTERNDE KATAK. │
│ • Eisenholz        │ ◄──► │ • Weizen & Nahrung │ ◄──► │ • Silbererz        │
│ • Sumpf-Torf       │      │ • Standard-Kupfer  │      │ • Grabwurz         │
│ • Egel & Gifte     │      │ • Ziegel-Lehm      │      │ • Seelen-Fragmente │
└────────────────────┘      └─────────┬──────────┘      └────────────────────┘
                                      │
                          ┌───────────┴────────────┐
                          │   ASCHÖDLAND (SÜD)     │
                          │   • Schwefel & Salpeter│
                          │   • Basalt-Werkstein   │
                          │   • Glutdrüsen         │
                          └────────────────────────┘
```

### 3.1 Gameplay-Konsequenz:
- Wer Mauern aus unzerstörbarem **Basalt** bauen will, muss Expeditionen ins Aschödland wagen.
- Wer Meister-Zweihänder und Paladinschilde schmieden will, braucht **Silber** aus den Flüsternden Katakomben.
- Dies zwingt Spieler und Gilden, Außenposten zu gründen oder Handelsabkommen zu schließen.

---

## 4. Eroberung von Außenposten & Territorial-Kontrolle

In jeder Provinz existieren neutrale oder von Banditen besetzte Stützpunkte:
- **Alte Steinbrüche** (erhöhen Steinertrag um 300%)
- **Verlassene Minenschächte** (Zugang zu seltenen Tiefenerzen)
- **Fluss-Mühlen** (Verdoppeln die Mehl- und Brotproduktion)

### 4.1 Der Ablauf einer Übernahme (Camp-Liberation):
1. **Kundschaften:** Der Spieler späht das Banditenlager aus (3 Wachen, 1 Scharfschütze auf dem Turm, 1 Hauptmann).
2. **Kampf:** Aktive Säuberung des Lagers im 3D-ARPG-Kampfsystem.
3. **Fahne hissen:** Nach dem Sieg interagiert der Spieler mit dem zentralen Flaggenmast und hisst das eigene Banner.
4. **Befestigung:** Der Außenposten wird zur sicheren Zone. Der Spieler kann nun 2 Palisaden, ein Schlaflager und eine Werkbank errichten.
5. **NPC-Arbeiter zuweisen:** 2 Dorfbewohner aus den Grauen Feldern können als Knappen entsandt werden, um die Mine automatisch im Hintergrund zu betreiben.

---

## 5. Reittiere, Packtiere & Karawanenlogistik

Da wertvolle Erze und schwere Eichenbalken hohes Inventargewicht besitzen, kann der Spieler nicht 500 Basaltsteine zu Fuß tragen.

### 5.1 Transportmittel-Stufen:

1. **Handkarren (Stufe I):**
   - Wird vom Spieler hinterhergezogen (reduzierte Laufgeschwindigkeit um 20%).
   - Bietet 12 Inventarplätze für Baumaterialien.
2. **Gepanzertes Lastpferd / Maultier (Stufe II):**
   - Folgt dem Spieler oder wird geritten.
   - Trägt bis zu 24 schwere Güter. Kann im Kampf fliehen oder von Wölfen angegriffen werden.
3. **Gilden-Ochsenkarren (Stufe III):**
   - Großtransport für Baukampagnen (60 Slots).
   - Benötigt einen Kutscher (NPC oder Spieler) und Begleitschutz.

### 5.2 Das Karawanen-Event (Action auf den Straßen):
Wenn eine Karawane schwere Fracht von einem Steinbruch nach Emberwatch transportiert, besteht auf der Route eine 35%-Wahrscheinlichkeit für einen **Hinterhalt**:
- Banditen blockieren die Straße mit brennenden Barrikaden.
- Der Spieler muss das Packpferd verteidigen, bevor die Räuber die Satteltaschen aufschlitzen und die Beute stehlen.
- **Resultat:** Reisen bleibt stets nervenaufreibend, spannend und lebendig!

---

## 6. Synergie mit dem Bausystem
- **Lokaler Bauvorrat:** Das Dorf kann nur wachsen, wenn der Nachschub an Spezialholz und Stein gesichert ist.
- **Sichtbare Lager:** Im Dorf stapeln sich die herangeschafften Baumstämme und Steinblöcke optisch sichtbar auf Holzlagerplätzen und Steinhaufen.
- **Stolz des Spielers:** Jedes fertige Gebäude zeugt von echten Abenteuern, überstandenen Expeditionen und siegreichen Kämpfen in fernen Landen.


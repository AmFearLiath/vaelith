# 🛡️ 03. MULTIPLAYER, GILDEN & TERRITORIEN

> **Konzept & Architektur:** Territoriale Souveränität, kooperatives Bauen, Gildenstrukturen und faires PvP ohne Grieving in der persistierenden Welt von *Emberwild*.

---

## 1. Die Kernproblematik in Multiplayer-Sandboxen

Multiplayer-Bausysteme (wie aus *Rust*, *Valheim* oder *Conan Exiles* bekannt) stehen vor zwei großen Risiken:
1. **Grieving & Landschaftszerstörung:** Spieler bauen willkürlich Wände vor Dungeons, blockieren Wege, spamen Strohhütten oder reißen fremde Werke in Abwesenheit der Besitzer komplett ein (Offline-Raiding).
2. **Identitätsverlust:** Wenn jeder überall alles bauen darf, verliert die Welt ihren architektonischen Zusammenhalt und wirkt wie ein chaotischer Müllplatz.

**Emberwild löst dies durch das „Glutstein-Territorien-Modell“ (Hearth & Ward Architecture).**

---

## 2. Der Glutstein (Village Ward-Stone & Claim-Radius)

Jede Siedlung und jedes beanspruchte Dorf außerhalb von Emberwatch wird von einem **Glutstein-Monument** beherrscht.

```
       ┌────────────────────────────────────────────────────────┐
       │             GRÜNE ZONE: GESCHÜTZTER WEILER             │
       │                                                        │
       │         [Wohnhaus]              [Schmiede]             │
       │                       ▲                                │
       │                       │ Radius: 45m                    │
       │        [Brunnen] ◄── [GLUTSTEIN] ──► [Kräutergarten]   │
       │                       │                                │
       │                       ▼                                │
       │                 [Palisadentor]                         │
       └────────────────────────────────────────────────────────┘
                 │                                    │
                 ▼                                    ▼
       ROTE ZONE: WILDNIS                  FREMDE PROVINZ / FEIND
  (Wildtiere, freies Sammeln,         (Bauverbot ohne Kriegserklärung,
     keine festen Häuser)                  kein Grieving möglich)
```

### 2.1 Regeln des Glutsteins:
1. **Der Schutzradius:**
   - Ein neu gesetzter Glutstein (Kosten: 50 Bruchstein, 10 Glutkerne, 1 Banner) spannt eine Schutzzone von **45 Metern Radius** auf.
   - Innerhalb dieses Radius dürfen **nur Gildenmitglieder** bzw. autorisierte Spieler Gebäude platzieren, abreißen oder modifizieren.
2. **Kollisionsgrenzen zwischen Gilden:**
   - Ein neuer Glutstein darf nicht näher als **150 Meter** an einen bestehenden feindlichen Glutstein gesetzt werden. Dadurch entstehen natürliche Pufferzonen, Straßen und Handelskorridore.
3. **Territoriale Glut-Erhaltung (Upkeep):**
   - Der Stein benötigt wöchentlich eine geringe Menge Brennstoff (z. B. 20 Glutkerne oder 50 Hartholz).
   - Fällt der Glutstein trocken, erlischt der Schutzschild: Gebäude können nach 72 Stunden Verfall von anderen Spielern recycled oder abgerissen werden. Dies verhindert Geisterstädte inaktiver Spieler.

---

## 3. Das Gilden- & Rangsystem

Um kooperatives Bauen im Team zu ermöglichen, ohne dass ein Troll-Mitglied die Burg über Nacht niederreißt, greift eine fünfstufige Rechtematrix:

### 3.1 Rollen und Berechtigungen

| Rang | Titel | Baurechte | Lagertruhen | Diplomatie / Territorium |
| :--- | :--- | :--- | :--- | :--- |
| **5** | **Gildenmeister / Burggraf** | Vollzugriff (Bauen, Abreißen, Glutstein-Upgrade) | Öffnen, Entnehmen, Tresorverwaltung | Kriegserklärung, Bündnisse, Glutstein setzen/löschen |
| **4** | **Baumeister (Architekt)** | Bauen, Upgraden, Umsetzen aller Strukturen | Handwerkskisten & Materiallager | Baustellen markieren, Monumente starten |
| **3** | **Wächter (Ritter/Offizier)** | Geschütztürme bedienen, Tore verriegeln | Waffenkammer & Tränkelager | Wachtruppen einteilen, Verteidigung aktivieren |
| **2** | **Handwerker (Geselle)** | Bauen nur in zugewiesenen Parzellen | Normale Handwerkskisten | Ressourcen spenden, Bauhämmer nutzen |
| **1** | **Rekrut (Knappe)** | Kein Baurecht | Nur persönliche Spielertruhe | Sammeln & Resourcen in Baukisten abwerfen |

### 3.2 Kooperatives Bauen („Baufonds & Baustellen-Geister“)
- Ein Baumeister platziert eine Gebäudebaustelle (z. B. ein großes Stein-Langhaus).
- Die Baustelle erscheint als Holzgerüst mit sichtbarer Materialliste:
  - `[0 / 120] Behauener Stein`
  - `[0 / 80] Eichenbalken`
  - `[0 / 40] Dachschindeln`
- **Jedes Gildenmitglied** (selbst Rekruten) kann herantreten, `[E]` drücken und mitgebrachte Materialien einzahlen.
- Sobald alle Materialien im Bauplatz liegen, können mehrere Spieler gleichzeitig mit dem Bauhammer zuschlagen – die Bauzeit verkürzt sich proportional zur Anzahl der Hämmernden!

---

## 4. Monumentale Gilden-Großprojekte

Einzelne Spieler errichten Fischerhütten und Palisaden. Gilden hingegen schalten **Welt-Monumente** frei, die signifikante strategische Vorteile auf der Weltkarte gewähren:

### 4.1 Die Monument-Blaupausen

1. **Die Hohe Wehrbrücke (Brückenbau über Schluchten):**
   - Verbindet unüberwindbare Schluchten oder Flussläufe auf der Weltkarte.
   - Verkürzt die Reisedauer von Karawanen und Helden um bis zu 80%.
   - Zölle: Die erbauende Gilde kann Wegzoll von fremden Händlern verlangen oder die Brücke mit Zugtoren abriegeln.
2. **Die Kathedrale des Lichts (Zitadellen-Wunder):**
   - Gigantisches Sakralbauwerk im Innenhof der Burg.
   - Gewährt allen Mitgliedern beim Ausritt den Segen *„Eiserner Glaube“* (+15% Rüstung, +20% Glut-Resistenz gegen Schattenkreaturen).
3. **Der Leuchtturm der Wachsamkeit (Wachturm Stufe IV):**
   - Deckt den Kriegsnebel (Fog of War) in einem Radius von 2 Provinzen auf.
   - Warnt die Gilde 15 Minuten im Voraus vor nahenden Banditen-Invasionen oder gegnerischen Karawanen.

---

## 5. Banner-Branding & Visuelle Clan-Identität

Jede Gilde konfiguriert im Heroldsamt ihr eigenes Wappen:
- **Wappenform:** Schildform (Gothic, Spanisch, Dreieckig, Bannerflaggge).
- **Farben:** Primär- und Sekundärfarbe (z. B. Aschgrau & Glutrot).
- **Symbole:** Wölfe, Schwerter, Eichenlaub, Schädel, Ambosse, Drachenschwingen.

### 5.1 Dynamische Anwendung in der 3D-Welt:
- **Burgtore & Wachtürme:** Beim Errichten generiert Three.js automatisch gerenderte Canvas-Banner mit dem Gildenwappen auf den Flaggenmasten.
- **Wachsoldaten & NPCs:** Die rekrutierten Wachen tragen Waffenröcke in den Farben der Gilde.
- **Gebietsgrenzen:** Entlang der Straßen werden automatisch kleine Wappen-Grenzpfähle generiert, wenn ein Reisender das Einflussgebiet der Gilde betritt (*„Ihr betretet das Territorium der Aschwölfe“*).

---

## 6. Faires PvP & Belagerungs-Philosophie (Anti-Grieving)

In vielen Spielen führt PvP dazu, dass monatelang erbaute Festungen zerstört werden, während die Spieler schlafen. In *Emberwild* gilt ein modernes, faires Belagerungskonzept:

1. **Kein Offline-Raiding:**
   - Ein feindlicher Außenposten kann nur belagert werden, wenn mindestens 30% der verteidigenden Gildenmitglieder online sind oder ein festes **Belagerungsfenster** (z. B. Samstag 19:00 - 21:00 Uhr) aktiv ist.
2. **Beschädigung statt Totalzerstörung:**
   - Belagerungswaffen (Rammböcke, Katapulte) zerstören Tore und Mauern **symbolisch in Trümmerhaufen** (`isBreached = true`), aber sie löschen die Struktur nicht aus der Datenbank.
   - Nach einer Schlacht können die Eigentümer beschädigte Mauern für 25% der ursprünglichen Baukosten reparieren, ohne das Gebäude neu entwerfen zu müssen.
3. **Der Beutezug (Plünder-Mechanik):**
   - Erobert der Angreifer den Glutstein, erhält er einen Teil der gelagerten Steuern und Vorräte der Burgkasse, aber **keine** privaten Spielerinventare und kein Recht, die Siedlung plattzuwalzen.

---

## 7. Zusammenfassung der Multiplayer-Vorteile
- **Volle Gestaltungsfreiheit** innerhalb des eigenen Glutstein-Claims.
- **Sichere Trennung** von Privatsphäre (Emberwatch als instanziierte Hauptburg) und kooperativem Wettstreit (Dorf & Außenposten in den Provinzen).
- **Gemeinschaftserlebnis** durch Baustellenfonds und Monumentalbauten.
- **Null Grieving-Frust**, aber volle Spannung bei organisierten Gildenkämpfen!


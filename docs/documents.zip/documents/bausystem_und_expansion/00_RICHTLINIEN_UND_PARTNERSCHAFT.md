# Emberwild – Zentrale Projekt- & Entwicklungsrichtlinien

**Dokumentversion:** 2.0  
**Geltungsbereich:** Gesamtes Emberwild-Projekt (Lore, Story, Building Workshop, Siedlungssystem, Wirtschaft, Kampfsystem, Weltarchitektur)

---

## 1. Das gemeinsame Leitmotiv & Partnerschaftsprinzip
* **Gleichberechtigte Spitzenentwicklung**: Menschlicher Entwickler und KI-Assistent arbeiten als Team auf Augenhöhe mit höchstem Qualitätsanspruch (AAA-Indie-Standard).
* **Gegenseitiges Korrekturprinzip**: „Ich korrigiere dich und du korrigierst mich.“ Fehler, Unstimmigkeiten, UX-Hürden oder suboptimale Architekturen werden sofort offen, konstruktiv und präzise angesprochen und verbessert.
* **Proaktives Mitdenken**: Bei jeder Anforderung werden Schnittstellen, Ergonomie (Shortcuts, Drag & Drop, Haptik, Sound-Feedback), Datensicherheit und zukünftige Erweiterungen (Multiplayer, Gilden, Quests) von Beginn an berücksichtigt.
* **Strikte Clean-Room-Engine & Code-Isolierung (`ASHFALL`)**:
  * Der Ordner `ASHFALL` ist ein reines passives Referenz- und Vergleichsarchiv.
  * **Verbot von Code-Übernahme**: Es darf ausnahmslos **kein Code** und **keine Dokumentation** aus dem Ordner `ASHFALL` in das Emberwild-Projekt übernommen, hineinkopiert oder gemerged werden.
  * Alle Core-Komponenten der neuen Engine werden im Clean-Room-Verfahren als 100% eigenes, modernes geistiges Eigentum (IP) neu geschrieben.

---

## 2. Nomenklatur & System-Trennung
* **`Builder` (Der Ingame-Baumodus)**:
  * Wird im Spielverlauf organisch über Quests freigeschaltet.
  * Dient ausschließlich dem Platzieren von **fertigen Gebäuden, Dekorationen, Pflanzen, Zäunen, Wegen und Feldern**.
  * Enthält **keine** einzelnen Wände, Dächer oder rohe CAD-Bauteile.
* **`Designer` (Das Gebäude-Atelier / CAD-Studio)**:
  * Befindet sich **ausschließlich im Hauptmenü** (außerhalb der Spielwelt).
  * Dient dem freien Konstruieren und Speichern modularer Gebäude aus Wänden, Dächern, Fenstern und Schichten.
  * Ist standardmäßig separat gesperrt und wird erst als späteres Meister-Feature freigegeben.

---

## 3. Kanonische Lore & Weltaufbau (Das 5-Zonen-Reich)

### 2.1 Die zentrale Geschichte & der Held
* **Zwei Welten im Ungleichgewicht**: Oberwelt und Unterwelt existierten einst gemeinsam, wurden durch eine historische Katastrophe getrennt und entwickelten sich jahrhundertelang isoliert. Beide Zivilisationen sind lebensfähig, benötigen jedoch die Ressourcen der jeweils anderen Seite:
  * *Oberwelt*: Holz, biologische Ressourcen, Landwirtschaft, Nahrung, natürliche Magieaffinität.
  * *Unterwelt*: Seltene Mineralien, Maschinenbau, hochentwickelte Technologie, energetische Vaelith-Verfahren.
* **Kein simples Gut-gegen-Böse**: Angst, Entfremdung und Misstrauen prägen die Beziehung, keine angeborene Feindschaft.
* **Der Protagonist als lebendige Brücke**:
  * Gezeugt durch den König der Unterwelt mit einer Frau aus der Oberwelt.
  * Seine Existenz ist kein Zufall, sondern Teil eines weitsichtigen Plans seines Vaters.
  * Er vereint Natur-Resonanz (Oberwelt) mit Maschinen- & Kristall-Verständnis (Unterwelt) und ist als Einziger fähig, die alten Schwellenanlagen zu bedienen und das magische Lebenskraft-Netzwerk **Vaelith** (das Geflecht) zu reaktivieren.
  * Er agiert nicht als imperialer Eroberer, sondern als Vermittler, Heiler und Baumeister einer gemeinsamen Zukunft.

### 2.2 Die 5 Zonen des Reiches
```mermaid
flowchart TD
    subgraph Oberwelt["DIE OBERWELT (Natur, Biologie & Volk)"]
        Z1["1. Zitadelle Emberwatch<br/>(Feste Herrschaftsflügel, Thronsaal, Ahnenkrypta, Elite)"]
        Z2["2. Die Grauen Felder (Weiler / Dorf)<br/>(Freies modulares Bauen, Bürger, Handwerk, Äcker, Weiden)"]
        Z3["3. Weltkarte & Provinzen (Wildnis)<br/>(Handelsstraßen, Außenposten, Biome, andere Kulturen)"]
    end

    subgraph Schwelle["DER SCHWELLENBEREICH (Vergessene Verbindungen)"]
        Z4["4. Dungeons, Katakomben & Resonanzstätten<br/>(Modulare Gewölbe, Vaelith-Generatoren, Boss-Kammern)"]
    end

    subgraph Unterwelt["DIE UNTERWELT (Technologie & Tiefenreiche)"]
        Z5["5. Die Tiefenstädte des Königs<br/>(Fortschrittliche Maschinen, Mineralien, Alchemie, Magie-Tech)"]
    end

    Z1 <--> Z2
    Z2 <--> Z3
    Z3 <--> Z4
    Z4 <--> Z5
```

---

## 3. Verbindliche technische Entwicklungsrichtlinien

### 3.1 100% Lokalisierungspflicht (i18n)
* Sämtliche für den Spieler sichtbaren Texte (UI-Elemente, Buttons, Toasts, Tooltips, Barks, Zitate, Krisen, Ereignisse, Beschreibungen) müssen ausnahmslos in die Sprachdateien eingepflegt werden:
  * Deutsch: `src/data/locales/de.js`
  * Englisch: `src/data/locales/en.js`
* **Hardcoded Text-Strings im UI- und Gameplay-Code sind strikt untersagt.** Jede Textausgabe erfolgt über `t('namespace.key', params)`.
* Die sprachliche Konsistenz wird regelmäßig mit der Testsuite `verify_i18n.mjs` validiert.

### 3.2 Modulare Erweiterbarkeit aller Systeme
* Alle Spielsysteme müssen erweiterbar konzipiert sein:
  * Registrierungs-APIs (z. B. `registerBlueprint()`, `registerIncident()`, `registerMajorCrisis()`).
  * Datengetriebene Schemata und Listen statt starrer 1:1-Verbindungen.
  * Flexible Filter nach Tags, Mindeststufen (`minTier`) oder Quest-Fortschritten.
* Kein System darf hardcoded auf eine feste Zahl von Gebäuden, Einheiten oder Zonen limitiert sein.

### 3.3 Data-Driven Tuning & Beseitigung magischer Zahlen
* **Keine magischen Zahlen im Code:** Ausnahmslos alle Werte für Gameplay, Wirtschaft, Timings, Erträge, Baukosten, KI-Schwellen, Abklingzeiten und Wahrscheinlichkeiten müssen in zentralen Konfigurationsdateien wie `src/data/settlementBalance.js` definiert sein.
* **Dual-Profil-Unterstützung**:
  * `live`: Für anspruchsvolle, nachhaltige Langzeit-Progression und Wirtschaft.
  * `dev`: Für schnelle Tests, Debugging und Entwicklungszyklen.
* Alle Werte bleiben zur Laufzeit editier- und umschaltbar (`G.settlementBalance`, `window.SETTLEMENT_BALANCE`).

### 3.4 Strikte Zero-Emoji-Richtlinie
* In Benutzeroberflächen, Dialogen, Toasts, Buttons, Tooltips und Beschreibungen werden strikt **keine bunten Emojis** verwendet.
* Alle visuellen Indikatoren sind maßgeschneiderte, reine Vektor-SVGs im stimmigen Dark-Fantasy-Stil oder edle typografische Symbole.

---

## 4. Ästhetik, Haptik & Ergonomie (Dark-Fantasy Medieval)

* **Designsprache**: Tiefes, warmes Holz, rauer Werkstein, gehämmertes Schmiedeeisen, gekrönt von warmem Bronze- und Antikgold (`#f3c969`, `#c49948`, `#6e5229`).
* **Haptisches Feedback**:
  * Jede Aktion besitzt klare visuelle Rückmeldungen (sanfte Glow-Effekte, Hover-Zustände, 3D-Snapshots).
  * Durchgängige Audio-Unterstützung (`ui_click`, `ui_open`, `ui_close`).
  * Gewichtige, weiche CSS-Animationen mit `cubic-bezier(0.16, 1, 0.3, 1)`.
* **Ergonomische Tastatur- & Maus-Steuerung**:
  * Direkte Shortcuts für Vielnutzer (`B` für Baumenü, `1`–`0` für Schnellzugriff, `Alt` für Leistenwechsel, `M` für Magnet-Snap, `R` für Drehen, `L` für Bibliothek, `Strg+Z`/`Strg+Y` für Undo/Redo).
  * Sauberes Abfangen von Browser-Defaults (z. B. Windows-Menüfokus bei `Alt`).

---

## 5. Abwärtskompatibilität & Verifikation
* **100% Spielstand-Kompatibilität**: Änderungen an Schemata oder Modellen dürfen bestehende Spielerstände (`localStorage`, Cloud-Saves) niemals zerstören.
* **Defensives Laden**: Baupläne, Werkstätten und Datenstrukturen laden fehlertolerant; fehlerhafte oder unvollständige Einträge werden repariert oder übersprungen, statt das Spiel abstürzen zu lassen.
* **Testverifikation vor Abschluss**: Nach jeder Codeänderung werden die zugehörigen Testsuiten (`test_building_workshop.mjs`, `test_build_mode.mjs`, `verify_i18n.mjs` etc.) ausgeführt.

---

## 6. Performance- & GPU-Ressourcenmanagement
* **Striktes WebGL-Lifecycle-Management (`disposeHierarchy`)**:
  * Kein 3D-Mesh, keine `BufferGeometry` und kein `Material` darf ohne Aufruf von `.dispose()` aus dem Szenengraphen entfernt werden.
  * Beim Löschen, Umbauen oder Ersetzen von Gebäuden im Builder/Designer werden alle Kind-Geometrien, Materialien und Shader rekursiv freigegeben, um Memory-Leaks im VRAM vollständig zu unterbinden.
* **Ruckelfreies, asynchrones Speichern**:
  * Speichervorgänge (Local-Saves, MySQL-Sync, Blaupausen-Export) dürfen den JavaScript-Hauptthread niemals blockieren.
  * Serialisierung erfolgt entkoppelt oder gedrosselt (Debounced), sodass die Renderschleife mit konstanten 60 FPS weiterläuft.

---

## 7. Admin-Suite, Backup-Engine, Debugger & Benutzerverwaltung
* **Zweck & Systemarchitektur**:
  * Die Admin-Suite wird parallel zur neuen Clean-Room-Engine als zentrales Steuer- und Wartungszentrum entwickelt.
  * **Lokale Datenbank**: XAMPP MySQL-Server auf Port `3307`.
* **Kernkomponenten der Admin-Suite**:
  1. **Dateisystem-Backup-Engine**:
     * Erstellt vollständige, versionierte Snapshots aller Code-Dateien, Konfigurationen, Schemata und Blaupausen.
     * Schließt schwere Binärdateien (`assets/`, `downloads/`, `*.zip`, `*.glb`) sowie sensitive Zugangsdaten und Passwörter strikt aus.
  2. **Echtzeit-Debugger & Interaktive Konsole**:
     * Bietet ein Live-Log und ein Befehlsfeld, um direkt aus der UI Systemevents zu triggern, Entitäten zu spawnen, Tageszeiten zu wechseln oder Wirtschaftswerte zu testen.
  3. **Vollwertige Benutzerverwaltung (Player Management)**:
     * Detaillierte Spielerübersicht: Ränge/Rollen (Spieler, Mod, Admin), Status, Inventare, Besitztümer, Tiere, Bauwerke, Spielzeit.
     * Live-Aktionen: Items/Gold vergeben oder entziehen, Werte manipulieren, Spieler warnen, kicken, bannen, befördern, löschen.

---

## 8. Weltatmosphäre, Sonnenzyklen & Texturschichten
* **Freundliche, lebendige Welt & Tag-Nacht-Zyklus**:
  * Saftig grüne, sonnige Idylle von Beginn an.
  * Zyklus: Standard 30 Minuten Tag / 12 Minuten Nacht (im Admin/Settings konfigurierbar).
  * Gemütliche Nachtstimmung (Laternen, Fenster, Glühwürmchen) mit nächtlichen Besonderheiten (Nachtblumen, seltene Kreaturen vor den Toren).
  * Reduzierte, erhabene Macht-Schreine: Auffrischung (temporär bis Reset) & Verstärkung (einmalig permanent).
* **PolyHaven-Integration (CC0 PBR-Texturen)**:
  * In-Editor-Browser mit visueller Vorschau nach Kategorien.
  * 1-Klick-Download (1K-Auflösung für beste WebGL-Performance, Speicherung unter `assets/textures/polyhaven/`).
* **Multi-Layer Wandschichten-System (`WallStylePreset`)**:
  * Wandaufteilung in horizontale Höhenbänder (Sockel, Mittelteil, Gesims) und vertikale Segmente (Ständer, Lamellen).
  * Einstellbare Höhe, Dicke/Tiefe (Vorsprung/Rücksprung) und UV-Texturdrehung.
  * Speicherung und Wiederverwendung als universelle Wand-Vorlagen.

---

## 9. Weltkarten-Architektur, Dynamische Siedlungs- & Dungeon-Generierung, Spieler-Spawns & Lore-Verflechtung
* **Clean-Room Welt- und Dungeon-Generierung**:
  * Vollständige Neuentwicklung der Welterstellung, Dungeongenerierung und Rendering-Engine ohne Altlasten.
  * Klare Trennung von **Burg-System** (Zitadelle, Wehrmauern, Herrschaftsflügel) und **Dorf-System** (Bürgerhäuser, Handwerksbetriebe, Marktplätze, Felder).
* **On-Demand-Siedlungsgenerierung über Map-Daten**:
  * Jeder Stadt-/Siedlungsknoten auf der Weltkarte besitzt Metadaten (Größe, Kultur, Ressourcenfokus, Biome).
  * Betritt ein Spieler einen Knoten zum ersten Mal, wird die Instanz (Stadt oder Dorf) prozedural und deterministisch anhand der Map-Daten generiert und dauerhaft persistiert.
  * **Reservierte Metropolen & Großstädte**: Große Städte sind fest reserviert für sichere PvE-Zonen, florierende Märkte, lebendige Tavernen, Unterkünfte, Händlergilden und Haupt-Questgeber.
* **Spieler-Spawn & Etablierung der Spieler-Basis**:
  * Spieler spawnen zufällig in einem definierten, erlaubten Wildnis- bzw. Siedlungsbereich.
  * **Sperrzonen für Spawns**: Städte und Knoten, die Quests, Schlüssel-NPCs oder storyrelevante Meilensteine beherbergen, sind für Spieler-Spawns strikt gesperrt.
  * Der Ort, an dem der Spieler spawnt, wird offiziell zu seiner **Spieler-Basis**.
* **Basis-Zentrierte Quest-Verflechtung & Dynamische Lore**:
  * Quests des Spielers orientieren sich immer an seiner individuellen Spieler-Basis als Zentrum.
  * Das System wählt Auftragsorte, Handelsrouten und Dungeons in konfigurierbaren Entfernungs-Radien (Nah-, Mittel- und Fernbereich) um die Heimatbasis aus.
  * Die realen Namen und Eigenschaften dieser umliegenden Städte werden dynamisch in die Dialoge, Questtexte und die persönliche Lore des Spielers eingewoben.


# 02 — 3D-BAUSYSTEM & INTERAKTIONS-MECHANIK

## 1. Technischer Überblick

Das Bausystem von *Emberwild* arbeitet direkt in der Three.js WebGL-Szene. Es transformiert den Spieler aus der reinen Kampfhocke in den **Baumodus (`[B]`)**, in dem die Welt taktil manipulierbar wird.

```mermaid
flowchart TD
    Start["Eingabe: Taste [B]"] --> EnterBM["BuildModeController aktivieren"]
    EnterBM --> Cam["Kamera fährt sanft hoch (+3.5m, 45° Pitch)"]
    EnterBM --> Ray["Maus-Raycast auf G.ground (Terrain)"]
    Ray --> Ghost["Hologramm-Mesh an Cursor-Position rendern"]
    
    subgraph InputLoop["Echtzeit-Interaktionsschleife"]
        Rot["Taste [R] / Mausrad -> Y-Rotation anpassen"]
        Coll["Kollisions-Check: canPlaceAt(x, z, rot, size)"]
        Coll -->|Frei & Eben| Valid["Hologramm leuchtet Cyan / Gold"]
        Coll -->|Kollision / Zu steil| Invalid["Hologramm leuchtet Rot (Pulsieren)"]
    end

    Ghost --> InputLoop
    InputLoop --> Place["Linksklick [LMB] bei Valid == true"]
    Place --> Deduct["Ressourcen aus Inventar abziehen"]
    Place --> SpawnSite["Baustelle spawnen (Pfähle & Gerüst)"]
    SpawnSite --> Finish["Schläge mit Bauhammer [E] -> Fertigstellung"]
    Finish --> World["3D-Mesh in Szene einfügen + NavMesh-Collider"]
```

---

## 2. Der 3D-Platzierungsmodus im Detail

### 2.1 Kamera & Steuerung
- **Aktivierung:** Druck auf die Taste `[B]` (Build) oder über den Bauplan im Inventar.
- **Kamera-Shift:** Die Action-Kamera hebt sich sanft um $+3{,}5\,\text{m}$ an und neigt sich um $45^\circ$, um eine saubere Draufsicht auf das Terrain zu ermöglichen.
- **Bewegung:** Der Spieler kann sich weiterhin mit `[W][A][S][D]` bewegen, um den Bauplatz zu umrunden.

### 2.2 Der Raycaster & das Cursor-Hologramm
- Ein permanenter Raycast schneidet die Mausebene mit dem Boden (`G.ground` / Mesh-Terrain).
- An der Schnittstelle $(x, y, z)$ wird das ausgewählte 3D-Blueprint als semi-transparentes **Hologramm-Mesh** gerendert (`MeshBasicMaterial` mit `transparent: true, opacity: 0.6`).
- **Rotation (`[R]` oder Mausrad):** Das Objekt dreht sich in präzisen $15^\circ$-Schritten um die vertikale Achse. Hält der Spieler `[Shift]` gedrückt, dreht es sich stufenlos.

### 2.3 Die Terrain- & Kollisionsvalidierung (`canPlaceAt`)
Das System führt vor jeder Platzierung eine 3-Punkte-Prüfung durch:
1. **Neigungsprüfung (Slope Check):** Ermittelt die Höhenunterschiede der 4 Eckpunkte des Gebäudes. Ist das Gefälle $> 15^\circ$, wird die Platzierung verweigert („Boden zu uneben“).
2. **Objekt-Kollisionsprüfung (AABB / Kreis):** Prüft den Abstand zu existierenden Gebäuden, Felsen, Bäumen und NPCs. Schneidet der Bau-Radius ein Hindernis, färbt sich das Hologramm rot.
3. **Zonen-Sperrzone (Protected Boundaries):** Hauptstraßen, Stadttore, Friedhöfe und Schreine besitzen eine geschützte Pufferzone (kein Zupflastern von Straßen oder Toren möglich).

---

## 3. Die Baustellen-Haptik: Errichtung & Bauhammer

Um das befriedigende Survival-ARPG-Gefühl zu erzeugen, poppen Gebäude nicht einfach wie im Browsergame auf, sondern durchlaufen eine greifbare Errichtungsphase:

```mermaid
stateDiagram-v2
    [*] --> Hologramm: Blueprint gewählt
    Hologramm --> Baustelle: Klick [LMB] & Ressourcen bezahlt
    Baustelle --> ImBau: Spieler/Arbeiter hämmert [E]
    ImBau --> Fertig: Baufortschritt erreicht 100%
    Fertig --> Beschaedigt: Feindangriff / Katastrophe
    Beschaedigt --> ImBau: Reparatur mit Ressourcen
    Fertig --> [*]: Abriss [X] (70% Material zurück)
```

1. **Phase 1: Das Fundament (Baustelle)**
   - Direkt nach dem Klick werden Holz, Stein und Gold aus dem Inventar/Lager abgezogen.
   - Am Boden erscheinen Holzpflöcke, eine mit Seilen abgespannte Markierung und Bauschutt.
   - Ein schwebender Fortschrittsbalken zeigt `0 / 100 %` an.
2. **Phase 2: Das Hämmern (Der Baufortschritt)**
   - Tritt der Spieler an die Baustelle und drückt `[E]` (oder schlägt mit dem ausgerüsteten Bauhammer), ertönt ein sattes metallisches Klingen (`hit_anvil` / `wood_chop`), Funken stieben auf und der Fortschritt steigt pro Schlag um $25\,\%$.
   - Alternativ: Wenn freie Dorfbewohner im Dorf leben, eilt automatisch ein Zimmermann herbei und vollendet den Bau selbstständig.
3. **Phase 3: Das Richtfest (Vollendung)**
   - Bei $100\,\%$ vollzieht Three.js einen Übergang: Das Gerüst zerspringt in Staubpartikel (`G.fx.burst('dust', x, y, z)`), das fertige Gebäude steht in voller Pracht da, Rauch beginnt aus dem Kamin zu steigen und eine warme Lichtquelle (`PointLight`) erhellt die Fenster.

---

## 4. Welt-Integration & Kollision (`G.nav`)

Ein Gebäude ist kein rein dekoratives Bild, sondern verändert die Physik der Spielwelt dauerhaft:

1. **Collider-Registrierung:**
   - Jedes Gebäude trägt in seinen Blueprint-Daten eine `footprint`-Definition:
     ```javascript
     footprint: { type: 'box', width: 4.8, depth: 4.2 } // oder { type: 'circle', radius: 2.5 }
     ```
   - Bei Fertigstellung ruft das Bausystem:
     ```javascript
     const col = addCollider(building.x, building.z, building.radius);
     G.nav.cutoutObstacle(building.x, building.z, building.width, building.depth, building.rot);
     ```
   - Dadurch weichen der Held, Monster und Dorfbewohner den Wänden automatisch aus.
2. **Interaktionspunkt (`_interactable`):**
   - Jedes fertige Gebäude erhält einen Interaktions-Marker an der Eingangstür oder Werkbank:
     - `[E] Öffnen / Verwalten:` Öffnet das Gebäude-Panel (Arbeiter zuweisen, Produktion einsehen, Ausbaustufe wählen).
     - `[R] Reparieren:` Stellt verlorene Integrität nach Angriffen wieder her.
     - `[Entf / X] Abreißen:` Bricht das Gebäude ab und erstattet $70\,\%$ der eingesetzten Rohstoffe in Form von Beutekisten am Boden.

---

## 5. Savegame-Persistenz & Rekonstruktion

Damit die gebaute Stadt nicht beim Gebietswechsel oder Neuladen verloren geht:

- Jedes erstellte Gebäude wird im Savegame unter `character.settlement.customBuildings` als serialisierbares JSON-Objekt gespeichert:
  ```json
  {
    "id": "bld_7f9a2",
    "blueprintId": "village_house_tier1",
    "area": "greyfields",
    "x": -34.5,
    "y": 0.0,
    "z": 48.2,
    "rot": 1.57,
    "health": 600,
    "maxHealth": 600,
    "tier": 1,
    "workers": ["npc_miner_2"],
    "created": 1794120000
  }
  ```
- Beim Betreten der Grauen Felder (`area:enter` greyfields) scannt das Bausystem die Liste und instanziiert alle Gebäude blitzschnell mit ihren Collidern und Lichtern.


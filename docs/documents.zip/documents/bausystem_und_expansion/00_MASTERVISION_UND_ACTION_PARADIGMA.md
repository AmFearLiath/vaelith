# 00 — MASTERVISION & ACTION-PARADIGMA

## 1. Die Ausgangslage: Der Paradigmenwechsel

Bislang besaß *Emberwild* ein hochentwickeltes Menü- und Simulationssystem („The Crown“), in dem Ressourcen passiv stiegen, Wehranlagen per Klick repariert und Bedrohungen im Interface abgewickelt wurden. 

**Das fundamentale Feedback des Spielers lautet:**
> *"Irgendwie fühlt sich alles momentan mehr wie eine Wirtschaftssimulation an, in der die 3D-Welt quasi nur dafür da ist, damit der Spieler auch mal Monster schlachten kann. Die 3D-Welt hat nicht wirklich etwas mit der ganzen Simulation zu tun. Der Spieler hat einfach zu wenige Aufgaben. Es ist alles viel zu einfach und zu schnell erledigt. Es ist keine Herausforderung für den Spieler da, die er selber erstmal in der Welt erledigen muss, um Fortschritte zu erzielen."*

Mit diesem Konzept vollziehen wir die **Transformation zum immersiven 3D-ARPG / Survival-Kingdom-Erlebnis** (inspiriert von *V Rising*, *Valheim*, *Mount & Blade* und *Dark Souls*). Fortschritt, Macht, Reichtum und Sicherheit müssen vom Spieler in der 3D-Welt erkämpft, erbaut und verteidigt werden.

---

## 2. Die Kernphilosophie: Das duale Herrschaftsgebiet

Ein zentraler Geniestreich der neuen Ausrichtung ist die **funktionale und visuelle Trennung des Herrschaftsgebiets** in zwei Welten:

```mermaid
flowchart TD
    subgraph Herrschaft["Das Reich von Emberwild"]
        Zitadelle["🏰 EMBERWATCH: Die Zitadelle / Burg<br/>• Massiver Steinwall & Wehrtürme<br/>• Sitz des Herrschers & des Glut-Ordens<br/>• Monumentaler Plot-Ausbau (Tier 1–3)<br/>• Unbezwingbarer Kern, Hochsicherheit"]
        Weiler["🏡 DIE GRAUEN FELDER: Das Dorf / Der Weiler<br/>• Offenes, weites Siedlungsland<br/>• Freies 3D-Bauen & organische Straßen<br/>• Bauernhöfe, Sägewerke, Mühlen, Hütten<br/>• Lebendiges Volk, Weiden, aber verwundbar"]
        Wildnis["🌲 DIE WILDNIS & PROVINZEN<br/>• Uralte Wälder, Felsmassive, Minen<br/>• Banditenlager, Aschebrut-Nester, Bosse<br/>• Rohstoff-Quellen, die erkämpft werden müssen"]
    end

    Wildnis -->|Rohstoffe: Stämme, Erze, Nahrung, Felle| Weiler
    Weiler -->|Verarbeitete Güter, Rekruten, Steuern| Zitadelle
    Zitadelle -->|Königlicher Schutz, Elite-Waffen, Segnungen| Weiler
```

### Die Rollenverteilung im Detail:
1. **Emberwatch (Die Hochburg):**
   - Repräsentiert die innere Machtzentrale. Hier regiert der Spieler über Edikte, empfängt Gesandte, lagert seine unantastbaren Reichtümer in der Schatzkammer und schmiedet legendäre Rüstungen in der Runenschmiede.
   - Der Raum innerhalb der Mauern ist begrenzt, ehrfurchtgebietend und durch massive Steinzinnen geschützt.
2. **Die Grauen Felder (Das lebendige Dorf):**
   - Das schlagende Herz der Wirtschaft und des Alltags. Hier schlagen Holzfäller Bäume, mahlen Mühlen Korn, grasen Rinder auf den Weiden und rauchen die Kamine der Fachwerkhäuser.
   - Dieses Dorf ist dynamisch: Der Spieler baut es mit freier Platzierung selbst auf. Es ist aber auch der erste Angriffspunkt für feindliche Horden. Wer sein Dorf nicht mit Wachtürmen und Palisaden schützt, verliert seine Ernte und Dorfbewohner.

---

## 3. Die vier Säulen des aktiven Gameplays

```mermaid
graph LR
    S1["1. Aktives Ernten & Sammeln<br/>(Hieb-Physik, Werkzeuge, Nodes)"]
    S2["2. Freies 3D-Bauen<br/>(Hologramm, Hammer, Ausbau)"]
    S3["3. Kämpfe & Rivalen<br/>(Wildnis-Jäger, feindliche Orden)"]
    S4["4. Welt-Expansion<br/>(Außenposten, Monopole, Karawanen)"]
```

1. **Säule 1: Aktives Ernten statt passiver Ticker**
   - Ressourcen fließen nicht mehr magisch aus dem Nichts ins Lager. 
   - Der Spieler nimmt Axt, Spitzhacke und Sichel in die Hand. Bäume fallen um, Felsadern splittern unter Funkenschlag, und Lasttiere werden beladen, um schwere Güter heimzubringen.
2. **Säule 2: Physisches 3D-Bauen mit echtem Raumgefühl**
   - Keine Tabellen-Buttons mehr. Der Spieler öffnet mit `[B]` den Baumodus, sieht das Gebäude als leuchtendes 3D-Hologramm vor sich, prüft den Boden, setzt das Fundament und zimmert die Balken selbst oder teilt Handwerker ein.
3. **Säule 3: Ständige Gefahr, Kämpfe & lebendige Welt**
   - Die Wildnis schläft nicht. Wer im Wald Holz schlägt, lockt durch den Lärm Aschewölfe an. Rivalisierende Asche-Jäger (simulierte feindliche Heldengruppen mit Spieler-Klassen) durchstreifen das Land und machen Jagd auf einsame Sammler.
4. **Säule 4: Notwendige und lohnende Welterkundung**
   - Nicht jeder Rohstoff existiert vor der Haustür. Wer edles Silber oder zähes Eisenholz will, muss in ferne Provinzen reiten, dort befestigte Außenposten errichten und gesicherte Handelswege nach Emberwatch etablieren.

---

## 4. Zielerlebnis: Der Tag eines Herrschers in Emberwild

- **Am Morgen (`06:00`):** Der Spieler tritt aus dem Thronsaal von Emberwatch auf den Wehrgang, blickt hinab auf sein dampfendes Dorf in den Grauen Feldern. Die Schmiede hämmert bereits, die Mühle dreht sich.
- **Am Vormittag:** Mit Packpferd und Spitzhacke reitet der Spieler an die Felsklippen der Westweiden, baut eine reiche Eisenerz-Ader ab und wehrt einen Hinterhalt von drei Asche-Ghoulen ab.
- **Am Mittag (`12:00`):** Zurück im Dorf öffnet er das Baumenü `[B]`, platziert zwei neue Wohnhütten für gerettete Bergleute und erweitert die südliche Holzpalisade um einen Wachturm.
- **Am Abend (`18:00`):** Die Glocke schlägt Alarm! Ein Aschewolf-Rudel pirscht sich an die Schafweiden heran. Der Spieler eilt mit den Bogenschützen zur Palisade, telegrafierte Sprünge der Bestien werden abgewehrt, der Alpha-Wolf fällt im Duell.
- **In der Nacht (`22:00`):** Im Schein der Fackeln kehrt Ruhe ein. In der Taverne „Zum Goldenen Funken“ feiert das Volk, während der Spieler in der Burg-Schatzkammer die Beute des Tages sichtet und das nächste Großprojekt plant.


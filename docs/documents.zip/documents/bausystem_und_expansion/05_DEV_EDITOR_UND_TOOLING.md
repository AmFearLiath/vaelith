# 🛠️ 05. IN-GAME DEV-EDITOR & TOOLING

> **Technische Spezifikation:** Der Entwickler- und Level-Editor (`F7` / `G.editor`) für visuelles World-Building, NavMesh-Debugging, Asset-Platzierung und JSON-Preset-Export in *Emberwild*.

---

## 1. Zweck & Abgrenzung zum Spieler-Baumodus

Während der **Spieler-Baumodus (`[B]`)** Beschränkungen unterliegt (Ressourcenkosten, Glutstein-Radius, Bauhammer-Bauzeit, kein Verlassen des Spielerkörpers), ist der **Dev-Editor (`F7`)** ein uneingeschränktes God-Mode-Werkzeug für Entwickler und GMs:

| Kriterium | Spieler-Baumodus (`[B]`) | Dev-Editor (`F7`) |
| :--- | :--- | :--- |
| **Kamera** | Third-Person Spielerzentriert | Freie Flugkamera (Fly-Cam noclip) |
| **Kosten** | Verbraucht Holz, Stein, Gold | Kostenlos / Unendliche Instanzen |
| **Objektkatalog** | Nur freigeschaltete Spieler-Gebäude | Jedes Mesh, GLB-Node, Licht & Trigger |
| **Transformation** | Snapping auf Boden & 45°-Schritte | Freie 3D-Gizmos (Translate, Rotate, Scale) |
| **Ausgabe** | Lokales Savegame / Multiplayer-Sync | JSON-Array Export für Quellcode / Presets |

---

## 2. Editor-Aktivierung & Tastenbelegung

Der Editor wird über `F7` oder in der Browserkonsole via `G.editor.toggle()` geöffnet:

```
[F7] ──> Toggle Editor-Modus (Pausiert Spieler-Controller, aktiviert Fly-Cam)
```

### 2.1 Steuerung im Editor:
- **`W / A / S / D`**: Kamera horizontal bewegen.
- **`Space / Strg`**: Kamera aufsteigen / absinken.
- **`Shift (Halten)`**: 3x Kamera-Geschwindigkeit (Turbo-Flug).
- **`Mausrad`**: Kamera-Geschwindigkeit stufenlos feineinstellen (0.1 bis 50 m/s).
- **`Rechtsklick + Mausbewegung`**: Umschauen / Blickwinkel drehen.
- **`Linksklick auf Objekt`**: Objekt selektieren und Gizmo anheften.
- **`[1] / [W]`**: Verschiebe-Gizmo (Translate).
- **`[2] / [E]`**: Rotations-Gizmo (Rotate).
- **`[3] / [R]`**: Skalierungs-Gizmo (Scale).
- **`[Entf] / [X]`**: Selektiertes Objekt löschen.
- **`Strg + D`**: Selektiertes Objekt duplizieren.
- **`[H]`**: NavMesh & Kollisions-Hitboxen ein-/ausblenden (Wireframe).

---

## 3. UI-Architektur & Toolbars

Sobald `F7` aktiv ist, blendet sich ein schlankes, dunkles Toolset im Stil von Unreal Engine / Blender über das Three.js-Canvas ein:

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ [Emberwild Dev-Editor v1.0]   [Scene: Fields]   [Objects: 142]   [FPS: 60]   │
├──────────────┬────────────────────────────────────────────────┬──────────────┤
│ ASSET-BROWSER│ 3D-VIEWPORT                                    │ INSPEKTOR    │
│              │                                                │              │
│ 📁 Gebäude   │                        ▲ Y (Grün)              │ Name: HouseA │
│  - house_a   │                        │                       │ Mesh: env_.. │
│  - house_b   │                        │   ▲ Z (Blau)          │              │
│  - forge     │                        │  /                    │ Position:    │
│  - tower     │                        │ /                     │ X:  14.52    │
│ 📁 Natur     │                        └────────► X (Rot)      │ Y:   0.00    │
│  - Pine_01   │                [Selektierte Schmiede]          │ Z: -32.10    │
│  - Rock_Huge │                                                │              │
│ 📁 Lichter   │                                                │ Rotation:    │
│  - TorchLight│                                                │ Y:  90.0°    │
│              │                                                │              │
│ [Search...]  │                                                │ [Snap to Grd]│
├──────────────┴────────────────────────────────────────────────┴──────────────┤
│ [JSON Exportieren (Clipboard)]    [JSON Importieren]    [NavMesh neu backen] │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Kernfunktionen des Dev-Editors

### 4.1 Asset-Palette mit 3D-Vorschau
Der Browser durchsucht automatisch alle geladenen GLB-Dateien (`env_town.glb`, `env_fields.glb`, `nature.glb`):
- Per Drag-and-Drop oder Doppelklick wird das Modell direkt an der aktuellen Kameraposition in die Szene geworfen.
- Automatische Normalen-Ausrichtung am Terrain (`snapToGround()`).

### 4.2 Live NavMesh- & Kollisions-Visualizer
- Mit Druck auf `[H]` schaltet der Editor in den Röntgenmodus:
  - **Grüne Wireframe-Ebenen:** Begehbare Flächen des NavMeshs.
  - **Rote Zylinder/Boxen:** Aktive Kollider (`spatial` Hindernisse, Bäume, Wände).
- Ermöglicht es Entwicklern sofort zu erkennen, warum eine KI oder ein Tier an einer bestimmten Ecke steckenbleibt.

### 4.3 Splat-Map & Bodenpinsel (Cobblestone / Pfade)
- Der Pinsel malt direkt in das dynamische Ground-Decal-System:
  - Pflasterstein-Pfade (`cobblestone_patch`)
  - Ausgetretene Trampelpfade (`dirt_path`)
  - Verbrannte Erde um Lagerfeuer (`scorched_earth`)
- Radius und Deckkraft sind per Regler steuerbar.

---

## 5. Datenformat & Export-Pipeline

Der Editor schreibt keinen Binärcode, sondern erzeugt saubere, versionierbare JSON-Dateien, die direkt in den Spielcode übernommen werden können.

### 5.1 Beispiel-Export (Clipboard-Format):
```json
[
  {
    "blueprintId": "smith_forge",
    "name": "Dorfschmiede_Nord",
    "position": [18.4, 0.0, -42.1],
    "rotation": [0, 1.5708, 0],
    "scale": [1, 1, 1],
    "collider": {
      "type": "cylinder",
      "radius": 2.6,
      "height": 4.0
    },
    "lights": [
      { "type": "point", "offset": [0, 1.8, 1.2], "color": "#ffaa44", "intensity": 2.5, "distance": 8 }
    ],
    "spawns": [
      { "type": "npc_blacksmith", "offset": [0.5, 0, 1.0] }
    ]
  }
]
```

### 5.2 Workflow vom Editor ins Release-Build:
1. Entwickler öffnet Level in `F7`, platziert Häuser, Wachtürme und Requisiten.
2. Klick auf `[JSON Exportieren]` kopiert das gesamte Layout in die Zwischenablage.
3. Einfügen in `src/data/settlementPresets.json` oder direktes Einladen im laufenden Spiel mit `G.editor.loadPreset("norddorf_preset")`.

---

## 6. Zusammenfassung & Entwicklungsnutzen
- **10x schnellere Iteration:** Kein ständiges Neuladen der Webseite und blindes Raten von Koordinaten (`x: 12.4, z: -30.1`) im Code mehr.
- **Perfekte Kollisionskontrolle:** Fehlerhafte KI-Pfade werden sofort visuell entlarvt.
- **Grundlage für Community-Karten:** Das gleiche Tool kann künftig Spielern als Festungs-Planer zur Verfügung gestellt werden.


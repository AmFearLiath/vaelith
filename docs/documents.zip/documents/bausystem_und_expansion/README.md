# 🏰 BAUSYSTEM & REICHSERWEITERUNG („Zitadelle & Weiler“)

> Dieses Verzeichnis enthält die vollständige Konzeption, Architektur und Spezifikation für das interaktive 3D-Bausystem, die Weltkarten-Expansion und das actiongeladene Survival-Kingdom-Gameplay von **Emberwild**.

---

## 📑 Inhaltsverzeichnis & Dokumenten-Übersicht

| Dokument | Thema & Inhalt |
| :--- | :--- |
| **[`00_MASTERVISION_UND_ACTION_PARADIGMA.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/00_MASTERVISION_UND_ACTION_PARADIGMA.md)** | Strategische Neuausrichtung: Weg vom passiven Menü-Clicker, hin zum aktiven 3D-ARPG-Erlebnis. Das Zusammenspiel von Burg (Emberwatch) und Dorf (Graue Felder). |
| **[`01_BURG_VS_DORF_GEBAEUDEKATALOG.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/01_BURG_VS_DORF_GEBAEUDEKATALOG.md)** | Vollständiger Blueprint-Katalog aller baubaren Strukturen: Schlossflügel innerhalb der Mauern vs. freie Dorfgebäude, Werkstätten, Weiden und Wehranlagen im Umland. |
| **[`02_3D_BAUSYSTEM_UND_INTERAKTION.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/02_3D_BAUSYSTEM_UND_INTERAKTION.md)** | Technische Spezifikation des Bausystems: Hologramm-Raycast, Rotationssteuerung, Kollisionsprüfung (Grün/Rot), Baustellen-Haptik mit Bauhammer, NavMesh-Integration und Savegame-Persistenz. |
| **[`03_MULTIPLAYER_GILDEN_UND_TERRITORIEN.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/03_MULTIPLAYER_GILDEN_UND_TERRITORIEN.md)** | Gilden- und Multiplayer-Architektur: Dorf-Glutstein (Claim-Radius), Rollen- und Rechtematrix, monumentale Großprojekte, Banner-Branding und faire Belagerungsregeln ohne Grieving. |
| **[`04_WELTKARTE_EXPANSION_UND_RESSOURCENKREISLAUF.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/04_WELTKARTE_EXPANSION_UND_RESSOURCENKREISLAUF.md)** | Aktives 3D-Ressourcensammeln (Holzfällen, Erzabbau, Kräuter, Jagd), Provinzen als Rohstoff-Monopole, Eroberung von Außenposten, Lastpferde und Transportlogistik. |
| **[`05_DEV_EDITOR_UND_TOOLING.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/05_DEV_EDITOR_UND_TOOLING.md)** | In-Game Entwickler-Editor (`F7` / `G.editor`): Fly-Cam, 3D-Transform-Gizmos, Live-NavMesh-Visualisierung, Splat-Map-Terrainpinsel und JSON-Layout-Export. |


# 01 — BURG VS. DORF: DER VOLLSTÄNDIGE GEBÄUDEKATALOG

## 1. Übersicht der Baubereiche

Das Bausystem unterscheidet streng zwischen zwei Zonen:
1. **Innerhalb der Burg (Emberwatch Zitadelle):** Feste Parzellen für monumentale Staats- und Herrschaftsflügel (3 Tiers, prachtvolle Ausbauten, unzerstörbar).
2. **Außerhalb der Burg (Die Grauen Felder):** Freies Raster- und Modulbauen für das alltägliche Dorfleben, Produktion, Landwirtschaft und vorgeschobene Verteidigung.

---

## 2. Gebäude innerhalb der Burg (Zitadelle Emberwatch)

Die Zitadelle ist der steinerne Hort der Macht. Alle Strukturen innerhalb der Mauern dienen der Herrschaft, Forschung, Elite-Ausrüstung und Reichsverwaltung:

```mermaid
classDiagram
    class ZitadelleGebaeude {
        +int tier (1-3)
        +bool unzerstoerbar
        +string funktion
    }
    ZitadelleGebaeude <|-- Thronsaal
    ZitadelleGebaeude <|-- KoeniglicheWaffenschmiede
    ZitadelleGebaeude <|-- ArkanerTurm
    ZitadelleGebaeude <|-- Reichsschatzkammer
    ZitadelleGebaeude <|-- OrdensKaserne
    ZitadelleGebaeude <|-- AhnenKrypta
```

### 2.1 Großer Thronsaal & Ratskammer
- **Funktion:** Politisches Zentrum, Erlass von Gesetzen, Steuern, Reichs-Diplomatie und Audienzen.
- **Trophäenhalle:** Wandflächen zur Montage besiegter Boss-Relikte (Schädel des Alpha-Wolfs, Krone des Aschkönigs, Glockensplitter des Wächters).
- **Stufen:**
  - *Tier 1 (Eichenthron):* Basis-Befehle, Steuereintreiber ($+5\,\%$ Goldeinkommen).
  - *Tier 2 (Marmorsaal):* Diplomatie-Pulte, Karawanen-Chartas, $+10\,\%$ Siedlungsmoral.
  - *Tier 3 (Kaiserliche Festhalle):* Schaltet Meister-Edikte frei, permanente Helden-Aura ($+10\,\%$ Schaden für alle Verbündeten in der Provinz).

### 2.2 Königliche Waffenkammer & Runenschmiede
- **Funktion:** Meister-Schmiede für High-Tier-Waffen (Tier 4 & Tier 5), Rüstungs-Sets und Rüstkammer-Upgrades der Garnison.
- **Stufen:**
  - *Tier 1 (Schmiedehütte):* Einfaches Schmelzen, Reparaturwerkbank, Tier-2-Waffencrafting.
  - *Tier 2 (Glut-Hochofen):* Herstellung von Stahlausrüstung, automatische Rüstungsaufwertung der Stadtwachen ($+15\,\%$ Rüstung).
  - *Tier 3 (Arkaner Amboss & Esse):* Runengravur, legendäres Crafting, Feuerschutz-Beschichtungen für Burgtore.

### 2.3 Arkanes Sanktuarium & Alchemie-Spire
- **Funktion:** Verzauberungen, Elixierbrauerei, Schnellreise-Riten und Wiederbelebungs-Altäre.
- **Stufen:**
  - *Tier 1 (Kräuterkammer):* Heiltränke und Gegengifte brauen.
  - *Tier 2 (Arkaner Turm):* Verzauberung von Waffen mit Elementarschaden (Feuer, Frost, Blitz, Schatten).
  - *Tier 3 (Sternwarte des Glut-Ordens):* Portal-Forschung, Schrein-Resonanz, automatischer Schutzschild gegen Katastrophen.

### 2.4 Reichs-Schatzkammer (The Vault)
- **Funktion:** Vollkommen sichere Lagerung vor Raubzügen und Plünderungen.
- **Stufen:**
  - *Tier 1 (Eisenkiste):* Bis zu $5.000$ Gold und $200$ seltene Barren gesichert.
  - *Tier 2 (Befestigter Tresorraum):* Bis zu $25.000$ Gold, automatische Zins-Erträge ($+2\,\%$ täglich).
  - *Tier 3 (Zwergische Felsenkammer):* Unbegrenzte Schatzlagerung, Zinsgewinne, $+25\,\%$ Handelsbonus bei wandernden Kaufleuten.

### 2.5 Garnisons-Hauptquartier & Ordenskaserne
- **Funktion:** Unterkunft und Ausbildungsstätte für Hauptmann Torin, Ritter und Scharfschützen.
- **Stufen:**
  - *Tier 1 (Wachstube):* 12 Stadtwachen, Standard-Patrouille am Nordtor.
  - *Tier 2 (Kaserne & Exerzierplatz):* $+8$ Bogenschützen, $+15\,\%$ Garnisons-Kampfkraft, Torwachen wehren kleinere Angriffe autonom ab.
  - *Tier 3 (Festungskommandantur):* Zugriff auf 4 Meisterspezialisten (Kriegs-Paladine, Belagerungs-Ingenieure), automatischer Alarm bei Gefahren im Umland.

### 2.6 Krypta der Ahnen & Reliquienschrein
- **Funktion:** Ehrung gefallener Recken, passive Segen und Schutz vor Seuchen.
- **Stufen:**
  - *Tier 1 (Gedenkstein):* $+5\,\%$ Seelen- und XP-Erhalt nach dem Tod.
  - *Tier 2 (Mausoleum):* $+10\,\%$ Resistenz gegen Asche- und Schattenschaden für den Helden.
  - *Tier 3 (Geweihte Krypta):* Wiederbelebungs-Segen: Der Spieler kann einmal alle 30 Minuten bei einem tödlichen Treffer mit $50\,\%$ Leben sofort auferstehen.

---

## 3. Gebäude außerhalb der Burg (Das Dorf in den Grauen Feldern)

Im offenen Umland platziert der Spieler die Gebäude frei über das Bausystem. Jedes Gebäude hat einen physischen Fußabdruck, Holzbalken-Mesh und Interaktionspunkte.

```mermaid
graph TD
    subgraph DorfKatalog["Katalog: Freie Dorf- & Umlandbauten"]
        subgraph Kat1["1. Wohnraum & Leben"]
            H1["Kleine Holzhütte<br/>(Kosten: 25 Holz, 10 Stein | +2 Bewohner)"]
            H2["Fachwerk-Bauernhaus<br/>(Kosten: 60 Holz, 35 Stein | +5 Bewohner)"]
            Tav["Dorfschenke 'Goldener Funke'<br/>(Kosten: 120 Holz, 80 Stein | Söldner, Moral)"]
            Bru["Dorfbrunnen & Platz<br/>(Kosten: 40 Stein, 10 Holz | Wasser, Handel)"]
        end
        subgraph Kat2["2. Produktion & Handwerk"]
            Saege["Großes Sägewerk<br/>(Kosten: 45 Holz, 20 Stein | Holz-Veredelung)"]
            Stein["Steinmetz-Bauhütte<br/>(Kosten: 30 Holz, 45 Stein | Quaderstein-Produktion)"]
            Mueh["Getreidemühle & Silo<br/>(Kosten: 70 Holz, 50 Stein | Mehl, Nahrung)"]
            Gerb["Lohgerberei & Weberei<br/>(Kosten: 40 Holz, 25 Stein | Leder, Stoffe)"]
        end
        subgraph Kat3["3. Landwirtschaft & Zucht"]
            Kopp["Weidekoppel & Schafpferch<br/>(Kosten: 20 Holz | Wolle, Milch, Fleisch)"]
            Stall["Pferdegestüt & Reitstall<br/>(Kosten: 80 Holz, 40 Stein | Reittierzucht, Lasttiere)"]
            Acker["Eingezäuntes Ackerbeet<br/>(Kosten: 10 Holz | Weizen, Flachs, Kräuter)"]
        end
        subgraph Kat4["4. Verteidigung & Wehranlagen"]
            Pali["Holzpalisade (je 4m)<br/>(Kosten: 8 Holz, 2 Stein | Barriere, HP 400)"]
            Tor["Befestigtes Wehrtor<br/>(Kosten: 25 Holz, 10 Eisen | Öffnen/Schließen)"]
            Turm["Holzwachturm<br/>(Kosten: 50 Holz, 20 Stein | 2 Bogenschützen-Slots)"]
            Falle["Pflockfalle & Graben<br/>(Kosten: 12 Holz, 5 Eisen | Verlangsamt Rudel)"]
            Feuer["Pechfeuerpfanne<br/>(Kosten: 10 Stein, 5 Eisen | Nacht-Sicht & Abschreckung)"]
            Sign["Signalfeuer-Hügel<br/>(Kosten: 30 Holz, 20 Stein | Ruft Burgtruppen)"]
        end
    end
```

---

## 4. Synergie-Matrix: Wie Burg und Dorf zusammenwirken

| Ressource / Mechanik | Herkunft im Dorf (Graue Felder) | Weiterverarbeitung / Veredelung | Endprodukt in der Burg (Emberwatch) |
| :--- | :--- | :--- | :--- |
| **Holz & Balken** | Holzfäller fällen Bäume im Umlandwald. | Sägewerk schneidet Stämme zu Bauholz. | Waffenkammer zimmert Bogenschäfte & Belagerungswerke. |
| **Erze & Stein** | Bergleute brechen Felsen an Felswänden. | Steinmetz behaut Quadersteine. | Hochofen schmilzt Plattenrüstungen & Zinnen. |
| **Nahrung & Getreide** | Äcker & Rinderweiden erzeugen Korn und Milch. | Windmühle & Bäckerei stellen Rationen her. | Großer Thronsaal versorgt die Palastgarde & Bürgerfeste. |
| **Leder & Wolle** | Jäger erbeuten Felle, Schafe liefern Vlies. | Gerberei & Weberei gerben Rüstleder. | Rüstkammer polstert Prunkrüstungen & Ordensbanner. |
| **Sicherheit & Rekruten** | Wohnhütten beherbergen Volk; Miliz bemannt Holztürme. | Kaserne drillt Rekruten zu regulären Soldaten. | Thronsaal ernennt Veteranen zu königlichen Rittern. |


# Emberwild – Building Workshop & Community Building Library

**Konzept- und technische Umsetzungsspezifikation**

| Eigenschaft | Wert |
|---|---|
| Projekt | Emberwild |
| System | Building Workshop & Community Building Library |
| Dokumenttyp | Konzept, Architektur und Implementierungsanforderungen |
| Status | Konzeptentwurf |
| Zielgruppe | KI-Entwicklungsagent, technische Projektentwicklung |
| Architektur | Erweiterung des bestehenden Building-Systems |
| Multiplayer | Von Beginn an berücksichtigen |
| Priorität | Hoch – Grundlage für den weiteren Ausbau des Baumodus |

---

# 1. Projektziel und Grundidee

Emberwild soll Spielern ermöglichen, eigene Gebäude aus modularen 3D-Bauteilen zu entwerfen, zu speichern und mit anderen Spielern zu teilen.

Dafür wird ein eigenständiges Werkzeug namens **Building Workshop** entwickelt.

Zusätzlich entsteht eine zentrale **Community Building Library**, in der Spieler ihre Gebäude veröffentlichen, die Entwürfe anderer Spieler entdecken, importieren und in ihren eigenen Spielwelten verwenden können.

Eine weitere Komponente ist die **Guild Building Library**, über die Gilden eigene Gebäudeentwürfe und Architekturstandards verwalten und unter ihren Mitgliedern teilen können.

Der bestehende Baumodus bleibt grundsätzlich erhalten. Er erhält lediglich die notwendigen Erweiterungen, um gespeicherte und importierte Gebäude-Blueprints auszuwählen und zu platzieren.

Das übergeordnete Ziel besteht darin, ein flexibles, kreatives und langfristig multiplayerfähiges Gebäudesystem zu schaffen, ohne die Performance der Spielwelt durch eine unkontrollierte Anzahl individueller Gebäude zu gefährden.

## 1.1 Leitprinzipien

- Spieler sollen eigene Gebäude gestalten können, ohne externe 3D-Modellierungssoftware zu benötigen.
- Spieler ohne ausgeprägte Kreativität oder architektonische Fähigkeiten sollen ebenfalls schöne Gebäude verwenden können.
- Gebäude werden aus einer kontrollierten Bibliothek wiederverwendbarer 3D-Bauteile zusammengesetzt.
- Ein Gebäude wird als Blueprint beschrieben, nicht als eigenständige Sammlung kopierter Mesh-Geometrien gespeichert.
- Der bestehende Baumodus bleibt für Platzierung und Bauausführung verantwortlich.
- Die grafische Darstellung wird unabhängig von der Spielmechanik optimiert.
- Multiplayerfähigkeit und Performance müssen von Anfang an berücksichtigt werden.
- Spieler können ihre Kreationen freiwillig mit anderen teilen.
- Gilden können eigene Architektur-Bibliotheken und Baustandards pflegen.
- Die serverseitige Validierung bleibt maßgeblich für alle veröffentlichten und platzierten Bauwerke.

---

# 2. Systemübersicht

Das Gesamtsystem besteht aus vier eigenständigen, miteinander verbundenen Bereichen.

## 2.1 Building Workshop

Eigenständiges Werkzeug zur Erstellung und Bearbeitung individueller Gebäude.

Funktionen:

- Modulare 3D-Bauteile auswählen.
- Bauteile in einer 3D-Arbeitsfläche platzieren.
- Bauteile verschieben, drehen und gegebenenfalls skalieren.
- Gebäude aus mehreren Bauteilen zusammensetzen.
- Materialien und freigegebene Varianten auswählen.
- Gebäude in einer 3D-Vorschau betrachten.
- Gebäudeinformationen und Metadaten festlegen.
- Baupläne speichern, bearbeiten, duplizieren und exportieren.
- Gebäude für die Community oder die eigene Gilde veröffentlichen.

## 2.2 Community Building Library

Globale Bibliothek für öffentlich veröffentlichte Gebäude.

Funktionen:

- Gebäude suchen und filtern.
- Kategorien und Tags verwenden.
- Gebäude in einer Detailansicht betrachten.
- 3D-Vorschau öffnen.
- Bewertungen und Favoriten verwalten.
- Gebäude in die eigene Blueprint-Bibliothek importieren.
- Erstellerinformationen anzeigen.
- Veröffentlichungen und Aktualisierungen nachvollziehen.

Die Bibliothek ist nicht an einen einzelnen Spielserver gebunden.

## 2.3 Guild Building Library

Private beziehungsweise zugriffsbeschränkte Bibliothek für Gilden.

Funktionen:

- Gildeneigene Gebäudeentwürfe verwalten.
- Gebäude für Gildenmitglieder freigeben.
- Gemeinsame Architekturstandards entwickeln.
- Gebäude für Außenposten, Produktionsstätten und Verteidigungsanlagen bereitstellen.
- Gildeninterne Favoriten und Sammlungen verwalten.
- Berechtigungen für Veröffentlichung und Bearbeitung festlegen.

## 2.4 Existing Build Mode

Der bestehende Baumodus bleibt für die eigentliche Platzierung und Errichtung von Gebäuden zuständig.

Er wird um folgende Funktionen erweitert:

- Auswahl eigener Blueprint-Gebäude.
- Auswahl importierter Community-Gebäude.
- Auswahl freigegebener Gildengebäude.
- Vorschau des ausgewählten Gebäudes.
- Prüfung der Platzierbarkeit.
- Berechnung der Baukosten.
- Platzierung und Baufortschritt.
- Speicherung und Wiederherstellung des Bauzustands.

Der Baumodus muss nicht wissen, ob ein Gebäude aus einem einzigen Mesh oder aus 100 einzelnen Bauteilen besteht.

Er arbeitet ausschließlich mit einer einheitlichen Blueprint-Schnittstelle.

---

# 3. Technische Ausgangslage in Emberwild

Die Implementierung muss auf der tatsächlich vorhandenen Projektarchitektur aufbauen.

Folgende bestehende Dateien wurden im bereitgestellten Projektpaket identifiziert:

| Datei | Bestehende Verantwortung |
|---|---|
| `src/worldsys/buildingBlueprints.js` | Blueprint-Katalog, Gebäudedefinitionen und Zusammensetzung von 3D-Bauteilen |
| `src/worldsys/buildMode.js` | Bestehender Baumodus und Gebäudeverwaltung |
| `src/worldsys/common.js` | Gemeinsame 3D-Asset-Ladefunktionen, Mesh-Klone und Kollisionshelfer |
| `src/ui/buildModeUI.js` | Benutzeroberfläche des Baumodus |
| `src/ui/styles/buildMode.css` | Styling des Baumodus |
| `src/core/assetIndex.js` | Verzeichnis vorhandener Assets |
| `src/worldsys/settlement.js` | Siedlungs- und Gebäudeintegration |

## 3.1 Bestehendes Blueprint-System

`src/worldsys/buildingBlueprints.js` enthält bereits:

- `BUILDING_BLUEPRINTS`
- `BLUEPRINT_CATEGORIES`
- `BLUEPRINT_SVGS`
- `getBlueprintById()`
- `buildBlueprintMeshes()`
- `buildScaffoldingMeshes()`

Die Gebäude werden bereits aus einzelnen Mesh-Bestandteilen zusammengesetzt.

Die vorhandene Funktion `buildBlueprintMeshes()` stellt einen wichtigen Ausgangspunkt für die spätere Building-Assembly dar.

Die Asset-Ladefunktionen befinden sich unter anderem in `src/worldsys/common.js`:

- `loadKit()`
- `kitNode()`
- `nodeParts()`
- `cloneNode()`
- `addCollider()`
- `removeCollider()`

Die vorhandenen GLB-Bibliotheken umfassen unter anderem:

- `assets/models/env_town.glb`
- `assets/models/env_fields.glb`
- `assets/models/env_props.glb`

Die tatsächliche Verfügbarkeit und Struktur einzelner Assets muss anhand der vollständigen lokalen Projektdateien überprüft werden. Das bereitgestellte ZIP enthält nicht sämtliche großen Asset-Dateien.

## 3.2 Wichtige Vorgabe

Vor der Implementierung muss der Agent die vollständigen vorhandenen Klassen, Methoden, Datenstrukturen und Aufrufwege untersuchen.

Es darf keine zweite, parallel arbeitende Gebäudearchitektur entstehen.

Vorhandene Funktionen sollen erweitert und sinnvoll abstrahiert werden.

Bestehende Gebäude, Platzierungsmechanismen, Baufortschritte, Kollisionen und Savegame-Daten müssen erhalten bleiben.

---

# 4. Building Workshop – Funktionskonzept

## 4.1 Allgemeines

Der Building Workshop ist ein eigenständiges Werkzeug außerhalb des regulären Baumodus.

Er bietet eine separate Arbeitsfläche, in der Spieler Gebäude aus freigegebenen Bauteilen zusammenstellen können.

Die Oberfläche soll zur Dark-Fantasy-Ästhetik von Emberwild passen:

- Dunkle Oberflächen.
- Bronze- und Goldakzente.
- Klare, gut lesbare Bedienelemente.
- Eine große zentrale 3D-Arbeitsfläche.
- Kompakte Werkzeugleisten.
- Keine unnötig überladene Benutzeroberfläche.

## 4.2 Aufbau der Arbeitsoberfläche

Empfohlene Bereiche:

**Linke Seitenleiste – Bauteilkatalog**

- Fundamente
- Bodenplatten
- Wände
- Eckelemente
- Fenster
- Türen
- Dächer
- Dachkanten
- Balken und Stützen
- Treppen
- Türme
- Mauern
- Dekoration
- Beleuchtung

Die verfügbaren Kategorien werden dynamisch aus der Asset-Bibliothek abgeleitet.

Nicht vorhandene Kategorien dürfen nicht mit erfundenen Assets gefüllt werden.

**Zentrale Arbeitsfläche**

- 3D-Ansicht des Gebäudes.
- Frei bewegliche Kamera.
- Zoom und Rotation.
- Raster und Platzierungshilfen.
- Auswahl einzelner Bauteile.
- Verschieben und Drehen.
- Vorschau der Materialvarianten.
- Undo und Redo.

**Rechte Eigenschaftenleiste**

Bei Auswahl eines Bauteils:

- Asset-Bezeichnung.
- Position X/Y/Z.
- Rotation.
- Zulässige Skalierungsoptionen.
- Materialvariante.
- Bauteilinformationen.
- Löschen und Duplizieren.

Bei Auswahl des gesamten Gebäudes:

- Gebäudename.
- Gebäudekategorie.
- Abmessungen.
- Grundfläche.
- Anzahl der Komponenten.
- Komplexitätswert.
- Geschätzte Baukosten.
- Gebäudebeschreibung.

## 4.3 Bearbeitungsfunktionen

Der Workshop soll folgende Operationen unterstützen:

- Bauteil hinzufügen.
- Bauteil auswählen.
- Bauteil verschieben.
- Bauteil drehen.
- Bauteil duplizieren.
- Bauteil löschen.
- Bauteile gruppieren, sofern technisch sinnvoll.
- Gruppe verschieben und drehen.
- Gebäude speichern.
- Gebäude unter neuem Namen speichern.
- Gebäudeversion aktualisieren.
- Änderungen rückgängig machen.
- Änderungen wiederherstellen.

### Platzierungsraster

Ein optionales Raster erleichtert das Zusammenfügen modularer Bauteile.

Bauteile können an Rasterpunkten oder definierten Verbindungspunkten ausgerichtet werden.

Einzelne Bauteile dürfen nur innerhalb ihrer erlaubten Transformationsgrenzen verändert werden.

Beliebige Skalierungen dürfen nicht automatisch zugelassen werden, da sie Kollisionen, Texturen und Anschlussgeometrien beschädigen können.

## 4.4 Bauteil-Kompatibilität

Die Asset-Bibliothek benötigt Metadaten über die Eigenschaften der einzelnen Bauteile.

Beispielsweise:

- Asset-ID.
- Asset-Datei und Node-Name.
- Kategorie.
- Standardmaßstab.
- Begrenzungsbox.
- Pivot-Punkt.
- Anschluss- beziehungsweise Snap-Punkte.
- Materialvarianten.
- Zulässige Rotationen.
- Zulässige Skalierungsbereiche.
- Kollisionsinformationen.
- Komplexitätswert.
- Freigabestatus.

Der Workshop muss ausschließlich bekannte und freigegebene Asset-IDs akzeptieren.

---

# 5. Building Blueprint System

## 5.1 Grundprinzip

Ein Gebäude ist eine Datenbeschreibung seiner Bauteile und Eigenschaften.

Die eigentliche 3D-Geometrie bleibt Bestandteil der vorhandenen Asset-Bibliothek.

Ein Blueprint speichert lediglich:

- Referenzen auf freigegebene Assets.
- Positionen und Rotationen.
- Zulässige Varianten.
- Gebäudemetadaten.
- Baukosten beziehungsweise Kosteninformationen.
- Komplexitätsinformationen.
- Versionsinformationen.

## 5.2 Beispielstruktur

Das folgende Beispiel beschreibt das gewünschte Datenprinzip. Es ist kein verbindliches fertiges Datenbankschema und muss an die vorhandenen Emberwild-Konventionen angepasst werden.

```javascript
{
    id: 'building_custom_001',

    metadata: {
        name: 'Waldläuferhaus',
        description: 'Ein kleines Haus aus Holz und Stein.',
        category: 'residential',
        tags: ['rustic', 'nordic'],
        authorId: 'player_123',
        visibility: 'private'
    },

    blueprint: {
        formatVersion: 1,

        components: [
            {
                id: 'component_001',
                assetId: 'wall_wood_01',

                position: {
                    x: 0,
                    y: 0,
                    z: 0
                },

                rotation: {
                    x: 0,
                    y: 0,
                    z: 0
                },

                variant: 'default'
            },

            {
                id: 'component_002',
                assetId: 'roof_thatch_02',

                position: {
                    x: 1,
                    y: 3,
                    z: 0
                },

                rotation: {
                    x: 0,
                    y: 0,
                    z: 0
                },

                variant: 'default'
            }
        ]
    },

    technical: {
        componentCount: 2,
        complexity: 3,
        footprint: {
            width: 4,
            depth: 4
        }
    }
}
```

## 5.3 Blueprint-Versionierung

Blueprints benötigen eine eigene Formatversion.

Beispiel:

- `formatVersion: 1`
- `formatVersion: 2`

Änderungen an der Datenstruktur dürfen ältere Baupläne nicht unbrauchbar machen.

Es soll eine zentrale Migrationsstrategie geben.

Nicht mehr unterstützte Asset-IDs müssen erkannt werden. Der Import darf fehlende Bauteile nicht stillschweigend durch beliebige andere Modelle ersetzen.

Stattdessen muss eine verständliche Fehlermeldung angezeigt werden.

## 5.4 Trennung von Blueprint und Gebäudeinstanz

Es muss eine klare Unterscheidung geben:

**Blueprint**

Die wiederverwendbare Bauanleitung.

**Building Instance**

Das tatsächlich in der Spielwelt errichtete Gebäude.

Eine Gebäudeinstanz enthält zusätzlich:

- Weltposition.
- Rotation.
- Besitzer.
- Siedlungszuordnung.
- Baufortschritt.
- Zustand.
- Gebäudestufe.
- Ressourcenverbrauch.
- Interaktionszustände.
- Multiplayer-Identität.

Änderungen an einem Blueprint dürfen bestehende Gebäudeinstanzen nicht automatisch verändern.

Ein Spieler kann einen Blueprint aktualisieren, ohne dadurch bereits errichtete Gebäude zu verändern.

---

# 6. Building Assembly und Rendering

## 6.1 Eigenständige Assembly-Schicht

Die Zusammensetzung der Gebäude soll in einer eigenständigen technischen Schicht erfolgen.

Diese Schicht übernimmt:

1. Blueprint einlesen.
2. Blueprint validieren.
3. Asset-Referenzen auflösen.
4. Benötigte Asset-Bibliotheken laden.
5. Bauteile klonen.
6. Transformationen anwenden.
7. Materialien und Varianten setzen.
8. Bauteile gruppieren.
9. Kollisionsrepräsentation erstellen.
10. Ergebnis an den jeweiligen Aufrufer zurückgeben.

Die vorhandene Funktion `buildBlueprintMeshes()` soll zunächst untersucht werden.

Wenn sie diese Aufgaben bereits ausreichend abdeckt, soll sie erweitert und nicht unnötig ersetzt werden.

## 6.2 Wiederverwendung von Geometrien

Identische Bauteile sollen möglichst dieselben Geometrie- und Materialressourcen verwenden.

Geometrien dürfen nicht für jede Gebäudeinstanz vollständig kopiert werden, wenn eine gemeinsame Nutzung möglich ist.

Three.js bietet dafür unter anderem:

- `THREE.InstancedMesh`
- gemeinsame `BufferGeometry`
- gemeinsame Materialien
- gruppierte Meshes

Instancing soll vor allem für häufig wiederholte Bauteile eingesetzt werden.

Beispiele:

- Wände.
- Dächer.
- Fenster.
- Säulen.
- Zäune.
- Balken.
- Standarddekoration.

Die Implementierung muss Materialunterschiede, Schatten, Beleuchtung und individuelle Objektzustände berücksichtigen.

Nicht jedes Mesh eignet sich automatisch für Instancing.

## 6.3 LOD und Sichtbarkeitsmanagement

Die Darstellung muss abhängig von Entfernung und Sichtbarkeit optimiert werden.

Vorgesehene Darstellungsstufen:

| Stufe | Darstellung |
|---|---|
| LOD 0 | Vollständiges Gebäude mit allen relevanten Details |
| LOD 1 | Vereinfachte Geometrie |
| LOD 2 | Stark vereinfachtes Gebäude |
| LOD 3 | Sehr einfache Gebäuderepräsentation oder keine Darstellung |

Die tatsächlichen Entfernungen müssen durch Profiling ermittelt werden.

Zusätzlich:

- Frustum Culling.
- Distance Culling.
- Sichtbarkeitsmanagement.
- Bereichsweises Laden und Entladen.
- Vermeidung unnötiger Materialwechsel.
- Begrenzung der gleichzeitig aktiven Detailobjekte.

## 6.4 Kollisionssystem

Nicht jedes einzelne Bauteil benötigt einen eigenen komplexen Collider.

Stattdessen soll ein Gebäude eine vereinfachte Kollisionsrepräsentation besitzen.

Sonderfälle:

- Türen benötigen eigene Interaktions- und Kollisionszustände.
- Tore können dynamische Kollisionszustände benötigen.
- Interaktive Objekte erhalten gezielte Collider.
- Dekorationen benötigen nur dann Kollisionen, wenn sie spielerisch relevant sind.

Die bestehende Kollisionsarchitektur in `src/worldsys/common.js` muss dabei berücksichtigt werden.

---

# 7. Performance- und Komplexitätsmanagement

## 7.1 Grundproblem

In einem Multiplayer-Spiel können über die Zeit sehr viele individuelle Gebäude entstehen.

Eine unbegrenzte Anzahl von Bauteilen, Materialien, Interaktionen und Kollidern kann zu erheblichen Performanceproblemen führen.

Dabei ist nicht allein die Anzahl der Gebäude entscheidend.

Relevant sind unter anderem:

- Anzahl der sichtbaren Gebäude.
- Anzahl der gleichzeitig sichtbaren Meshes.
- Draw Calls.
- Polygonanzahl.
- Materialvielfalt.
- Anzahl der Collider.
- Interaktive Komponenten.
- Schattenwerfer.
- Beleuchtungsobjekte.
- Speicherbedarf.
- Netzwerkübertragung.
- Häufigkeit von Zustandsänderungen.

## 7.2 Building Complexity Budget

Jedes Gebäude erhält einen berechneten Komplexitätswert.

Dieser Wert ergibt sich aus den verwendeten Bauteilen und ihren Eigenschaften.

Beispielhafte Startwerte für einen Prototyp:

| Bauteil | Beispielpunkte |
|---|---:|
| Einfache Wand | 1 |
| Dachsegment | 2 |
| Fenster | 1 |
| Tür | 3 |
| Interaktives Tor | 5 |
| Beleuchtung | 2 |
| Komplexe Dekoration | 3 |

Ein Gebäude erhält daraus einen Gesamtwert.

Die Werte sind zunächst ausschließlich Testwerte. Sie müssen durch Messungen an tatsächlichen Emberwild-Assets angepasst werden.

## 7.3 Mögliche Limits

Konfigurierbare Grenzen:

- Maximale Bauteilanzahl pro Gebäude.
- Maximale Komplexität pro Gebäude.
- Maximale Materialvarianten.
- Maximale Anzahl interaktiver Komponenten.
- Maximale Gebäudegrundfläche.
- Maximale Anzahl komplexer Beleuchtungsobjekte.
- Maximales Komplexitätsbudget pro Siedlung.
- Maximales Komplexitätsbudget pro Gebiet.

Die Grenzen müssen zentral konfigurierbar sein.

Es dürfen keine unkoordinierten Zahlenwerte an unterschiedlichen Stellen im Code entstehen.

## 7.4 Keine unnötigen Einschränkungen

Das System soll kreative Freiheit ermöglichen.

Die Limits sollen nicht pauschal verhindern, dass Spieler große oder aufwendige Gebäude erstellen.

Stattdessen sollen die Kosten für technische Komplexität nachvollziehbar sein.

Ein Gebäude mit 100 einfachen Bauteilen kann beispielsweise weniger problematisch sein als eines mit 30 aufwendigen interaktiven Bauteilen.

## 7.5 Performance-Profile

Es sollen später unterschiedliche Server- und Clientprofile möglich sein.

Beispielsweise:

- Standard.
- Performance.
- High Detail.

Die Profile dürfen die tatsächlichen Spielregeln nicht unkontrolliert verändern.

Sie steuern primär die Darstellungsqualität und gegebenenfalls serverseitige Baukomplexitätsgrenzen.

---

# 8. Community Building Library

## 8.1 Ziel

Die Community Building Library ist eine globale Bibliothek für veröffentlichte Gebäudeentwürfe.

Sie soll unabhängig von einzelnen Spielservern funktionieren.

Spieler können dort eigene Bauwerke veröffentlichen und Bauwerke anderer Spieler entdecken und importieren.

## 8.2 Kategorien

Folgende Kategorien sind vorgesehen:

| Kategorie-ID | Bezeichnung | Beispiele |
|---|---|---|
| `residential` | Wohngebäude | Hütten, Häuser, Villen |
| `production` | Produktion | Schmieden, Sägewerke, Mühlen |
| `agriculture` | Landwirtschaft | Bauernhöfe, Ställe, Scheunen |
| `trade` | Handel | Märkte, Tavernen, Kontore |
| `defense` | Verteidigung | Wachtürme, Mauern, Bastionen |
| `community` | Gemeinschaft | Rathäuser, Hallen, Versammlungsorte |
| `monument` | Monumente | Statuen, Schreine, Denkmäler |
| `decoration` | Dekoration | Brunnen, Pavillons, Gärten |
| `other` | Sonstiges | Weitere Bauwerke |

Die Kategorien sollen zentral definiert werden.

## 8.3 Tags

Zusätzlich zu Kategorien sollen Spieler Tags vergeben können.

Beispiele:

- Rustikal.
- Nordisch.
- Mittelalterlich.
- Düster.
- Adel.
- Einfach.
- Aufwendig.
- Kompakt.
- Groß.
- Befestigt.
- Landwirtschaftlich.

Tags dürfen nicht beliebig unbegrenzt angelegt werden.

Eine zentrale Liste sowie eine kontrollierte Erweiterungsmöglichkeit sind vorzusehen.

## 8.4 Suche und Filter

Die Bibliothek soll folgende Filter unterstützen:

- Gebäudekategorie.
- Gebäudestil.
- Tags.
- Größe.
- Komplexität.
- Materialbedarf.
- Ersteller.
- Beliebtheit.
- Bewertung.
- Veröffentlichungsdatum.
- Aktualisierungsdatum.

Sortierungen:

- Neueste.
- Beliebteste.
- Höchstbewertete.
- Meistimportierte.
- Zuletzt aktualisierte.
- Empfehlungen.

Die Suche muss serverseitig paginiert werden.

Es dürfen nicht sämtliche Blueprint-Datensätze gleichzeitig an den Client übertragen werden.

## 8.5 Gebäudedetailseite

Jedes öffentliche Gebäude erhält eine Detailansicht.

Inhalte:

**Allgemein**

- Gebäudename.
- Beschreibung.
- Kategorie.
- Tags.
- Ersteller.
- Veröffentlichungsdatum.
- Aktualisierungsdatum.

**Vorschau**

- Vorschaubild.
- 3D-Vorschau.
- Drehbare Kamera.
- Zoom.
- Optional verschiedene Ansichten.

**Technische Informationen**

- Bauteilanzahl.
- Komplexitätswert.
- Abmessungen.
- Grundfläche.
- Materialbedarf.
- Kompatibilitätsstatus.
- Blueprint-Version.

**Community**

- Bewertungen.
- Favoriten.
- Importanzahl.
- Erstellerprofil.
- Meldemöglichkeit.

## 8.6 Importprozess

Der Import übernimmt den Blueprint in die persönliche Blueprint-Bibliothek des Spielers.

Er errichtet das Gebäude nicht automatisch in der Spielwelt.

Ablauf:

1. Spieler öffnet einen Gebäudeentwurf.
2. Spieler prüft Vorschau und technische Informationen.
3. Spieler wählt Importieren.
4. Server beziehungsweise zuständige Bibliothekslogik validiert den Blueprint.
5. Blueprint wird in die persönliche Bibliothek übernommen.
6. Gebäude erscheint im regulären Baumodus zur Auswahl.

Importierte Baupläne müssen als Kopie behandelt werden.

Änderungen am Original dürfen nicht automatisch Änderungen an importierten Kopien auslösen.

Die ursprüngliche Urheberschaft muss trotzdem nachvollziehbar bleiben.

---

# 9. Veröffentlichungs- und Rechteverwaltung

## 9.1 Sichtbarkeit

Jeder Blueprint besitzt eine Sichtbarkeitseinstellung.

| Sichtbarkeit | Zugriff |
|---|---|
| `private` | Nur der Ersteller |
| `guild` | Berechtigte Mitglieder der eigenen Gilde |
| `public` | Alle berechtigten Emberwild-Spieler |

Zusätzlich soll eine Veröffentlichung zurückgezogen werden können.

Zurückgezogene Bauwerke können für bereits erfolgte Importe weiterhin lokal verfügbar bleiben, sofern keine technischen oder rechtlichen Gründe dagegen sprechen.

## 9.2 Veröffentlichungsprozess

1. Spieler erstellt ein Gebäude.
2. Spieler speichert den Blueprint.
3. Spieler ergänzt Metadaten.
4. Spieler erstellt eine Vorschau.
5. Spieler wählt die Sichtbarkeit.
6. Blueprint wird technisch validiert.
7. Bei öffentlicher Veröffentlichung erfolgt eine serverseitige Prüfung.
8. Bei erfolgreicher Prüfung wird der Blueprint in der Bibliothek veröffentlicht.

## 9.3 Ersteller und Urheberschaft

Der ursprüngliche Ersteller muss dauerhaft nachvollziehbar sein.

Ein importierter Blueprint darf nicht einfach als eigene Originalkreation erneut veröffentlicht werden.

Dafür sind mindestens folgende Informationen erforderlich:

- Originalautor.
- Original-Blueprint-ID.
- Importquelle.
- Ursprüngliche Version.
- Eigene Bearbeitung.
- Veröffentlichungsstatus.

Wenn ein Spieler einen importierten Blueprint verändert und erneut veröffentlicht, muss die Beziehung zum Original erhalten bleiben.

## 9.4 Bewertungen

Spieler können Gebäude bewerten und favorisieren.

Bewertungssystem:

- Ein Bewertungssystem mit klar definierter Skala.
- Nur angemeldete Spieler dürfen bewerten.
- Eine Bewertung pro Spieler und Blueprint.
- Aktualisierung der eigenen Bewertung möglich.
- Missbrauchsschutz gegen wiederholte Manipulation.

Downloads beziehungsweise Importe sollen nicht automatisch mit einer positiven Bewertung gleichgesetzt werden.

## 9.5 Moderation

Die Bibliothek benötigt:

- Meldesystem.
- Zurückziehen eigener Veröffentlichungen.
- Moderationsstatus.
- Sperrung problematischer Baupläne.
- Nachvollziehbare Moderationsentscheidungen.
- Schutz gegen Spam und automatisierte Massenveröffentlichungen.

---

# 10. Guild Building Library

## 10.1 Ziel

Jede Gilde erhält eine eigene Architektur-Bibliothek.

Sie dient als gemeinsamer Bestand an Bauplänen, die innerhalb der Gilde verwendet werden können.

## 10.2 Funktionen

- Gildeninterne Gebäude veröffentlichen.
- Gebäude importieren.
- Favoriten verwalten.
- Architektur-Sammlungen anlegen.
- Gebäude für bestimmte Rollen freigeben.
- Gebäude für bestimmte Gildenprojekte bereitstellen.
- Eigene Baustandards entwickeln.

## 10.3 Berechtigungen

Die Gildenbibliothek muss das vorhandene Emberwild-Berechtigungssystem berücksichtigen.

Mögliche Berechtigungen:

- Gebäude ansehen.
- Gebäude importieren.
- Gebäude veröffentlichen.
- Gebäude bearbeiten.
- Gebäude entfernen.
- Bibliothek verwalten.

Die konkreten Rollen dürfen nicht unabhängig vom bestehenden Gildensystem neu erfunden werden.

Die Integration muss anhand der vorhandenen Rollen- und Berechtigungsarchitektur erfolgen.

## 10.4 Gildenarchitektur

Eine Gilde kann beispielsweise einen eigenen Baustil definieren.

Beispiele:

- Einheitliche Wachtürme.
- Einheitliche Außenposten.
- Einheitliche Produktionsgebäude.
- Einheitliche Wohngebäude.
- Besondere Gebäude für Hauptsiedlungen.

Damit kann eine Gilde über verschiedene Provinzen hinweg einen wiedererkennbaren architektonischen Stil entwickeln.

---

# 11. Erweiterung des bestehenden Baumodus

## 11.1 Grundsatz

Der bestehende Baumodus wird nicht durch den Building Workshop ersetzt.

Er erhält eine zusätzliche Möglichkeit, eigene und importierte Gebäude auszuwählen.

## 11.2 Neue Blueprint-Auswahl

Der Spieler soll zwischen folgenden Quellen wählen können:

- Emberwild-Standardgebäude.
- Eigene Gebäude.
- Importierte Community-Gebäude.
- Gildengebäude.

Die bestehende Blueprint-Kategorisierung soll dabei weiterhin funktionieren.

## 11.3 Platzierung

Nach der Auswahl eines Blueprints wird das Gebäude über den vorhandenen Platzierungsmechanismus dargestellt.

Der bestehende Baumodus übernimmt weiterhin:

- Ghost Preview.
- Rotation.
- Terrain-Raycasts.
- Kollisionsprüfung.
- Geländeprüfung.
- Gebietskontrolle.
- Platzierungsvalidierung.
- Baukosten.
- Baustellengerüst.
- Baufortschritt.
- Fertigstellung.
- Abriss.
- Versetzen bestehender Gebäude.
- Persistenz.

Die vorhandenen Funktionen müssen erhalten bleiben.

## 11.4 Einheitliche Blueprint-Schnittstelle

Der Baumodus soll keine Sonderlogik für Community-Gebäude benötigen.

Jeder gültige Blueprint muss über dieselbe Schnittstelle geladen und platziert werden können.

Die Herkunft des Blueprints darf die eigentliche Platzierungslogik nicht beeinflussen.

Die Berechtigung, die Baukosten und die Platzierungsbedingungen werden separat geprüft.

---

# 12. Multiplayer-Architektur

## 12.1 Grundprinzip

Die Architektur muss strikt zwischen serverseitigen Spieldaten und clientseitiger Darstellung unterscheiden.

Der Server verwaltet den autoritativen Zustand.

Der Client übernimmt die visuelle Darstellung und lokale Optimierung.

## 12.2 Serverseitige Verantwortung

Der Server verwaltet:

- Blueprint-Referenzen.
- Gebäudeinstanzen.
- Besitzer.
- Gilden- und Berechtigungsinformationen.
- Weltposition.
- Rotation.
- Baufortschritt.
- Ressourcenverbrauch.
- Gebäudestatus.
- Interaktionen.
- Persistenz.
- Komplexitätslimits.
- Platzierungsvalidierung.

Der Server darf nicht auf die vom Client behauptete Gültigkeit eines Blueprints vertrauen.

## 12.3 Clientseitige Verantwortung

Der Client übernimmt:

- Laden der GLB-Assets.
- Auflösen der Asset-Referenzen.
- Zusammensetzen der Meshes.
- Materialdarstellung.
- Beleuchtung.
- LOD.
- Frustum Culling.
- Distance Culling.
- Instancing.
- Darstellung der Ghost Preview.
- Visuelle Animationen.
- Lokale Darstellung der Interaktionen.

## 12.4 Netzwerkübertragung

Über das Netzwerk werden keine vollständigen Mesh-Geometrien übertragen.

Übertragen werden lediglich:

- Blueprint-ID beziehungsweise validierte Blueprint-Daten.
- Gebäudeinstanz-ID.
- Weltposition.
- Rotation.
- Zustand.
- Baufortschritt.
- Relevante Änderungen.

Die Asset-Geometrien werden aus der lokal vorhandenen Emberwild-Asset-Bibliothek geladen.

## 12.5 Multiplayer-Welten

Die Community Building Library ist global verfügbar und unabhängig von einzelnen Spielwelten.

Ein Spieler kann einen Blueprint auf einer Welt erstellen und ihn auf einer anderen Welt importieren, sofern die dortigen Regeln dies erlauben.

Die tatsächlichen Gebäudeinstanzen bleiben vollständig an die jeweilige Spielwelt gebunden.

Nicht übertragen werden:

- Gebäudeinstanzen.
- Besitzverhältnisse.
- Siedlungszugehörigkeiten.
- Ressourcenbestände.
- Baufortschritte.
- Weltzustände.

Ein Blueprint ist lediglich ein wiederverwendbarer Entwurf.

---

# 13. Sicherheit und Validierung

Alle importierten und veröffentlichten Baupläne müssen serverseitig validiert werden.

## 13.1 Asset-Validierung

Jedes Bauteil muss:

- Eine bekannte Asset-ID besitzen.
- In der freigegebenen Asset-Bibliothek existieren.
- Für die betreffende Blueprint-Version zulässig sein.
- Zulässige Transformationen verwenden.
- Gültige Varianten referenzieren.

Unbekannte Assets müssen abgelehnt werden.

## 13.2 Transformationsvalidierung

Prüfen:

- Endliche numerische Werte.
- Zulässige Positionen.
- Zulässige Rotationen.
- Zulässige Skalierung.
- Maximale Abmessungen.
- Maximale Grundfläche.
- Keine NaN- oder Infinity-Werte.
- Keine unerlaubten Transformationen.

## 13.3 Komplexitätsvalidierung

Prüfen:

- Maximale Komponentenanzahl.
- Gesamtkomplexität.
- Materialanzahl.
- Interaktive Komponenten.
- Beleuchtungsobjekte.
- Maximale Gebäudedimensionen.

## 13.4 Schutz vor Manipulation

Blueprints dürfen keine ausführbaren Skripte enthalten.

Es dürfen keine externen Mesh-Dateien oder beliebigen URLs übermittelt werden.

Die Bibliothek akzeptiert ausschließlich validierte Asset-Referenzen.

Der Client darf weder seine Berechtigungen noch die Komplexitätsgrenzen selbst bestimmen.

## 13.5 Platzierungsvalidierung

Beim tatsächlichen Bau muss der Server prüfen:

- Gehört das Gebiet zum zulässigen Baugebiet?
- Ist der Spieler berechtigt?
- Sind die Baukosten vorhanden?
- Ist die Position zulässig?
- Gibt es unerlaubte Überschneidungen?
- Ist das Gebäude innerhalb der zulässigen Dimensionen?
- Ist das Komplexitätsbudget der Siedlung ausreichend?
- Sind die Voraussetzungen der jeweiligen Gebäudeart erfüllt?

---

# 14. Datenhaltung und Persistenz

Die konkrete Datenbank- und Speichertechnologie muss anhand der vorhandenen Emberwild-Architektur festgelegt werden.

Es werden logisch getrennte Datenbereiche benötigt.

## 14.1 Persönliche Blueprint-Bibliothek

Speichert:

- Eigene Entwürfe.
- Importierte Entwürfe.
- Favoriten.
- Versionen.
- Sichtbarkeit.
- Bearbeitungsstatus.

## 14.2 Community Building Library

Speichert:

- Öffentliche Blueprints.
- Metadaten.
- Erstellerinformationen.
- Kategorien.
- Tags.
- Bewertungen.
- Importstatistiken.
- Moderationsstatus.
- Versionen.

## 14.3 Guild Building Library

Speichert:

- Gilden-Blueprints.
- Gildenzugehörigkeit.
- Freigaben.
- Berechtigungen.
- Versionen.
- Sammlungen.

## 14.4 World Building Instances

Speichert für jede Spielwelt:

- Gebäudeinstanz-ID.
- Blueprint-Referenz.
- Gegebenenfalls verwendete Blueprint-Version.
- Weltposition.
- Rotation.
- Besitzer.
- Siedlungszuordnung.
- Baufortschritt.
- Gebäudestatus.
- Interaktionszustände.

Die globalen Bibliotheksdaten dürfen nicht mit den lokalen Gebäudeinstanzen vermischt werden.

---

# 15. Erweiterbarkeit und zukünftige Funktionen

Das System soll spätere Erweiterungen ermöglichen, ohne die Kernarchitektur neu aufzubauen.

Mögliche Erweiterungen:

- Architektur-Wettbewerbe.
- Empfehlungen der Woche.
- Community-Auszeichnungen.
- Gildeninterne Bauprojekte.
- Gebäudesammlungen.
- Architekturpakete.
- Saisonale Bauwerke.
- Vorlagen für Außenposten.
- Vorlagen für Handelsstationen.
- Vorgefertigte Siedlungsensembles.
- Import mehrerer Gebäude als zusammenhängendes Bauprojekt.
- Gebäudestufen und Ausbauvarianten.
- Community-Profile für Architekten.

Diese Funktionen sind zunächst nicht Bestandteil des MVP.

---

# 16. Vorgeschlagene technische Modulstruktur

Die folgenden Modulnamen sind Architekturvorschläge.

Vor ihrer Anlage muss geprüft werden, ob entsprechende Verantwortlichkeiten bereits existieren.

Bestehende Funktionen haben Vorrang vor redundanten Neuentwicklungen.

## 16.1 Building Workshop

Mögliche Module:

- `BuildingWorkshopManager`
- `BuildingWorkshopUI`
- `BuildingEditor`
- `BuildingComponentCatalog`
- `BuildingSnapSystem`
- `BuildingBlueprintSerializer`
- `BuildingBlueprintValidator`

## 16.2 Building Runtime

Mögliche Module:

- `BuildingAssemblyManager`
- `BuildingRenderManager`
- `BuildingLODManager`
- `BuildingInstanceManager`
- `BuildingCollisionManager`
- `BuildingComplexityManager`

## 16.3 Bibliotheken

Mögliche Module:

- `PersonalBuildingLibrary`
- `CommunityBuildingLibrary`
- `GuildBuildingLibrary`
- `BuildingPublicationManager`
- `BuildingImportManager`
- `BuildingRatingManager`
- `BuildingModerationManager`

## 16.4 Multiplayer

Mögliche Module:

- `BuildingNetworkManager`
- `BuildingAuthorityValidator`
- `BuildingPermissionManager`
- `BuildingPersistenceManager`

Die tatsächliche Modulaufteilung soll erst nach Analyse der bestehenden Projektarchitektur festgelegt werden.

Nicht jedes vorgeschlagene Modul muss zwingend eine eigene Datei oder Klasse werden.

---

# 17. Implementierungsphasen

Die Umsetzung erfolgt schrittweise.

Es darf nicht versucht werden, alle vier Systembereiche gleichzeitig vollständig zu implementieren.

## Phase 0 – Bestandsaufnahme

Ziel: Bestehendes System vollständig verstehen.

Aufgaben:

1. `buildingBlueprints.js` vollständig analysieren.
2. `buildMode.js` vollständig analysieren.
3. `common.js` vollständig analysieren.
4. `buildModeUI.js` vollständig analysieren.
5. Gebäudedefinitionen und Asset-Referenzen untersuchen.
6. Vorhandene Platzierungs-, Kollisions- und Speicherlogik untersuchen.
7. Abhängigkeiten zu `settlement.js` erfassen.
8. Vorhandene Asset-Struktur und Node-Namen untersuchen.
9. Bestehende Savegame-Daten untersuchen.
10. Technische Risiken dokumentieren.

**Ergebnis:** Ein belastbares Architektur- und Änderungsdokument.

## Phase 1 – Blueprint-Architektur stabilisieren

Ziel: Eine einheitliche Blueprint-Grundlage schaffen.

Aufgaben:

- Blueprint-Datenstruktur festlegen.
- Formatversion einführen.
- Asset-Referenzen standardisieren.
- Validierung implementieren.
- Komplexitätsberechnung vorbereiten.
- Blueprint-Serialisierung und Deserialisierung implementieren.
- Bestehende Gebäude kompatibel halten.

**Ergebnis:** Standardisierte und validierbare Gebäude-Blueprints.

## Phase 2 – Building Workshop MVP

Ziel: Eigene Gebäude lokal erstellen können.

Aufgaben:

- Eigenständige Arbeitsoberfläche.
- Asset-Katalog.
- 3D-Arbeitsfläche.
- Bauteile hinzufügen.
- Bauteile verschieben.
- Bauteile drehen.
- Bauteile löschen.
- Undo und Redo.
- Gebäude speichern.
- Gebäude laden.
- Blueprint-Vorschau.
- Komplexitätsanzeige.

Zunächst ausschließlich lokale beziehungsweise persönliche Blueprints.

**Ergebnis:** Spieler können eigene Gebäude entwerfen und speichern.

## Phase 3 – Integration in den Baumodus

Ziel: Eigene Gebäude im Spiel verwenden.

Aufgaben:

- Persönliche Blueprint-Bibliothek anbinden.
- Blueprint-Auswahl im bestehenden Baumodus ergänzen.
- Ghost Preview integrieren.
- Bestehende Platzierungsprüfung verwenden.
- Baukosten berechnen.
- Baufortschritt integrieren.
- Gebäudeinstanzen speichern.
- Bestehende Standardgebäude erhalten.

**Ergebnis:** Eigene Gebäude können regulär in Emberwild errichtet werden.

## Phase 4 – Performance und Building Runtime

Ziel: Große Mengen individueller Gebäude effizient darstellen.

Aufgaben:

- Mesh-Wiederverwendung.
- Instancing.
- Materialoptimierung.
- LOD.
- Distance Culling.
- Frustum Culling.
- Vereinfachte Kollisionsmodelle.
- Komplexitätslimits.
- Performance-Messungen.

**Ergebnis:** Belastbare Darstellungsarchitektur für umfangreiche Siedlungen.

## Phase 5 – Community Building Library

Ziel: Gebäude öffentlich teilen und importieren.

Aufgaben:

- Bibliotheksdatenmodell.
- Veröffentlichung.
- Serverseitige Validierung.
- Suche und Filter.
- Gebäudedetailseiten.
- Vorschau.
- Import.
- Favoriten.
- Bewertungen.
- Moderation.
- Versionierung.

**Ergebnis:** Globale Community-Bibliothek.

## Phase 6 – Guild Building Library

Ziel: Gemeinsame Architektur innerhalb von Gilden.

Aufgaben:

- Gildenbibliothek.
- Integration der vorhandenen Gildenidentität.
- Berechtigungen.
- Freigaben.
- Gildeninterne Sammlungen.
- Verwaltung und Versionierung.

**Ergebnis:** Gilden können eigene Baupläne verwalten und teilen.

## Phase 7 – Multiplayer-Härtung

Ziel: Das System für den dauerhaften Multiplayer-Betrieb absichern.

Aufgaben:

- Autoritative Servervalidierung.
- Netzwerkübertragung.
- Synchronisierung.
- Persistenz.
- Bereichsweises Laden.
- Rechteprüfung.
- Manipulationsschutz.
- Lasttests.
- Wiederherstellung nach Verbindungsabbrüchen.

**Ergebnis:** Multiplayerfähiges Gebäudesystem.

---

# 18. Test- und Qualitätsanforderungen

Jede Implementierungsphase muss überprüfbare Ergebnisse liefern.

## 18.1 Funktionstests

- Gebäude erstellen.
- Gebäude speichern.
- Gebäude laden.
- Gebäude bearbeiten.
- Gebäude duplizieren.
- Gebäude importieren.
- Gebäude veröffentlichen.
- Gebäude zurückziehen.
- Gebäude platzieren.
- Gebäude wiederherstellen.
- Alte Blueprints laden.

## 18.2 Performance-Tests

Testfälle mit:

- Vielen identischen Gebäuden.
- Vielen unterschiedlichen Gebäuden.
- Sehr vielen wiederholten Bauteilen.
- Komplexen Gebäuden.
- Vielen interaktiven Bauteilen.
- Großen Siedlungen.
- Gebäuden in unterschiedlichen Sichtweiten.

Messwerte:

- Draw Calls.
- FPS.
- Frame Time.
- Speicherbedarf.
- Anzahl aktiver Meshes.
- Anzahl aktiver Collider.
- Ladezeiten.
- Netzwerkdatenmenge.

Die tatsächlichen Grenzwerte müssen durch Messungen auf repräsentativer Hardware ermittelt werden.

## 18.3 Multiplayer-Tests

- Mehrere Spieler platzieren Gebäude gleichzeitig.
- Zwei Spieler greifen auf denselben Blueprint zu.
- Ein Spieler importiert einen Blueprint während einer Veröffentlichung.
- Ein Spieler versucht einen manipulierten Blueprint zu veröffentlichen.
- Ein Spieler versucht fremde Gebäude zu bearbeiten.
- Gildenberechtigungen werden geprüft.
- Verbindungsabbrüche während einer Platzierung werden behandelt.
- Gebäude bleiben nach Serverneustart erhalten.

## 18.4 Kompatibilität

- Bestehende Emberwild-Standardgebäude funktionieren weiterhin.
- Bestehende Savegames bleiben kompatibel.
- Fehlende Assets führen zu kontrollierten Fehlern.
- Veraltete Blueprint-Versionen werden erkannt.
- Unbekannte Asset-IDs werden abgelehnt.

---

# 19. Nicht-Ziele des ersten Entwicklungsstands

Folgende Funktionen sollen zunächst ausdrücklich nicht umgesetzt werden:

- Import beliebiger externer GLB-, GLTF- oder OBJ-Dateien durch Spieler.
- Eigene Mesh-Erstellung innerhalb des Building Workshop.
- Skriptfähige Bauteile.
- Beliebige externe Materialien oder Texturen.
- Automatische Übertragung von Gebäuden zwischen Spielwelten.
- Vollständige Architektur-Wettbewerbe.
- Komplexe Community-Marktplatzmechaniken.
- Monetarisierung von Gebäudeentwürfen.
- Automatische Änderungen bereits errichteter Gebäude nach Blueprint-Aktualisierungen.

Diese Funktionen können später separat bewertet werden.

---

# 20. Verbindliche Entwicklungsregeln für den KI-Agenten

Bei der Umsetzung sind folgende Regeln einzuhalten:

1. Vor jeder Änderung die vorhandene Implementierung untersuchen.
2. Bestehende Systeme erweitern, nicht unnötig ersetzen.
3. Keine parallelen Blueprint-Systeme erzeugen.
4. Bestehende Gebäude und ihre Funktionen erhalten.
5. Keine Mockdaten als tatsächliche Spielmechanik ausgeben.
6. Keine nicht vorhandenen Assets oder Asset-IDs erfinden.
7. Alle neuen Datenstrukturen versionierbar gestalten.
8. Multiplayer-Sicherheit von Beginn an berücksichtigen.
9. Serverseitige Validierung nicht durch Clientprüfungen ersetzen.
10. Performance nicht ausschließlich anhand der Gebäudeanzahl bewerten.
11. Wiederverwendung von Meshes und Materialien bevorzugen.
12. Komplexitätsgrenzen zentral verwalten.
13. Keine unnötigen Abhängigkeiten hinzufügen.
14. Fehlerbehandlung und Debug-Ausgaben implementieren.
15. Bestehende Savegames und Gebäudedefinitionen nicht beschädigen.
16. Jede abgeschlossene Phase mit reproduzierbaren Tests überprüfen.
17. Dokumentation und Kommentare vollständig pflegen.
18. Keine Funktionen als fertig deklarieren, solange ihre Funktionalität nicht nachgewiesen wurde.

Bei Architekturentscheidungen, die sich aus der vorhandenen Codebasis nicht eindeutig ableiten lassen, muss der Agent die offenen Punkte dokumentieren und eine begründete Empfehlung aussprechen.

Er darf nicht stillschweigend Annahmen über die vorhandene Multiplayer-Infrastruktur, Datenbank oder Serverkommunikation treffen.

---

# 21. Erwartetes Endergebnis

Das fertige System soll Spielern vier miteinander verbundene Möglichkeiten bieten:

**1. Eigene Gebäude erstellen**

Im Building Workshop können Spieler individuelle Gebäude aus freigegebenen modularen Bauteilen zusammenstellen.

**2. Eigene Gebäude verwenden**

Der bestehende Baumodus kann diese Gebäude auswählen, prüfen, platzieren und errichten.

**3. Gebäude mit der Community teilen**

In der Community Building Library können Spieler ihre Kreationen veröffentlichen und die Entwürfe anderer Spieler importieren.

**4. Gildenarchitektur entwickeln**

Über die Guild Building Library können Gilden eigene Baustile und Gebäudeentwürfe verwalten und gemeinsam verwenden.

Die technische Grundlage sorgt dafür, dass die Gebäude effizient zusammengesetzt, dargestellt, gespeichert und synchronisiert werden.

---

# 22. Abschließende Architekturentscheidung

Für Emberwild wird ein modulares Gebäudesystem mit einer klaren Trennung zwischen Entwurf, Speicherung, Platzierung und Darstellung angestrebt.

Der Building Workshop ist ein eigenständiges Werkzeug zur Konstruktion individueller Gebäude.

Die Community Building Library und Guild Building Library stellen Baupläne bereit und ermöglichen den Austausch zwischen Spielern.

Der vorhandene Baumodus bleibt für die Errichtung der Gebäude verantwortlich.

Die Building Runtime übernimmt die effiziente Darstellung und Verwaltung der zusammengesetzten Meshes.

**Die zentrale technische Entscheidung lautet: Ein Gebäude ist ein versionierter Blueprint aus freigegebenen Asset-Referenzen. Die tatsächlich dargestellten Meshes werden clientseitig aus der vorhandenen Asset-Bibliothek zusammengesetzt.**

Damit kann Emberwild langfristig eine große Anzahl individueller Gebäude unterstützen, ohne für jedes Gebäude neue Geometrien übertragen oder dauerhaft als eigenständige 3D-Datei speichern zu müssen.

Das System soll Kreativität ermöglichen, die Community einbeziehen und gleichzeitig die technische Kontrolle über die Spielwelt behalten.

**Ende der Spezifikation.**
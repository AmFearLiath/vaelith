# Master-Roadmap: Clean-Room EmberEngine & Ökosystem-Umbau

> [!IMPORTANT]
> **Leitprinzip des Umbaus**: Der Ordner `ASHFALL/` dient ausschließlich als passive Vergleichs- und Referenzbibliothek. Die neue Engine (**EmberEngine**) wird vollständig von Grund auf neu („Clean-Room“) geschrieben – ohne alte Codeartefakte oder simple Umbenennungen. Beide Engines koexistieren nahtlos über die Umschalt-Weiche in `config.json` (`"legacy"` vs. `"ember"`).

```mermaid
flowchart TD
    A["Phase 1: Fundament & Backup (Abgeschlossen)"] --> B["Phase 2: Core-Engine-Neubau (EmberEngine)"]
    B --> C["Phase 3: High-Performance Speicher- & VRAM-Pipeline"]
    C --> D["Phase 4: Trennung Builder (Ingame) vs. Designer (CAD)"]
    D --> E["Phase 5: Tag-Nacht-Zyklus & Organische Weltprogression"]
    E --> F["Phase 6: Bestiarium, Dungeons & Discord-Ökosystem"]
```

---

## 1. Status Quo & Bereits abgeschlossene Meilensteine

* [x] **Versionierter Backup-Manager & Admin-Suite**:
  * Vollautomatisches Backup-Tool ([`tools/backupEngine.mjs`](file:///F:/Emberwild/tools/backupEngine.mjs)) mit striktem Ausschluss von `assets/`, `downloads/`, `ASHFALL/`, `backups/` und sensitiven Keys.
  * Ingame Herrschafts-Panel ([`AdminDashboard.js`](file:///F:/Emberwild/src/admin/adminDashboard.js), Taste `F9`) mit Backups, Benutzerverwaltung, Serverkonfiguration und Live-Konsole.
* [x] **Discord-Authentifizierung & Savegame-Transfer**:
  * Discord-OAuth2-Flow (ohne native Browser-Alerts) direkt integriert.
  * Discord-Profilbild & Nickname im Titelmenü, Pause-Menü und den Spieleinstellungen ([`settingsPanel.js`](file:///F:/Emberwild/src/ui/settingsPanel.js)).
  * Automatische Savegame-Migration: Bestehende Spielstände werden beim Verbinden mit Discord sofort nahtlos transferiert und an die Discord-ID gebunden.
* [x] **Dungeon-Reset & Auto-Loot-Koordination**:
  * Dungeon-Cooldown-Manager ([`dungeonReset.js`](file:///F:/Emberwild/src/worldsys/dungeonReset.js)) mit einstellbaren Reset-Intervallen (15 / 30 Min.).
  * Autonome Begleiter- & Reittier-Beuteaufnahme ([`autoLootCoordinator.js`](file:///F:/Emberwild/src/loot/autoLootCoordinator.js)) ohne Zielkonflikte.

---

## 2. Die nächste Phase: Die neue High-End EmberEngine

### Phase 2.1: Das neue Core-Loop & Rendering-System (`src/engine/`)
1. **Entkopplung von Logik und Rendering**:
   * Feste Logik-Tickrate (z. B. 60 Ticks/s) mit akkumuliertem Zeitdelta, unabhängig von variabler Monitor-Bildwiederholrate (120 Hz, 144 Hz).
   * Verhindert Mikroruckler und ungleichmäßige Physikberechnungen.
2. **Dual-Engine Bootloader ([`src/main.js`](file:///F:/Emberwild/src/main.js))**:
   * Liest `config.json`:
     * `"engine": "legacy"`: Startet die bisherige Architektur.
     * `"engine": "ember"`: Startet den neuen modularen Clean-Room-Engine-Kernel ([`src/engine/emberKernel.js`](file:///F:/Emberwild/src/engine/emberKernel.js)).
   * Ermöglicht risikofreie Entwicklung, Tests und 1:1-Performanzvergleiche im laufenden Betrieb.

### Phase 2.2: VRAM-Management & Freeze-Freie Speicher-Pipeline
1. **Rekursive GPU-Ressourcen-Freigabe (`disposeHierarchy`)**:
   * Beim Entfernen von Gebäuden oder Zonenwechseln werden Geometrien, Texturen und Shadermaterialien gezielt und vollständig aus dem VRAM entladen.
   * Keine kontinuierlich ansteigende GPU-Speicherlast mehr bei langen Spielsessions.
2. **Asynchrones & Debounced Speichern (Web Worker / IndexedDB)**:
   * Das Platzieren von Gebäuden friert das Spiel nicht mehr ein:
   * Daten werden asynchron in Blöcken serialisiert und im Hintergrund geschrieben, anstatt den Hauptthread mit synchronen `localStorage.setItem`-Aufrufen zu blockieren.

---

## 3. Saubere Trennung: Builder vs. Designer

| Kriterium | Ingame-Baumodus (`Builder`) | Architektur-Studio (`Designer`) |
| :--- | :--- | :--- |
| **Ort** | Direkt in der Spielwelt (Emberwatch / Siedlung) | Eigenes Menü-Studio im Hauptmenü |
| **Elemente** | Fertige Gebäude, Wege, Zäune, Pflanzen, Deko | Modulare Wände, Dächer, Stützen, Böden |
| **Freischaltung** | Organisch über Quests & Fortschritt im Spiel | Separat (Meilenstein, Freischaltcode / Feature) |
| **Granularität** | Platzieren, Drehen, Höhenversatz im Grid | Feinste CAD-Strukturierung & Texturierung |

### Erweiterte Features für den Designer:
1. **Multi-Layer Wandstile**:
   * Mehrere Schichten pro Wand: Einstellbare Basishöhe (z. B. Sockel aus Feldstein), vertikale / horizontale Zwischenebenen und Deckebene.
   * Frei wählbare Texturen und Orientierungen (z. B. untere Ebene horizontal, Mittelteil vertikal gestreift, oberer Abschluss horizontal).
2. **PolyHaven CC0 PBR Textur-Pipeline**:
   * Automatisierter Downloader & Materialvorlagen für PBR-Texturen (Albedo, Normal, Roughness, AO).

---

## 4. Gameplay-Ökosystem: Tag-Nacht, Welt- & Dungeon-Generierung & Lore

1. **Dynamischer Tag-Nacht-Zyklus**:
   * Konfigurierbare Zeiteinheiten (Standard: **30 Minuten Tag**, **12 Minuten Nacht**).
   * Fließende Farbtemperatur- und Schattenübergänge (morgendlicher Nebel, goldene Nachmittagssonne, tiefe Mitternachts-Schatten).
   * Nacht-Mechaniken: Fackeln erhellen Siedlungen, nachtaktive Kreaturen durchstreifen die Aschlande.
2. **On-Demand-Siedlungsgenerierung über Map-Daten**:
   * Strikte Trennung von **Burg-System** (Zitadelle, Befestigung, Thronsäle) und **Dorf-System** (Bürgerquartiere, Wirtschaft, Handwerk).
   * Prozedurale Generierung von Städten und Dörfern beim erstmaligen Betreten eines Map-Knotens, skaliert nach der Größe in den Weltkartendaten.
   * **Reservierte Metropolen**: Große Städte sind geschützte PvE-Zentren für Märkte, Tavernen, Unterkünfte, Händler und Haupt-NPCs.
3. **Spieler-Spawn, Spieler-Basis & Dynamische Lore-Quests**:
   * Spieler spawnen zufällig im erlaubten Wildnisgebiet; Quest- und Lore-relevante Städte sind für Spawns gesperrt.
   * Der individuelle Spawnpunkt wird zur **Spieler-Basis**.
   * Quests gehen von der Spieler-Basis aus und wählen umliegende Städte und Dungeons in konfigurierbaren Entfernungs-Radien.
   * Die Namen der generierten Städte und Landmarken werden dynamisch in die Dialoge, Questtexte und die persönliche Lore des Spielers eingewoben.
4. **Organische Progression in Emberwatch**:
   * Start in der leeren, verfallenen Burg Emberwatch.
   * Verrostete Werkzeuge in den Trümmern sammeln, erste Ressourcen schlagen, Feuerstelle errichten.
   * Befreiung des ersten NPCs und Errichtung einer ersten Unterkunft schaltet schrittweise den `Builder` frei.

---

## 5. Konkrete Umsetzungsschritte (Schritt-für-Schritt)

1. [x] **Schritt 1**: Erstellung der `src/engine/`-Struktur mit dem Clean-Room `EmberKernel` (60Hz Tick, entkoppeltes Rendering), GPU-Disposal-Utilities (`disposeHierarchy`) und Bootloader-Weiche in `config.json` / `main.js`.
2. [x] **Schritt 2**: Implementierung der asynchronen Speicher-Pipeline (Beseitigung des Freezes beim Platzieren mit Debounce & IndexedDB-Mirroring).
3. [x] **Schritt 3**: On-Demand Welt- und Siedlungsgenerierung (Burg vs. Dorf, Stadtgrößen-Skalierung, PvE-Metropolen-Reservierung).
4. [x] **Schritt 4**: Spieler-Spawn-System (Basis-Etablierung, Sperrzonen für Spawns, radius-basierte Questverteilung und dynamische Stadt-Lore).
5. [x] **Schritt 5**: Integration des Multi-Layer-Wandsystems in den Designer & PolyHaven CC0 PBR Texturen (Schichten-Stack, vertikale Lamellengruppen, UV-Drehung 0°/90°, Live-WYSIWYG 3D) + HUD Action Bar Redesign & Top-HUD Delta-Indikatoren.
6. [x] **Schritt 6**: Implementierung des Tag-Nacht-Zyklus (`src/engine/environment/dayNightCycle.js`) mit 24h-Progression, orbitaler Sonnen-/Mond-Bahn, dynamischem Licht-, Dunst- & Fackelsystem + Clean-Room GPU-instanzierter Dungeon-Generator (`src/engine/dungeon/`).
7. [ ] **Schritt 7**: Ausgestaltung des Emberwatch-Tutorialstarts mit ersten Quests und NPC-Befreiung.


# Emberwild: 3D-Perspektive, Vertikalität & Treppennavigation
## Konzept & Architektur-Roadmap (Post-Bausystem)

> **Status:** Konzept & Architektur-Blaupause  
> **Priorität:** Nach vollständigem Abschluss des 3D-Bausystems (Phasen 1 & 2)  
> **Fokus:** Echte 3-Dimensionalität, Treppensteigen, vertikale Stadtarchitektur und nahtlose Third-Person-Perspektive  

---

## 1. Vision & Kernphilosophie

*Emberwild* vereint hochkomplexe Rollenspiel-Wirtschaftssimulation, Siedlungsbau und ARPG-Kämpfe.  
Bislang fand die Bewegung der Spielfigur primär auf einer 2D-Ebene (`Y = 0` mit Isometrie-Kamera) statt, während alle Spielmodelle (Zitadelle, Bürgerhäuser, Reittiere, Tiere, Dungeons) bereits vollständige, hochwertige **360-Grad-3D-Meshes** sind.

Das Ziel dieser Erweiterung ist:
1. **Volle Nutzung aller 3 Dimensionen**: Die Spielfigur und NPCs können Höhenunterschiede, Wehrmauern, Treppen, Rampen, Brücken und Wachtürme real erklimmen.
2. **Der nahtlose Hybrid-Modus**:
   * **Herausgezoomt**: Das etablierte isometrische Baustellen- & Taktik-Interface (Übersicht über Siedlung, Ressourcen, Wege und Verteidigungslinien).
   * **Herangezoomt**: Die Kamera senkt sich dynamisch hinter die Schulter des Helden in die **Third-Person-Perspektive**. Der Spieler erlebt sein eigenes gebautes Reich hautnah aus den Augen seines Charakters.

---

## 2. Vertikalität: Treppen, Wehrmauern & Y-Achsen-Physik

### 2.1 Das bisherige Limit vs. Die 3D-Lösung
* **Bisher:** Das Navigationsgitter (`src/core/nav.js`) projiziert Positionen auf eine flache 2D-Ebene. Treppen und Wehrmauern wirkten als blockierende Hindernisse oder flache Texturen.
* **Neu:** Echte Höhenberechnung (`Y-Sampling`) und physikalische Stufenüberwindung.

```
                    ┌──────────────────────────┐  Wehrgang / Zinnen (Y = 4.2m)
                    │  Begehbare Burgmauer    │
            ┌───────┴──────────────────────────┘
            │   ___ Stufe 3 (Y = 3.15m)
        ┌───┴──
        │   ___ Stufe 2 (Y = 2.10m)
    ┌───┴──
    │   ___ Stufe 1 (Y = 1.05m)
────┴────────────────────────────────────────── Boden / Pflasterstein (Y = 0.0m)
```

### 2.2 Treppen-Climber & Stufen-Toleranz
1. **Sanfter Stufen-Climber (`stepHeight = 0.35m`)**:
   * Die Kollisionskapsel des Spielers kann Höhenkanten bis zu 35 cm ohne Sprungtaste automatisch und ruckelfrei hochgleiten (`slideY`).
   * Treppen im Spiel werden entweder mit abgeschrägten unsichtbaren Kollisions-Rampen versehen oder über das Stufen-Sampling direkt abgetastet.
2. **Raycast-Ground-Snapping**:
   * Ein senkrechter Raycast von `pos.y + 1.0m` nach unten ermittelt die exakte Standhöhe auf Treppenstufen, Brücken oder Deckenplatten.
   * Der Held steht immer bündig auf der jeweiligen Stufe, die Schrittgeräusche passen sich dem Material (Stein, Holz) an.
3. **Begehbare Wehrmauern von Emberwatch**:
   * Die monumentale Stadtmauer von Emberwatch erhält an den Innenseiten Aufgangstreppen.
   * Spieler und Bogenschützen-Wachen können oben auf den Zinnen patrouillieren und Angreifer von oben herab bekämpfen.
4. **Kanten- & Fallkontrolle**:
   * Verlässt der Spieler eine Kante (z. B. Sprung von einer Koppel oder Wehrmauer), setzt eine sanfte Fallbeschleunigung (`gravity = -18 m/s²`) ein, gefolgt von einer weichen Abroll- oder Aufprallanimation.

---

## 3. Kamerasystem: Hybrid-Zoom & Spring-Arm (Third-Person)

### 3.1 Kamera-Modi im nahtlosen Übergang

| Modus | Neigung (`pitch`) | Distanz (`distance`) | FOV | Steuerung & Zweck |
| :--- | :--- | :--- | :--- | :--- |
| **Baumodus / Taktik** | `45° – 60°` | `24 – 38 m` | `30°` | Maximale Übersicht, Gebäude platzieren, Territorium verwalten |
| **Isometrisches RPG** | `52°` (Standard) | `18 – 24 m` | `30°` | Klassische Hack & Slash-Übersicht, Point-and-Click oder WASD |
| **Third-Person Action** | `14° – 22°` | `4.5 – 6.5 m` | `60°` | Immersives Begehen der eigenen Straßen, Dungeons & Action-Kämpfe |

### 3.2 Spring-Arm (Kamera-Kollisionssystem)
In der Third-Person-Perspektive steht die Kamera hinter dem Helden.  
Damit sie in engen Gassen, Burgtoren oder an Felswänden nicht in die Geometrie hineinschneidet:
* **Spherical Sweep Raycast**: Ein Raycast mit Kugelradius (0.3m) prüft die Linie vom Spielerkopf (`pos.y + 1.6m`) zur gewünschten Kameraposition.
* Bei Hindernissen (Wand, Säule, Baum) zieht sich die Kamera sofort butterweich vor das Hindernis heran.
* **Dithering-Fade**: Dächer und Baumkronen über dem Kopf des Spielers faden semi-transparent aus (wird in [`src/render/occlusion.js`](file:///f:/Emberwild/src/render/occlusion.js) bereits vorbereitet).

### 3.3 Mouselook & Freie Umschau
* Mit gehaltener rechter Maustaste (oder permanent im 3D-Action-Modus) dreht die Maus die Kamera horizontal (`yaw`) und vertikal (`pitch`).
* Das Fadenkreuz oder die Blickrichtung bestimmt die Angriffs- und Zauberrichtung.

---

## 4. Vollständige Steuerungsumschaltung: WASD vs. Point-To-Go

*(Bereits in Phase 1 als Fundament implementiert)*

```
                            [ Einstellungs-Menü ]
                                     │
                    ┌────────────────┴────────────────┐
                    ▼                                 ▼
           [ WASD Aktiviert ]               [ WASD Deaktiviert ]
      ───────────────────────────       ───────────────────────────
      • Bewegung: W, A, S, D            • Bewegung: Klick-auf-den-Boden
      • Ausweichen: Leertaste            • Klick-Ringe & Pfadfindung
      • Linksklick (LMB):               • Linksklick (LMB):
        Sofortiger Primärangriff /        Point-To-Go & Laufen zum Ziel
        Interaktion mit NPC/Loot          (Shift+LMB für Stand-Angriff)
      • Rechtsklick (RMB):              • Rechtsklick (RMB):
        Sekundärfähigkeit                 Sekundärfähigkeit
      • Kein Klick-Laufen auf Boden     • Klassisches ARPG-Gefühl
```

---

## 5. Bausystem-Erweiterung: Mehrstöckigkeit & Modulare Treppen

Sobald das 3D-Kamerasystem aktiv ist, profitiert das Bausystem direkt davon:
1. **Modulare Treppen-Bauteile**:
   * *Holztreppe des Weilers* (für Hütten und Palissaden).
   * *Monumentale Steintreppe der Zitadelle* (für Mauern und Schlossterrassen).
   * *Wendeltreppe* (für Wachtürme).
2. **Mehrstöckige Gebäudeflächen (Z-Ebenen)**:
   * Gebäude besitzen nicht mehr nur einen Boden-Footprint, sondern begehbare Obergeschosse.
   * Dachterrassen, Balkone und Wachposten können vom Spieler betreten und mit Dekorationen (Bänke, Truhen, Laternen) eingerichtet werden.

---

## 6. Phasen- & Zeitplan

```mermaid
flowchart TD
    A["Aktueller Fokus: Bau- & Designmodus abschließen"] --> B["Phase 3D.1: Vertikalität & Treppen-Physik"]
    B --> C["Phase 3D.2: Spring-Arm & Third-Person Kamera"]
    C --> D["Phase 3D.3: 3D-Zielen & Mauern-Begehung"]

    subgraph "Schritt 1 (Jetzt)"
    A
    end

    subgraph "Schritt 2 (Konzept-Umsetzung)"
    B
    C
    D
    end
```

1. **Aktuell (Höchste Priorität)**:
   * Perfektionierung des Bausystems (Phase 1 & 2): Werkzeuge, Undo/Redo, Tierzucht, Pfade, Siedlungswirtschaft & Soundkulisse.
2. **Phase 3D.1 – Vertikale Fortbewegung**:
   * `stepHeight`-Kollision und Raycast-Ground-Snapping implementieren.
   * Treppenaufgänge der Stadtmauer und bestehender Gebäude begehbar machen.
3. **Phase 3D.2 – Kamera & Third-Person Rig**:
   * Sanfter Mausrad-Übergang von Isometrie zur Schulterkamera.
   * Spring-Arm Kamera-Kollisionsschutz.
4. **Phase 3D.3 – 3D-Kampf & Mehrstöckiges Bauen**:
   * Platzierbare Treppen im Baumodus.
   * Zielen mit Fadenkreuz für Fernkampf/Magie.


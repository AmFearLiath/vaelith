# 01 — Architektur-Analyse: ASHFALL

## 1. Gesamturteil auf einen Blick

**ASHFALL besitzt eine außergewöhnlich saubere, disziplinierte und hochperformante Architektur.**  
Obwohl das Projekt komplett ohne Bundler (kein Vite/Webpack), ohne externes UI-Framework (kein React/Vue) und ohne TypeScript in reinem ES-Modul-JavaScript (`three.js r186`) geschrieben wurde, weist es eine Strukturqualität auf, die viele kommerzielle Indie-Projekte übertrifft.

**Kurzantwort auf die Frage „Können wir das Spiel als Grundlage nehmen?“:**  
**Ja, uneingeschränkt.** Die Codebasis ist modular, datengetrieben (Data-Driven Design), strikt entkoppelt über einen Event-Bus und einen zentralen Kontext (`G`), hervorragend dokumentiert (`docs/ARCHITECTURE.md`) und durch automatisierte Browser-Tests (`tools/test/`) abgesichert.

---

## 2. Kernpfeiler der Architektur

### 2.1 Zero-Build ES-Module & Offline-First Runtime
- **Aufbau:** `index.html` lädt über eine native `<script type="importmap">` direkt `vendor/three/build/three.module.js` sowie `src/main.js`.
- **Vorteil:** Sofortiger Start über jeden statischen Webserver (`start.bat` / `start.sh`), null Build-Zeit, keine veralteten NPM-Abhängigkeiten zur Laufzeit, 100 % deterministisch und offline lauffähig.
- **Erweiterbarkeit:** Neue Module können einfach per ES-`import` eingebunden werden.

### 2.2 Zentraler Service-Locator `G` (`src/core/G.js`) & Feste Update-Reihenfolge (`src/core/loop.js`)
- Alle Subsysteme hängen an einem einzigen, klar dokumentierten globalen Kontextobjekt `G` (`G.world`, `G.player`, `G.monsters`, `G.combat`, `G.skills`, `G.quests`, `G.npcs`, `G.ui`, `G.audio`, `G.fx` usw.).
- **Deterministische Frame-Pipeline (`ORDER`):**  
  Anstatt unkoordinierter `requestAnimationFrame`-Aufrufe nutzt `src/core/loop.js` feste Prioritätsstufen:
  `input → spatial → player → skills → companion → monsters → combat → loot → world → quests → rift → demo → fx → camera → lights → audio → ui → render`.
- **Zeitskalierung:** Trennung zwischen `G.time.dt` (skalierte Spielzeit inkl. Hit-Stop und Slow-Motion bei Boss-Kills/Legendary-Drops) und `G.time.realDt` (unskalierte Zeit für UI und Kamera).
- **Fehlertoleranz:** Wirft ein Subsystem in `update()` einen Fehler, fängt die Loop ihn ab, loggt ihn einmalig und hält das Spiel am Laufen.

### 2.3 Entkopplung über den Event-Bus (`src/core/events.js`)
- Über 45 kanonische Events (`actor:damaged`, `monster:killed`, `area:enter`, `quest:updated`, `item:equipped`, `boss:phase`, `weather:changed` u.v.m.) entkoppeln die Systeme vorbildlich:
  - Das **Kampfsystem (`src/combat/`)** muss nicht wissen, wie Quests oder Audio funktionieren – es feuert `monster:killed`, woraufhin `G.loot` Drops berechnet, `G.quests` Kill-Zähler erhöht, `G.audio` Todessounds abspielt und `G.killstreak` den Bonus-XP-Timer aktualisiert.
  - Das macht das Einfügen neuer Spielmechaniken extrem einfach: Neue Systeme klinken sich einfach per `G.events.on(...)` ein.

### 2.4 Herausragende Rendering- & Performance-Architektur (`src/render/`, `src/entities/monsters/render.js`)
Hier zeigt sich besondere technische Exzellenz:
1. **Multi-Draw Monster-Batching (`THREE.BatchedMesh`):**  
   Alle regulären Monster bestehen aus starren Gliedmaßen-Rigs (`assets/models/rigs/*.glb`). Anstatt für jedes Monster Dutzende `Mesh`-Objekte und Draw-Calls zu erzeugen, backt die Engine die Animationen in Pose-Tabellen und zeichnet **alle Monster aller Typen in einem einzigen `WEBGL_multi_draw`-Call pro Render-Pass** (über eine Float-Record-Textur via `gl_DrawID`).  
   *Ergebnis:* 150–175 Monster gleichzeitig auf dem Bildschirm laufen mit stabilen 60 FPS (~4 ms CPU-Zeit, < 310 Draw Calls).
2. **Gepooltes Lichtsystem (`src/render/lights.js`):**  
   Eine feste Anzahl echter `PointLight`-Instanzen (Low: 4, Medium: 8, High: 12) wird jeden Frame dynamisch den wichtigsten Lichtquellen um den Spieler zugewiesen. Dadurch ändert sich die Lichtanzahl im Szene-Graphen nie zur Laufzeit → **null Shader-Recompiles / Ruckler im Kampf**.
3. **Shader-Warmup (`G.fx.warmup`, `compileAsync`):**  
   Alle Partikel-, Telegraph- und Post-Processing-Shader werden beim Laden vorab kompiliert.
4. **Dithered Occlusion Cutout (`src/render/occlusion.js`):**  
   Verdeckende Wände, Bäume und Dächer werden per 4×4-Ordered-Dither-Shader sanft ausgeblendet, sobald der Held dahinter steht.
5. **Chunked Environment Instancing (`src/world/props.js`):**  
   Umgebungs-Props werden in 32×32m-Chunks pro Material gebatcht bzw. per `InstancedMesh` gerendert.

### 2.5 Strikte Trennung von Daten und Logik (`src/data/`)
- Monsterwerte (`src/entities/monsters/types.js`), Item-Basen & Affixe (`src/data/items/`), Klassen & Talente (`src/data/talents.js`), Quests (`src/data/text/quests.js`) und Dialoge (`src/data/text/dialogue.js`) liegen in reinen, deklarativen Datenstrukturen vor.
- Sogar das Game-Feel (Hit-Stop, Screen-Shake, Reichweiten, Cooldowns) ist zentral in `src/game/feel.js` und `src/combat/tuning.js` gebündelt.

### 2.6 Prozedurale Audio-Engine (`src/audio/`)
- Kompletter Verzicht auf große MP3/WAV-Dateien: Alle Soundeffekte, Umgebungsgeräusche und dynamischen Musik-Layer werden über WebAudio-DSP-Rezepte (`src/audio/recipes/`) und Web-Worker synthetisiert.
- Automatische Fallback-Auflösung verhindert fehlende Sound-Fehler bei neuen Skills.

### 2.7 Determinismus & Testbarkeit (`src/core/rng.js`, `tools/test/`)
- Alle Welt-, Dungeon- und Loot-Entscheidungen laufen über einen Seed-basierten Zufallsgenerator (`Rng`).
- In `tools/test/` existiert eine komplette Playwright-Testsuite sowie Node-Unit-Tests (u.a. für Dungeon-Generierung, Wirtschaft, Kampf-TTK und komplette Spieldurchläufe durch den `BotBrain`).

---

## 3. Schwachstellen & Technische Rahmenbedingungen (Worauf wir beim Erweitern achten müssen)

So stark die Architektur ist, gibt es vier architektonische Eigenheiten, die man bei größeren Erweiterungen kennen und berücksichtigen muss:

| Bereich | Aktueller Stand / Limitierung | Bedeutung für Erweiterungen |
|---|---|---|
| **1. Flache Kampfebene (`y = 0`)** | Die gesamte Spielmechanik, Kollision (`G.spatial`) und Navigation (`G.nav`) finden mathematisch auf der XZ-Ebene (`y = 0`) statt. Höhenunterschiede (Klippen, Abgründe) sind rein visuell. | Mehrstöckige Brücken (über UND unter denen man gleichzeitig laufen kann) oder echte Höhen-Physik bräuchten ein Ebenen-Flag (`layer`) im `NavGrid`. Für klassische ARPG-Karten (Diablo/PoE-Stil) reicht `y = 0` mit optischen Rampen jedoch völlig aus. |
| **2. Statisches `NavGrid` pro Gebiet** | `NavGrid` nutzt ein festes Float/Uint-Raster mit `0.5 m` Zellgröße. Bei `260×260 m` (Grey Fields) sind das `520×520 = 270.400` Zellen. Flow-Field und A* sind darauf extrem schnell (A* < 0.3 ms dank gewichteter Heuristik). | Vergrößert man eine einzelne Karte auf z. B. `2000×2000 m` am Stück, wächst das NavGrid auf 16 Mio. Zellen (hoher RAM- & Initialisierungsbedarf). Bis `600×600 m` funktioniert das aktuelle System direkt; für noch größere Welten empfiehlt sich ein Zonen-/Chunk-Streaming oder Cluster-Pathfinding. |
| **3. Part-Rig-Konvention für Monster** | Normale Monster nutzen **keine** Skinned Meshes (Knochen-Gewichtung), sondern hierarchische Einzelteil-Rigs (`pelvis`, `spine`, `head` etc.), damit das `BatchedMesh`-Multi-Draw-System funktioniert. | Neue Gegner können entweder bestehende Rigs mit neuem Tint/Skalierung/Waffen-Attachments nutzen (in Minuten machbar) oder per Blender-Python-Skript (`tools/blender/`) als Part-Rig exportiert werden. |
| **4. Savegame im `localStorage`** | Spielstände liegen unter `ashfall.v1` als JSON im Browser-`localStorage` (Limit ~5 MB). | Aktuell ist ein Savegame nur wenige Kilobyte groß. Selbst mit 50 neuen Quests und doppeltem Inventar bleibt es weit unter 100 KB. Wichtig ist lediglich Abwärtskompatibilität in `save.js` bzw. `_ensure()` bei neuen Charakterfeldern. |

---

## 4. Fazit zur Architektur

Die Architektur von **ASHFALL** ist **kein fragiler Prototyp**, sondern ein durchdachtes, produktionsreifes ARPG-Fundament:
- **Saubere Schnittstellen:** Jedes System hat eine klar abgegrenzte Verantwortung.
- **Enorme Performance-Reserven:** Durch das Multi-Draw-Instancing und das Light-Pooling langweilt sich die GPU/CPU selbst bei großen Gegnerhorden.
- **Entwicklerfreundlich:** Dank F2-Developer-Panel, `window.ASHFALL.debug`, Hot-Reload-fähigen ES-Modulen und einem KI-Bot (`BotBrain`), der neue Inhalte automatisch testen kann, lassen sich Erweiterungen schnell und sicher umsetzen.


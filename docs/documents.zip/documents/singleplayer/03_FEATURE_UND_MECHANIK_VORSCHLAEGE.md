# 03 — Eigene Vorschläge: Neue Features, Mechaniken & Erweiterungen für ASHFALL

Basierend auf der düsteren Dark-Fantasy-Atmosphäre von **ASHFALL** (*ein gefallenes Königreich unter ewigem Ascheregen, korrumpierte Katakomben, geschmolzene Tiefen*) und den bereits vorhandenen Systemen in der Codebasis sind hier maßgeschneiderte Vorschläge für neue Features und Spielmechaniken – sortiert nach **Spielspaß-Impact** und **Synergie mit der bestehenden Architektur**.

---

## 1. Kampf- & Umwelt-Mechaniken (Mehr Tiefe im Action-Gameplay)

### 1.1 Interaktive Umwelt-Gefahren & Taktische Fallen (Environmental Combat)
Aktuell gibt es zerstörbare Fässer/Urnen (`src/worldsys/destructibles.js`) und Bodeneffekte (`src/combat/groundEffects.js`). Wir können diese beiden Systeme verknüpfen:
- **Explosive Glut-Fässer (Cinder Barrels) & Öl-Krüge:** Zerschlägt man sie, entsteht eine Feuer-Explosion (`G.combat.aoe` + `groundEffects`), die sowohl Monster als auch den Spieler verbrennen kann.
- **Einstürzende Kronleuchter / Glockenturm-Trümmer:** In Katakomben und Hallen können morsche Stützpfeiler zerschlagen werden, um Steinschlag auf ein darunterstehendes Elite-Pack auszulösen.
- **Dungeon-Fallen:** Stachelgruben mit Zeitintervall, Flammenwerfer-Statuen an Korridorwänden und Druckplatten – die auch Monster treffen, wenn man sie geschickt hineinlockt (oder mit *Chain Hook* / *Knockback* hineinstößt!).

### 1.2 Elementar-Reaktionen (Status-Kombos)
In `src/combat/status.js` existieren bereits `burn`, `chill`, `freeze`, `shock` und `weaken`. Wir können **Elementar-Kombo-Reaktionen** einführen (ideal für Hexweaver, Legendary-Procs oder das Zusammenspiel mit dem Companion):
- **Thermoschock (Freeze + Fire):** Trifft ein starker Feuer-Angriff ein eingefrorenes (`freeze`) Ziel, bricht das Eis sofort in einer *Dampf-/Splitter-Nova* (`shatter`), die 200 % Bonusschaden im Umkreis verursacht.
- **Leitfähigkeit (Water/Drowned + Lightning):** Stehen Gegner im Wasser der Katakomben (`surfaceAt(x, z) === 'water'`) und werden mit `lightning` getroffen, springt der Schock automatisch auf alle Ziele im selben Wasserbecken über.
- **Seelenbrand (Weaken + Burn):** Verfluchte Ziele, die brennen, hinterlassen beim Tod eine explodierende Aschewolke.

---

## 2. Item-, Crafting- & Charakter-Progression

### 2.1 Das „Aschen-Schmiede“-System: Sockel, Runen & Glutsteine (Sockets & Cinderstones)
Beim Schmied Aldric Venn (`src/game/economy.js`) gibt es bereits *Salvage*, *Repair* und *Temper* (Affix-Reroll). Wir können das Item-System um **Sockel** erweitern:
- Seltene und legendäre Ausrüstung kann 1–2 Sockel besitzen (oder beim Schmied gegen Materialien `scrap / dust / embers` erhalten).
- **Glutsteine / Runen (Cinderstones & Runes):** Neue Stapel-Items, die von Bossen, in Geheimräumen oder Rifts droppen:
  - *Rubin-Glut:* +Feuerschaden / Entzünden-Chance
  - *Saphir-Reif:* +Mana-Regeneration / Kälte-Resistenz
  - *Knochen-Rune:* +Minion-Leben / Leben pro Treffer
  - *Meister-Runen:* Verändern Mechaniken (z. B. *„Dodge-Roll hinterlässt eine Frostspur“*).

### 2.2 Set-Gegenstände (Item Sets mit 2er- und 4er-Bonus)
Neben `legendary` und `unique` (`src/data/items/`) passen **Klassenspezifische oder Elementare Rüstungs-Sets** perfekt in die Beute-Spirale:
- Beispiele: *„Tracht des Glockenwächters“ (Ironclad)*, *„Gewänder der Ertrunkenen Mutter“ (Hexweaver)*, *„Knochenchor-Ornat“ (Gravecaller)*.
- `src/game/stats.js` zählt beim Berechnen der Ausrüstung einfach die angelegten Teile eines Sets und aktiviert beim Erreichen von 2 bzw. 4 Teilen mächtige Set-Boni (mit eigenem grünen oder violetten Lichtstrahl beim Drop!).

### 2.3 Begleiter-Ausrüstung & Söldner-Ausbau (Companion Paper-Doll)
Aktuell skaliert der Companion (`src/modes/companion.js`) pauschal mit `0.6 ×` Spielerschaden und hebt keinen Loot auf.
- **Erweiterung:** Der Companion bekommt im Charakterfenster einen eigenen kleinen Tab mit **3 Slots (Waffe, Rüstung, Schmuck)** sowie einen kleinen Mini-Skillbaum (3 Spezialisierungen: *Wächter*, *Elementarist*, *Kopfgeldjäger*).
- Damit bekommen auch gefundene Items, die eigentlich für eine andere Klasse gedacht sind (z. B. ein starker Zweihandstab, den man als Ironclad findet), sofort einen spannenden Nutzen!

---

## 3. Lebendige Welt, Atmosphäre & Exploration

### 3.1 Dynamische Welt-Events: „Der Asche-Sturm“ (Ashfall Eclipse / Helltide-Event)
Alle 15–20 Spielminuten (oder ausgelöst durch ein optionales Ritual in der Welt) verdunkelt sich der Himmel in den *Grey Fields* zu einem blutroten Glutsturm (nutzt `G.world.applyPalette` + `G.weather`):
- Monster in den Grey Fields werden während des Sturms um +2 Level stärker, haben erhöhte Elite-Dichte und lassen **Blut-Glut (Cinder Shards)** fallen.
- In der Karte öffnen sich temporäre **Asche-Truhen**, die nur mit der während des Sturms gesammelten Blut-Glut geöffnet werden können und garantierte Legendaries enthalten.
- Sobald der Sturm endet, kehrt das normale Wetter zurück.

### 3.2 Verfluchte Schreine & Risiko-Mechaniken (Curse & Blessing Shrines)
In `src/worldsys/shrines.js` gibt es bereits 5 positive Schreine. Wir können **Blut-Altäre (Altar of Cinders)** hinzufügen:
- Aktiviert man den Altar, wählt man einen Pakt: Für 90 Sekunden erleidet der Held z. B. +25 % mehr Schaden oder verliert langsam Leben, erhält dafür aber **+100 % Magic Find und doppelte Angriffsgeschwindigkeit** sowie sofort 2 gespawnte Elite-Packs.

### 3.3 Bestiarium, Lore-Codex & Erfolge (Journal-Erweiterung)
Das Quest-Log (`J`, `src/ui/quests.js`) lässt sich durch zwei zusätzliche Reiter erweitern:
1. **Bestiarium:** Zeigt jedes besiegte Monster und jeden Boss als drehbares 3D-Modell (wie im Charakter-Erstellungsbildschirm), inklusive Kill-Zähler, Resistenzen/Schwächen und kurzer Lore-Beschreibung. Ab bestimmten Kill-Stufen (z. B. 100 Ghouls getötet) schaltet man dauerhaft +3 % Schaden gegen diese Monsterfamilie frei!
2. **Chroniken von Ashfall (Lore-Bücher):** In Dungeons und Ruinen liegen anklickbare Tagebücher/Schriftrollen, die die Vorgeschichte von König Varkhul, Sister Oda und dem Fall von Emberwatch vertiefen.

---

## 4. Endgame-Erweiterungen (Langzeitmotivation nach Varkhul)

### 4.1 Modifizierte Rifts („Runed Rifts“ / Nightmare Sigils)
Das Rift-System (`src/rift/index.js`) ist bereits vorhanden. Aktuell öffnet der Obelisk immer einen Standard-Rift.
- **Vorschlag:** Am Rift-Obelisken kann man **Rift-Siegel** (oder Gold/Embers) einsetzen, um dem Rift **Karten-Modifikatoren (Map Affixes)** hinzuzufügen:
  - *„Boden aus Lava“:* Regelmäßige Geysire im gesamten Dungeon (+40 % Loot-Qualität).
  - *„Zwillings-Wächter“:* Am Ende spawnen **zwei** Rift-Guardians gleichzeitig (+1 garantierter Legendary-Drop).
  - *„Keine Heiltränke, aber doppelte Health-Orbs“.*
- **Endlose Rift-Stufen (Tier 1 bis Tier 50+)** mit einer persönlichen Bestenliste pro Held im Savegame.

### 4.2 Das „Flüstern des Aschkönigs“ (Boss-Rush / Echo-Arena)
Nach dem Sieg über Varkhul schaltet sich im *Ash Throne* oder über den Obelisken die **Crucible of Ash (Arena der Echos)** frei:
- Ein Wellen-Überlebensmodus in einer kompakten Arena, bei dem alle 5 Wellen veränderte Echo-Versionen der Story-Bosse (*Bell Warden*, *Mother of the Drowned*, *Harrowgast*, *Slagjaw*, *Varkhul*) mit neuen Phasen-Attacken auftreten.

### 4.3 Eine vierte spielbare Klasse: „The Ashstalker“ (oder „Plague Doctor / Inquisitor“)
Da `src/skills/skillSystem.js`, `src/data/classes.js` und `src/data/talents.js` strikt modular aufgebaut sind (jede Klasse ist eine eigene Datei wie `ironclad.js`), ließe sich später sogar eine **4. Klasse** ergänzen:
- **Ashstalker (Beweglichkeit / Fokus-Ressource):** Schneller Fern- und Nahkampf-Hybrid mit Armbrust/Dolchen, Rauchbomben (Stealth/Blind), Krähenfüßen-Fallen, Gift-/Schatten-Klingen und Ketten-Ausweichrollen.

---

## 5. Empfohlene Roadmap (Reihenfolge für die Umsetzung)

Falls wir mit dem Ausbau starten wollen, empfiehlt sich folgende schrittweise Reihenfolge (vom schnellsten sichtbaren Mehrwert bis zu großen System-Erweiterungen):

```mermaid
flowchart TD
    P1["Phase 1: Lebendige Welt & Intelligente NPCs<br/>(NPC-Tagesabläufe, Welt-Reaktionen, schlaueres Companion-Brain)"]
    P2["Phase 2: Neue Gegner, KI-Rollen & Elite-Affixe<br/>(Heiler/Nekromanten, Berserker, neue Elite-Affixe, Bestiarium)"]
    P3["Phase 3: Quest-Erweiterung & Kopfgeld-System<br/>(Neue Objective-Typen: Eskorte/Verteidigung, Bounty-Board, neue Nebenquests)"]
    P4["Phase 4: Kartenvergrößerung & Neue Gebiete<br/>(Größere Dungeons, neue Außenregion z. B. Sunken Moor / Cinderwood)"]
    P5["Phase 5: Endgame & Crafting-Tiefe<br/>(Runen/Sockel beim Schmied, Modifizierte Rifts, Asche-Sturm-Events)"]

    P1 --> P2 --> P3 --> P4 --> P5
```


# 02 — Erweiterbarkeit der vier angefragten Kernbereiche

Dieses Dokument analysiert im Detail, wie sich die vier gewünschten Erweiterungen (**Karte vergrößern**, **Quests hinzufügen**, **neue Gegner erstellen**, **NPCs intelligenter machen**) auf Basis der bestehenden ASHFALL-Architektur umsetzen lassen.

---

## 1. Karte vergrößern & Neue Gebiete hinzufügen

### Wie es aktuell funktioniert
- **Außenwelt (`src/world/areas/greyfields.js`):** Ca. `260 × 260 m` groß. Nutzt `NavGrid` (`0.5 m` Zellen), einen `SplatPainter` (`1024 × 1024` Textur für Gras/Erde/Straße/Asche), prozedurales Gras (`buildGrass`) und `PropKit` (automatisches 32m-Chunk-Batching von GLB- und prozeduralen Props).
- **Dungeons (`src/world/dungeon/generate.js` & `build.js`):** Nutzt ein `2 m`-Zellen-Grid mit den Größen `small` (`40×40` Zellen = `80×80 m`, 6 Räume), `medium` (`48×48` = `96×96 m`, 8 Räume) und `large` (`56×56` = `112×112 m`, 10 Räume).
- **Gebietsübergänge (`src/world/world.js`):** Über `entrances` (Kreis-Trigger mit Zielgebiet `to`, `level` und `entry`) und `G.waypoints` (Schnellreise-Steine) beliebig verknüpfbar.

### Wie wir die Karte vergrößern können (3 Stufen)

#### Stufe A: Bestehende Karten direkt vergrößern (Sofort & ohne Engine-Umbau möglich)
1. **Dungeons vergrößern:**  
   In `src/world/dungeon/generate.js` (`SIZES`) können wir problemlos `huge` (`80×80` Zellen = `160×160 m`, 18–22 Räume, mehr Loops, zusätzliche Geheimräume) oder `labyrinth` einführen. Da Wände und Böden über `PropKit` in 32m-Chunks geinstanced werden, bleibt die Framerate bei 60 FPS.
2. **Außenwelt (Grey Fields) vergrößern:**  
   Das aktuelle Setup verträgt problemlos eine Verdopplung bis Vervierfachung der Fläche (z. B. von `260×260 m` auf `500×500 m`), wenn wir die `SplatPainter`-Auflösung von `1024` auf `2048` erhöhen. `NavGrid` hat bereits eine gewichtete A*-Heuristik für lange Strecken (> 30 m), sodass Pathfinding über `500 m` unter `0.5 ms` bleibt.

#### Stufe B: Neue zusammenhängende Regionen / Akte hinzufügen (Empfohlen für ARPG-Abwechslung)
Über `G.world.register('id', () => import('./world/areas/<id>.js'))` lassen sich beliebig viele neue Gebiete nahtlos anbinden:
- **Südliche oder Westliche Ausgänge aus Emberwatch / Grey Fields:** Z. B. *The Sunken Moor* (Sumpfgebiet mit langsamem Wasser und Nebel), *The Cinderwood* (brennender Nadelwald), *The Iron Quarry* (verlassene Mine & Festungsruine).
- Jedes Gebiet bringt seine eigene Farbpalette (`palette`), eigenes Wetter, eigene Fußstapfen-Sounds und eigene Wegpunkte mit.

#### Stufe C: Dynamisches Frustum-Culling & Monster-Hibernation für Mega-Maps (> 600×600 m)
Wenn eine einzelne Karte extrem groß sein soll (Open-World-Gefühl mit 300–500 Monstern gleichzeitig auf der Karte):
- **Chunk-Visibility:** Da `PropKit` Props ohnehin schon in `32×32 m`-Chunks gruppiert, können Chunks außerhalb des Kamera-Sichtfelds (`> 45 m` vom Spieler entfernt) einfach per `chunk.visible = false` ausgeblendet werden.
- **Monster-Sleep-Radius:** Monster, die weiter als `60 m` vom Spieler entfernt und nicht im Kampf (`!m.aggro`) sind, werden im KI-Tick übersprungen (`update` nur alle 0.5 s statt jeden Frame).

---

## 2. Quests hinzufügen & Quest-System ausbauen

### Wie es aktuell funktioniert
Das Quest-System (`src/quests/index.js`, `src/quests/worldQuests.js`, `src/quests/markers.js` und `src/data/text/quests.js`) ist bereits extrem sauber und datengetrieben aufgebaut:
- Jede Quest in `QUESTS` definiert `id`, `kind` (`main` | `side`), `giver`, `requires` (Vorbedingungen), `objectives` und `rewards` (`xp`, `gold`, `item`).
- Unterstützte Objective-Typen aktuell:
  - `kill` (benannter Gegner, z. B. Rare-Elite)
  - `killType` (X Monster eines Typs oder einer Familie töten)
  - `killBoss` (Boss oder Mini-Boss besiegen)
  - `reach` (Gebiet oder benannte Zone erreichen)
  - `talk` (mit NPC sprechen)
  - `collect` (Quest-Gegenstand aufheben)
  - `survive` (Wellen-Event überleben, wie beim *Weeping Shrine*)
  - `interact` (Weltobjekt oder NPC in der Welt anklicken)
  - `horde` (Spezial-Event am Tor)
- **Automatische UI-Integration:** Neue Quests in `src/data/text/quests.js` erscheinen **automatisch** im Quest-Log (`J`), im HUD-Tracker unter der Minimap, als `!` / `?` über den NPCs und als leuchtender Wegweiser-Pfeil zu Füßen des Helden (`markers.js`).

### Wie wir das Quest-System erweitern können
1. **Neue Story- & Nebenquests per Daten-Eintrag:**  
   Einfache Quests (Jagdaufträge, Boss-Quests, Sammel-Quests) erfordern **null Änderungen am Engine-Code** – nur einen neuen Eintrag in `src/data/text/quests.js` und passende Dialogzeilen in `src/data/text/dialogue.js`.
2. **Neue Objective-Typen in `QuestSystem` & `WorldQuests`:**
   - **`escort` (Eskorte):** Einen verwundeten NPC (nutzt `G.npcs` + `walkTo`) sicher durch ein Gebiet begleiten, während Hinterhalte spawnen.
   - **`defend` (Objekt verteidigen):** Ein Objekt mit eigenem HP-Balken (z. B. Barrikade, Ritualstein, Karren) für X Sekunden vor anstürmenden Ghouls schützen.
   - **`destroy` (Zerstörung):** X Korruptions-Kristalle, Nester oder Knochenhaufen (`G.destructibles`) in einem Gebiet zerstören.
   - **`dungeonClear` / `timed`:** Einen Bereich innerhalb eines Zeitlimits säubern.
   - **`choice` (Verzweigte Quests):** Entscheidung im Dialog (z. B. ein Relikt Sister Oda für Heilungs-Segen oder dem Schmied Aldric für eine einzigartige Waffe geben), gespeichert über `G.quests.setFlag(...)`.
3. **Dynamisches Kopfgeld-Brett (Bounty Board) in Emberwatch:**  
   Ein neues Interaktionsobjekt in der Stadt, das pro Spielsitzung/Seed 3 zufällige Kopfgeld-Quests generiert (z. B. *„Töte den Champion-Pack in den Katakomben Ebene 2“* oder *„Säubere das verfluchte Lager in den Grey Fields“*).

---

## 3. Neue Gegner erstellen

### Wie es aktuell funktioniert
Das Monstersystem (`src/entities/monsters/`) trennt **Daten (`types.js`)**, **KI-Verhalten (`ai.js`)**, **Elite-Modifikatoren (`elites.js`)** und **3D-Rigs (`render.js`)**:
- Es gibt aktuell 12 reguläre Gegnertypen (in Gebietsvarianten), 3 Mini-Bosse und 2 Beschwörungs-Minions.
- Jeder Gegnertyp in `MONSTER_TYPES` definiert:
  - Basiswerte (`hpMul`, `dmgMul`, `speed`, `armorMul`, `resist`, `scale`, `tint`)
  - KI-Profil (`swarm`, `brute`, `ranged`, `caster`, `burrower`, `exploder`, `shield`, `miniboss`)
  - Angriffsliste (`attacks[]`) mit frei kombinierbaren Primitiven: `swipe`, `tele` (Kreis/Kegel/Linie/Ring), `lunge`, `projectile` (Mehrfachschuss, Homing, AoE-Einschlag), `fireball`, `summon`, `swell`, `charge`, `spit` (hinterlässt Boden-Effekte wie Feuer/Gift/Lava), `emerge`.

### Drei Wege, wie wir neue Gegner erstellen können

#### Weg 1: Neue Gegner-Archetypen über Daten & bestehende Rigs (Sofort umsetzbar)
Durch Kombination aus `scale`, `tint` (Farbmultiplikator), `trail`, `attacks` und `ai` lassen sich sofort völlig neue Gegnervarianten bauen, z. B.:
- **Necromancer / Bone Priest** (nutzt `siltAbbot`- oder `archer`-Rig, `caster`-KI): Beschwört Gefallene wieder (`summon`), feuert Schatten-Projektile und wirkt `weaken`-Flüche.
- **Frost Weaver / Rime Wraith** (nutzt `imp`- oder `ghoulDrowned`-Rig): Hinterlässt Eisflächen, friert den Spieler per Ring-Telegraph ein.
- **Plague Carrier** (nutzt skaliertes `bloater`-Rig): Spuckt Giftpfützen aus der Distanz (`spit`) und teilt sich beim Tod in kleine Schwärmer.
- **Ash Hound / Stalker** (nutzt geducktes/schnelles `ghoul`-Rig): Extrem schnell, springt aus dem Schatten (`lunge` mit Blutung/Slow).

#### Weg 2: Neue KI-Profile (`src/entities/monsters/ai.js`) & Elite-Affixe (`elites.js`)
- **Neue KI-Rollen:**
  - `healer` / `totem`: Steht hinter der Frontlinie und heilt/bufft verbündete Monster im Umkreis (zwingt den Spieler zur Zielpriorisierung).
  - `trapper` / `ambusher`: Versteckt sich getarnt im Aschenebel oder als scheinbare Leiche am Boden und erhebt sich erst, wenn der Spieler auf 3 m herankommt.
  - `berserker`: Wird unter 40 % HP um 50 % schneller, größer gerendert und greift rücksichtslos an.
- **Neue Elite-Affixe (`src/entities/monsters/elites.js`):**
  - *Waller (Mauernbauer):* Erschafft temporäre Knochen-/Steinsäulen, die den Weg blockieren.
  - *Arcane / Void Beam:* Rotiert tödliche Laserstrahlen (`G.fx.beam`) im Raum.
  - *Avenger:* Stirbt ein Pack-Mitglied, werden die übrigen Champions größer und stärker.
  - *Storm-Tethered:* Blitz-Ketten zwischen den Mitgliedern eines Champion-Packs.

#### Weg 3: Komplett neue 3D-Modelle über die Blender-Pipeline (`tools/blender/`)
Da das Projekt alle Modelle per reproduzierbaren Blender-Python-Skripten erzeugt hat, können wir für völlig neue Silhouetten (z. B. Spinnen/Arachniden, Gargoyles, schwebende Geister/Banshees, Speerträger) neue Part-Rigs (`.glb`) generieren und über `smoke.mjs --index-only` in `assetIndex.js` registrieren.

---

## 4. NPCs intelligenter & lebendiger machen

### Wie es aktuell funktioniert
Es gibt aktuell zwei getrennte KI-Systeme für freundliche Charaktere:
1. **Dorfbewohner (`src/npcs/index.js`):**  
   Haben Animations-States (`Idle`, `Walk`, `Run`, `Work`, `Talk`, `Wave`, `Cower`), A*-Pathfinding auf dem `NavGrid` (`walkTo`), drehen ihren Kopf automatisch zum Spieler (`_lookAtHero`), winken zur Begrüßung (`greet`), rufen kontextsensitive Sätze (`bark`), weichen dem Spieler aus bzw. bleiben beim Anvisieren stehen.
2. **Kampf-Begleiter & Bot (`src/modes/brain.js`, `src/modes/companion.js`):**  
   Die `BotBrain`-Klasse ist bereits eine erstaunlich fähige Taktik-KI (8 Entscheidungen pro Sekunde): Sie erkennt feindliche Boden-Telegraphen geometrisch (`teleContains`) und weicht per Dodge-Roll aus, trinkt Heiltränke bei < 45 % HP, wählt situativ AoE-, Gap-Closer- oder Buff-Skills, hält als Fernkämpfer Abstand und folgt dem Spieler.

### Wie wir die NPCs deutlich intelligenter machen können

#### A. Intelligente Stadt- & Welt-NPCs (Lebendiges Emberwatch)
1. **Tagesabläufe & Routinen (State-Machine / Schedules):**  
   Statt starr an einem Punkt zu stehen oder zufällig zwischen 2 Punkten zu pendeln, bekommen NPCs echte Routinen:
   - *Aldric der Schmied* holt Roheisen aus der Kiste, hämmert am Amboss (mit Funkenflug), kühlt das Werkstück im Wasserfass ab (Dampf-FX) und geht abends ans Lagerfeuer.
   - *Captain Holt* patrouilliert die Palisade entlang, inspiziert die Tore und salutiert, wenn der Held nach einem Boss-Kill zurückkehrt.
   - **NPC-zu-NPC-Interaktionen:** Wenn sich zwei wandernde Dorfbewohner begegnen, bleiben sie kurz stehen, drehen sich zueinander (`face`) und führen ein kurzes Gespräch (Wechsel-Barks mit `Talk`-Animation).
2. **Welt-Reaktivität & Gedächtnis (World-State Awareness):**  
   NPCs reagieren dynamisch auf:
   - **Wetter & Ereignisse:** Bei Gewitter oder Aschesturm suchen Kinder (`lys`, `wren`) Schutz unter Vordächern oder nutzen die `Cower`-Animation bei Donnerschlägen.
   - **Ausrüstung & Klasse des Spielers:** Trägt der Spieler ein legendäres Item oder eine bestimmte Klasse (z. B. Gravecaller mit Skelett-Armee in der Stadt!), kommentieren die Wachen und Bewohner dies nervös oder ehrfürchtig (*„Haltet Eure Knochenknechte von meinem Marktstand fern, Totenrufer!“*).
   - **Baufortschritt in der Stadt:** Mit erledigten Quests reparieren NPCs sichtbare Teile von Emberwatch, zünden neue Leuchtfeuer an oder eröffnen neue Stände.
3. **Erweiterte Dialog-Intelligenz (`src/ui/dialogue.js`):**
   - Verzweigte Antwortmöglichkeiten für den Spieler (Fragen zu Lore, Gerüchten über Geheimräume, Feilschen oder Entscheidungen bei Quests).
   - **Beziehungs-/Reputations-Level (Trust):** Wer Nebenquests für Händler oder Schmied erledigt, schaltet Rabatte, bessere Gamble-Chancen oder Spezial-Rezepte frei.

#### B. Intelligente Kampf-NPCs (Begleiter, Wachen & Begegnungen in der Wildnis)
1. **Taktische Befehle & KI-Profile für den Begleiter (`src/modes/companion.js` & `brain.js`):**
   - Verhalten umschaltbar: **Aggressiv** (jagt Gegner aktiv), **Defensiv / Beschützer** (fängt Gegner ab, die den Spieler angreifen, nutzt Taunt/CC), **Fokus-Feuer** (greift immer das Ziel unter dem Mauszeiger des Spielers oder Elites zuerst an).
   - **Skill-Synergien (Combo-KI):** Das `BotBrain` prüft die Status-Effekte der Gegner (`m.status`). Hat der Spieler Gegner eingefroren (`freeze`) oder geschockt (`shock`), priorisiert der Begleiter sofort seine schwersten AoE-Finisher auf diese Gruppe!
   - **Gefahrenzonen-Vermeidung:** Erweiterung von `teleContains` um persistente Bodeneffekte (`G.combat.groundEffects` wie Giftwolken, Molten Trails und Lava-Pfützen), sodass der Begleiter nicht in brennendem Boden stehen bleibt.
2. **Kämpfende Wachen & Überlebende in der Außenwelt:**
   - Am Stadttor von Emberwatch oder an Vorposten in den *Grey Fields* können verbündete Wachen (`faction: 'hero'`) stehen, die anstürmende Monster bekämpfen.
   - Zufällige Begegnungen in Dungeons/Feldern: Ein umzingelter Händler oder Ordensritter kämpft gegen ein Monster-Pack – rettet der Spieler ihn rechtzeitig, bedankt er sich mit seltenem Handel oder kämpft für den Rest des Dungeons an der Seite des Spielers.


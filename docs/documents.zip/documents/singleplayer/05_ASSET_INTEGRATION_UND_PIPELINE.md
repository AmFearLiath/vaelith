# 05 – Asset-Analyse & Integration: Können wir die Assets aus `LivingKingdom` für ASHFALL verwenden?

**Geprüfte Verzeichnisse:**
- `D:\LivingKingdom\_Userfiles\_Konzept\Assets\Pack\...`
- `D:\LivingKingdom\_Userfiles\_Konzept\Assets\3D\...`
- `D:\LivingKingdom\assets\nature\...` & `D:\LivingKingdom\assets\asset_catalog.toml`
- `f:\ASHFALL-ultracode\vendor\three\addons\loaders\...` & `f:\ASHFALL-ultracode\src\core\assets.js`

---

## 1. Kurzfazit: Ja – fast 100 % der Assets sind sofort nutzbar!

Die kurze und beste Antwort lautet: **Ja, wir können die Assets direkt in ASHFALL verwenden – und die wichtigsten Pakete liegen sogar schon im exakt richtigen Format (`.gltf`) vor!**

Warum klappt das technisch so reibungslos?
1. **ASHFALL nutzt Three.js mit vollständigem Loader-Paket:**
   In [`f:\ASHFALL-ultracode\vendor\three\addons\loaders\`](file:///f:/ASHFALL-ultracode/vendor/three/addons/loaders) sind bereits **alle benötigten 3D-Loader vorinstalliert**:
   - [`GLTFLoader.js`](file:///f:/ASHFALL-ultracode/vendor/three/addons/loaders/GLTFLoader.js) + [`SkeletonUtils.js`](file:///f:/ASHFALL-ultracode/vendor/three/addons/utils/SkeletonUtils.js) (wird bereits in [`src/core/assets.js`](file:///f:/ASHFALL-ultracode/src/core/assets.js) genutzt!)
   - [`OBJLoader.js`](file:///f:/ASHFALL-ultracode/vendor/three/addons/loaders/OBJLoader.js) + [`MTLLoader.js`](file:///f:/ASHFALL-ultracode/vendor/three/addons/loaders/MTLLoader.js) (für die modularen Dorf-, Tempel- und Terrain-Sammlungen)
   - [`FBXLoader.js`](file:///f:/ASHFALL-ultracode/vendor/three/addons/loaders/FBXLoader.js) (für die zusätzlichen FBX-Naturpakete)
   - [`GLTFExporter.js`](file:///f:/ASHFALL-ultracode/vendor/three/addons/exporters/GLTFExporter.js) (damit können wir `.obj`/`.fbx`-Modelle bei Bedarf sogar direkt in kompakte `.glb`-Dateien umwandeln).
2. **Saubere Lizenz (CC0 Public Domain):**
   Die großen Asset-Packs stammen von **Quaternius (`CC0 1.0 Universal – Public Domain`)** und dürfen ohne Einschränkungen kommerziell und frei modifiziert in ASHFALL eingebunden werden.

---

## 2. Detaillierte Bestandsaufnahme aller gefundenen Asset-Pakete

Hier ist die genaue Übersicht über alle Schätze, die in `D:\LivingKingdom` schlummern, und wofür wir sie in ASHFALL einsetzen können:

### Paket 1: `Ultimate Animated Animals - July 2021` (⭐⭐⭐ Sofort einsatzbereit!)
- **Pfad:** `D:\LivingKingdom\_Userfiles\_Konzept\Assets\Pack\Ultimate Animated Animals - July 2021\glTF\`
- **Format:** **Self-Contained `.gltf`** (Geometrie, Bones, Skinning-Gewichte und Materialien sind direkt als Base64 in jeder einzelnen `.gltf`-Datei eingebettet – **keine externen Textur- oder `.bin`-Abhängigkeiten!**)
- **Enthaltene 12 Tier-Modelle (alle komplett geriggt & animiert):**
  1. **`Wolf.gltf`** – Perfekt für wilde Wolfsrudel, mutierte *Schattenwölfe* (Gegner) oder gezähmte Kampf-Begleiter!
  2. **`Stag.gltf`** (Hirschbock mit Geweih) & **`Deer.gltf`** (Reh/Hirschkuh) – Perfekt für das lebendige Wald-Ökosystem, Jagd-Quests oder einen *Riesenhirsch* als Natur-Reittier/Boss.
  3. **`Fox.gltf`** (Fuchs) – Kleiner Räuber für Wälder, Waldränder und als flinker Tier-Begleiter.
  4. **`Horse.gltf`** & **`Horse_White.gltf`** (Braunes & weißes Pferd) – **Sofort nutzbar als Reittiere (Mounts)** für den Spieler sowie als Zugtiere in Emberwatch!
  5. **`Husky.gltf`** & **`ShibaInu.gltf`** (Hunde) – Treue Stadt- und Spieler-Begleiter (mit Such-/Spürsinn-Mechanik).
  6. **`Bull.gltf`** & **`Cow.gltf`** (Stier & Kuh) – Weidetiere für die Landwirtschaft in Emberwatch (oder ein mutierter *Höllenstier* als Elite-Monster!).
  7. **`Donkey.gltf`** & **`Alpaca.gltf`** (Esel & Alpaka) – Packtiere für Handelskarawanen und Eskort-Quests!
- **Enthaltene Animationen (bereits in den Dateien enthalten!):**
  - `Idle`, `Idle_2`, `Idle_2_HeadLow` (Grasen/Schnüffeln)
  - `Walk`, `Gallop`, `Gallop_Jump`, `Jump_ToIdle`
  - `Attack` (Angriffs-Animation!)
  - `Eating` (Fressen für das Ökosystem!)
  - `Idle_HitReact1`, `Idle_HitReact2` (Treffer-Feedback!)
  - `Death` (Sterbe-Animation!)

---

### Paket 2: `Stylized Nature MegaKit[Standard]` & `D:\LivingKingdom\assets\nature` (⭐⭐⭐ Sofort einsatzbereit!)
- **Pfad:**
  - `D:\LivingKingdom\_Userfiles\_Konzept\Assets\Pack\Stylized Nature MegaKit[Standard]\glTF\`
  - Bereits fertig sortiert inklusive Metadaten-Katalog in: `D:\LivingKingdom\assets\nature\` + `D:\LivingKingdom\assets\asset_catalog.toml`
- **Format:** **68 `.gltf` + `.bin` + `.png` Texturen**
- **Inhalt:**
  - **20 Bäume:**
    - `CommonTree_1..5` (5 Laubbäume für gesunde/geheilte Wälder)
    - `Pine_1..5` (5 Nadelbäume für Hochland, Berge & Taiga)
    - `TwistedTree_1..5` (5 knorrige, verfluchte Bäume – passen **perfekt** zum düsteren Ashfall-Look in Sümpfen & verfluchten Wäldern!)
    - `DeadTree_1..5` (5 abgestorbene Bäume für Asche-Ödland und verbrannte Zonen)
  - **19 Pflanzen & Bodendecker:**
    - `Bush_Common`, `Bush_Common_Flowers` (Beerensammler-Büsche!)
    - `Fern_1` (Waldfarn), `Clover_1..2` (Klee), `Plant_1`, `Plant_7`
    - `Flower_3_Single/Group`, `Flower_4_Single/Group`, `Petal_1..5` (Blüten für geheilte Natur-Schreine & Alchemie-Kräuter!)
    - `Mushroom_Common`, `Mushroom_Laetiporus` (Pilze für Höhlen, Sümpfe & Sporen-Mutationen)
    - `Grass_Common_Short/Tall`, `Grass_Wispy_Short/Tall`
  - **24 Felsen & Pflastersteine:**
    - `Rock_Medium_1..3`, `Pebble_Round_1..5`, `Pebble_Square_1..6`
    - `RockPath_Round_*` & `RockPath_Square_*` (10 Wegstein-Varianten für Straßenbau in der Siedlung!)
- **Besonderer Vorteil:** Die Datei `D:\LivingKingdom\assets\asset_catalog.toml` enthält bereits fertige ökologische Parameter (`height_range`, `spread_range`, `biomes`, `rarity`, `provides_wood`, `provides_food`, `edible`), die wir direkt nach JavaScript konvertieren können!

---

### Paket 3: `Ultimate Stylized Nature - May 2022` (⭐⭐⭐ Sofort einsatzbereit!)
- **Pfad:** `D:\LivingKingdom\_Userfiles\_Konzept\Assets\Pack\Ultimate Stylized Nature - May 2022\glTF\`
- **Format:** **51 `.gltf` Modelle + 21 Texturen**
- **Inhalt:**
  - `BirchTree_1..5` (5 Birken-Varianten – ideal für lichte Grenzland-Wälder)
  - `MapleTree_1..5` (5 Ahornbäume mit warmem Herbstlaub – passen farblich genial zum Gold-/Glut-Farbschema von ASHFALL!)
  - `DeadTree_1..10` (10 weitere tote Bäume)
  - `Flower_1..5_Clump`, `Bush_Large/Small_Flowers`, `Grass_Large_Extruded`

---

### Paket 4: `modular_village_collection.zip` (⭐⭐⭐ Perfekt für „The Crown“ / Siedlungsbau in Emberwatch!)
- **Pfad:** `D:\LivingKingdom\_Userfiles\_Konzept\Assets\3D\modular_village_collection.zip`
- **Format:** **135 modulare `.obj` + `.mtl` Modelle** (direkt ladbar via `OBJLoader` + `MTLLoader` oder per Skript in ein einziges `village.glb`-Bundle packbar!)
- **Inhalt (Goldgrube für den Siedlungsbau & größere Städte):**
  - **Spezial-Gebäude & Mechaniken:**
    - `Waterwheel_1` + `Waterwheel_Flume_*` (Komplette Wassermühle mit Wasserkanal-Segmenten!)
    - `Wall_Prop_Windmill_1` (Windmühlen-Flügel für Farmen/Bäckerei!)
    - `Prop_Well_1`, `Prop_Well_Cobblestone`, `Prop_Well_Dirt`, `Prop_Well_Grass` (Brunnen in 4 Ausbaustufen!)
  - **Gebäude-Baukasten (Stein, Fachwerk/Stucco & Holz):**
    - `Stone_Wall_1..5`, `Stone_Arch`, `Stone_Doorway_*`, `Stone_Pillar`, `Stone_Steps`
    - `Stucco_Window_*`, `Stucco_Doorway_*`, `Stucco_Prop_Support_Beam_*`
    - `Roof_Straight_*`, `Roof_Concave_*`, `Roof_Convex_*`, `Roof_Prop_Chimney_Stone/Pipe`
    - `Canopy_*` (Marktstände & Überdachungen für Händler in Emberwatch!)
  - **Lebendige Dorf-Props & Logistik:**
    - `Prop_Cart_1`, `Prop_Cart_1_Barrels`, `Prop_Cart_1_Hay` (Handwagen für NPC-Warentransport & Karawanen!)
    - `Prop_Boat_1..2` + `Prop_Boat_Oars_1..2` (Ruderboote für Fischer & Küsten-/Sumpf-Reisen!)
    - `Prop_Barrel_1..2`, `Prop_Crate_1`, `Prop_Hay_1`, `Prop_Ladder_1`, `Prop_Broom`
    - `Prop_Lamp_Street`, `Wall_Prop_Lamp`, `Wall_Prop_Bell_1`, `Wall_Prop_Sign_1`, `Wall_Prop_Door_Ornate`
    - `Cobblestone_Floor_1`, `Cobblestone_Dirt_Transition_1..4`, `Stone_Sewer_Grate_1..2` (Kanalisations-Zugänge für Untergrund-Dungeons!)

---

### Paket 5: `modular_temple_collection.zip` (⭐⭐⭐ Perfekt für neue Dungeons & Rätsel-Mechaniken!)
- **Pfad:** `D:\LivingKingdom\_Userfiles\_Konzept\Assets\3D\modular_temple_collection.zip`
- **Format:** **Modulare `.obj` + `.mtl` Modelle**
- **Inhalt:**
  - **Interaktive Dungeon-Rätsel-Bauteile (!):**
    - `Puzzle_Control_Lever.obj` (Schalter/Hebel)
    - `Puzzle_Control_Pressure_Plate.obj` (Trittplatte)
    - `Puzzle_Control_Rising_Switch.obj` (Aufsteigender Obelisk-Schalter)
    - `Puzzle_Floor_Conduit_*` & `Rotating_Platform_*` (Drehbare Energie-/Licht-Leitungen im Boden für echte Tempel-Rätsel!)
  - **Monumentale Tempel-Architektur:**
    - `Pillar_Large_Arch`, `Balcony_Curved_*`, `Floor_Ruined_*`, `Stairs_*`, `Wall_*`
    - `Prop_Flag_Sun`, `Prop_Flag_Moon`, `Prop_Flag_Eclipse`, `Prop_Flag_Stars` (Sonnen-, Mond- und Finsternis-Banner & Teppiche!)
    - `Prop_Vase_1..3` (Zerstörbare Tempel-Vasen für Loot!)

---

### Paket 6: `modular_terrain_collection.zip` (⭐⭐⭐ Perfekt für neue Küsten-, Insel- & Berg-Biome!)
- **Pfad:** `D:\LivingKingdom\_Userfiles\_Konzept\Assets\3D\modular_terrain_collection.zip`
- **Format:** **Modulare `.obj` + `.mtl` Modelle**
- **Inhalt:**
  - **Neues Biom „Küste / Hafen / Schiffswrack-Strand“:**
    - `Beach_Prop_Docks_Straight`, `Beach_Prop_Docks_Corner`, `Beach_Prop_Docks_Steps` (Holzstege & Hafen-Anleger!)
    - `Beach_Prop_Treasure_Chest` (Schatztruhe)
    - `Beach_Prop_Tree_Palm_1..3`, `Beach_Prop_Coconut_1`, `Beach_Prop_Shell_1..2`, `Beach_Prop_Starfish_1..2`
    - `Beach_Terrain_Sand_*`
  - **Hügel-, Fluss- & Ruinen-Landschaft:**
    - `Hilly_Prop_Ruins_Pillar_1..5`, `Hilly_Prop_Hollow_Trunk`, `Hilly_Prop_Stepping_Stones_1..8`
    - `Hilly_Terrain_Water_Flat/Slope/Curve`, `Mountain_1..4`, `Shared_Prop_Boulder_1..6`

---

### Paket 7: Weitere Natur-Archive (`FBX` & `.7z`)
- `Textured Stylized Trees - May 2020\FBX` (45 Bäume + 12 Farbvarianten-Texturen: Frühling, Sommer, Herbst, Frost)
- `Ultimate Nature Pack - Jun 2019\FBX` (150 Low-Poly Natur-Modelle)
- `Assets\3D\nature_kit.zip` (über 300 kleine Natur-Blöcke in `.obj` und `.fbx`)
- `Assets\3D\Plants\Stylish plants.7z` & `tropical shrubs.7z`

---

## 3. Wie harmonieren die Assets optisch mit ASHFALL?

Ein wichtiger Punkt bei jedem Spiel ist die **visuelle Kohärenz**:
- **ASHFALL** nutzt stilisierte Low-/Mid-Poly-Geometrie (`props.glb`, `monsters.glb`, `equipment.glb`) kombiniert mit **atmosphärischem PBR-Lighting, Punktlichtern, Nebel, Bloom, SSAO und Farbkorrektur (`PostFX`)**.
- Die Assets aus `LivingKingdom` (insbesondere die Quaternius-Packs) haben **exakt dieselbe stilisierte Low-/Mid-Poly-Formensprache**!
- **Der Trick für 100 % nahtlose Optik in ASHFALL:**
  Beim Laden über [`AssetLibrary`](file:///f:/ASHFALL-ultracode/src/core/assets.js) durchlaufen die Meshes einen kurzen **Material-Harmonizer** (5 Zeilen Code):
  1. `castShadow = true` und `receiveShadow = true` aktivieren.
  2. `roughness` (z. B. `0.75–0.88`) und `envMapIntensity` an die ASHFALL-Beleuchtung anpassen.
  3. **Biom-/Mutations-Tinting:**
     - In **verdorbenen Asche-Zonen** werden Bäume/Tiere leicht entsättigt oder mit Asche-/Glut-Emissives versehen.
     - In **geheilten Zonen („The Wild“) und in Emberwatch („The Crown“)** erstrahlen die Birken, Ahornbäume, Blumen und Tiere in ihren warmen, lebendigen Originalfarben – was dem Spieler ein **unglaublich belohnendes visuelles Feedback** gibt, wenn er ein Gebiet von der Asche befreit!

---

## 4. Technische Integration in ASHFALL (So binden wir sie ein)

Um die Assets im Projekt `f:\ASHFALL-ultracode` zu nutzen, kopieren wir die benötigten Ordner nach `f:\ASHFALL-ultracode\assets\` (z. B. `assets/animals/`, `assets/nature/`, `assets/village/`, `assets/temple/`) und registrieren sie in [`src/core/assetIndex.js`](file:///f:/ASHFALL-ultracode/src/core/assetIndex.js).

### Beispiel 1: Ein animiertes Tier (`Wolf.gltf` oder `Horse.gltf`) in ASHFALL spawnen
Da [`src/core/assets.js`](file:///f:/ASHFALL-ultracode/src/core/assets.js) bereits `GLTFLoader` und `SkeletonUtils.clone` besitzt, reichen wenige Zeilen:

```js
// Laden & Clonen über die bestehende AssetLibrary (G.assets)
const gltf = await G.assets.loadGLB('assets/animals/Wolf.gltf', { force: true });
const mesh = G.assets.cloneSkinned(gltf.scene);

// AnimationMixer für Idle, Walk, Gallop, Attack, Eating, Death
const mixer = new THREE.AnimationMixer(mesh);
const clips = Object.fromEntries(gltf.animations.map((c) => [c.name, mixer.clipAction(c)]));
clips.Idle?.play();

// Genetik-Farbvariation & Größe direkt anwenden (aus LivingKingdom 04_KREATURENSYSTEM.md):
mesh.scale.setScalar(genome.size); // z.B. 1.35 für Alpha-/Riesenwolf
```

### Beispiel 2: Hunderte Bäume, Blumen & Wegsteine per GPU-Instancing
Genau wie in `14_ASSET_KATALOG.md` beschrieben, können wir `CommonTree_1..5`, `BirchTree_1..5`, `TwistedTree_1..5` und `RockPath_*` über `THREE.InstancedMesh` rendern – damit kosten selbst **500 Bäume und Sträucher pro Karte nur eine Handvoll Draw-Calls** bei stabilen 60 FPS.

---

## 5. Konkreter Vorschlag für den nächsten Schritt

Wenn du möchtest, können wir **sofort praktisch starten**:
1. Ich kopiere die **12 animierten Tiere (`Ultimate Animated Animals`)** und die **68 Natur-glTF-Assets (`Stylized Nature MegaKit` + `Ultimate Stylized Nature`)** sauber strukturiert in deinen `f:\ASHFALL-ultracode\assets\`-Ordner.
2. Wir bauen einen **Asset- & Kreaturen-Browser direkt als neuen Tab ins Developer Panel (`F2`)** ein, mit dem du jedes Tier (`Wolf`, `Hirsch`, `Pferd`, `Fuchs`, `Hund` usw.) inklusive seiner Animationen (`Idle`, `Gallop`, `Attack`, `Eating`) und jedes neue Natur-/Gebäude-Asset live vor deinem Helden in der Spielwelt spawnen und testen kannst!


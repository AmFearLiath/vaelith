# 04 – Konzept-Fusion: ASHFALL × Living Kingdoms („The Crown, The Blade & The Wild“)

**Basis-Projekte:**
- **ASHFALL** (`f:\ASHFALL-ultracode`) – Dark-Fantasy Action-RPG (Three.js, Echtzeit-Kampf, 3 Klassen, Loot- & Item-Generator, prozedurale Dungeons)
- **The Crown & The Wild: Living Kingdoms** (`D:\LivingKingdom\_Userfiles\_Konzept` & `D:\LivingKingdom\_Konzept`) – Siedlungsbau, lebendiges Ökosystem, Kreaturengenetik, Utility-AI-NPCs, AI Director & Systemic Incarnation

---

## 1. Können wir beide Konzepte miteinander vereinen?

**Ja – und zwar außergewöhnlich gut.**  
Was auf den ersten Blick wie zwei unterschiedliche Genres wirkt (Action-RPG vs. Aufbau-/Ökosystem-Simulation), ergänzt sich in Wahrheit perfekt. In der Spieleindustrie gehören genau solche Hybride (wie *Cult of the Lamb*, *SpellForce*, *ActRaiser*, *Enshrouded* oder *valheimartige Base-Building-ARPGs*) zu den fesselndsten Konzepten überhaupt, weil sich **aktive Action-Phasen** und **entspannende Aufbau-/Simulations-Phasen** gegenseitig antreiben.

### Warum ASHFALL und Living Kingdoms zusammenpassen wie zwei Puzzleteile:
1. **ASHFALL liefert das komplette „Mikro-Gameplay“ (Inkarnation / Action):**
   - In *Living Kingdoms* war unter `11_SYSTEMIC_INCARNATION.md` bereits geplant, dass der Spieler direkt in eine Entität der Welt schlüpfen und sie in der Third-Person-/Iso-Perspektive steuern kann.
   - **ASHFALL hat dieses System bereits komplett fertig:** Ein flüssiges 3D-Charakter-, Kampf-, Skill-, Inventar-, Dungeon- und Boss-System in Three.js!
2. **Living Kingdoms liefert das „Makro-Gameplay“ (Tiefe, Persistenz & Lebendigkeit):**
   - ASHFALL hatte bisher eine statische Stadt (`Emberwatch`) und rein kampffokussierte Außenwelten.
   - *Living Kingdoms* bringt genau das mit, was ASHFALL zu einem einzigartigen Spiel macht: **Siedlungsbau, ein reaktives Ökosystem (Flora/Fauna/Nahrungsketten), Tierzucht & Genetik, intelligente Dorfbewohner mit Bedürfnissen/Berufen (Utility-AI) und einen AI Director für emergente Krisen.**

---

## 2. Die gemeinsame Kernvision: „Heile die Welt oder beherrsche das Chaos“

### Die narrative & spielerische Klammer
Nach dem **Asche-Kataklysmus (Ashfall)** ist die Welt in Dunkelheit, Ruinen und mutierte Wildnis zerfallen. **Emberwatch** ist die letzte Zuflucht der Menschheit.  
Du bist nicht nur ein einzelner Wanderer, sondern der **Hüter von Emberwatch**:

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                 ASHFALL: LIVING KINGDOMS (HYBRID-KONZEPT)                    │
├────────────────────────┬─────────────────────────┬───────────────────────────┤
│    1. THE BLADE        │     2. THE CROWN        │      3. THE WILD          │
│   (Ashfall ARPG)       │  (Siedlung & Ökonomie)  │  (Ökosystem & Genetik)    │
├────────────────────────┼─────────────────────────┼───────────────────────────┤
│ • Direkt gesteuerter   │ • Ausbau von Emberwatch │ • Lebendige Flora & Fauna │
│   Held (3 Klassen)     │   & Außenposten         │   (Hirsche, Wölfe, Füchse)│
│ • Dungeons, Bosse,     │ • Gebäude platzieren    │ • Nahrungsketten &        │
│   Rifts & Loot-Jagd    │   (Schmiede, Mühle,     │   Biom-Gesundheit         │
│ • Sammeln von Relikten,│   Farmen, Labor)        │ • Asche-Korruption vs.    │
│   Samen & Gen-Proben   │ • Utility-AI NPCs mit   │   Natur-Heilung           │
│ • Verteidigung der     │   Jobs, Bedürfnissen &  │ • Zähmung, Tierzucht,     │
│   Siedlung bei Krisen  │   Warenketten           │   Reittiere & Mutationen  │
└───────────┬────────────┴────────────┬────────────┴─────────────┬─────────────┘
            │                         │                          │
            └─────────────────────────┼──────────────────────────┘
                                      ▼
            ┌────────────────────────────────────────────────────┐
            │        DER EWIGE KREISLAUF (CORE LOOP)             │
            │                                                    │
            │  Expedition & Kampf (The Blade)                    │
            │    → bringt Ressourcen, Samen, Tiere & Sicherheit  │
            │  Siedlungsbau & Handwerk (The Crown)               │
            │    → stärkt den Helden, verändert die Umwelt       │
            │  Ökosystem & AI Director (The Wild)                │
            │    → reagiert auf Abbau, Heilung oder Korruption   │
            └────────────────────────────────────────────────────┘
```

---

## 3. Wie sich die Systeme aus `LivingKingdom` konkret in `ASHFALL` integrieren lassen

Hier ist die genaue Zuordnung, wie wir nahezu **alle Konzepte aus `D:\LivingKingdom\_Userfiles\_Konzept`** direkt in ASHFALL übernehmen können:

### 3.1 „The Wild“: Ökosystem, Nahrungskette & Asche-Korruption (`03_SPIELWELT.md`, `06_OEKOSYSTEM.md`)
In ASHFALL gibt es aktuell verdorbene Gebiete (`The Grey Fields`, `The Burning Hollow`). Mit dem Ökosystem-Konzept aus *Living Kingdoms* bekommt jedes Gebiet einen dynamischen **Biom-Zustand**:
- **Biom-Gesundheit vs. Asche-Verderbnis (`0% – 100%`):**
  - Zu Beginn ist ein Gebiet von Asche, verdorrten Bäumen (`DeadTree_1..10`, `TwistedTree_1..5`) und Untoten/Dämonen geprägt.
  - Wenn der Spieler dort **Asche-Knoten zerstört**, **Natur-Schreine reinigt** oder **Samen pflanzt**, regeneriert sich das Biom sichtbar zur Laufzeit: Aus verbrannter Erde sprießen Gräser, Blumen (`Flower_Clump`), Birken (`BirchTree`) und Laubbäume (`CommonTree`), und das düstere Nebellicht wandelt sich in warmes Sonnenlicht!
- **Aktion → Reaktion → Konsequenz (Ökologische Rückkopplung):**
  - In gesunden Zonen leben **Herbivoren** (Hirsche `Deer`/`Stag`, Alpakas) und **Karnivoren** (Wölfe `Wolf`, Füchse `Fox`).
  - **Raubbau-Konsequenz:** Wenn deine Holzfäller aus Emberwatch zu viel Wald roden oder du alle Hirsche jagst, kippt das Gleichgewicht:
    ```
    Zu viel Wald gerodet / Hirsche ausgerottet
      → Wölfe hungern & wandern Richtung Emberwatch
      → Asche-Sporen befallen geschwächte Tiere
      → Es entstehen mutierte „Asche-Wölfe“ (Elite-Rudel)
      → Überfall auf die Felder und Karawanen deiner Siedlung!
    ```

---

### 3.2 Kreaturensystem, Genetik, Begleiter & Reittiere (`04_KREATURENSYSTEM.md`, `08_BIO_TECH_SYSTEM.md`)
Das `CreatureGenetics`-System aus *Living Kingdoms* ist reines, leichtgewichtiges Daten-Design (`size`, `speed`, `strength`, `aggression`, `resistances`, `coatColor`, `mutations`) und lässt sich **1:1 in JavaScript (`src/entities/creatures/`)** übernehmen:
1. **Wildtiere zähmen statt nur bekämpfen:**
   - Statt jedes Tier zu töten, kann der Spieler verletzte oder junge Wildtiere (Wolf, Hirsch, Fuchs, Pferd, Hund) mit Nahrung/Beruhigungstränken **zähmen** (`tameness: 0 → 100`) und nach Emberwatch schicken.
2. **Tierzucht & Bio-Alchemie in Emberwatch (`08_BIO_TECH_SYSTEM.md`):**
   - Im **Bestiarium / Zuchtgehege** (oder Alchemie-Labor) der Siedlung können zwei Tiere gekreuzt werden (`breedCreatures(parentA, parentB)`).
   - Die Nachkommen erben die besten Gene (`size`, `speed`, `strength`, Elementar-Resistenzen) und können **fantastische Mutationen** ausbilden, die bereits in `04_KREATURENSYSTEM.md` definiert sind:
     - **Schattenwolf** (Wolf + Schatten-Essenz): Nachtaktiv, schneller Angriff, teleportiert sich mit dem Helden.
     - **Riesenhirsch** (Stag + Gigantismus): Majestätisches Reittier mit Dornen-Aura.
     - **Phönix-/Asche-Begleiter** (Feuer-Mutation): Gewährt Feuerresistenz und verbrennt nahe Gegner.
     - **Kristall-Bestie** (Mineral-Mutation): Hohe Rüstung, lässt regelmäßig Edelsteine/Arcane Dust fallen.
3. **Direkter Nutzen im ARPG:**
   - **Kampf-Begleiter (Pets):** Begleiten den Helden zusätzlich zum Söldner.
   - **Reittiere (Mounts):** Gezähmte Pferde (`Horse.gltf`, `Horse_White.gltf`) oder Hirsche (`Stag.gltf`) erhöhen die Reisegeschwindigkeit in großen Außenwelten massiv.
   - **Nutztiere:** Kühe (`Cow`), Schafe, Esel (`Donkey`) und Alpakas (`Alpaca`) versorgen die Siedlung und ziehen Handelskarawanen.

---

### 3.3 „The Crown“: Siedlungsbau & Wirtschaft in Emberwatch (`05_WIRTSCHAFTSSYSTEM.md`)
Statt dass `Emberwatch` nur eine kleine statische Karte mit 4 Händlern ist, wird die Stadt (und freigeschaltete Außenposten in den Regionen) zur **baubaren Heimatbasis**:
- **Kamera-Umschaltung (Held ↔ Bau-Modus):**
  - Sobald der Spieler in Emberwatch (oder an einem eroberten Außenposten) ist, kann er per Tastendruck (z. B. `V` oder Button im HUD) in die **höhere Aufbauspiel-Kamera (Makro-Ansicht)** wechseln.
- **Gebäude platzieren & aufwerten (mit den Modular-Village-Assets):**
  - **Rohstoff-Gebäude:** Holzfällerhütte, Steinbruch, Erzschmelze, Wassermühle (`Waterwheel_1`), Windmühle (`Windmill_1`), Brunnen (`Prop_Well`).
  - **Versorgung:** Bauernhof, Bäckerei, Taverne (für NPC-Zufriedenheit und Buff-Mahlzeiten vor Dungeon-Runs).
  - **Helden-Infrastruktur:** Schmiede-Ausbau (schaltet höhere Crafting-Tiers frei), Alchemisten-Turm (Bio-Tech & Tränke), Bestien-Gehege (Tierzucht), Wachtürme & Stadtmauern (`Stone_Wall`, `Stone_Arch`).
- **Siedlungs-Warenketten unterstützen den Helden:**
  - Während du in Dungeons kämpfst, produzieren deine Dorfbewohner im Hintergrund (über das **Simulations-LOD** aus `07_NPC_SIMULATION.md`) Holz, Stein, Nahrung, `Iron Scrap`, `Arcane Dust` und Gold.

---

### 3.4 Intelligente NPCs mit Utility-AI & Bedürfnissen (`07_NPC_SIMULATION.md`)
In unserer ersten Analyse hattest du bereits gefragt, ob wir **NPCs intelligenter machen** können. Das Konzept aus `07_NPC_SIMULATION.md` liefert dafür die perfekte Vorlage:
- **Bedürfnisse (`NpcNeeds`):** Hunger, Energie (Schlaf), Sicherheit (`safety`), Wohnkomfort (`comfort`) und Zufriedenheit (`happiness`).
- **Persönlichkeit & Berufe (`NpcPersonality` & `NpcSkills`):**
  - Jeder gerettete Überlebende, den du in der Spielwelt findest und nach Emberwatch bringst, hat eigene Attribute (z. B. *„Fleißiger Schmied“*, *„Furchtlose Jägerin“*, *„Kräuterkundiger“*).
  - Du kannst NPCs konkreten Betrieben in Emberwatch zuweisen oder sie als **Begleiter/Wachen** ausrüsten!
- **Tagesabläufe per Utility-AI:**
  - Morgens gehen NPCs vom Wohnhaus zum Arbeitsplatz (Feld, Mühle, Schmiede, Wachturm), holen Rohstoffe mit Karren (`Prop_Cart_1`), essen mittags am Marktplatz, plaudern abends an den Straßenlaternen (`Prop_Lamp_Street`) und fliehen in die Häuser, wenn ein Monster-Überfall stattfindet.
- **Simulations-LOD (Performance-Garantie):**
  - **Ist der Spieler in Emberwatch (LOD 2):** Volle 3D-Darstellung, echte Laufwege, sichtbares Tragen von Waren und Sprechblasen/Dialoge.
  - **Ist der Spieler im Dungeon (LOD 0/1):** Reine Bilanz-Berechnung im Hintergrund (1 Tick pro Sekunde) – kostet **0 ms Renderzeit** während der Kämpfe!

---

### 3.5 AI Director & Emergente Krisen (`09_EVENTS_UND_KRISEN.md`)
Der **AI Director** verknüpft *The Crown*, *The Wild* und *The Blade* zu dynamischen Quests:
- Er überwacht alle 30 Sekunden drei Werte:
  1. **Siedlungs-Wohlstand** (Vorräte, Bevölkerung, Verteidigung)
  2. **Ökosystem-Balance** (Wald-Dichte, Wildtier-Population, Jagddruck)
  3. **Asche-Bedrohung** (Wie viele Dungeons/Rifts sind ungesäubert?)
- Daraus erzeugt er **emergente Welt-Events & Quests**:
  - **„Die hungrige Meute“:** Durch Überjagung im *Greyfield* greift ein Rudel mutierter Schattenwölfe die Schafweiden von Emberwatch an → Verteidige das Dorf oder lege Nahrungsköder aus!
  - **„Die Purpur-Sporenplage“:** Eine Pilz-Mutation (`Mushroom_Laetiporus`) breitet sich von den Katakomben auf die Getreidefelder aus → Dringe in die Katakomben ein, besiege den Sporen-Wirt und erforsche im Bio-Labor resistentes Saatgut!
  - **„Die Karawane in Not“:** Eine Handelskarawane deiner Siedlung (`Prop_Cart_1` + `Donkey.gltf`) wurde im *Burning Hollow* überfallen → Eskortiere sie zurück!

---

## 4. Wie fühlt sich der Mix im Spielalltag an? (Ein Beispiel-Durchlauf)

1. **Morgen in Emberwatch (Aufbau & Pflege – 5 bis 10 Min.):**
   - Du kehrst mit Beute aus einem Dungeon zurück.
   - Deine Holzfäller und Steinmetze haben genug Material gesammelt: Du schaltest kurz in die **Bau-Ansicht**, errichtest eine **Wassermühle** am Fluss und erweiterst das **Wildtier-Gehege**.
   - Im Gehege ist ein neues Wolfsjunges geschlüpft, das die *Frost-Mutation* seiner Eltern geerbt hat. Du wählst es als deinen neuen Begleiter aus.
2. **Aufbruch in die Grenzlande (Erkundung & Ökologie – 10 Min.):**
   - Du steigst auf dein gezähmtes **Reitpferd (`Horse_White`)** und reitest in die *Grey Fields*.
   - Im nördlichen Teil hast du gestern einen Asche-Schrein gereinigt – dort wachsen jetzt junge Birken (`BirchTree`) und eine Herde Hirsche (`Deer` / `Stag`) zieht friedlich umher.
   - Weiter südlich meldet der **AI Director**: *„Ein Asche-Riss vergiftet den Fluss – die Fauna mutiert!“*
3. **Action & Bosskampf (ARPG Core – 10 bis 15 Min.):**
   - Du steigst ab, kämpfst dich mit deinem Helden und deinem Frost-Wolf durch die mutierten Kreaturen in den **alten Tempel (`Modular Temple`)**, löst dort ein Schalter-/Bodenplatten-Rätsel (`Puzzle_Control_Lever` / `Pressure_Plate`) und besiegst den Tempel-Boss.
   - Als Belohnung erhältst du ein **Legendäres Schwert**, einen **alten Bauplan (Windmühle)**, **heilige Baum-Samen** und **2 gerettete Handwerker** für Emberwatch!

---

## 5. Empfohlene Umsetzungs-Reihenfolge (Modulare Meilensteine)

Damit das Projekt jederzeit spielbar bleibt und wir Schritt für Schritt vorgehen können, empfiehlt sich folgende Reihenfolge:

| Phase | Fokus | Was wird eingebaut? |
|---|---|---|
| **Meilenstein 1** | **Lebendige Tierwelt, Reittiere & Begleiter** | Integration der 12 animierten glTF-Tiere (`Wolf`, `Stag`, `Deer`, `Fox`, `Horse`, `Husky` etc.) + Basis-Ökosystem (Grasen, Rudel, Jagd) + Zähmung & Reiten. |
| **Meilenstein 2** | **Neue Biome, Natur-Heilung & Tempel-Rätsel** | Integration der Natur-glTFs (`BirchTree`, `MapleTree`, `TwistedTree`, `Mushrooms`) & Tempel-Assets. Mechanik: Verdorbene Zonen heilen und sichtbar begrünen! |
| **Meilenstein 3** | **Intelligente Dorfbewohner (Utility-AI)** | Bewohner in Emberwatch erhalten Namen, Berufe, Bedürfnisse (`Hunger`, `Schlaf`, `Sicherheit`) und sichtbare Tagesabläufe. |
| **Meilenstein 4** | **Siedlungsbau („The Crown“) in Emberwatch** | Bau-Kamera, Platzieren von Gebäuden (aus `Modular Village`), passive Rohstoffproduktion & Stadt-Aufwertung. |
| **Meilenstein 5** | **Genetik-Zucht & AI Director Krisen** | Kreuzen gezähmter Tiere mit sichtbaren Mutationen + dynamische Ökosystem-/Siedlungs-Quests durch den AI Director. |


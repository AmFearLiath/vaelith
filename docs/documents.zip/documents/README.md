# 📖 EMBERWILD — DOKUMENTATION & ARCHIV
## Verzeichnis-Struktur & Übersicht aller Konzepte

> Diese zentrale Dokumentations-Ablage trennt die Konzepte, Architekturen und Mechaniken von **Emberwild** sauber in zwei Kernbereiche:

---

## 📂 1. [`singleplayer/`](file:///f:/Emberwild/documents/singleplayer/) — Kern-Architektur & Singleplayer-Systeme
Enthält die vollständige Basis-Dokumentation, Architektur-Analysen und Designpläne der Singleplayer-Engine:

| Dokument | Thema |
| :--- | :--- |
| **[`01_ARCHITEKTUR_ANALYSE.md`](file:///f:/Emberwild/documents/singleplayer/01_ARCHITEKTUR_ANALYSE.md)** | Codebase-Audit, Three.js-Pipeline, Asset-Lader, ECS/Entity-System, Combat-Loop. |
| **[`02_ERWEITERBARKEIT_KERNBEREICHE.md`](file:///f:/Emberwild/documents/singleplayer/02_ERWEITERBARKEIT_KERNBEREICHE.md)** | Erweiterbarkeit von Combat, Skills, Quests, Loot, AI, Animationen & Audio. |
| **[`03_FEATURE_UND_MECHANIK_VORSCHLAEGE.md`](file:///f:/Emberwild/documents/singleplayer/03_FEATURE_UND_MECHANIK_VORSCHLAEGE.md)** | Mechanik-Vorschläge für Nekromantie, Resonanzen, Crafting, Mounts & Bestiarium. |
| **[`04_KONZEPT_FUSION_ASHFALL_UND_LIVING_KINGDOM.md`](file:///f:/Emberwild/documents/singleplayer/04_KONZEPT_FUSION_ASHFALL_UND_LIVING_KINGDOM.md)** | Meilensteine der Fusion: Die Krone (Siedlung), 12 Schreine, Reiten & Zucht, AI-Direktor. |
| **[`05_ASSET_INTEGRATION_UND_PIPELINE.md`](file:///f:/Emberwild/documents/singleplayer/05_ASSET_INTEGRATION_UND_PIPELINE.md)** | Asset-Pipeline: GLTF/GLB, Quaternius Farm- & Wildtiere, Synty-Rüstungen & Icons. |

---

## 🌐 2. [`multiplayer/`](file:///f:/Emberwild/documents/multiplayer/) — MMO, Territorien & Welten-Architektur
Enthält das vollständige, modulare Konzept für das Multiplayer- und Territorial-System von Emberwild:

| Dokument | Thema |
| :--- | :--- |
| **[`00_UEBERSICHT_UND_MASTERPLAN.md`](file:///f:/Emberwild/documents/multiplayer/00_UEBERSICHT_UND_MASTERPLAN.md)** | Gesamtüberblick, Kernphilosophie (Solo vs. Clan), Makro-zu-Mikro-Schleife. |
| **[`01_WELTKARTE_UND_ZONEN_ARCHITEKTUR.md`](file:///f:/Emberwild/documents/multiplayer/01_WELTKARTE_UND_ZONEN_ARCHITEKTUR.md)** | Azgaar-Pipeline, Kontinental-Raster, physische Reiserouten, 2.5D-Zonenwechsel. |
| **[`02_GILDEN_CLANS_UND_TERRITORIEN.md`](file:///f:/Emberwild/documents/multiplayer/02_GILDEN_CLANS_UND_TERRITORIEN.md)** | Bünde der Flamme, Ränge, Gilden-Schatzkammer, Bannsteine, Solo-Spieler-Pfad. |
| **[`03_DIPLOMATIE_HANDEL_UND_UNTERSTUETZUNG.md`](file:///f:/Emberwild/documents/multiplayer/03_DIPLOMATIE_HANDEL_UND_UNTERSTUETZUNG.md)** | Friedenspakte, Allianzen, Flammen-Portale, Handelskarawanen & Basar. |
| **[`04_KAMPF_BELAGERUNGEN_UND_GVG.md`](file:///f:/Emberwild/documents/multiplayer/04_KAMPF_BELAGERUNGEN_UND_GVG.md)** | Schrein-Belagerungen in 3 Phasen, Kriegsfenster (kein Offline-Raiding), PvP-Karma. |
| **[`05_SERVER_EVENTS_UND_WELTBOSSE.md`](file:///f:/Emberwild/documents/multiplayer/05_SERVER_EVENTS_UND_WELTBOSSE.md)** | Weltereignisse: The Great Cinderfall, Titan Ignis, Konklave der Ersten Flamme. |
| **[`06_PERFORMANZ_NETZWERK_UND_CODE_STRUKTUR.md`](file:///f:/Emberwild/documents/multiplayer/06_PERFORMANZ_NETZWERK_UND_CODE_STRUKTUR.md)** | Authoritativer Server-Cluster (20 Hz), Prediction & Interpolation, Sharding, 60 FPS. |
| **[`07_LEVELDESIGN_GENERIERUNG_UND_DEV_EDITOR.md`](file:///f:/Emberwild/documents/multiplayer/07_LEVELDESIGN_GENERIERUNG_UND_DEV_EDITOR.md)** | Deterministisch-hybride Generierung, On-Demand Lifecycle, In-Game Dev-Map-Editor. |
| **[`08_ENTSCHEIDUNGSFRAGEN_UND_WEICHENSTELLUNGEN.md`](file:///f:/Emberwild/documents/multiplayer/08_ENTSCHEIDUNGSFRAGEN_UND_WEICHENSTELLUNGEN.md)** | Strategische Weichenstellungen: Welttopologie, Servermodell, Territoriumskosten, PvP-Regeln & Roadmap. |

---

## 🏛️ 3. [`concept_fusion/`](file:///f:/Emberwild/documents/concept_fusion/) — Synthese mit *The Crown & The Wild*
Detaillierte Ausarbeitung der Übernahme-Kandidaten aus den Konzepten von *Living Kingdoms*:

| Dokument | Thema |
| :--- | :--- |
| **[`00_OVERVIEW_AND_ANALYSIS.md`](file:///f:/Emberwild/documents/concept_fusion/00_OVERVIEW_AND_ANALYSIS.md)** | Gesamtübersicht, Kernvision, Übernahme-Kandidaten vs. bewusst ausgelassene Systeme. |
| **[`01_ASHEN_ECOLOGY_AND_MUTATIONS.md`](file:///f:/Emberwild/documents/concept_fusion/01_ASHEN_ECOLOGY_AND_MUTATIONS.md)** | Nahrungsketten, Tierverhalten, Asche-Mutationen & Vertiefung von Zucht und Genetik. |
| **[`02_SETTLEMENT_ECONOMY_AND_CARAVANS.md`](file:///f:/Emberwild/documents/concept_fusion/02_SETTLEMENT_ECONOMY_AND_CARAVANS.md)** | 4-Stufen-Warenwirtschaft, physische Karawanen zwischen Emberwatch und den 294 Provinzen. |
| **[`03_NPC_CAREER_MANAGERS_AND_VILLAGE_LIFE.md`](file:///f:/Emberwild/documents/concept_fusion/03_NPC_CAREER_MANAGERS_AND_VILLAGE_LIFE.md)** | Gebäude-Meister (Vorarbeiter), Berufsaufstiege, Arbeitsmarkt, Sim-LOD & Dorfleben. |
| **[`04_EMERGENT_EVENTS_AND_CRISIS_DIRECTOR.md`](file:///f:/Emberwild/documents/concept_fusion/04_EMERGENT_EVENTS_AND_CRISIS_DIRECTOR.md)** | Der Asche-Direktor, Zustandstrigger, 4 Krisenstufen & emergente Quests. |
| **[`05_INTEGRATION_ROADMAP_AND_TECH_FIT.md`](file:///f:/Emberwild/documents/concept_fusion/05_INTEGRATION_ROADMAP_AND_TECH_FIT.md)** | 4-Phasen-Implementierungsplan, technischer Fit in Three.js/ESM, Performance-Budget (60 FPS). |

---

## 🏰 4. [`bausystem_und_expansion/`](file:///f:/Emberwild/documents/bausystem_und_expansion/) — Bausystem, Action-Paradigma & Expansion
Vollständige Konzeption für das interaktive 3D-Bausystem, Zitadelle vs. Dorf, Weltkarten-Ressourcenkreislauf, Gilden & Dev-Tooling:

| Dokument | Thema |
| :--- | :--- |
| **[`00_MASTERVISION_UND_ACTION_PARADIGMA.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/00_MASTERVISION_UND_ACTION_PARADIGMA.md)** | Neuausrichtung: Weg vom passiven Menü-Clicker, hin zum aktiven 3D-ARPG-Erlebnis. Burg vs. Dorf. |
| **[`01_BURG_VS_DORF_GEBAEUDEKATALOG.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/01_BURG_VS_DORF_GEBAEUDEKATALOG.md)** | Vollständiger Blueprint-Katalog aller baubaren Strukturen: Schlossflügel vs. freie Dorfgebäude. |
| **[`02_3D_BAUSYSTEM_UND_INTERAKTION.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/02_3D_BAUSYSTEM_UND_INTERAKTION.md)** | Technische Spezifikation: Hologramm-Raycast, Rotationssteuerung, Bauhammer-Phasen, NavMesh & Save. |
| **[`03_MULTIPLAYER_GILDEN_UND_TERRITORIEN.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/03_MULTIPLAYER_GILDEN_UND_TERRITORIEN.md)** | Gilden- & Multiplayer-Architektur: Glutstein-Claim, Rollenmatrix, Monumente, Banner, Anti-Grieving. |
| **[`04_EXPANSIONSKREISLAUF_UND_PROVINZEN.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/04_EXPANSIONSKREISLAUF_UND_PROVINZEN.md)** | Expansionsloop: Provinz-Eroberung, Außenposten, Karawanen & Reichs-Boni. |
| **[`05_DEV_EDITOR_UND_TOOLING.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/05_DEV_EDITOR_UND_TOOLING.md)** | In-Game Dev-Editor: Hotkey [F6], Gizmo-Transform, Spawner, Prefab-Export. |

---

## 🏔️ 5. Zukunftskonzepte (Post-Bausystem)
Konzepte für zukünftige Entwicklungsphasen nach Fertigstellung des Bausystems:

| Dokument | Thema |
| :--- | :--- |
| **[`3D_PERSPEKTIVE_UND_VERTIKALITAET_KONZEPT.md`](file:///f:/Emberwild/documents/3D_PERSPEKTIVE_UND_VERTIKALITAET_KONZEPT.md)** | Echte 3D-Dimensionen, Treppensteigen, Y-Sampling, begehbare Wehrmauern, Spring-Arm Kamera & Hybrid-Third-Person. |
| **[`04_WELTKARTE_EXPANSION_UND_RESSOURCENKREISLAUF.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/04_WELTKARTE_EXPANSION_UND_RESSOURCENKREISLAUF.md)** | Aktives 3D-Ernten (Holz, Erz, Kräuter, Jagd), Provinzen als Rohstoff-Monopole, Außenposten & Karawanen. |
| **[`05_DEV_EDITOR_UND_TOOLING.md`](file:///f:/Emberwild/documents/bausystem_und_expansion/05_DEV_EDITOR_UND_TOOLING.md)** | In-Game Entwickler-Editor (`F7` / `G.editor`): Fly-Cam, 3D-Gizmos, Live-NavMesh, JSON-Export. |



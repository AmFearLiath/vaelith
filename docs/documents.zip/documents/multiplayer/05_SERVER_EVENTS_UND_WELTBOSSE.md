# 🌋 DOKUMENT 05: SERVER-EVENTS & WELTBOSSE
## Globale Kataklysmen, Titanenschlachten & Das Konklave der Flamme

> **Teil der Reihe:** Emberwild Multiplayer & Territorien  
> **Status:** Konzept- und Designdokument (Kein Code)

---

## 1. Philosophie: Dynamische Welt statt statischer Grind

In **Emberwild** ist die Spielwelt niemals in Ruhe. Das Ascheland pulsiert, atmet und schlägt zurück.  
Server-Events sind keine isolierten Instanzen, sondern **Ereignisse auf dem echten Kontinent**, die das Zusammenspiel aller Spieler erfordern — vom kleinen Solo-Kräutersammler bis zur größten Gildenallianz.

---

## 2. Event 1: *Der Große Cinderfall (The Great Cinderfall)*

```mermaid
flowchart TD
    Warning["Phase 1: Der Rote Himmel (12 Std. Vorwarnung)<br/>Ascheregen verstärkt sich; Himmel färbt sich purpurrot"] --> Invasion["Phase 2: Die Wanderhorden (2 Std.)<br/>Massiver Ansturm auf alle 12 Schreine simultan"]
    Invasion --> TitanSpawn["Phase 3: Der Welten-Titan erwacht<br/>Ignis der Schmelz-Koloss wandert über die Weltkarte"]
    TitanSpawn --> Victory["Sieg: Titan besiegt<br/>Kontinent erhält 'Segen des ewigen Frühlings'<br/>Reiche Ernten & Legendäre Beute"]
    TitanSpawn --> Defeat["Niederlage: Bannkreise gebrochen<br/>Land verfällt für 24h in tiefen Aschefluch"]
```

### 2.1 Ablauf & Phasen
1. **Vorwarnung (Der Omen-Tag):**
   - Auf der großen Weltkarte zieht eine gewaltige, rot glühende Wolkenfront auf.
   - Farm- und Plantagenerträge steigen kurzfristig (Panik-Ernte vor dem Sturm).
2. **Die Aschesturm-Invasion:**
   - Hunderte Monster (Ghoule, Asche-Wächter, Knochen-Titanen) strömen aus den Asche-Spalten.
   - Die in `director.js` verankerte Krisen-Logik skaliert serverweit: Wellen stürmen nicht nur ein Dorf, sondern attackieren alle von Gilden beanspruchten Schreine gleichzeitig.
   - Gilden müssen zusammenarbeiten, um Nachbarschreine zu retten, wenn deren Verteidigung wankt.
3. **Der Weltboss: „Ignis – Der Schmelz-Koloss“:**
   - Ein gigantischer Titan aus geschmolzenem Stein und flüssigem Obsidian wandert über die Zonen der Weltkarte.
   - **Multi-Phasen-Kampf in der 2.5D-Ansicht:**
     - *Phase A (Panzerung):* Barbaren auf Panzerstieren müssen die Beine des Titanen rammen, um ihn zum Einsturz zu bringen.
     - *Phase B (Feuersturm):* Magier errichten Eisbarrieren, um die Teams vor flüssigen Magmageschossen zu schützen.
     - *Phase C (Asche-Seelen):* Der Boss absorbiert tote Kreaturen. Totenbeschwörer müssen die Seelen vor ihm erwecken und als brennende Aschekrieger gegen den Koloss selbst wenden.

### 2.2 Belohnungen des Cinderfalls
- **Für Teilnehmer:** Jeder Spieler, der mindestens 5 Minuten am Event teilnimmt, erhält eine *Truhe der Ewigen Glut*.
- **Für die siegreichen Gilden:**
  - *Titanen-Kern:* Rohstoff zum Bau des Stufe-4-Palastes oder mythischer Belagerungswaffen.
  - *Uralte DNA-Essenz:* Einzigartige Gene für das Gestüt (`breeding.js`), um feuerspeiende Reittiere zu züchten.

---

## 3. Event 2: *Das Konklave der Ersten Flamme (Das Kronen-Turnier)*

Ein wöchentliches, prestige-trächtiges Event, bei dem die mächtigsten Bünde um die Vorherrschaft des gesamten Kontinents ringen.

### 3.1 Der Sonnenkrater (Die neutrale Arena)
- Im geografischen Zentrum von Aethelgard liegt der **Uralte Sonnenkrater**.
- Einmal pro Woche (z. B. jeden Sonntagabend) öffnet sich das Tor zum Krater für 90 Minuten.
- Alle Gilden können mit ihren besten Kriegern und Reittieren einrücken.

### 3.2 Die Spielmechanik: Flammen-Tribute
- Im Krater brennt die **Erste Flamme**, die erloschen zu sein droht.
- **Ressourcen- und Kampfwettstreit:**
  - Gilden müssen **Asche-Glutsteine** und **hochwertige Nahrung von den Plantagen** in das Flammenbecken opfern.
  - Währenddessen ist der Krater ein offenes Schlachtfeld: Angreifende Gilden versuchen, die Träger der gegnerischen Bünde aufzuhalten.
  - Jeder geopferte Korb und jeder siegreiche Kampf generiert *Flammen-Gunst*.

### 3.3 Der Preis: Der Titel „Hüter der Krone“
Die Gilde mit der höchsten Gunst wird für 7 Tage zum amtierenden Herrscher des Kontinents gekrönt:
- **Königliche Steuern:** Die Herrscher-Gilde erhält automatisch 5% aller im Auktionshaus gezahlten Handelssteuern des Kontinents in ihre Gildenbank.
- **Das Flammenmähnen-Ross:** Ein majestätisches, glühendes Reittier mit maximalen Werten für den Großmeister der Gilde.
- **Monument in Emberwatch:** Eine riesige Statue des Sieger-Clans wird auf dem Marktplatz von Emberwatch errichtet.

---

## 4. Lokale Mini-Events (Spontane Vorkommnisse)

Neben den Mega-Events triggert das System kleinere, dynamische Vorkommnisse in einzelnen Provinzen:
- **Die Asche-Karawane des Königs:** Eine vom Schicksal verlassene Gold-Karawane bleibt in einer Zone stecken. Solo-Spieler und Gilden kämpfen um die Bergung der Beutekisten.
- **Herde Wilder Ur-Büffel:** Eine seltene Herde bricht durch die Grey Fields. Spieler können mit Wurffallen und Zähm-Ausrüstung (`mounts.js`) versuchen, legendäre Zuchttiere für ihren Stall zu fangen.
- **Schrein-Resonanz:** Für 3 Stunden werfen alle Plantagen und Farmen in einem geheilten Schrein-Bezirk die doppelte Ernte ab.

---
*Nächstes Dokument: [`06_PERFORMANZ_NETZWERK_UND_CODE_STRUKTUR.md`](file:///f:/Emberwild/documents/multiplayer/06_PERFORMANZ_NETZWERK_UND_CODE_STRUKTUR.md)*.


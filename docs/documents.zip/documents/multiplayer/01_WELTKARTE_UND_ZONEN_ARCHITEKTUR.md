# 🗺️ DOKUMENT 01: WELTKARTE & ZONEN-ARCHITEKTUR
## Kontinentale Ausdehnung, Azgaar-Pipeline & Nahtloser 2.5D-Zonenwechsel

> **Teil der Reihe:** Emberwild Multiplayer & Territorien  
> **Ziel:** Unbegrenzter Raum für tausende Spieler und hunderte Gilden bei gleichbleibend flüssiger 60 FPS Performance.

---

## 1. Das Problem & Die Lösung

### Bisherige Situation
- Die aktuelle Karte (**Grey Fields & Emberwatch**) hat Dimensionen von ca. `[-200, +200]` Einheiten. Sie eignet sich hervorragend als Kernregion für eine Siedlung und 12 Schreine, bietet aber auf Dauer nicht genug Platz für Dutzende konkurrierende Imperien, riesige Farmen und weitläufige Landesgrenzen.

### Die Lösung: Zweistufige Welt (Makro- und Mikro-Ebene)
1. **Makro-Ebene (Die Große Weltkarte):**
   - Ein gigantischer Kontinent namens **„Aethelgard – Die Aschelande“**.
   - Die Karte wird mit **Azgaar's Fantasy Map Generator** (oder einem kompatiblen prozeduralen Voronoi-Graph-System) erstellt und als standardisiertes Datenformat (GeoJSON / Azgaar `.map` JSON) exportiert.
   - Der Kontinent besteht aus **Provinzen / Sektoren (Hex-/Voronoi-Zellen)**, Flüssen, Gebirgszügen, Biomen und Straßennetzwerken.
2. **Mikro-Ebene (Die 2.5D-Isometrische Zonen-Ansicht):**
   - Klickt der Spieler auf eine Provinz auf der Weltkarte oder wandert über die Grenze einer Zone, wechselt die Ansicht nahtlos in die vertraute Three.js-Echtzeit-Ansicht.
   - Jede Provinz besitzt ein eigenes, reproduzierbares Terrain (Höhenkarte, Biom, Bäume, Ruinen) basierend auf dem Seed der Weltkarte.

---

## 2. Azgaar Fantasy Map Generator Pipeline

### 2.1 Daten-Extraktion aus Azgaar
Azgaar generiert hochkomplexe Welten mit realistischer Geographie, die sich perfekt als Gilden-Spielfeld eignen. Der Pipeline-Ablauf:

```mermaid
flowchart LR
    Azgaar["Azgaar Map Generator<br/>(.map / GeoJSON)"] --> Parser["Map-Parser & Compiler<br/>(tools/compile_worldmap.js)"]
    Parser --> WorldManifest["world_manifest.json<br/>• Provinzen & Polygone<br/>• Biome & Höhen<br/>• Ressourcen-Nodes<br/>• Nachbarschafts-Graph"]
    WorldManifest --> MacroUI["Makro-UI (Canvas/SVG)<br/>Weltkarten-Ansicht"]
    WorldManifest --> ZoneGen["Zonen-Generator (Three.js)<br/>Erzeugt 2.5D-Zone on-the-fly"]
```

### 2.2 Struktur des `world_manifest.json`
Jede Provinz besitzt feste Metadaten:
```json
{
  "provinceId": "prov_cinder_vales_04",
  "name": "Die Asche-Täler von Kael",
  "biome": "scorched_fields",
  "elevation": 42.5,
  "seed": 8941205,
  "controllingGuildId": "guild_iron_ember",
  "controllingGuildColor": "#b8860b",
  "neighbors": ["prov_emberwatch_01", "prov_obsidian_pass_07"],
  "shrines": [
    { "id": "shrine_04_a", "type": "wrath", "state": "cleansed", "bonus": "attack_power_10" }
  ],
  "resourceNodes": {
    "ironMines": 2,
    "ancientGroves": 1,
    "fertileSoilPlots": 3
  },
  "dangerLevel": 3
}
```

---

## 3. Die Makro-Weltkarten-Ansicht (UI & Interaktion)

### 3.1 Visueller Stil & Theme
- **Dark Fantasy Ästhetik:** Altes Pergament, verbrannte Ränder, glühende Gold- und Asche-Adern, Cinzel-Typografie.
- **Interaktiver Zoom & Pan:**
  - *Weit herausgezoomt:* Gesamter Kontinent, politische Grenzen der Bünde (Territoriumskarten mit transparenten Gildenfarben), wandernde Aschestürme.
  - *Mittel-Zoom:* Provinzen-Namen, Schreinsymbole, aktive Karawanen, Festungs-Wappen.
  - *Nah-Zoom:* Sichtbare Ressourcen-Knoten, Farmen, Außenposten.

### 3.2 Interaktions-Ablauf & Physische Reise-Regeln (Kein freier Klick-Teleport)
Auf der Weltkarte kann sich der Spieler **nicht einfach per Klick quer über den Kontinent teleportieren**. Territorien müssen physisch bereist werden:
1. **Zonen-Inspektion (Klick/Hover):**
   - Ein Klick auf ein beliebiges Gebiet öffnet lediglich das Informations-Panel (Besitzer, Gefahrenstufe, Schrein-Status, Ressourcenerträge).
2. **Reise-Optionen (Reiseaufwand & Routen):**
   - **„Grenzübergang zu Fuß / im Sattel“:** Der Spieler reitet aktiv an die Zonengrenze seiner aktuellen Provinz und überquert sie nahtlos in die Nachbarzone.
   - **„Reise-Marsch auf der Weltkarte“:** Der Spieler wählt ein Ziel entlang einer gesicherten Straße. Seine Spielfigur bewegt sich in Echtzeit/Schnelllauf über die Weltkarte. Bei feindlichen Zonen besteht die Gefahr von Hinterhalten.
   - **„Schrein-Resonanz (Portal-Sprung)“:** Reine Schnellreise existiert ausschließlich zwischen vollständig gereinigten, aktivierten Schreinen derselben Gilde oder befreundeter Allianzen (mit Cooldown und Essenz-Kosten).
3. **„Zone betreten“ (Echtzeit):** Ist der Spieler physisch vor Ort oder reist per Portal, schaltet die Ansicht in die 2.5D-Isometrie um.

---

## 4. Nahtloser Übergang in die isometrische 2.5D-Ansicht

### 4.1 Ladefluss & Performance (Unter 1,5 Sekunden)
Wenn eine Zone betreten wird:
1. **Kamera-Flug (Cinematic Zoom):**
   Die Kamera zoomt weich auf das Polygon der Provinz auf der Weltkarte ein. Gleichzeitig blendet eine subtile Aschepartikel-Wolke über den Bildschirm.
2. **Zonen-Streaming:**
   - Der Client entlädt die Geometrien der alten Zone (Texturen und Mesh-Vorlagen verbleiben im Shared-Cache).
   - Das Terrain der Zielprovinz wird via WebWorker aus dem festen Seed generiert (Perlin/Simplex Noise Höhenkarte + Biom-Blending).
3. **Entity-Spawn:**
   - Platzierung des zentralen Heiligtums/Schreins.
   - Platzierung von Bauwerken (Spieler-Gebäude, Farmen, Plantagen, Festungsmauern), die aus der persistenten Datenbank des Servers stammen.
   - Reittiere, Farmtiere (Kühe, Schweine, Schafe) und NPCs (Bauer Gerwin, Meister-Pflanzerin Veda) spawnen an ihren registrierten Koordinaten.
4. **Kamera dockt an:**
   Die Kamera schaltet nahtlos in die vertraute isometrische Verfolger-Perspektive (`camera.position.set(px, py + 18, pz + 14)`).

---

## 5. Territoriale Expansion: Vom Dorf zum Imperium

```mermaid
stateDiagram-v2
    [*] --> Wildnis: Unentdecktes Ascheland
    Wildnis --> Beansprucht: Bund errichtet Bannstein
    Beansprucht --> Geheilt: 12 Schreine aktiviert & verteidigt
    Geheilt --> Befestigt: Festungsmauern, Plantagen & Außenposten
    Befestigt --> ProvinzVerbunden: Straße zur Nachbarprovinz gesichert
    ProvinzVerbunden --> Imperium: Mehrere Provinzen in zusammenhängender Kette
```

1. **Startpunkt:** Jede Gilde wählt ihren Ursprungssitz (eine freie Wildnis-Provinz oder Emberwatch).
2. **Grenz-Kontiguität:** Ein Bund kann nur Provinzen beanspruchen, die **direkt an ihr bestehendes Territorium angrenzen** oder über eine gesicherte Seeroute/Straße verbunden sind. Dies verhindert unlogisches Zersplittern („Zonenspringen“).
3. **Versorgungslinien:** Liegt eine Provinz isoliert (vom Feind abgeschnitten), verlieren die Schreine dort ihre Schutzaura und die Ressourcenproduktion sinkt um 50%.

---
*Nächstes Dokument: [`02_GILDEN_CLANS_UND_TERRITORIEN.md`](file:///f:/Emberwild/documents/multiplayer/02_GILDEN_CLANS_UND_TERRITORIEN.md)*.


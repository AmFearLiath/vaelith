# ⚡ DOKUMENT 06: PERFORMANZ, NETZWERK & CODE-STRUKTUR
## Technische Architektur, Authoritative Netcode, Sharding & 60-FPS-Garantie

> **Teil der Reihe:** Emberwild Multiplayer & Territorien  
> **Status:** Technisches Architektur- und Spezifikationsdokument (Kein Code)

---

## 1. Leitende Architektur-Ziele

Um ein flüssiges, reaktionsschnelles ARPG-Erlebnis wie in Diablo oder Path of Exile im WebGL/Three.js-Kontext zu garantieren, muss die Architektur drei harte Kriterien erfüllen:
1. **Butterweiches Gameplay (Konstante 60 FPS):** Kein Frame-Drop beim Betreten von Zonen oder bei großen Schlachten mit dutzenden Einheiten.
2. **Cheat-Sicherheit (Authoritative State):** Lebenspunkte, Items, Schrein-Besitz und Kampfergebnisse werden ausnahmslos auf dem Server berechnet.
3. **Skalierbarkeit (Zonen-Sharding):** Die Welt teilt sich in leichtgewichtige, voneinander isolierte Zonen-Worker auf.

---

## 2. Die Client-Server-Architektur

```mermaid
graph TB
    subgraph Client["Three.js WebGL Client (Browser)"]
        Renderer["WebGL 2.0 Renderer / Camera Controller"]
        InputHandler["Mouse & Keyboard Controller"]
        Prediction["Client-Side Prediction & Interpolation"]
        NetworkBridgeClient["Network Bridge (Binary WebSocket)"]
        LocalSim["Lokale Darstellung: Partikel, Shader & Animationen"]
    end

    subgraph Gateway["Edge Gateway & Router"]
        LoadBalancer["WebSocket Gateway (Reverse Proxy / TLS)"]
        SessionAuth["Session & JWT Authenticator"]
    end

    subgraph Cluster["Authoritative Node.js Server Cluster"]
        WorldCoord["World Coordinator (Makro-Karte & Gilden-DB)"]
        subgraph Shards["Zonen-Worker (Shards)"]
            Zone1["Zone Worker 01 (Emberwatch)"]
            Zone2["Zone Worker 02 (Grey Fields)"]
            ZoneN["Zone Worker N (Schrein-Provinz)"]
        end
    end

    subgraph Persistence["Datenbank & Cache"]
        Redis["Redis (In-Memory Realm Cache & Pub/Sub)"]
        Postgres["PostgreSQL (Accounts, Gilden, Items, Territorien)"]
    end

    InputHandler --> Prediction
    Prediction --> NetworkBridgeClient
    NetworkBridgeClient <==> LoadBalancer
    LoadBalancer <==> Shards
    Shards <==> WorldCoord
    Shards <==> Redis
    WorldCoord <==> Postgres
    NetworkBridgeClient --> Renderer
    Renderer --> LocalSim
```

---

## 3. Netcode: Latenz-Kompensation & Tick-Rate

### 3.1 20 Hz Server-Tick mit 60 FPS Client-Interpolation
- **Server Tick-Rate:** Der Zonen-Server rechnet mit **20 Ticks pro Sekunde** (alle 50 ms ein Snapshot-Update). Das schont die CPU-Last des Servers massiv.
- **Client-Side Prediction:**
  - Klickt der Spieler auf den Boden, bewegt sich sein Charakter **sofort lokal ohne 50 ms Verzögerung** (prädiktives Pathfinding via `nav.js`).
  - Der Server validiert den Pfad und sendet Bestätigungen oder Positions-Korrekturen (Reconciliation nur bei Diskrepanzen > 0.3 Einheiten).
- **Entity Interpolation:**
  - Andere Spieler, Reittiere, Monster und Aschekrieger werden im Client über einen Ring-Puffer von 100 ms weich hermite-interpoliert. Kein Ruckeln oder Teleportieren.

### 3.2 Binäres Delta-Kompressions-Protokoll (ArrayBuffer)
Statt sperrigem JSON (hoher Overhead) kommuniziert der Netcode über **kompakte Binär-Frames (Float32/Int16)**:
```
[Byte 0: Opcode (1 Byte)] 
[Byte 1-2: Entity ID (uint16)] 
[Byte 3-4: PosX (int16 * 100)] 
[Byte 5-6: PosZ (int16 * 100)] 
[Byte 7: Rotation (uint8)] 
[Byte 8: AnimState / SkillID (uint8)]
Gesamt: Nur 9 Bytes pro Entity-Update!
```

---

## 4. Zonen-Sharding & Schlafende Welten

### 4.1 Dynamischer Ressourcen-Lebenszyklus
Eine Weltkarte mit 50 oder 100 Provinzen kann nicht gleichzeitig bei voller Last laufen. Daher gilt:

```mermaid
stateDiagram-v2
    [*] --> Inaktiv: 0 Spieler in der Zone
    Inaktiv --> Aufwecken: 1. Spieler betritt Zone via Weltkarte
    Aufwecken --> Aktiv: 20 Hz Tickrate, Monster-Spawns, KI aktiv
    Aktiv --> HoheLast: Belagerung / >20 Spieler -> Sub-Worker Spawnen
    Aktiv --> Einschlafen: Letzter Spieler verlässt Zone
    Einschlafen --> Inaktiv: DB-Zustand gesichert; RAM freigegeben
```

- **Inaktive Zonen:** Verbrauchen 0% CPU und wenige Kilobytes RAM in Redis. Nur passive Ressourcen-Generierung (Plantagen-Wachstum) wird rein mathematisch beim Wiederbetreten nachkalkuliert (`deltaTime * Ertrag`).

---

## 5. Grafische Performance im WebGL-Client

Um bei 30 Spielern, 40 Reittieren, 50 Monstern und 30 Aschekriegern weiterhin konstante 60 FPS zu sichern:

### 5.1 Instanced Mesh Rendering (`InstancedMesh`)
- Anstatt für jedes Schwein, Schaf, Skelett oder jeden Baum ein eigenes Three.js-Mesh im Szenengraphen zu halten, werden identische Modelle zu **Instanced Meshes** gebündelt:
  - 1 Draw-Call für alle 50 Asche-Skelette.
  - 1 Draw-Call für alle 30 Farmtiere.
  - 1 Draw-Call für alle Fichten und Felsen.
- Die Animationsphasen und Transformationen werden über Matrizen im GPU-Instanzpuffer aktualisiert.

### 5.2 Distance & Frustum Culling
- Einheiten außerhalb des Sichtkegels der isometrischen Kamera (`camera.position`) werden von der CPU gar nicht erst an die Render-Pipeline übergeben.
- Partikelsysteme (Rauch der Aschekrieger, Lagerfeuerfunken) schalten auf Distanzen > 35 Einheiten automatisch ab (Level of Detail / LOD).

### 5.3 Asynchrones Asset-Streaming
- Alle Texturen und 3D-Meshes werden in einem persistenten Cache im Browser (`IndexedDB` / RAM) gehalten.
- Beim Wechsel von der Weltkarte in eine 2.5D-Zone werden Assets **nicht neu geladen**, sondern instanziiert. Die Ladezeit beträgt so im Schnitt unter **1,2 Sekunden**.

---

## 6. Vorgeschlagene Verzeichnis- & Code-Struktur

Wenn dieses System in zukünftigen Phasen modular in den Code überführt wird, dockt es wie folgt an:

```
f:\Emberwild\
├── src\
│   ├── core\                  # Game Loop, EventBus, State-Store
│   ├── worldsys\              # Bestehende Weltsysteme (Settlement, Nature, Mounts)
│   │   ├── settlement.js      # Erweitert um Gilden-Quartiere & Schutz
│   │   ├── nature.js          # Erweitert um Bannsteine & Schrein-Besitz
│   │   ├── mounts.js          # Reit- & Zuchtsystem (bereits synchronisierbar)
│   │   └── director.js        # Server-Event-Triggers
│   ├── network\               # [NEU] Multiplayer-Kern
│   │   ├── clientNetBridge.js # WebSocket-Handler & Binär-Serializer
│   │   ├── predictor.js       # Client-Side Prediction & Interpolation
│   │   └── stateSync.js       # Entity-Abgleich zwischen Server & Client
│   ├── map\                   # [NEU] Weltkarten-Makro-System
│   │   ├── azgaarParser.js    # Einlesen & Berechnen der Voronoi/Azgaar-Provinzen
│   │   ├── worldMapView.js    # Canvas/SVG-Viewer für Kontinentalkarte
│   │   └── zoneTransition.js  # Weicher Kamera-Übergang von Makro zu 2.5D
│   └── ui\                    # Benutzeroberflächen
│       ├── guildPanel.js      # Gilden-Verwaltung, Ränge, Forschung
│       ├── diplomacyPanel.js  # Kriege, Allianzen, Handelskarawanen
│       └── worldMapPanel.js   # Interaktive Kontinent-Übersicht
└── server\                    # [NEU] Autoritärer Realm-Server
    ├── cluster.js             # Master-Prozess & Port-Zuweisung
    ├── shardWorker.js         # Zonen-Prozess (20 Hz Tickrate, Physics, AI)
    ├── database\              # Postgres / Redis Anbindung
    └── protocols\             # Binäres Protokoll-Schema
```

---
*Ende der Dokumentations-Reihe. Alle Dokumente sind im Ordner [`documents/multiplayer/`](file:///f:/Emberwild/documents/multiplayer/) abgelegt.*


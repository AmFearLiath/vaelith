# ⚔️ DOKUMENT 04: KAMPF, BELAGERUNGEN & GvG
## Kriegskunst in Emberwild: Schrein-Schlachten, Belagerungsgeräte & PvP-Regelwerk

> **Teil der Reihe:** Emberwild Multiplayer & Territorien  
> **Status:** Konzept- und Designdokument (Kein Code)

---

## 1. Philosophie: Taktischer Wettstreit statt toxisches Griefing

In vielen Sandbox-MMOs führt offenes PvP dazu, dass Neulinge und Gelegenheitsspieler frustriert aufgeben, weil sie offline überfallen werden.  
**Emberwild bricht mit dieser Frustration durch drei Kernprinzipien:**
1. **Kein Offline-Raiding:** Territorien können nur in vorher angekündigten, festen **Kriegsfenstern (Vulnerability Windows)** attackiert werden.
2. **Schutz der Heimatbasis:** Persönliche Häuser und die Kern-Enklave (Emberwatch) sind unzerstörbar. Umkämpft sind die vorgelagerten **12 Schreine**, Außenposten und Minen.
3. **Sinnstiftendes PvP:** Schlachten drehen sich um Ressourcen, Schrein-Auren und Ruhm auf der Weltkarte, nicht um das Auslöschen von Spieler-Fortschritten.

---

## 2. Der Ablauf einer Schrein-Belagerung (GvG)

Ein Krieg um einen uralten Schrein läuft in einem dreistufigen, hochgradig taktischen Event ab:

```mermaid
journey
    title Ablauf einer Schrein-Belagerung
    section Phase 1: Aufmarsch (15 Min)
      Kriegshorn ertönt & Schutzschild fährt hoch: 5: Verteidiger
      Aufmarsch auf Reittieren & Aufstellen von Ballisten: 4: Angreifer
    section Phase 2: Die Resonanz-Runen (20 Min)
      Verteidigung der Engpässe & Tore: 4: Verteidiger
      Eroberung der 3 Runenkreise zur Schildsenkung: 5: Angreifer
    section Phase 3: Sturm auf den Bannstein (15 Min)
      Letztes Gefecht & Totenbeschwörer-Armeen: 5: Beide
      Zerstörung oder erfolgreiche Verteidigung des Steins: 5: Beide
```

### 2.1 Phase 1 – Der Aufmarsch & die Peripherie
- **Schutzschild:** Solange die 3 vorgelagerten Resonanz-Runen intakt sind, ist der Schrein immun gegen direkten Schaden.
- **Kavallerie-Gefechte:** Angreifer und Verteidiger treffen auf Reittieren aufeinander. Schnelle Reittiere (Rappen) jagen feindliche Nachschub-Karawanen, während schwere Reittiere (Panzerstiere) als lebende Rammböcke gegen Barrikaden eingesetzt werden.

### 2.2 Phase 2 – Der Kampf um die Runenkreise
- Die 3 Runenkreise liegen verteilt um das Schrein-Areal (z. B. an einer Klippe, im dichten Asche-Wald und an einer Flussfurt).
- **Zonen-Herrschaft (King of the Hill):** Ein Runenkreis gilt als erobert, wenn eine Gilde 60 Sekunden lang die Überzahl im Kreis hält.
- **Taktischer Einsatz:** 
  - Magier decken den Kreis mit Flächenschaden (Blizzard, Feuersbrunst) ein.
  - Barbaren setzen Wirbelwind und Schildstöße ein, um Gegner aus dem Kreis zu schleudern.

### 2.3 Phase 3 – Das Letzte Gefecht um den Bannstein
- Sind mindestens 2 von 3 Runenkreisen gefallen, bricht das Schutzschild des Haupt-Bannsteins zusammen.
- **Bannstein-Trefferpunkte:** Der Bannstein besitzt massive Lebenspunkte.
- **Die Rolle des Totenbeschwörers:** Hier entfaltet der Totenbeschwörer seine volle Zerstörungskraft: Aus jedem im Kampf gefallenen Spieler (egal ob Freund oder Feind) entsteht ein rauchender, feuriger **Aschekrieger**. Diese Aschekrieger stürmen automatisch auf die feindlichen Belagerer ein und explodieren bei Zerstörung.
- **Siegbedingungen:**
  - **Angreifer gewinnt:** Wird der Bannstein vor Ablauf der Zeit zerstört, erobert der Bund den Schrein. Das Territorium färbt sich auf der großen Weltkarte sofort in den Gildenfarben.
  - **Verteidiger gewinnt:** Läuft die Belagerungszeit ab (45 Minuten Gesamtdauer) und der Stein steht noch, schlägt das Schrein-Heiligtum eine gewaltige Schockwelle aus heiligem Feuer, die alle Angreifer vertreibt. Der Schrein erhält 48 Stunden Immunität.

---

## 3. Belagerungswaffen & Verteidigungs-Strukturen

Gebaut in der Gilden-Manufaktur und platziert durch den Kriegsvogt:

| Waffe / Struktur | Typ | Nutzen | Konter |
| :--- | :--- | :--- | :--- |
| **Obsidian-Balliste** | Fernkampf | Durchschlägt feindliche Reittiere und verursacht Flächenschaden an Spielergruppen. | Schnelle Barbaren-Flankenangriffe. |
| **Gepanzerter Rammbock** | Nahkampf | Zerstört Holztore und Palisaden in Sekunden. Wird von 2 Spielern gelenkt. | Magier-Feuerzauber (brennbares Holz). |
| **Pflanzen-Dornenwall** | Verteidigung | Errichtet aus Spezialholz der Plantage; verlangsamt Angreifer um 60% und vergiftet sie. | Zerstörbar durch physische Hiebe. |
| **Nekrotische Asche-Mine** | Falle | Unsichtbar im Boden; detoniert bei feindlichem Kontakt und ruft 3 Asche-Skelette hervor. | Entdeckung durch Späher auf Reittieren. |

---

## 4. PvP-Karma & Strafsystem für Schurken

Um die Welt immersiv, aber fair zu halten:
- **Ehrenhaftes GvG:** Tötungen während offizieller Schrein-Belagerungen oder in Kriegsgebieten erzeugen **kein negatives Karma**, sondern Gilden-Ruhmespunkte.
- **Schurken-Status (Banditen-System):**
  - Wer friedliche Reisende oder unschuldige Solo-Spieler auf neutralen Straßen hinterrücks attackiert, erhält **Asche-Sünde (Schurken-Karma)**.
  - Schurken erhalten einen roten Totenkopf über dem Kopf.
  - Stadtwachen in Emberwatch greifen Schurken sofort an.
  - Beim Tod lässt ein Schurke 30% seines getragenen Goldes und zufällige Crafting-Materialien als Beutebeutel für alle fallen.

---
*Nächstes Dokument: [`05_SERVER_EVENTS_UND_WELTBOSSE.md`](file:///f:/Emberwild/documents/multiplayer/05_SERVER_EVENTS_UND_WELTBOSSE.md)*.


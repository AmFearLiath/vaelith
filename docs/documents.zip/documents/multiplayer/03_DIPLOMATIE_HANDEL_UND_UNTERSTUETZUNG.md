# 🤝 DOKUMENT 03: DIPLOMATIE, HANDEL & UNTERSTÜTZUNG
## Kooperation, Karawanen & Ökonomische Symbiose

> **Teil der Reihe:** Emberwild Multiplayer & Territorien  
> **Status:** Konzept- und Designdokument (Kein Code)

---

## 1. Das Diplomatische Spektrum

Gilden können miteinander in vordefinierte diplomatische Beziehungen treten, die direkte spielmechanische Auswirkungen im Code und auf der Weltkarte haben.

```mermaid
graph LR
    A["Ewige Allianz (Bruderbund)"] <--> B["Handels- & Friedenspakt"]
    B <--> C["Neutral (Standard)"]
    C <--> D["Grenzstreitigkeiten (Spannung)"]
    D <--> E["Blutfehde (Totaler Krieg)"]
```

### 1.1 Die Beziehungsstufen im Detail

1. **Ewige Allianz (Bruderbund):**
   - Maximal 3 Bünde können eine permanente Allianz bilden.
   - **Geteilte Schrein-Auren:** Mitglieder beider Gilden genießen alle Schrein-Boni in beider Territorien.
   - **Automatischer Beistand:** Werden Schreine des Partners attackiert, können Verteidiger per Schnellreise-Portal direkt zum umkämpften Heiligtum springen.
   - **Freier Karawanenverkehr:** Keine Zölle, freier Zugang zu Gilden-Märkten.
2. **Handels- & Friedenspakt:**
   - Kein PvP zwischen Mitgliedern möglich (Friendly Fire deaktiviert).
   - Erlaubt das Einrichten von Handelsrouten zwischen den Hauptstädten.
   - Ressourcen können mit ermäßigten Transfersteuern ausgetauscht werden.
3. **Neutraler Status:**
   - Standardzustand bei Erstkontakt.
   - Mitglieder können friedlich aneinander vorbeireiten. In unbeanspruchtem Ödland gilt das Standard-Verhalten (PvE).
4. **Blutfehde / Krieg:**
   - Vollständiger PvP-Status in allen Außengebieten und feindlichen Provinzen.
   - Schrein-Belagerungen sind freigeschaltet.

---

## 2. Gegenseitige Unterstützung: Kämpfe & Verteidigung

### 2.1 Das Schrein-Notsignal & Schnellreisen
- Wird ein Schrein oder ein Vorposten einer Gilde von Monstern (Krisen-Direktor) oder feindlichen Spielern angegriffen, ertönt ein **akustisches Kriegshorn** für alle Gildenmitglieder und verbündete Allianzen.
- Auf der Weltkarte pulsiert die betroffene Provinz tiefrot.
- **Flammen-Portale:** Befreundete Krieger können an einem beliebigen Schrein ihrer Heimatbasis das Portal aktivieren, um innerhalb von 5 Sekunden an der bedrohten Front zu erscheinen.

### 2.2 Kampfsynergien zwischen Klassen & Gilden
Wenn mehrere Bünde zusammen kämpfen, ergänzen sich die Spezialisierungen:
- **Barbaren:** Bilden die Schildphalanx an den Toren und blockieren feindliche Kavallerie (Reittier-Stoßangriffe).
- **Magier:** Errichten Schutzkreise über den Schrein-Runen und beschwören Feuermauern, um enge Schluchten abzusichern.
- **Totenbeschwörer:** Lassen gefallene Verteidiger und feindliche Schergen als rauchende **Aschekrieger** auferstehen. In großen Gefechten entstehen so gewaltige Schockwellen, die die gegnerische Schlachtreihe aufreiben.

---

## 3. Gegenseitige Unterstützung: Ressourcen & Karawanen

### 3.1 Das Nothilfe-System (Direkttransfer)
- Wenn eine Gilde eine Hungersnot erleidet (z. B. durch einen zerstörten Bauernhof auf der Emberfarm) oder dringend Obsidian für Schrein-Reparaturen benötigt:
  - Der Flammenschmied stellt ein **Hilfsgesuch** in das Allianzen-Netzwerk.
  - Befreundete Bünde können per Klick im `settlementPanel.js` die benötigten Ressourcen aus ihrer Schatzkammer übersenden.

### 3.2 Die lebendige Karawanen-Mechanik
Ressourcen reisen nicht nur abstrakt durch Menüs, sondern als **physische Einheiten durch die Welt**:

```mermaid
sequenceDiagram
    participant Sender as Gilde A (Emberfarm & Plantagen)
    participant Road as Handelsstraße (Weltkarte & 2.5D Zone)
    participant Bandit as Monster / Feindliche Plünderer
    participant Receiver as Gilde B (Bergwerks-Außenposten)

    Sender->>Road: Entsendet Ochsen-Karawane mit 200 Getreide & Heilkräutern
    Note over Road: Karawane bewegt sich mit 4 km/h entlang der Straße
    Bandit->>Road: Startet Hinterhalt auf der Straße!
    alt Eskorte erfolgreich
        Road->>Receiver: Karawane erreicht sicher das Zieltor (+Bonus-Handels-XP)
    else Karawane zerstört
        Bandit->>Road: Plündert 50% der Fracht
    end
```

- **Reittier-Integration:** Für Karawanen werden die in `breeding.js` gezüchteten Zugstiere und Packtiere eingesetzt. Höhere Tierstufen (Tier III Panzerstier) bieten mehr Tragekapazität und dickere Rüstung gegen Angreifer.
- **Eskorten-Quests:** Solo-Spieler und Gildenmitglieder können sich als Begleitschutz anheuern lassen und erhalten Gold für jeden sicher erreichten Wegpunkt.

---

## 4. Der Freie Kontinentale Markt (Auktionshaus & Handelskontor)

In der neutralen Metropole **Emberwatch** befindet sich der **Große Basar**:
- **Zugang für alle:** Sowohl Solo-Spieler als auch Gildenmitglieder können hier Waren anbieten.
- **Warenkategorien:**
  - *Plantagen-Erzeugnisse:* Edelfrüchte, seltene Färbemittel, Trank-Zutaten.
  - *Zuchttiere & Fohlen:* Zertifizierte Reittiere mit speziellen Genen (z. B. +15% Temposchub, Feuerresistenz).
  - *Ausrüstung & Waffen:* Geschmiedete Sets aus Obsidian und Aschestein.
  - *Bannstein-Runen:* Rohstoffe für die Schrein-Aktivierung.
- **Wirtschaftliche Stabilität:** Ein dynamisches Steuersystem verhindert Hyperinflation. Ein Teil des Goldes wird beim Verkauf dauerhaft aus dem Spielkreislauf entfernt (Gold-Sink).

---
*Nächstes Dokument: [`04_KAMPF_BELAGERUNGEN_UND_GVG.md`](file:///f:/Emberwild/documents/multiplayer/04_KAMPF_BELAGERUNGEN_UND_GVG.md)*.


# 🎨 DOKUMENT 07: LEVELDESIGN, WELT-GENERIERUNG & DEV-MAP-EDITOR
## Prozedural vs. Manuell, On-Demand-Generierung & Der In-Game-Editor

> **Teil der Reihe:** Emberwild Multiplayer & Territorien  
> **Status:** Konzept- und Architekturentwurf (Kein Code)

---

## 1. Die Kernfrage: Manuell oder Prozedural?

### 1.1 Der Vergleich der Ansätze
| Merkmal | Rein Manuell | Rein Prozedural | **Der Hybride Ansatz (Emberwild-Weg)** |
| :--- | :--- | :--- | :--- |
| **Erstellungsaufwand** | Enorm hoch für 50–100 Provinzen; Monate an Handarbeit. | Geringer Initialaufwand (Algorithmus). | **Optimal:** Grundgerüst prozedural, Schlüsselpunkte handgemacht. |
| **Atmosphäre & Polish** | Maximal (jedes Licht, jeder Baum bewusst platziert). | Oft repetitiv, unruhig oder generisch. | **Höchste Qualität:** Handkuratierte Schauplätze eingebettet in prozedurales Gelände. |
| **Konsistenz & Bugs** | Keine Spawning-Glitches in Wänden. | Gefahr, dass Pfade blockiert sind. | **Deterministisch:** Feste Seeds + automatisierte NavMesh-Validierung. |
| **Nachträgliche Edits** | Direkt möglich. | Sehr schwer (Änderung im Seed verändert alles). | **Perfekt:** Editor speichert *Delta-Overlays* (manuelle Anpassungen überschreiben Prozedur). |

### 1.2 Die Architekturentscheidung für Emberwild: *Deterministisch-Hybride Generierung*
1. **Das Terrain & Natur-Fundament (Prozedural aus Seed):**
   - Jede Provinz auf der Azgaar-Weltkarte besitzt einen festen mathematischen Seed (z. B. `seed: 8941205`).
   - Die Höhenkarte (Perlin/Simplex-Noise), Biome (Sumpf, Aschewald, Obsidian-Ödland), Klippen und Grundflüsse werden deterministisch berechnet.
2. **Die POIs & Landmarks (Handgefertigte Prefabs / Module):**
   - Schreine, Dörfer, Mineneingänge, Brücken und Banditenlager existieren als handkuratierte Module (wie die bisherige *Emberwatch*-Town und die *Greyfields*-Ruinen).
   - Der Generator platziert diese handgefertigten Blöcke passgenau an den logisch sinnvollsten Stellen im Terrain.
3. **Manuelle Feinarbeit per Dev-Editor (Delta-Layer):**
   - Ein Entwickler (oder Admin) kann jede Provinz betreten, Bäume verschieben, Gebäude drehen, Lichtstimmungen justieren und neue Quests setzen.
   - Der Editor speichert **nur die Änderungen (Deltas)** in einer JSON-Datei, ohne dass das gesamte Terrain neu gespeichert werden muss.

---

## 2. Wann werden Gebiete generiert? (On-Demand Lifecycle)

### 2.1 Warum *nicht* alle Gebiete im Vorfeld berechnen?
Wenn 100 Provinzen komplett vorab generiert und im Speicher gehalten würden:
- Gigantischer Festplatten- und Datenbankbedarf vor Launch.
- Änderungen am Algorithmus würden bereits bestehende unbetretene Gebiete blockieren.

### 2.2 Der On-Demand Lifecycle (Lazy Generation & Persistenz)

```mermaid
stateDiagram-v2
    [*] --> Unentdeckt: Provinz existiert nur als Seed im world_manifest.json
    Unentdeckt --> ErsteGenerierung: 1. Spieler nähert sich der Provinzgrenze
    ErsteGenerierung --> StatischGespeichert: Terrain + POIs werden aus Seed gebacken & in DB fixiert
    StatischGespeichert --> Aktiv: Spieler läuft in der Zone (20 Hz Tickrate)
    Aktiv --> Ruhezustand: Alle Spieler verlassen die Zone (RAM freigegeben)
    Ruhezustand --> Aktiv: Spieler kehrt zurück (Laden aus DB + Delta-Layer)
```

1. **Stufe 1 (Unentdeckt / Blaupause):** Die Provinz existiert nur als mathematischer Eintrag in `world_manifest.json` (Seed, Biom, Ressourcen, Nachbarn).
2. **Stufe 2 (Erste Generierung):** Betritt der erste Spieler jemals dieses Gebiet, berechnet der Zonen-Worker in ca. 400 Millisekunden das Terrain, setzt die 12 Schreine und verteilt Natur & Erze. Das Resultat wird in der Datenbank als Grundstein fixiert.
3. **Stufe 3 (Persistenz & Schlafen):** Wenn kein Spieler mehr anwesend ist, wird die Zone serialisiert und in den Ruhezustand versetzt. Baut eine Gilde später ein Haus oder fällt Bäume, wird dies als permanentes Delta gespeichert.

---

## 3. Der In-Game Dev-Map-Editor

Ein vollwertiger, eleganter Dev-Map-Editor ist für ein Spiel dieses Umfangs **hochgradig sinnvoll und technisch absolut machbar**, da Three.js bereits alle Voraussetzungen für Raycasting, Gizmos und Objektplatzierung mitbringt.

```
┌──────────────────────────────────────────────────────────────────────────────┐
│  [DEV-EDITOR] Provinz: Asche-Täler von Kael (Seed: 8941205)  [MODUS: EDIT]   │
├─────────────┬──────────────────────────────────────────────────┬─────────────┤
│  KATALOG    │                                                  │  EIGENSCHAFT│
│  ─────────  │                   3D-VIEWPORT                    │  ────────── │
│  ▸ Häuser   │                                                  │  Objekt:    │
│  ▸ Bäume    │                    [ Gizmo: ✣ ]                  │  house_b    │
│  ▸ Steine   │                  ┌──────────────┐                │  Pos:       │
│  ▸ Zäune    │                  │  Selected    │                │  X: -14.2   │
│  ▸ Schreine │                  │  Building    │                │  Y: 0.0     │
│  ▸ NPCs     │                  └──────────────┘                │  Z: 28.5    │
│  ▸ Lichter  │                                                  │  Rot: 1.87  │
│  ▸ Monster  │                                                  │  Scale: 0.7 │
├─────────────┴──────────────────────────────────────────────────┴─────────────┤
│ [Pinsel: Terrain-Glätten] [NavMesh neu berechnen] [Test-Hero Spawnen] [SAVE] │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 3.1 Kernfunktionen des Dev-Map-Editors
1. **Transform-Gizmos (Translate, Rotate, Scale):**
   - Anklicken eines beliebigen Objekts in der Welt (Haus, Baum, Schrein, Zaun).
   - Verschieben entlang der X/Z-Achsen, Drehen im Kreis und Skalieren per Maus.
2. **Asset-Palette (Katalog):**
   - Zugriff auf alle geladenen GLB-Bibliotheken (`env_town.glb`, `env_fields.glb`, `Farm Animals`, `Nature Kit`).
   - Drag & Drop oder Klick-Plazierung direkt auf den Untergrund (`Raycaster` gegen Terrain-Mesh).
3. **Terrain-Pinsel (Höhen- und Textur-Malen):**
   - *Heben/Senken:* Modifiziert das Höhenmesh sanft per Pinselradius.
   - *Splat-Painter:* Zeichnet Wege (Dreck, Pflaster), Gras oder verbrannte Asche auf den Boden.
4. **NPC- & Spawn-Konfigurator:**
   - Platzierung von Handwerkern, Händlern, Wachen oder Monster-Spawn-Zonen.
   - Festlegen von Patrouillen-Wegpunkten für Reittiere und Tiere.
5. **Echtzeit-NavMesh-Aktualisierung:**
   - Ein Knopfdruck berechnet die begehbaren Zellen (`nav.js`) im Umkreis neu, damit Einheiten niemals in neu platzierten Gebäuden steckenbleiben.
6. **Export & Import (`zone_delta.json`):**
   - Speichert die Änderungen per Knopfdruck als JSON ab, die sofort in das Projektverzeichnis geschrieben wird.

---

## 4. Reise-Mechanik: Physische Reise statt Teleportation

Auf der Makro-Weltkarte kann der Spieler **nicht einfach per Klick quer über den Kontinent teleportieren**. Die Reise ist ein integraler Bestandteil des Spielgefühls:

### 4.1 Die 3 Arten des Reisens
1. **Zu Fuß / Im Sattel (Echtzeit-Wanderung):**
   - Der Spieler reitet durch seine aktuelle Zone an den Rand des Gebiets (Grenz-Wegweiser / Pass).
   - Das Überqueren der Grenze löst den Ladevorgang der Nachbarzone aus.
   - Schnelle Reittiere (hochgezüchtete Rappen oder Wölfe) verkürzen die Reisezeit dramatisch.
2. **Reise-Modus auf der Weltkarte (Autopilot entlang gesicherter Straßen):**
   - Öffnet der Spieler die Weltkarte, kann er eine befreundete oder neutrale Nachbarprovinz als Marschziel wählen.
   - Sein Reittier-Avatar bewegt sich auf der Weltkarte entlang der visualisierten Straßen.
   - **Gefahr im Ödland:** Führt die Straße durch unbeanspruchtes oder feindliches Land, besteht die Chance auf Zufallsbegegnungen (Banditenüberfall, Monsterhorde), die den Spieler in eine 2.5D-Kampfinstanz zwingen.
3. **Schrein-Resonanz (Schnellreise nur im eigenen Bund / Allianzen):**
   - Teleportation existiert **nur zwischen bereits vollständig gereinigten und aktivierten Schreinen desselben Bundes** oder befreundeter Allianzen.
   - Verbraucht *Natur-Essenz* oder *Asche-Glutsteine* und besitzt eine Abklingzeit (Cooldown von 15 Minuten).

---

## 5. Das Solo-Königreich: Friedliches Leben & Volle Autarkie

Ein Spieler, der kein Interesse an Gildenpolitik, Clankriegen oder Belagerungen hat, genießt eine vollwertige, eigenständige Spielerfahrung:

```mermaid
graph TD
    SoloStart["Solo-Aschewanderer (Friedlicher Modus)"]
    SafeZone["Eigene Enklave / Hofgut in Emberwatch"]
    Farmlife["Erweiterte Landwirtschaft & Plantagen<br/>(Seltene Luxusfrüchte, Gewürze, Arzneien)"]
    Breeding["Meister-Gestüt & Tierzucht<br/>(Kreuzung, Zähmung wilder Bestien, Gen-Sammlung)"]
    Trade["Freier Handel & Kontor<br/>(Verkauf von Reittieren & Nahrung an Großgilden)"]
    Mercenary["Söldner- und Forscher-Quests<br/>(Reinigung uralter Ruinen, Schrein-Forschung)"]

    SoloStart --> SafeZone
    SafeZone --> Farmlife
    SafeZone --> Breeding
    Farmlife --> Trade
    Breeding --> Trade
    SafeZone --> Mercenary
```

### 5.1 Solo-Features im Detail:
1. **Der Eigene Landsitz:** Der Solo-Spieler kann sein eigenes Hofgut in geschützten Regionen bis auf Stufe 5 ausbauen (Herrenhaus, private Stallungen, Gewächshäuser).
2. **Meister-Züchter & Bestiarium-Forscher:** Solo-Spieler können sich komplett auf das Zähmen wilder Kreaturen und die genetische Kreuzung spezialisieren. Seltene Tier-Merkmale (z. B. feuerfeste Hufe, Ausdauer-Auren) sind bei großen Gilden für deren Kavallerie heiß begehrt und erzielen Höchstpreise am Basar.
3. **Landwirtschafts-Tycoon:** Plantagen werfen Gourmet-Zutaten und seltene Kräuter ab, die für epische Buff-Nahrung in Belagerungsschlachten gebraucht werden.
4. **Schutz vor PvP:** Im Solo-/Friedens-Modus kann der Spieler **nicht von anderen Spielern attackiert oder belagert werden**. Sein Hofgut ist unantastbar.

---
*Ende von Dokument 07. Integriert in das Gesamtkonzept in [`documents/multiplayer/00_UEBERSICHT_UND_MASTERPLAN.md`](file:///f:/Emberwild/documents/multiplayer/00_UEBERSICHT_UND_MASTERPLAN.md)*.


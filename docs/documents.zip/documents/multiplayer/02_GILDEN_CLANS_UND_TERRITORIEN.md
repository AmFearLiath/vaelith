# 🛡️ DOKUMENT 02: GILDEN, CLANS & TERRITORIEN
## Die Bünde der Flamme: Organisation, Reichs-Verwaltung & Expansion

> **Teil der Reihe:** Emberwild Multiplayer & Territorien  
> **Status:** Konzept- und Designdokument (Kein Code)

---

## 1. Philosophie: Gemeinschaft & Autarkie

In **Emberwild** sind Gilden nicht nur bloße Chat-Gruppen, sondern **staatliche Gebilde**, die wie Feudalreiche agieren. Gleichzeitig wird der autarke Solo-Spieler nicht abgehängt, sondern nimmt als spezialisierter Söldner, Händler oder unabhängiger Grundbesitzer eine wichtige ökonomische Rolle ein.

---

## 2. Gründung & Innere Struktur eines Bundes

### 2.1 Gründungs-Voraussetzungen
- **Charakter-Stufe:** Mindestens Level 15.
- **Gründungskosten:** 10.000 Goldstücke + 1x *Reiner Asche-Glutstein* (aus der Quest *Die ewige Glut*).
- **Gründungsort:** Kann entweder in der neutralen Stadt **Emberwatch** oder an einem freien uralten Schrein in der Wildnis gegründet werden.
- **Identität:** Gildenname, Gilden-Tag (3-5 Zeichen), Wappen-Editor (Farben, Symbole, Rahmen im Cinzel/Gothic-Stil).

### 2.2 Ränge & Rechte-Matrix

```mermaid
graph TD
    GM["Rang 1: Flammenschmied (Großmeister)"]
    KV["Rang 2: Kriegsvogt (Militär & Belagerung)"]
    SM["Rang 3: Schatzmeister (Finanzen, Farmen & Zölle)"]
    PI["Rang 4: Pionier (Bau, Gestüt & Zucht)"]
    RE["Rang 5: Ascheknappe (Vollmitglied)"]
    GA["Gast / Freier Bürger (Solo-Spieler mit Passierschein)"]

    GM --> KV
    GM --> SM
    KV --> PI
    SM --> PI
    PI --> RE
    RE --> GA
```

| Recht / Aktion | Flammenschmied | Kriegsvogt | Schatzmeister | Pionier | Ascheknappe |
| :--- | :---: | :---: | :---: | :---: | :---: |
| Territorium beanspruchen / aufgeben | ✅ | ❌ | ❌ | ❌ | ❌ |
| Krieg erklären / Frieden schließen | ✅ | ✅ | ❌ | ❌ | ❌ |
| Gildenbank: Rohstoffe abheben | ✅ | ✅ | ✅ | ✅ (Begrenzt) | ❌ (Nur Spenden) |
| Gildenbank: Gold abheben | ✅ | ❌ | ✅ | ❌ | ❌ |
| Gebäude errichten / upgraden | ✅ | ✅ | ✅ | ✅ | ❌ |
| Gilden-Gestüt: Zuchttiere entnehmen | ✅ | ✅ | ❌ | ✅ | ❌ |
| Mitglieder einladen / befördern | ✅ | ✅ | ❌ | ❌ | ❌ |

---

## 3. Die Gilden-Zentrale: Festung & Gildenhalle

Jede Gilde besitzt einen **Hauptsitz**, der als Herz des Territoriums dient.

### 3.1 Monumentale Bauwerke der Gilde
1. **Die Große Gildenhalle:**
   - Schaltet die Gilden-Forschung frei.
   - Bietet einen gemeinsamen Versammlungsraum mit Thron, Besprechungstisch und interaktiver Weltkarte.
2. **Die Gilden-Schatzkammer:**
   - Riesiger geteilter Speicher für Holz, Stein, Obsidian, Eisen, Getreide, Früchte und Fleisch.
   - Bietet detaillierte Transaktions-Logs („Wer hat 500 Obsidian entnommen?“).
3. **Das Gilden-Gestüt (Großstallungen):**
   - Basiert auf dem implementierten Reittier- und Zuchtsystem (`mounts.js`, `breeding.js`).
   - Mitglieder können dort ihre Zuchttiere (gepanzerte Stiere, Asche-Wollraben, Streitpferde) einstellen.
   - Ermöglicht das **Gilden-Kreuzungs-Programm**: Spezialisten züchten Elitetiere mit seltenen Genen, die für den gesamten Bund im Kriegsfall verfügbar sind.
4. **Die Gilden-Manufaktur & Waffenschmiede:**
   - Produziert Belagerungsgerät, Rammböcke, Barrikaden und Schrein-Runensteine.

---

## 4. Reichs-Expansion & Territoriale Verwaltung

### 4.1 Wie ein Clan Territorium gewinnt
Ein Territorium besteht aus einer oder mehreren zusammenhängenden Provinzen auf der Weltkarte:
1. **Säuberung:** Alle uralten Schreine der Ziel-Provinz müssen vom Aschefluch gereinigt werden (Besiegen der 5 Asche-Wächter und des Champions).
2. **Setzen des Bannsteins:** Der Bund platziert im Zentrum der Provinz ein Gilden-Monument. Ab diesem Moment erscheint die Provinz auf der großen Weltkarte in den Farben des Clans.
3. **Integration in das Reich:** Die Provinz wird durch Straßen und Karawanenposten mit den Nachbarprovinzen vernetzt.

### 4.2 Reichs-Perks & Gilden-Forschungsbaum
Über Ruhmes-Punkte (erworben durch Weltevents, Schreinverteidigung und Bauprojekte) schaltet die Gilde passive Boni frei:

```
[Flüstern der Glut]
  ├── [Zweig I: Kriegskunst]
  │     ├── Verstärkte Aschekrieger (+15% HP & Feuerexplosion)
  │     └── Kavallerie-Disziplin (+20% Reittier-Ausdauer & Sturmschaden)
  ├── [Zweig II: Wirtschaft & Landbau]
  │     ├── Goldene Saat (+25% Ertrag auf Plantagen & Farmen)
  │     └── Effiziente Minenarbeiter (+20% Erzabbau in Außenposten)
  └── [Zweig III: Territoriale Macht]
        ├── Bannstein-Schutzschild (+50% Schrein-Haltbarkeit)
        └── Karawanen-Geleitschutz (Automatische NPC-Wächter für Transporte)
```

---

## 5. Der Friedliche Solo-Weg vs. Der Pfad des Imperiums

Beim Charakter-Start oder jederzeit in Emberwatch wählt der Spieler seinen Lebensweg:

```mermaid
graph TD
    Choice{"Wähle deinen Pfad"}
    Choice -->|Friedlicher Lebensweg| Solo["Autarker Landbesitzer & Forscher<br/>• Permanenter Nicht-Angriffs-Schutz (Kein PvP/Raiding)<br/>• Eigener Landsitz & Meister-Gestüt<br/>• Beliefert Großgilden mit Luxusgütern<br/>• Volle Siedlungs-Entwicklung"]
    Choice -->|Der Pfad des Schwertes| Gilde["Bund- & Clankriege (Herrschaft)<br/>• Territorien erobern & Schreine halten<br/>• GvG-Schlachten & Schrein-Belagerungen<br/>• Wettkampf um die Kontinental-Krone<br/>• Bündnisse & Diplomatie"]
```

### 5.1 Das Friedliche Leben: Ausreichend Beschäftigung & Fülle
Wer alleine und friedlich spielen möchte, hat vollen Zugriff auf das Spiel:
- **Eigener Landsitz:** Der persönliche Hof kann wie eine vollwertige Siedlung mit Herrenhaus, Farm, Plantagen, Mühlen und Werkstätten ausgebaut werden.
- **Meister-Züchter & Zähmung:** Solo-Spieler können sich auf das Aufspüren wilder Tiere, das Zähmen und die gentechnische Kreuzung (`breeding.js`) im Gestüt spezialisieren. Die dabei erzeugten Elite-Reittiere (hohe Ausdauer, Resistenzen) sind unverzichtbar für Großgilden, die dafür horrende Summen auf dem Basar zahlen.
- **Wirtschafts-Magnat:** Durch Spezialisierung auf Arzneipflanzen und seltene Früchte wird der friedliche Spieler zum Hauptversorger der Kriegstruppen.
- **Forscher & Schrein-Hüter:** Erkunden von Ruinen, Lösen von Rätseln und Heilen der Natur abseits der Kriegsschauplätze.

---
*Nächstes Dokument: [`03_DIPLOMATIE_HANDEL_UND_UNTERSTUETZUNG.md`](file:///f:/Emberwild/documents/multiplayer/03_DIPLOMATIE_HANDEL_UND_UNTERSTUETZUNG.md)*.


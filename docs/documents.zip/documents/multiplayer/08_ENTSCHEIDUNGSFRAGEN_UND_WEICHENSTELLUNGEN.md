# 📋 DOKUMENT 08: ENTSCHEIDUNGSFRAGEN & WEICHENSTELLUNGEN
## Strategische Kernfragen vor Implementierungsbeginn

> **Teil der Reihe:** Emberwild Architektur & Konzepte  
> **Status:** Offener Fragebogen für Game-Design- & Technische Weichenstellungen  
> **Anleitung:** Trage deine Antworten oder Präferenzen einfach direkt unter den jeweiligen Fragen ein oder diskutiere sie im Chat.

---

## Themenbereich 1: Welt-Topologie & Kontinent (Azgaar / Zonen)

### Frage 1.1: Größe und Anzahl der Provinzen
*Hintergrund:* Azgaar kann Welten mit 20 bis über 500 Provinzen (Zellen) generieren. Je mehr Provinzen existieren, desto mehr Platz gibt es für Gilden, aber desto verteilter sind die Spieler.
- **Option A (Kompakter Kontinent):** Ca. 25–40 Provinzen. Führt zu dichteren Nachbarschaften, schnelleren Konflikten und lebendigeren Straßen.
- **Option B (Ausgewogenes Mittelmaß - Empfohlen):** Ca. 60–80 Provinzen. Bietet genügend Raum für ruhige Solo-Ecken und 10–15 große Clans, ohne leer zu wirken.
- **Option C (Riesige Sandbox):** 150+ Provinzen. Fokus auf langes Erkunden und weite Distanzen.
> **Deine Entscheidung / Notiz:** 

Antwort: Option B sollte denke ich die beste Wahl sein

---

### Frage 1.2: Visueller Übergang an den Zonengrenzen
*Hintergrund:* Wenn der Spieler die Grenze einer 2.5D-Zone erreicht:
- **Option A (Grenzübergänge an festen Punkten):** Wie klassische ARPGs (Tore, Bergpässe, Brücken, Wegweiser). Erreicht man das Tor, lädt die nächste Zone.
- **Option B (Nahtlose Kantenüberquerung):** Man kann an jedem Punkt des Kartenrandes (z. B. durch den Wald) in die Nachbarzone laufen.
> **Deine Entscheidung / Notiz:** 

Antwort: Es kommt denke ich auf das Terrain an. Man muss halt schauen ob ein Gebiet in den Bergen ist, die nur über einen Pass erreichbar sind, ob das Gebiet am Wasser liegt und dadurch Wege versperrt sind oder ob das Gebiet in offenem Land liegt und von allen Seiten betreten werden kann

---

## Themenbereich 2: Spieler-Persistenz & Welt-Server-Modell

### Frage 2.1: Ein Megaserver (Sharded Realm) oder Server-Auswahl?
*Hintergrund:* Wie betreten Spieler die Welt?
- **Option A (Zentraler Realm / Megaserver - Empfohlen):** Alle Spieler spielen auf derselben Kontinentalkarte. Instanzierung geschieht unsichtbar im Hintergrund pro Provinz (Zonen-Sharding). Man sieht immer die Clans auf der Weltkarte.
- **Option B (Klassische Server-Liste):** Spieler wählen beim Start einen Realm (z. B. „Realm 1: Aethelgard“, „Realm 2: Cinderfall“), jeweils mit eigener Weltkarte.
> **Deine Entscheidung / Notiz:** 

Antwort: Option A

---

### Frage 2.2: Solo-Offline-Modus vs. Immer Online
*Hintergrund:* Kann ein Spieler das Spiel auch komplett ohne Internet / Server rein lokal im Browser spielen?
- **Option A (Hybrid):** Solo-Spieler können lokal offline spielen (Speicherung in `localStorage` wie bisher). Für Multiplayer / Clans wählt man im Hauptmenü „Online-Welt betreten“.
- **Option B (Pure Online-Architektur):** Jeder Spielstand liegt auf dem Server, um Item-Duplikation und Cheat-Sicherheit zu garantieren.
> **Deine Entscheidung / Notiz:** 

Antwort: Option B

---

## Themenbereich 3: Clan-Wirtschaft & Territoriums-Kosten

### Frage 3.1: Gibt es Territoriums-Unterhalt (Upkeep)?
*Hintergrund:* In vielen MMOs erobern die 2 stärksten Großgilden die gesamte Karte und halten sie ewig („Map-Stagnation“).
- **Option A (Territoriums-Tribut / Upkeep - Empfohlen):** Jede gehaltene Provinz verbraucht täglich Ressourcen (z. B. 100 Getreide der Emberfarm, 50 Holz, 20 Gold). Je größer das Imperium, desto teurer der Unterhalt. Können die Kosten nicht gedeckt werden, wird die Schrein-Aura geschwächt.
- **Option B (Kein Unterhalt):** Einmal erobert, gehört das Gebiet der Gilde für immer, bis ein anderer Clan es aktiv belagert.
> **Deine Entscheidung / Notiz:** 

Antwort: Option A - Gebiete müssen aber auch verteidigt werden und von anderen übernommen werden können.

---

### Frage 3.2: Was passiert mit Bauwerken bei Eroberung?
*Hintergrund:* Wenn Gilde A einen Schrein von Gilde B erobert:
- **Option A (Besitzwechsel & Reparatur):** Die Außenposten und Mauern bleiben stehen, nehmen 50% Haltbarkeitsschaden und müssen von den neuen Besitzern mit Stein/Holz repariert werden.
- **Option B (Totale Zerstörung):** Alle errichteten Festungsanlagen der Verlierer stürzen ein; der Sieger muss komplett neu aufbauen.
> **Deine Entscheidung / Notiz:** 

Antwort: Option A

---

## Themenbereich 4: Kampfsystem & PvP-Feinheiten

### Frage 4.1: Beuteverlust beim Tod (Loot-Drop-Regeln)
*Hintergrund:* Was passiert, wenn ein Spieler im Kampf stirbt?
- **Option A (ARPG-Standard / Casual-freundlich - Empfohlen):** Angelegte Ausrüstung und Inventar-Items bleiben **immer erhalten**. Beim Tod verliert man lediglich 10% Gold und Haltbarkeit (Reparatur beim Schmied).
- **Option B (Teilweiser Beuteverlust im PvP):** Im PvE kein Item-Verlust. Im offenen Clan-Krieg oder als Schurke (negatives Karma) lässt man gefundene Rohstoffe (Holz, Erz, Kräuter) als Beutebeutel fallen.
- **Option C (Full-Loot):** Sehr hardcore; alles Inventar fällt zu Boden (meist frustrierend für Gelegenheitsspieler).
> **Deine Entscheidung / Notiz:** 

Antwort: Option A

---

### Frage 4.2: Freundliches Feuer (Friendly Fire) bei Flächenangriffen
*Hintergrund:* Magier haben riesige Feuerbälle, Barbaren Wirbelwind, Nekromanten Ascheexplosionen.
- **Option A (Sicher):** Gruppen-, Allianz- und Gildenmitglieder sind immun gegen eigene Flächenzauber.
- **Option B (Taktisch):** Eigene Gilde ist sicher, aber neutrale Gastspieler könnten Schaden nehmen, wenn sie in den Feuersturm laufen.
> **Deine Entscheidung / Notiz:** 

Antwort: Option A

---

## Themenbereich 5: Reittiere & Zucht im Multiplayer

### Frage 5.1: Sterblichkeit von Reit- und Farmtieren
*Hintergrund:* Im Zuchtsystem (`breeding.js`) züchtet der Spieler mit viel Liebe Tiere über mehrere Generationen.
- **Option A (Unsterbliche Gefährten - Empfohlen):** Reittiere können im Kampf „bewusstlos“ werden oder fliehen, sterben aber niemals permanent. Sie erholen sich im Stall oder durch Futter.
- **Option B (Permanenter Verlust möglich):** Reittiere haben ein echtes Lebensende bei 0 HP. (Führt oft dazu, dass Spieler ihre besten Zuchttiere aus Angst im Stall einsperren und nie im Kampf reiten).
> **Deine Entscheidung / Notiz:** 

Antwort: Option A

---

### Frage 5.2: Gilden-Gestüt vs. Privates Eigentum
- **Option A:** Jedes Tier gehört immer fest einem Spieler. Im Gilden-Gestüt kann man Tiere für andere Mitglieder zum „Ausleihen“ freigeben.
- **Option B:** Tiere, die in die Gildenhalle gespendet werden, gehen vollständig in das Gilden-Kollektiv über.
> **Deine Entscheidung / Notiz:** 

Antwort: Option A - Der Spieler muss aber für den Unterhalt und die Pflege der Tiere aufkommen oder sich selber darum kümmern (Quest: Dein Tier ist Krank, besorge ihm Medizin... oder ähnliche Quests)

---

## Themenbereich 6: Entwicklungs-Reihenfolge & Roadmap

### Frage 6.1: Welcher Baustein soll als Erstes realisiert werden?
Sobald wir mit der Entwicklung starten, welche Reihenfolge bevorzugst du?
- **Pfad 1 (Welt & Visualisierung zuerst):** 
  Zuerst die große **Azgaar-Weltkarten-Ansicht** bauen (mit Routen, Provinz-Klick und dem In-Game Dev-Map-Editor), sodass man das Reich schon visuell vor sich sieht und Gebiete gestalten kann.
- **Pfad 2 (Netzwerk-Fundament zuerst):**
  Zuerst den **Node.js-Server** und WebSocket-Netcode aufsetzen, sodass man zu zweit in Emberwatch herumlaufen und sich sehen kann.
- **Pfad 3 (Solo-Vertiefung zuerst):**
  Zuerst das Hofgut, die erweiterte Zucht und Quests im Singleplayer noch weiter ausbauen, bevor die Netzwerk-Ebene angeflanscht wird.
> **Deine Entscheidung / Notiz:** 


Antwort: Das bisher vorhandene System sollte nochmal analysiert werden, alles muss modular sein und eventuell umstrukturiert werden. Es muss klar definiert werden was zu was gehört (Singleplayer/Multiplayer/Allgemein). Desweiteren müssen die Texte des Spiels übersetzt werden, da an manchen Stellen immer noch Texte in der falschen Sprache erscheinen.

Das Spiel sollte ausserdem vollständig multilingual nutzbar sein, dies muss bei der Programmierung berücksichtigt werden.

Wir haben eine sehr gut programmierte und saubere Engine übernommen und sollten unbedingt darauf achten diese beizubehalten, zu pflegen und nur bei Bedarf zu erweitern. Ich möchte vermeiden Funktionen einzubauen welche in zukünftigen Versionen nur behinderlich sind oder bereits in anderer Form vorhanden sind.

Solltest du das Gefühl haben, dass eine Datei zu gross wird, die Struktur nicht mehr optimal ist, oder es einen besseren Weg gibt, so zögere bitte nicht diese umzuschreiben, anzupassen oder aufzuteilen. Benachrichtige mich dann aber im Vorfeld darüber und diskutiere mit mir die beste Vorgehensweise. Das betrifft insbesondere strukturelle Änderungen oder das hinzufügen von grossen neuen Funktionalitäten, die nicht vorher abgesprochen wurden.

---

*Dieses Dokument liegt im Ordner [`documents/multiplayer/08_ENTSCHEIDUNGSFRAGEN_UND_WEICHENSTELLUNGEN.md`](file:///f:/Emberwild/documents/multiplayer/08_ENTSCHEIDUNGSFRAGEN_UND_WEICHENSTELLUNGEN.md).*


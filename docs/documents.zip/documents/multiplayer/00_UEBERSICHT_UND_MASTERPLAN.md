# 🌐 EMBERWILD — MULTIPLAYER, TERRITORIEN & WELTEN-ARCHITEKTUR
## Master-Dokumentation & System-Übersicht

> **Status:** Konzept & Architekturentwurf (Ready for Phased Implementation)  
> **Version:** 1.0.0  
> **Ziel-Engine/Stack:** WebGL 2.0 / Three.js r128 (Client), Node.js WebSocket / authoritative Server, GeoJSON/Azgaar Map-Pipeline  
> **Kontext:** Nahtlose Erweiterung der bestehenden Singleplayer-Engine (`settlement.js`, `nature.js`, `mounts.js`, `breeding.js`, `monsters.js`, `director.js`) in ein sharded MMO/GvG-Territorial-ARPG.

---

## 1. Executive Summary & Vision

Emberwild entwickelt sich von einem lokalen ARPG/Colony-Sim-Hybrid zu einer **lebendigen, geteilten Dark-Fantasy-Welt**. 
Das Kernprinzip lautet: **Vom einsamen Überlebenden in Emberwatch zum Herrscher über ein ganzes Reich.**

### Die Säulen des Konzeptes:
1. **Globale Kontinentalkarte (Makro-Ebene):** 
   Eine monumentale Weltkarte (erzeugt oder inspiriert via *Azgaar's Fantasy Map Generator*), unterteilt in Provinzen, Biome, Reiche und strategische Knotenpunkte. Spieler und Clans überblicken hier das Weltgeschehen, Truppenbewegungen, Handelskarawanen, Territoriumsgrenzen und Aschestürme.
2. **Nahtlose 2.5D-Isometrische Zonen (Mikro-Ebene):**
   Klickt ein Spieler auf eine Provinz oder reist dorthin, lädt die bekannte hochperformante Three.js-Echtzeitwelt (wie die bisherige *Grey Fields & Emberwatch*-Map). Hier wird gekämpft, gebaut, geerntet, gezüchtet und belagert.
3. **Autarke Solo-Freiheit:**
   Solo-Spieler sind vollwertige Akteure in der Welt. Sie besitzen geschützte Enklaven, betreiben Farmen/Plantagen, erforschen Schreine und verkaufen exklusive Zuchttiere und Luxusgüter über neutrale Märkte an die großen Bünde.
4. **Bünde & Imperien (Gilden & Clans):**
   Clans beanspruchen Provinzen, errichten monumentale Festungen, schalten Reichs-Perks frei und dehnen ihr Territorium über mehrere Zonen aus.
5. **Schrein-Bannkreise & Naturheilung:**
   Das 12-Schreine-System skaliert auf die gesamte Welt. Das Heilen der Asche ist kein reiner Selbstzweck, sondern der Motor für territoriale Expansion, Rohstoffbesteuerung und Schrein-Auren.
6. **Tiefe Diplomatie & Belagerungsschlachten:**
   Friedenspakte, Karawanenschutzbündnisse und automatisierte Rohstoffhilfe auf der einen Seite — strukturierte Schrein-Belagerungen (GvG) mit Vorwarnzeit und Schutzschilden auf der anderen Seite (kein willkürliches Offline-Griefing).
7. **Globale Server-Events:**
   *The Great Cinderfall* (kontinentale Aschestürme mit wandernden Titanen) und das wöchentliche *Konklave der Ersten Flamme*.

---

## 2. Dokumenten-Index der Multiplayer-Reihe

Im Ordner [`documents/multiplayer/`](file:///f:/Emberwild/documents/multiplayer/) befinden sich alle spezialisierten Sub-Dokumente:

| Dokument | Titel & Fokus |
| :--- | :--- |
| **[`00_UEBERSICHT_UND_MASTERPLAN.md`](file:///f:/Emberwild/documents/multiplayer/00_UEBERSICHT_UND_MASTERPLAN.md)** | *Dieses Dokument:* Gesamtüberblick, Architektur, Verknüpfung der Systeme. |
| **[`01_WELTKARTE_UND_ZONEN_ARCHITEKTUR.md`](file:///f:/Emberwild/documents/multiplayer/01_WELTKARTE_UND_ZONEN_ARCHITEKTUR.md)** | Azgaar-Kartenpipeline, Kontinental-Raster, Instanzierung, Klick-to-Zone-Ladefluss, Biome. |
| **[`02_GILDEN_CLANS_UND_TERRITORIEN.md`](file:///f:/Emberwild/documents/multiplayer/02_GILDEN_CLANS_UND_TERRITORIEN.md)** | Bund-Gründung, Ränge, Gilden-Schatzkammer, Bannsteine, Provinzen-Expansion, Reichs-Perks. |
| **[`03_DIPLOMATIE_HANDEL_UND_UNTERSTUETZUNG.md`](file:///f:/Emberwild/documents/multiplayer/03_DIPLOMATIE_HANDEL_UND_UNTERSTUETZUNG.md)** | Friedenspakte, Defensiv-Bündnisse, Karawanen, Rohstoff-Nothilfe, Solo-Marktplatz. |
| **[`04_KAMPF_BELAGERUNGEN_UND_GVG.md`](file:///f:/Emberwild/documents/multiplayer/04_KAMPF_BELAGERUNGEN_UND_GVG.md)** | Kriegszeiten, Schrein-Belagerungen in 3 Phasen, PvP-Regeln, Nekromantie & Reittiere im PvP. |
| **[`05_SERVER_EVENTS_UND_WELTBOSSE.md`](file:///f:/Emberwild/documents/multiplayer/05_SERVER_EVENTS_UND_WELTBOSSE.md)** | Großer Cinderfall, Titan Ignis, Konklave der Flamme, dynamische Skalierung des Krisen-Direktors. |
| **[`06_PERFORMANZ_NETZWERK_UND_CODE_STRUKTUR.md`](file:///f:/Emberwild/documents/multiplayer/06_PERFORMANZ_NETZWERK_UND_CODE_STRUKTUR.md)** | Node.js WebSocket-Netcode, State-Interpolation, Instanz-Sharding, Entity-Culling, 60 FPS-Garantie. |
| **[`07_LEVELDESIGN_GENERIERUNG_UND_DEV_EDITOR.md`](file:///f:/Emberwild/documents/multiplayer/07_LEVELDESIGN_GENERIERUNG_UND_DEV_EDITOR.md)** | Hybride Generierung, On-Demand Zonen-Lifecycle, In-Game Dev-Map-Editor, physische Reisen (kein Klick-Teleport) & Autarkes Solo-Königreich. |

---

## 3. Die Makro-zu-Mikro-Schleife (Game Loop)

```mermaid
sequenceDiagram
    autonumber
    actor Player as Spieler / Gilde
    participant WorldMap as Große Weltkarte (Azgaar / SVG / Canvas)
    participant Server as Realm Server (Node.js Cluster)
    participant ZoneEngine as 2.5D Isometrische Zonen-Engine (Three.js)

    Player->>WorldMap: Inspiziert Kontinent, Territorien & Karawanen
    Player->>WorldMap: Wählt Ziel-Provinz (z. B. "Provinz 04: Obsidian-Senke")
    WorldMap->>Server: Request JoinZone(provinzId, spielerToken)
    Server-->>ZoneEngine: Überträgt Zonen-Seed, Schrein-Status, Gilden-Bannstein & Entities
    ZoneEngine->>Player: Rendert isometrische Welt (Laufbar, Bauen, Kämpfen)
    Player->>ZoneEngine: Säubert Schrein / Erntet Plantage / Kämpft
    ZoneEngine->>Server: Sync Entity-Updates & Territoriums-Fortschritt
    Server-->>WorldMap: Aktualisiert Provinzen-Besitzer & Grenzen auf der Weltkarte
```

---

## 4. Leitprinzipien für Code-Architektur & Performance

1. **Kein Monolith:** 
   Das bestehende Frontend bleibt modular. Module wie [`settlement.js`](file:///f:/Emberwild/src/worldsys/settlement.js), [`nature.js`](file:///f:/Emberwild/src/worldsys/nature.js) und [`mounts.js`](file:///f:/Emberwild/src/worldsys/mounts.js) werden über einen standardisierten **EventBus & NetworkBridge** angesteuert.
2. **Autoritärer Server, prädiktiver Client:**
   Kämpfe, Ressourcen und Besitztümer werden server-authoritativ validiert. Der Client interpoliert Bewegungen sofort (Client-Side Prediction), um die butterweiche ARPG-Steuerung beizubehalten.
3. **Zonen-Sharding:**
   Nicht die gesamte Welt läuft in einem Thread. Jede Zone ist ein leichtgewichtiger Node.js-Worker. Betreten 0 Spieler eine Zone, geht sie in den Ruhezustand (Tick-Rate sinkt auf 0.1 Hz).
4. **Asset- und VRAM-Effizienz:**
   Geometrien und Texturen (Quaternius-Farmtiere, Synty-Modelle) werden instanziert (`InstancedMesh`) und geshared. Der Wechsel zwischen Weltkarte und 2.5D-Zone erfolgt in unter 1,5 Sekunden.

---
*Weiter zu den Detaildokumenten im Verzeichnis [`documents/multiplayer/`](file:///f:/Emberwild/documents/multiplayer/)*.


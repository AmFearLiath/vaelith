# Emberwild – The Crown
# Technische Gesamtspezifikation: Siedlungsverwaltung – Verteidigung

**Ziel:** Implementierung einer vollständigen militärischen und ökologischen Verteidigungsverwaltung für Emberwatch.

**Geltungsbereich:** UI, Spiellogik, Datenhaltung, Ökosystemintegration, NPC-Verhalten, Ereignissystem, Balancing und Internationalisierung.

---

# 1. Grundkonzept und Designvorgaben

Die Verteidigungsverwaltung ist die zentrale Sicherheits- und Gefahrenverwaltung einer Siedlung.

Sie muss zwei grundsätzlich unterschiedliche Bedrohungsarten berücksichtigen:

### A. Organisierte und humanoide Bedrohungen

- Banditen und Plünderer
- Kundschafter und Späher
- Saboteure und Diebe
- Aschebrut und mutierte Kreaturen
- Organisierte Angreifer und Belagerer
- Später: Angriffe feindlicher Gilden im Rahmen regulärer Gildenkriege

### B. Ökologische Bedrohungen

- Hungrige Raubtiere
- Wolfsrudel und Bären
- Wildschweine und andere aggressive Wildtiere
- Verdrängte Tiergruppen
- Nahrungsmangel durch Überjagung
- Angriffe auf Weiden, Zuchttiere, Nutztiere und Produktionsstätten

Die Verteidigung soll nicht nur auf Angriffe reagieren. Der Spieler muss Gefahren frühzeitig erkennen, ihre Ursachen verstehen und durch geeignete Maßnahmen verhindern können.

## 1.1 Visuelles Design

Alle fünf Ansichten orientieren sich an den erstellten Screenshots.

- Dunkles Fantasy-Design mit Schwarz-, Braun- und Bronzeoberflächen.
- Goldene Rahmen, Ornamente und Hervorhebungen.
- Einheitliche mittelalterliche Symbolsprache.
- Hochwertige Gebäude- und Charakterillustrationen.
- Grüne Statusanzeigen für positive Zustände.
- Gelbe und orange Statusanzeigen für Warnungen.
- Rote Statusanzeigen für kritische Gefahren.
- Keine Emojis.
- Icons als SVG.
- Einheitliche Tooltip-Architektur über `bindCrownTooltip`.
- Großes Overlay, während die Spielwelt im Hintergrund sichtbar bleibt.
- Responsive Panel- und Kartenanordnung.
- Alle UI-Texte müssen über i18n verwaltet werden.

## 1.2 Navigationsstruktur

Die linke Hauptnavigation der Siedlungsverwaltung bleibt unverändert.

Innerhalb von `Verteidigung` existieren fünf horizontale Untertabs:

1. Übersicht
2. Garnison
3. Verteidigungsanlagen
4. Bedrohungen
5. Reaktionen

Die fünf Bereiche verwenden dieselben Datenquellen und dürfen keine voneinander unabhängigen Verteidigungswerte berechnen.

---

# 2. Tab: Übersicht

**Ziel:** Zentrale Zusammenfassung der Verteidigungsfähigkeit und der aktuellen Gefahrenlage.

Die Übersicht soll dem Spieler ermöglichen, den Zustand seiner Siedlung innerhalb weniger Sekunden zu erfassen.

## 2.1 KPI-Kopfbereich

Fünf zentrale Informationsbereiche:

### Sicherheitsstufe der Siedlung
- Prozentualer Sicherheitswert.
- Abgeleiteter Sicherheitsstatus, beispielsweise „Bollwerk von Emberwatch“.
- Berechnung aus Garnison, Verteidigungsanlagen, Betriebs-Wehrkraft und weiteren relevanten Faktoren.

### Aktive Garnison
- Eingesetzte Stadtwachen.
- Maximale Garnisonskapazität.
- Aktueller Kommandant.
- Einsatzbereitschaft.

### Gesamt-Wehrkraft
- Kumulierte Verteidigungspunkte.
- Boni durch Kommandant, Ausrüstung und Wach-Doktrinen.
- Tooltip mit nachvollziehbarer Berechnungsgrundlage.

### Tor-Bedrohung (Aschebrut)
- Aktueller Bedrohungsindex.
- Gefahrenstatus.
- Entwicklung des Bedrohungswerts.

### Raubtier-Hunger (Fauna)
- Hungerindex der relevanten Raubtierpopulationen.
- Gefahrenstatus.
- Zusammenhang mit der Herbivoren-Dichte und Überjagung.

Wichtig: Tor-Bedrohung und Raubtier-Hunger sind getrennte Kennzahlen. Sie dürfen nicht zu einem allgemeinen Bedrohungswert zusammengefasst werden.

## 2.2 Aktuelle Bedrohungen

Eine kompakte Liste der momentan relevanten Gefahren:

- Hungrige Raubtiere.
- Banditenkundschafter.
- Wildtierstreifzüge.
- Aschebrut.
- Sabotage und Diebstahl.
- Aktive oder bevorstehende Angriffe.

Jeder Eintrag enthält:

- Bedrohungsart.
- Herkunft.
- Gefahrenstufe.
- Aufenthaltsort.
- Gruppengröße, sofern vorhanden.
- Zeitliche Entwicklung.
- Betroffene Gebäude oder Bereiche.
- Möglichkeit, die Detailansicht im Tab `Bedrohungen` zu öffnen.

## 2.3 Ökosystem und Wildtiere

Anzeige der ökologischen Kennzahlen:

- Herbivoren-Dichte im Umland.
- Raubtier-Aktivität.
- Nahrungsverfügbarkeit.
- Überjagungsindex.
- Ökologisches Gleichgewicht.
- Raubtier-Hungerindex.

Die Werte müssen aus dem tatsächlichen Ökosystem stammen.

Ein Beispiel für die Zusammenhänge:

1. Spieler jagen übermäßig viele Pflanzenfresser.
2. Die Herbivoren-Dichte sinkt.
3. Die verfügbaren natürlichen Nahrungsquellen für Raubtiere nehmen ab.
4. Der Raubtier-Hungerindex steigt.
5. Raubtiere suchen alternative Nahrungsquellen.
6. Weiden und Siedlungsbereiche geraten zunehmend in Gefahr.

Die Oberfläche muss die Ursache der Gefährdung erklären und mögliche Präventionsmaßnahmen anzeigen.

## 2.4 Verteidigungsring

Kompakte Übersicht der baulichen Verteidigung:

- Mauern und Palisaden.
- Wachtürme.
- Tore.
- Fallen.
- Beleuchtung.
- Integrität und Reparaturzustand.

Ein Klick führt zur Detailverwaltung im Tab `Verteidigungsanlagen`.

## 2.5 Garnison

Kurzübersicht:

- Eingesetzte Stadtwachen.
- Bogenschützen.
- Spezialisten.
- Gesamt-Wehrkraft.
- Einsatzbereitschaft.
- Kommandant.

Ein Klick öffnet den Tab `Garnison`.

## 2.6 Verteidigungsbereitschaft

Zusammenfassende Checkliste:

- Garnison vollständig beziehungsweise ausreichend besetzt.
- Verteidigungsanlagen betriebsbereit.
- Munition und Vorräte ausreichend.
- Wachposten besetzt.
- Produktionsstätten ausreichend geschützt.

## 2.7 Reaktionsregeln

Kurzübersicht der aktuell verwendeten Verteidigungsregeln:

- Wildtierangriffe.
- Banditenangriffe.
- Aschebrut.
- Sabotage.
- Belagerungen.

Ein Klick führt zu den Einstellungen im Tab `Reaktionen`.

---

# 3. Tab: Garnison

**Ziel:** Vollständige Verwaltung der militärischen NPC-Einheiten und ihrer Einsatzfähigkeit.

Hier werden die Verteidiger selbst verwaltet, nicht die baulichen Verteidigungsanlagen.

## 3.1 Garnisonskommando

Profil des Kommandanten:

**Hauptmann Torin Ironmark**

Anzuzeigen sind:

- Charakterporträt.
- Name und Rang.
- Kommandantenstatus.
- Persönliche Fähigkeiten.
- Führungsbonus.
- Einfluss auf Wehrkraft und Moral.
- Zugehörige Bastion.
- Status des NPC.

Torin muss als tatsächlicher NPC aus dem Spielsystem geladen werden. Sein Profil darf nicht ausschließlich aus UI-Daten bestehen.

## 3.2 Garnisonsstatus

Kennzahlen:

- Eingesetzte Wachen.
- Maximale Garnisonskapazität.
- Gesamt-Wehrkraft.
- Einsatzbereitschaft.
- Durchschnittsrang.
- Rüstkammerstufe.
- Laufender Unterhalt pro Minute beziehungsweise Zyklus.

## 3.3 Wachmannschaft und Einheiten

Individuelle Verwaltung der Einheiten:

- Stadtwachen.
- Bogenschützen.
- Spezialisten.
- Weitere später freischaltbare Einheiten.

Pro Einheit beziehungsweise NPC:

- Name und Charakterporträt.
- Einheitentyp.
- Rang.
- XP und Fortschritt.
- Wehrkraft.
- Ausrüstung.
- Aktueller Einsatzort.
- Verfügbarkeit.
- Zustand.

Interaktionen:

- Wachen zuweisen.
- Wachen abziehen.
- Einheiten umverteilen.
- Ausbildung beginnen.
- Ausrüstung verwalten.
- Einsatzbereich ändern.

Die Besetzung darf die verfügbare Bevölkerung und die tatsächlichen NPC-Arbeitsplätze berücksichtigen.

## 3.4 Rüstkammer

Drei Ausstattungsstufen:

1. Miliz-Leder.
2. Geschmiedetes Eisen.
3. Runenklingen.

Pro Stufe:

- Ausrüstungsbeschreibung.
- Kampfwert.
- Boni auf Wehrkraft.
- Benötigte Materialien.
- Goldkosten.
- Freischaltbedingungen.
- Aktueller Ausbaustatus.

Interaktion:

- Rüstkammer aufwerten.

Die Aufwertung verbraucht reale Ressourcen aus den entsprechenden Beständen beziehungsweise Produktionslagern.

Die Kampfwertsteigerung muss auf die tatsächlichen Einheiten angewendet werden.

## 3.5 Wach-Doktrinen

Drei auswählbare Einsatzmodi:

### Ausgewogene Stadtwacht
- Gleichmäßiger Schutz von Mauern, Toren und Weiden.
- Moderater Unterhalt.
- Standardmodus.

### Torsicherung & Festungswall
- +40 % Wehrkraft an Toren und Bastion.
- Reduzierte Sabotagechancen.
- Eingeschränkte Reichweite außerhalb der Siedlung.

### Grenz-Aufklärung & Späher
- Kontinuierliche Reduktion der Bedrohung im Umland.
- Erhöhte Frühwarnung.
- Bessere Erkennung von Hinterhalten.

Die Doktrinen müssen tatsächlich Einfluss auf die Berechnung der Wehrkraft und die KI-Reaktionen nehmen.

## 3.6 Aktive Garnisonsbefehle

### Spähtrupp aussenden
- Reduziert bei Erfolg die Bedrohung im Umland.
- Erzeugt einen Späherbericht.
- Kann Informationen über Gegnerlager und Bewegungen liefern.
- Kann Beute einbringen.
- Verwendet eine konfigurierbare Abklingzeit.

### Verteidigungs-Drill
- Wachen erhalten XP.
- Verbraucht Gold.
- Hat eine Abklingzeit.

### Tore verriegeln / Alarmbereitschaft
- Erhöht den Torschutz.
- Aktiviert Alarmzustände.
- Kann Bewegung und Handel durch Tore einschränken.
- Ist zeitlich beziehungsweise ereignisbezogen begrenzt.

---

# 4. Tab: Verteidigungsanlagen

**Ziel:** Verwaltung sämtlicher baulicher Verteidigungsmaßnahmen der Siedlung.

## 4.1 KPI-Bereich

- Gesamt-Wehrkraft.
- Anlagen-Integrität.
- Mauerstärke.
- Anzahl reparaturbedürftiger Anlagen.
- Verteidigungsstatus.

## 4.2 Siedlungsplan / Verteidigungsring

Interaktive Karte der Siedlung.

Darstellung:

- Mauern und Palisaden.
- Tore und Torhäuser.
- Wachtürme.
- Fallen.
- Beleuchtung.
- Verteidigungspositionen.
- Schwachstellen.
- Beschädigte Anlagen.

Karteninteraktionen:

- Layer ein- und ausschalten.
- Einzelne Anlagen auswählen.
- Anlagenstatus anzeigen.
- Details öffnen.
- Reparaturaufträge erstellen.
- Besatzungen zuweisen.

Die Karte muss auf tatsächlichen Gebäude- und Positionsdaten basieren.

## 4.3 Anlagenverwaltung

Übersicht aller Verteidigungsanlagen.

Pro Anlage:

- Name und Typ.
- Ausbaustufe.
- Integrität.
- Wehrkraft.
- Besatzung.
- Zustand.
- Reparaturbedarf.
- Unterhaltskosten.

## 4.4 Anlagendetails

Bei Auswahl einer Anlage:

- Beschreibung.
- Aktuelle Stufe.
- Maximale Stufe.
- Integrität.
- Verteidigungswert.
- Reichweite beziehungsweise Sichtweite.
- Besatzung.
- Boni und Modifikatoren.
- Materialbedarf.

## 4.5 Ausbau und Wartung

Interaktionen:

- Mauern verstärken.
- Tore verbessern.
- Wachtürme aufwerten.
- Fallen verbessern.
- Beleuchtung erweitern.
- Beschädigte Anlagen reparieren.
- Anlagenbesatzung ändern.

Alle Aktionen müssen Baukosten, Ressourcenbestände und tatsächliche Gebäudezustände berücksichtigen.

---

# 5. Tab: Bedrohungen

**Ziel:** Analyse und Überwachung aller ökologischen und organisierten Bedrohungen.

## 5.1 KPI-Bereich

- Anzahl aktiver Bedrohungen.
- Anzahl kritischer Bedrohungen.
- Ökologische Gefahr.
- Humanoide Gefahr.
- Ökosystem-Stabilität.
- Überjagungsstatus.

Ökologische und humanoide Gefahren müssen separat berechnet werden.

## 5.2 Bedrohungsliste

Kategorien:

### Ökologisch
- Hungrige Raubtiere.
- Wolfsrudel.
- Bären.
- Wildschweine.
- Andere aggressive Wildtiere.
- Verdrängte Tiergruppen.
- Mutierte Kreaturen, sofern sie ökologisch agieren.

### Humanoid
- Banditen.
- Plünderer.
- Kundschafter.
- Saboteure.
- Diebe.
- Aschebrut.
- Organisierte Angreifer.

Pro Bedrohung:

- Typ.
- Herkunft.
- Aufenthaltsort.
- Gruppengröße.
- Gefahrenstufe.
- Bewegungsrichtung.
- Ziel beziehungsweise potenziell gefährdete Bereiche.
- Erwartete Entwicklung.

## 5.3 Detailanalyse

Bei Auswahl einer Bedrohung:

- Individuelle Gefahrenbeschreibung.
- Ursprung der Gefahr.
- Aktuelle Position.
- Verhalten.
- Aggressivität.
- Betroffene Siedlungsbereiche.
- Mögliche Auswirkungen.
- Gegenmaßnahmen.

Bei Tiergruppen zusätzlich:

- Art.
- Anzahl.
- Hungerzustand.
- Nahrungsverfügbarkeit.
- Beutevorkommen.
- Jagdverhalten.
- Zusammenhang mit der ökologischen Situation.

## 5.4 Ökosystemanalyse

Detaillierte Anzeige:

- Herbivoren-Dichte.
- Flora- beziehungsweise Nahrungskapazität.
- Anzahl kürzlich erlegter Beutetiere.
- Raubtier-Hungerindex.
- Raubtier-Aktivität.
- Ökologisches Gleichgewicht.
- Veränderung über die Zeit.

Die Berechnungen müssen nachvollziehbar sein.

## 5.5 Gefahrenprognose

Mögliche Entwicklungen:

- Annäherung an die Siedlung.
- Angriffe auf Weiden.
- Angriffe auf Nutztiere.
- Angriffe auf Produktionsstätten.
- Überfälle auf Handelswege.
- Sabotage.
- Belagerungen.

Prognosen müssen aus tatsächlichen Daten und KI-Zuständen abgeleitet werden. Keine zufälligen, ausschließlich für die Anzeige erzeugten Bedrohungswerte.

## 5.6 Gegenmaßnahmen

Je nach Bedrohung:

- Spähtrupp entsenden.
- Patrouillen aktivieren.
- Wachhunde einsetzen.
- Fallen und Schlingen verwenden.
- Feuerkörbe aktivieren.
- Weiden sichern.
- Garnison alarmieren.
- Verteidigungsanlagen verstärken.

## 5.7 Ereignisprotokoll

Chronik der letzten relevanten Vorfälle:

- Entdeckte Gegner.
- Abgewehrte Angriffe.
- Erlegte oder vertriebene Tiere.
- Verluste.
- Gestohlene Ressourcen.
- Ökologische Veränderungen.
- Späherberichte.

Ein vollständiges Logbuch muss aufrufbar sein.

---

# 6. Tab: Reaktionen

**Ziel:** Konfiguration der automatischen und manuellen Verteidigungsreaktionen.

Der Spieler soll definieren können, wie seine Siedlung auf unterschiedliche Gefahren reagiert.

## 6.1 KPI-Bereich

- Reaktionsbereitschaft.
- Anzahl aktiver Regeln.
- Anzahl automatisierter Reaktionen.
- Verfügbare manuelle Eingriffe.
- Präventionseffekt.

Der Präventionseffekt darf nur aus tatsächlich verhinderten beziehungsweise reduzierten Gefahren abgeleitet werden, nicht aus einer frei erfundenen UI-Berechnung.

## 6.2 Reaktionsregeln

Konfigurierbare Kategorien:

- Raubtiersichtungen.
- Angriffe auf Weiden.
- Banditen und Plünderer.
- Aschebrut und Mutationen.
- Sabotage und Diebstahl.
- Belagerungen und Großangriffe.

Pro Regel:

- Aktivierungsstatus.
- Beschreibung.
- Auslöser.
- Bedingungen.
- Automatische Reaktionen.
- Priorität.
- Abklingzeit.
- Ressourcenbedarf.
- Status der letzten Ausführung.

## 6.3 Regelkonfiguration

Ein Regelsystem mit konfigurierbaren Bedingungen.

Beispiel:

**Regel: Raubtiersichtungen**

Auslöser:
- Raubtier-Hungerindex >= 60 %.
- Sichtung im Umkreis <= 3 km.
- Optional: Überjagungsindex >= 30 %.

Automatische Reaktionen:
- Wachhunde auf Weiden aktivieren.
- Patrouille zum Sichtungsort entsenden.
- Feuerkörbe an Außenposten entzünden.
- Optional: Garnison in Alarmbereitschaft versetzen.

Die Bedingungen müssen kombinierbar sein.

Mindestens erforderlich:

- UND-Verknüpfungen.
- ODER-Verknüpfungen, sofern das Regelmodell dies unterstützt.
- Aktivieren und Deaktivieren einzelner Bedingungen.
- Konfigurierbare Schwellenwerte.
- Konfigurierbare automatische Aktionen.

## 6.4 Reaktionsprioritäten

Priorisierung der Gefahren:

1. Belagerung / Großangriff.
2. Banditen / Plünderer.
3. Angriff auf Weiden.
4. Aschebrut / Mutationen.
5. Raubtiersichtungen.
6. Sabotage / Diebstahl.

Die Reihenfolge muss vom Spieler veränderbar sein.

Interaktion:
- Drag & Drop.
- Prioritätsnummern automatisch aktualisieren.
- Änderungen speichern.

Bei gleichzeitigen Ereignissen muss das Verteidigungssystem die Prioritäten berücksichtigen.

## 6.5 Manuelle Krisenreaktionen

Sonderaktionen für größere Ereignisse:

### Verteidigung mobilisieren
- Alle verfügbaren Kräfte zusammenziehen.
- Verteidigungspositionen aktivieren.
- Garnison in Alarmbereitschaft versetzen.

### Verbündete rufen
- Gilde oder verbündete Siedlungen kontaktieren.
- Hilfsanfrage erzeugen.
- Multiplayer-Berechtigungen berücksichtigen.

### Notversorgung aktivieren
- Zusätzliche Rationen.
- Munition.
- Heilmittel.
- Weitere notwendige Verteidigungsressourcen.

Diese Aktionen benötigen tatsächliche Spielmechaniken und dürfen nicht nur UI-Schaltflächen sein.

## 6.6 Benachrichtigungen und Berichte

Konfigurierbare Benachrichtigungen:

- Vorwarnungen bei steigender Gefahr.
- Späherberichte.
- Angriffe und Verteidigungsergebnisse.
- Ökologische Veränderungen.
- Jagd- und Beuteentwicklung.
- Raubtier-Hunger.
- Nur kritische Ereignisse.

## 6.7 Allgemeine Einstellungen

- Automatische Reaktionen aktivieren/deaktivieren.
- Reaktionsverzögerung.
- Ressourcenlimit.
- Verhalten bei Ressourcenmangel.
- Verhalten bei mehreren gleichzeitigen Gefahren.

---

# 7. Core-Architektur und notwendige Spiellogik

Die Oberfläche darf keine eigenständige Verteidigungssimulation implementieren.

Alle Werte und Aktionen müssen über zentrale Spiellogik laufen.

Bestehende Systeme sollen erweitert und wiederverwendet werden.

## 7.1 Bestehende Systeme

Folgende Dateien sind die vorgesehenen Integrationspunkte:

### `src/worldsys/settlement.js`

Verantwortlich für:

- Siedlungsdaten.
- Gebäude und Betriebszustände.
- Garnisonsstatus.
- Bastion `watch_bastion`.
- Kommandant Torin Ironmark.
- Bevölkerungs- und Moralzustände.
- Sicherheits-Moral über `getMoraleState().safety`.
- Weiden und Zuchttierbestände.
- Verteidigungsrelevante Siedlungsdaten.

### `src/worldsys/settlementCrises.js`

Verantwortlich für:

- Vorfalls- und Krisensystem.
- `SETTLEMENT_INCIDENTS`.
- Die zwölf definierten Vorfälle.
- `requiredDefense`.
- `calculateDefenseScore()`.
- Die drei Großkrisen aus `MAJOR_CRISES`.
- Auswertung der Verteidigungsfähigkeit.
- Auswirkungen auf Gebäude und Ressourcen.

Die vorhandene Wehrkraftberechnung soll als Grundlage dienen:

`Level × 2 + Summe(Arbeiter-Rang + 1) + Meisterbonus (+3)`

Die tatsächliche Implementierung und die beteiligten Gebäude müssen vor Erweiterung geprüft werden.

### `src/entities/animals/animalManager.js`

Verantwortlich für:

- Tierpopulationen.
- Tiergruppen.
- Beuteverfügbarkeit.
- Raubtierverhalten.
- Nahrungssuche.
- Hungerzustände.
- Räumliche Aktivität.
- Angriffe auf Siedlungsbereiche.

### `src/entities/animals/genetics.js`

Verantwortlich für:

- Genetische Eigenschaften.
- Mutationen.
- Tiermerkmale.
- Vererbung.
- Auswirkungen besonderer Tiermerkmale auf Gefährlichkeit und Verhalten.

### `src/data/settlementBalance.js`

Verantwortlich für:

- Verteidigungskosten.
- Garnisonskosten.
- Ausrüstungsaufwertungen.
- Aktionskosten.
- Cooldowns.
- Gefahren-Schwellenwerte.
- Doktrinen-Boni.
- Krisen-Balancing.
- Live- und Dev-Balancingprofile.

### `src/ui/settlementPanel.js`

Verantwortlich für:

- Einbindung in die bestehende Siedlungsverwaltung.
- UI-Integration.
- Tooltip-System `bindCrownTooltip`.
- Gemeinsame Interaktions- und Darstellungsmechanismen.

### `src/data/locales/de.js` und `src/data/locales/en.js`

Alle neuen Texte müssen vollständig internationalisiert werden.

Dazu gehören:

- Überschriften.
- Beschreibungen.
- Buttons.
- Statusmeldungen.
- Bedrohungstypen.
- Doktrinen.
- Reaktionsregeln.
- Tooltips.
- Ereignisberichte.
- Fehlermeldungen.
- Bestätigungsdialoge.

Keine fest codierten UI-Texte.

---

# 8. Benötigte Core-Komponenten

Die vorhandenen Systeme sollen nicht unnötig durch parallele Implementierungen ersetzt werden.

Falls die entsprechenden Funktionen noch nicht existieren, sollten die folgenden Verantwortlichkeiten modular ergänzt werden.

## 8.1 SettlementDefenseManager

Zentrale Schnittstelle für die Verteidigungsverwaltung.

Verantwortlichkeiten:

- Gesamt-Wehrkraft ermitteln.
- Sicherheitsstatus berechnen.
- Garnisonsdaten zusammenführen.
- Verteidigungsanlagen auswerten.
- Betriebs-Wehrkraft ermitteln.
- Bedrohungsdaten aggregieren.
- Verteidigungsbereitschaft berechnen.
- Verteidigungsaktionen ausführen.
- Verteidigungszustand speichern.

Die Komponente soll auf die bestehenden Settlement- und Crisis-Systeme zugreifen, statt eigene Kopien der Daten anzulegen.

## 8.2 GarrisonManager

Verantwortlichkeiten:

- Garnison verwalten.
- Wachen zuweisen und abziehen.
- Einheitenstatus verwalten.
- Ränge und XP berücksichtigen.
- Kommandantenboni anwenden.
- Ausrüstung verwalten.
- Doktrinen auswerten.
- Garnisonsunterhalt berechnen.
- Verteidigungsbefehle ausführen.

## 8.3 DefenseStructureManager

Verantwortlichkeiten:

- Verteidigungsanlagen verwalten.
- Mauern und Palisaden.
- Tore.
- Wachtürme.
- Fallen.
- Beleuchtung.
- Integrität.
- Reparaturzustände.
- Ausbau und Wartung.
- Positionen und Verteidigungsbereiche.

## 8.4 ThreatAssessmentManager

Verantwortlichkeiten:

- Bedrohungen erkennen.
- Bedrohungsarten klassifizieren.
- Gefahrenstufen bestimmen.
- Ökologische Gefahren bewerten.
- Humanoide Gefahren bewerten.
- Gefahrenentwicklung prognostizieren.
- Betroffene Siedlungsbereiche ermitteln.
- Bedrohungshistorie bereitstellen.

## 8.5 EcologicalThreatManager

Verantwortlichkeiten:

- Herbivoren-Dichte auswerten.
- Flora- und Nahrungskapazität berücksichtigen.
- Überjagung erkennen.
- Raubtier-Hungerindex ermitteln.
- Raubtier-Aktivität auswerten.
- Verändertes Jagdverhalten berücksichtigen.
- Gefährdete Weiden und Nutztiere erkennen.
- Ökologische Gefahren an das Verteidigungssystem melden.

Wichtig: Die ökologische Gefahrenberechnung soll vorhandene Tier- und Ökosystemdaten verwenden. Keine zweite, unabhängige Tierpopulation oder Hungerberechnung anlegen.

## 8.6 DefenseReactionManager

Verantwortlich für:

- Reaktionsregeln.
- Auslöser und Bedingungen.
- Automatische Aktionen.
- Reaktionsprioritäten.
- Cooldowns.
- Ressourcenlimits.
- Manuelle Krisenaktionen.
- Ausführungsprotokolle.
- Regelkonflikte und gleichzeitige Ereignisse.

## 8.7 DefenseEventLog

Verantwortlich für:

- Angriffe.
- Abgewehrte Angriffe.
- Verluste.
- Beute.
- Späherberichte.
- Ökologische Warnungen.
- Reparaturen.
- Verteidigungsaktionen.
- Krisenereignisse.

Jedes Ereignis soll mindestens enthalten:

- Eindeutige ID.
- Ereignistyp.
- Zeitstempel.
- Herkunft.
- Betroffenen Bereich.
- Ergebnis.
- Auswirkungen.
- Zugehörige Bedrohungs- oder Krisen-ID.

---

# 9. Datenmodelle und Schnittstellen

Die folgenden Strukturen sind konzeptionelle Anforderungen, keine Behauptung, dass diese Objekte bereits im Projekt existieren.

Der Agent soll zunächst die vorhandenen Datenstrukturen untersuchen und diese erweitern, statt redundante Modelle einzuführen.

## 9.1 DefenseState

Zentrale Verteidigungsdaten:

- settlementId
- securityScore
- totalDefenseScore
- readiness
- garrison
- structures
- threatAssessment
- activeDoctrine
- reactionRules
- reactionPriorities
- eventHistory
- lastUpdated

## 9.2 GarrisonState

- commanderId
- assignedGuards
- guardCapacity
- units
- equipmentTier
- activeDoctrine
- upkeep
- readiness

## 9.3 DefenseStructureState

- buildingId
- structureType
- level
- integrity
- defenseScore
- assignedGuards
- position
- repairStatus
- upkeep

## 9.4 ThreatState

- threatId
- threatType
- threatCategory
- source
- location
- target
- groupSize
- severity
- activity
- detectedAt
- lastUpdated
- status
- predictedImpact

## 9.5 ReactionRule

- ruleId
- enabled
- priority
- triggers
- conditions
- actions
- cooldown
- resourceLimit
- lastExecuted
- executionStatus

## 9.6 DefenseEvent

- eventId
- eventType
- timestamp
- source
- target
- severity
- result
- rewards
- losses
- descriptionKey
- relatedThreatId

---

# 10. Ereignis- und Reaktionsarchitektur

Das Verteidigungssystem soll ereignisorientiert arbeiten.

Beispiele:

- `animal.predator.hunger_changed`
- `animal.prey.population_changed`
- `animal.predator.near_settlement`
- `animal.predator.attacked_livestock`
- `settlement.defense.threat_detected`
- `settlement.defense.threat_resolved`
- `settlement.defense.garrison_changed`
- `settlement.defense.structure_damaged`
- `settlement.defense.incident_started`
- `settlement.defense.incident_resolved`
- `settlement.defense.reaction_executed`

Die Namen sind Vorschläge und müssen an das vorhandene Event-System angepasst werden.

Grundsätzlicher Ablauf:

1. Ein bestehendes Core-System erkennt eine relevante Veränderung.
2. Das Ereignis wird an die zuständigen Systeme gemeldet.
3. Das Threat Assessment bewertet die Gefahrenlage.
4. Der Reaction Manager prüft aktive Regeln und Prioritäten.
5. Die zulässigen Aktionen werden ausgeführt.
6. Die tatsächlichen Auswirkungen werden in den jeweiligen Core-Systemen gespeichert.
7. Das Event Log erhält einen Eintrag.
8. Die UI aktualisiert die betroffenen Anzeigen.

Die UI darf keine Spielaktionen selbst simulieren.

---

# 11. Ökologische Verteidigungsmechaniken

Diese Mechaniken sind besonders wichtig für die Identität von Emberwild.

## 11.1 Überjagung

Übermäßige Jagd muss Auswirkungen auf die lokale Tierpopulation haben.

Zu berücksichtigen:

- Aktuelle Herbivoren-Population.
- Regionale Flora-Kapazität.
- Anzahl erlegter Tiere.
- Regenerationsrate.
- Räumliche Verteilung.
- Verfügbare Beutetiere.

## 11.2 Raubtier-Hunger

Der Hungerindex muss die tatsächliche Nahrungssituation der Raubtiere widerspiegeln.

Mögliche Folgen:

- Erhöhte Aktivität.
- Veränderte Jagdrouten.
- Annäherung an Siedlungen.
- Angriffe auf Nutztiere.
- Angriffe auf Weiden.
- Gegebenenfalls Angriffe auf Produktionsstätten.

## 11.3 Schutzmaßnahmen

### Wachhunde
- Hunde können Weiden zugeordnet werden.
- Anzahl und Eignung müssen berücksichtigt werden.
- Wachhunde können Raubtiere erkennen, alarmieren und vertreiben.

### Fallen und Schlingen
- Platzierung in geeigneten Bereichen.
- Fangwahrscheinlichkeit.
- Wartungsbedarf.
- Materialkosten.
- Mögliche Nebenwirkungen auf andere Tiere.
- Beute und Ressourcen aus erfolgreichen Fängen.

### Feuerkörbe
- Aktivierbar an Außenposten.
- Verbrauch von Holz oder Kohle.
- Abschreckungswirkung abhängig von Tierart und Situation.

Diese Mechaniken dürfen nicht unabhängig vom Animal Manager arbeiten.

---

# 12. Multiplayer- und Sicherheitsanforderungen

Emberwild ist langfristig als Multiplayer-Spiel geplant.

Die Verteidigungsverwaltung muss deshalb bereits jetzt zwischen NPC-Bedrohungen und Spielerkriegen unterscheiden.

## 12.1 NPC-Bedrohungen

- Tiere und ökologische Gefahren.
- Banditen und Plünderer.
- Aschebrut.
- KI-gesteuerte Angreifer.

Diese Bedrohungen können unabhängig vom Spielerstatus auftreten.

## 12.2 Gildenkriege

- Kämpfe zwischen Gilden und Clans.
- Territorialkonflikte.
- Belagerungen und Angriffe im Rahmen erlaubter Kriegszustände.
- Serverseitige Prüfung von Berechtigungen.

## 12.3 Schutz von Solospielern

- Solospieler erhalten besonderen Schutz.
- Verteidigungsregeln dürfen diesen Schutz nicht umgehen.
- Gilden dürfen geschützte Spieler nicht als ungeschützte Stellvertreter missbrauchen.
- Offline-Raids gegen Spielerbesitz müssen verhindert werden.
- Verteidigungs- und Angriffsbefehle müssen serverseitig validiert werden.

## 12.4 Keine Charaktertransfers zwischen Welten

Jede Emberwild-Welt besitzt ihre eigene Karte und ihre eigene Provinzstruktur.

Charaktere sollen nicht zwischen verschiedenen Welten transferiert werden können.

---

# 13. Balancing und Konfiguration

Alle relevanten Werte müssen über `src/data/settlementBalance.js` konfigurierbar sein.

Mindestens:

- Verteidigungsboni.
- Garnisonskosten.
- Ausrüstungskosten.
- Trainingskosten.
- Doktrinen-Modifikatoren.
- Aktionskosten.
- Cooldowns.
- Alarmzeiten.
- Gefahren-Schwellenwerte.
- Ökologische Grenzwerte.
- Fallen-Wahrscheinlichkeiten.
- Wachhund-Kapazitäten.
- Feuerkorb-Verbrauch.
- Krisenanforderungen.
- Reparaturkosten.
- Ressourcenlimits.

Die vorhandenen Profile `live` und `dev` müssen berücksichtigt werden.

Keine kritischen Balancing-Werte direkt in UI-Komponenten oder mehrfach in unterschiedlichen Systemen hinterlegen.

---

# 14. Technische Qualitätsanforderungen

## 14.1 Keine Mockup-Logik

Alle angezeigten Werte müssen aus tatsächlichen Core-Daten stammen.

Insbesondere:

- Keine statischen Verteidigungswerte.
- Keine erfundenen Bedrohungsprognosen.
- Keine simulierten NPC-Zuweisungen.
- Keine rein visuellen Produktions- oder Ressourcenaktionen.
- Keine Aktionen, die nur einen Status im UI ändern.

## 14.2 Datenkonsistenz

- Die UI ist keine Datenautorität.
- Der Core ist für Berechnung und Speicherung verantwortlich.
- Ressourcen dürfen nicht mehrfach verbraucht werden.
- Aktionen müssen atomar beziehungsweise gegen doppelte Ausführung abgesichert sein.
- Cooldowns müssen zentral verwaltet werden.
- Gleichzeitige Krisen benötigen eine definierte Priorisierung.
- Veraltete UI-Daten müssen aktualisiert werden.

## 14.3 Multiplayer-Sicherheit

Alle kritischen Aktionen müssen serverseitig validierbar sein.

Dazu gehören:

- Wachen zuweisen.
- Ausrüstung aufwerten.
- Ressourcen verbrauchen.
- Doktrinen ändern.
- Verteidigungsanlagen ausbauen.
- Spähtrupps entsenden.
- Reaktionsregeln ausführen.
- Krisenreaktionen auslösen.

## 14.4 Tooltips

Das vorhandene `bindCrownTooltip` aus `src/ui/settlementPanel.js` soll für alle relevanten KPIs und interaktiven Elemente verwendet werden.

Tooltips sollen erklären:

- Bedeutung eines Wertes.
- Berechnungsgrundlage.
- Auswirkungen.
- Kosten.
- Voraussetzungen.
- Einschränkungen.

## 14.5 Internationalisierung

Vollständige deutsche und englische Abdeckung.

- `src/data/locales/de.js`
- `src/data/locales/en.js`

Keine fest codierten deutschen Texte in den UI-Komponenten.

## 14.6 Barrierearme Bedienung

- Erkennbare Statusfarben zusätzlich mit Symbolen und Text.
- Klare Zustände für aktiv, inaktiv, blockiert und nicht verfügbar.
- Bedienelemente mit nachvollziehbaren Tooltips.
- Bestätigungen bei kostenintensiven Aktionen.
- Keine Aktionen ohne erkennbare Rückmeldung.

---

# 15. Implementierungsreihenfolge

Die Implementierung soll schrittweise erfolgen. Die vorhandene Spiellogik ist wichtiger als die sofortige Fertigstellung aller UI-Elemente.

## Phase 1 – Bestandsaufnahme

- Bestehende Settlement-Architektur untersuchen.
- `settlement.js` vollständig analysieren.
- `settlementCrises.js` vollständig analysieren.
- `animalManager.js` und `genetics.js` untersuchen.
- Bestehende Gebäude und tatsächliche Anzahl der verteidigungsrelevanten Betriebe ermitteln.
- Vorhandene NPC- und Inventarsysteme prüfen.
- Event-System und Persistenz prüfen.
- Bestehende Datenmodelle dokumentieren.

Keine bestehende Logik ersetzen, bevor ihre Funktion und Abhängigkeiten verstanden wurden.

## Phase 2 – Verteidigungskern

- SettlementDefenseManager integrieren.
- Gesamt-Wehrkraft und Sicherheitswert.
- Garnisonsstatus.
- Betriebs-Wehrkraft.
- Verteidigungsbereitschaft.
- Verteidigungsanlagen.
- Gemeinsames DefenseState-Modell.

## Phase 3 – Ökologische Bedrohungen

- Herbivoren-Dichte.
- Überjagung.
- Raubtier-Hungerindex.
- Tiergruppen in Siedlungsnähe.
- Angriffe auf Weiden.
- Angriffe auf Nutztiere.
- Ökologische Bedrohungsprognosen.

## Phase 4 – Garnison und Anlagen

- Wachen verwalten.
- Torin Ironmark integrieren.
- Rüstkammer.
- Doktrinen.
- Training und XP.
- Verteidigungsanlagen.
- Reparatur und Ausbau.

## Phase 5 – Reaktionssystem

- Regelmodell.
- Auslöser und Bedingungen.
- Prioritäten.
- Automatische Aktionen.
- Cooldowns.
- Manuelle Krisenreaktionen.
- Benachrichtigungen.
- Event Log.

## Phase 6 – UI-Integration

Die fünf Screenshots als Designreferenz umsetzen.

- Übersicht.
- Garnison.
- Verteidigungsanlagen.
- Bedrohungen.
- Reaktionen.

Alle Komponenten müssen auf dieselben Core-Daten zugreifen.

## Phase 7 – Tests und Balancing

Mindestens folgende Szenarien testen:

1. Normale Siedlung ohne aktive Bedrohungen.
2. Überjagung im Umland.
3. Raubtier-Hunger steigt.
4. Wolfsrudel nähert sich einer Weide.
5. Wachhunde vertreiben Raubtiere.
6. Produktionsstätte wird angegriffen.
7. Banditenkundschafter werden entdeckt.
8. Banditen greifen ein Tor an.
9. Garnison ist unzureichend besetzt.
10. Verteidigungsanlage wird beschädigt.
11. Mehrere Vorfälle treten gleichzeitig auf.
12. Ressourcen reichen nicht für eine Reaktion.
13. Eine automatische Reaktionsregel wird ausgeführt.
14. Eine Großkrise erfordert manuelles Eingreifen.

Erst wenn die zugrunde liegende Spiellogik korrekt funktioniert, sollte das zugehörige UI als fertig gelten.

---

# 16. Wichtige Prüf- und Klärungspunkte

Vor der Implementierung muss der Agent folgende Punkte anhand des tatsächlichen Quellcodes prüfen:

### A. Anzahl der verteidigungsrelevanten Betriebe

Die Spezifikation nennt neun Betriebe.

Es muss geprüft werden, welche Gebäude tatsächlich in `BUILDING_MASTER_DEFAULTS` existieren und welche davon einen eigenen Wehrwert erhalten sollen.

Die Anzahl darf nicht aus einem Screenshot übernommen werden.

### B. Garnisonskapazität

Die Beispielbilder enthalten unterschiedliche Angaben wie `3/3` und `24/24`.

Diese Werte müssen eindeutig getrennt werden:

- Anzahl der verfügbaren Garnisons-Slots.
- Tatsächlich zugewiesene Wachen.
- Maximale Garnisonskapazität.
- Aktuelle Einheitenverteilung.

### C. Vorfalls- und Krisensystem

Die vorhandenen zwölf Vorfälle und drei Großkrisen müssen vollständig analysiert werden.

Es ist zu prüfen, welche bereits tatsächliche Aktionen und Konsequenzen besitzen und welche nur Definitionen oder Auslöser darstellen.

### D. Ökologische Berechnung

Der Raubtier-Hungerindex und die Überjagung müssen auf vorhandenen Tierdaten beruhen.

Falls diese Werte noch nicht existieren, müssen sie als echte Core-Mechaniken ergänzt werden.

### E. NPC- und Ausrüstungssystem

Vor der Implementierung der Garnison muss geprüft werden, ob Wachen, Ränge, XP, Ausrüstung und Kommandantenboni bereits vollständig unterstützt werden.

Fehlende Funktionen sind im zuständigen NPC- beziehungsweise Settlement-System zu ergänzen.

---

# 17. Definition of Done

Die Verteidigungsverwaltung gilt erst dann als vollständig implementiert, wenn:

- Alle fünf Tabs vollständig funktionieren.
- Sämtliche Werte aus tatsächlichen Core-Daten stammen.
- Garnisonen tatsächlich verwaltet werden können.
- Verteidigungsanlagen tatsächliche Zustände besitzen und verändert werden können.
- Ökologische Gefahren aus dem echten Ökosystem entstehen.
- Organisierte NPC-Angriffe korrekt erkannt und verarbeitet werden.
- Betriebe und Weiden tatsächlich geschützt werden können.
- Reaktionsregeln tatsächlich ausgeführt werden.
- Automatische und manuelle Aktionen Ressourcen und Spielzustände korrekt verändern.
- Vorfälle und Ergebnisse nachvollziehbar protokolliert werden.
- Die deutsche und englische Lokalisierung vollständig ist.
- Live- und Dev-Balancingprofile funktionieren.
- Die Multiplayer-Sicherheitsanforderungen berücksichtigt werden.
- Die bestehenden Settlement- und Ökosystemsysteme nicht durch redundante Parallelimplementierungen ersetzt wurden.

---

# 18. Arbeitsanweisung an den KI-Agenten

Implementiere die Verteidigungsverwaltung für Emberwatch auf Basis dieser Spezifikation und der fünf bereitgestellten UI-Referenzbilder.

**Arbeite Core-first und nicht UI-first.**

Beginne mit einer vollständigen Analyse der bestehenden Systeme und dokumentiere:

1. Was bereits existiert.
2. Welche Funktionen bereits vollständig implementiert sind.
3. Welche Funktionen teilweise vorhanden sind.
4. Welche Funktionen vollständig fehlen.
5. Welche bestehenden Klassen und Module erweitert werden müssen.
6. Welche neuen Module tatsächlich erforderlich sind.

Erstelle daraus einen konkreten Implementierungsplan.

Danach implementiere die Verteidigungsmechaniken schrittweise.

Wichtige Regeln:

- Bestehende funktionierende Logik nicht unnötig ersetzen.
- Keine parallelen Datenmodelle für bereits vorhandene Systeme schaffen.
- Keine Mockup-Werte oder Fake-Aktionen verwenden.
- Keine nicht vorhandenen Core-Funktionen in der UI vortäuschen.
- Alle Aktionen müssen tatsächlich Auswirkungen auf die Spielsimulation haben.
- Bestehende Dokumentation und Kommentare erhalten und bei Änderungen aktualisieren.
- Neue Systeme vollständig dokumentieren.
- Fehlerbehandlung und Grenzfälle berücksichtigen.
- Nach jeder Implementierungsphase Syntax-, Integrations- und Funktionstests durchführen.

**Das Ziel ist kein hübsches Verwaltungsfenster ohne Funktion, sondern ein tatsächlich funktionierendes Verteidigungssystem, das die ökologische Simulation, NPC-KI, Siedlungswirtschaft und spätere Multiplayer-Mechaniken miteinander verbindet.**
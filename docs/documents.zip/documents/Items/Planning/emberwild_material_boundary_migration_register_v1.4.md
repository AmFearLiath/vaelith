# Emberwild – Materialabgrenzungs- und Migrationsregister

**Version:** 1.4  
**Stand:** MAT-001 bis MAT-024 bearbeitet  
**Grundlage:** `Emberwild-Items_complete_A1-A8_MAT-001-018.zip`

## Statusübersicht

- MAT-001 bis MAT-018: bereits umgesetzt und in vorherigen Registerversionen dokumentiert.
- MAT-019 bis MAT-024: Entscheidungen dieses Abschnitts; Katalogänderungen umgesetzt, soweit erforderlich.
- MAT-025: Architekturvorschlag zur kanonischen Item-Identität und Registry bleibt bestehen.

## MAT-019 – Bienenwachs, Erdwachs und Siegelwachs

**Entscheidung:** Bienenwachs bleibt A6, Erdwachs A8. Siegelwachs bleibt als aufbereitetes, beim Versiegeln verbrauchtes Produkt in D6. Keine Zusammenlegung.

## MAT-020 – Pflanzenöl, Rohöl und Waffenöl

**Entscheidung:** Pflanzenöl und Rohöl bleiben Rohstoffe in A8. Waffenöl und hochwertiges Waffenöl bleiben fertige Wartungs-Verbrauchsgüter in D5. Kein zusätzliches Zwischenprodukt ohne eigenständige Rezeptstufe.

## MAT-021 – Tierfett und Speisefett

**Entscheidung:** Tierfett bleibt Rohstoff in A6. Schmalz (`food.processed.lard`) wird als verarbeitetes Speisefett neu in C3 geführt.

## MAT-022 – Lebensfluid, Uressenz und Essenz der Lebenskraft

**Entscheidung:** Alle drei bleiben eigenständige Identitäten. Die metaphysische Beziehung bleibt eine Lore-Frage. Vaeliths Essenz bleibt vorerst als nicht handelbare Sonderressource in C6; die Katalogzuordnung ist als Ausnahme dokumentiert.

## MAT-023 – Naturbitumen und natürlicher Teer

**Entscheidung:** Beide bleiben vorerst getrennt. Naturbitumen bezeichnet eine geologische bituminöse Substanz aus ölführenden Lagerstätten; natürlicher Teer bezeichnet organische natürliche Ablagerungen. Die spätere Weltverteilung und Rezeptfunktion müssen die Trennung bestätigen.

## MAT-024 – Seil, Wurfseil und Seilmaterial

**Entscheidung:** B5 führt verarbeitete Seil- und Schnurmaterialien. Allgemeines Seil und Wurfseil werden als wiederverwendbare Ausrüstungsgegenstände von D6 nach E8 verschoben. Ihre historischen IDs bleiben aus Kompatibilitätsgründen unverändert.

## Geänderte Kataloge

| Katalog | Version | Hauptänderung |
|---|---:|---|
| A6 | 0.4 | Tierfett als Rohstoff präzisiert |
| A8 | 0.3 | Rohöle, Wachse und besondere Naturstoffe abgegrenzt |
| B5 | 0.3 | Seilmaterialien von Ausrüstung abgegrenzt |
| C3 | 0.3 | Schmalz ergänzt |
| C6 | 0.2 | Vaelith-Essenz präzisiert |
| D5 | 0.2 | Waffenöle als Pflegeverbrauchsgüter präzisiert |
| D6 | 0.3 | Siegelwachs präzisiert; Seil/Wurfseil verschoben |
| E8 | 0.3 | Seil und Wurfseil aufgenommen |

**Grundregeln:** Eine Item-ID besitzt genau eine vollständige Definition. Bestehende IDs bleiben stabil. Basiswerte und Gewichte bleiben `null`.

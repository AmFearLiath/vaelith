# Validierungsbericht MAT-019 bis MAT-024

- Aktive Kataloge: **34**
- Kanonische Item-Definitionen: **1000**
- ID-Kollisionen: **0**
- Migrationsaliase: **14**
- Neu ergänzte Items: `food.processed.lard`
- Nach E8 verschoben: `consumable.misc.rope`, `consumable.misc.grappling_rope`
- Naturbitumen und natürlicher Teer bleiben getrennt.
- Basiswert und Gewicht des neuen Items bleiben `null`.

Alle aktiven Katalogpfade, Registry-Zuordnungen und ID-Eindeutigkeiten wurden geprüft.

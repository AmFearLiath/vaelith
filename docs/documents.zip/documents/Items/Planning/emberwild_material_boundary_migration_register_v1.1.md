# Emberwild – Materialabgrenzungs- und Migrationsregister

Version: 1.1.0
Status: aktualisiert nach MAT-001 bis MAT-006

## Bearbeitete Entscheidungen

### MAT-001 – Holz und magische Holzwerkstoffe
**Status:** `resolved_catalog_changes_applied`
Erstholz (A1) -> Bearbeitetes Erstholz (B1) -> magisch stabilisiertes Urholz (B6); bestehende IDs beibehalten.

### MAT-002 – Stein und Resonanzmaterialien
**Status:** `resolved_catalog_changes_applied`
Natürlicher Resonanzstein (A2) und Bearbeiteter Resonanzstein (B2) werden über Anzeigenamen und Beschreibung unterschieden.

### MAT-003 – Metalle und Legierungen
**Status:** `resolved_catalog_changes_applied`
Zinkbarren mat.metal.zinc_ingot ergänzt; Produktionsstufe Zinkerz -> Zinkbarren -> Messingbarren festgelegt.

### MAT-004 – Metalle und Legierungen
**Status:** `resolved_catalog_changes_applied`
Dunkelstahllegierung ist metallurgisches Zwischenprodukt; Dunkelstahlbarren standardisierte Gussform; B6-Veredelung ist zusätzlicher magischer Schritt. Zusammensetzung bleibt offen.

### MAT-005 – Metalle und Legierungen
**Status:** `resolved_catalog_changes_applied`
A3-Rohstoff heißt Urmetallerz; B3-Barren bewahren natürliche Grundeigenschaften; B6 enthält gezielte magische Abstimmung/Stabilisierung.

### MAT-006 – Metalle und Halbzeuge
**Status:** `architecture_decision_defined_migration_specified`
Materialneutrale Halbzeug-Grunditems mit Materialvariante auf der Instanz. Zwei spezifische Halbzeug-IDs werden als Migrationsaliase abgebildet; Edelmetallblech bleibt bis zur Festlegung einer konkreten Metallart separat. Inventar-/Rezeptimplementierung bleibt später.

## Weiterhin offene Konflikte

- **MAT-007 – Tierische Rohstoffe und Lebensmittel** (`proposed_pending_approval`): A6-Ei als zentrale Item-ID verwenden und C1 auf dieselbe Ressource verweisen lassen. Falls C1 ein eigenständiges Lebensmittel-Objekt benötigt, sollte es eine Referenz/Verwendungsrolle statt einer zweiten Material-ID sein.
- **MAT-008 – Tierische Rohstoffe und Lebensmittel** (`proposed_pending_approval`): res.animal.milk als zentrale Item-ID verwenden. Rohmilch kann direkt getrunken werden; C1/C5 sollen keine eigenständigen Dubletten erzeugen.
- **MAT-009 – Tierische Rohstoffe und Lebensmittel** (`proposed_pending_approval`): res.animal.honey als zentrale Item-ID verwenden; C1 referenziert diese Ressource. Spezialhonige in C6 bleiben eigenständige Items, sofern ihre besonderen Eigenschaften gewollt sind.
- **MAT-010 – Pflanzliche Rohstoffe und Lebensmittel** (`proposed_pending_approval`): A4 als führende Quelle für die geerntete Pflanze verwenden. C1 soll dieselben Pflanzen als Zutaten referenzieren. Technische ID res.plant.meadow_herb und Anzeigename Wiesenkerbel auf inhaltliche Übereinstimmung prüfen.
- **MAT-011 – Lebensmittelverarbeitung** (`proposed_pending_approval`): Sortenmehle als konkrete Items behalten. Das allgemeine Mehl entweder als ausdrücklich definierte Mehlmischung spezifizieren oder als Dublette aus C3 entfernen.
- **MAT-012 – Lebensmittelverarbeitung** (`proposed_pending_approval`): Butter, Frischkäse, Rahm, Joghurt und Käse als verarbeitete Lebensmittel in C3 bündeln. C1 bleibt für unverarbeitete Rohzutaten reserviert.
- **MAT-013 – Verbrauchsgüter und Gifte** (`proposed_pending_approval`): Einfaches Gegengift zentral in D3 führen. D1 bleibt medizinischen Verbänden, Salben und Wundversorgung vorbehalten.
- **MAT-014 – Werkzeuge und Gebrauchsgegenstände** (`proposed_pending_approval`): Jeweils ein allgemeines Werkzeug behalten und in den passenden Unterkatalog verschieben oder eine klare Spezialisierung definieren. Keine zwei gleichartigen Basiswerkzeuge ohne funktionalen Unterschied.
- **MAT-015 – Werkzeuge und Gebrauchsgegenstände** (`design_decision_required`): B5-Item als hergestelltes Netzmaterial/Netzprodukt präzisieren (z. B. Netzgeflecht), E6 als fertiges, verwendbares Fischereigerät behalten.
- **MAT-016 – Verbrauchsgüter und Werkzeuge** (`proposed_pending_approval`): Feuersteinset als wiederverwendbares Werkzeug nach E8 verschieben; Feuersteinrohstoff bleibt A2. Falls das Set bei Nutzung verbraucht wird, muss diese Verbrauchsmechanik ausdrücklich beschrieben sein.
- **MAT-017 – Verbrauchsgüter und Werkzeuge** (`needs_mechanics_definition`): Bei wiederverwendbarem Filterkörper nach E8 verschieben und verbrauchbares Filtermedium separat in D6 führen. Bei Einwegfilter bleibt ein D6-Item zulässig.
- **MAT-018 – Verbrauchsgüter und Werkzeuge** (`needs_mechanics_definition`): In D6 belassen, wenn jeder Einsatz Köder verbraucht. Falls Köder mehrfach verwendet werden können, E6/E8 prüfen.
- **MAT-019 – Wachs, Harze und Naturstoffe** (`source_review_required`): Beide Rohwachse getrennt behalten. Siegelwachs als verarbeitetes Verbrauchsprodukt in D6 behalten, sofern es beim Versiegeln verbraucht wird; andernfalls B5 als Materialprodukt führen.
- **MAT-020 – Öle und geologische Kohlenwasserstoffe** (`source_review_required`): Rohstoffe in A8 belassen; Waffenöle als formulierte Wartungs-/Pflegeprodukte in D5 belassen. B5 nur ergänzen, wenn ein eigenständiges Zwischenprodukt wie raffiniertes Öl in Rezepten gebraucht wird.
- **MAT-021 – Lebensmittel und Tierrohstoffe** (`needs_definition`): Tierfett als Rohstoff belassen. Verarbeitetes Speisefett nur als eigenes C3-Item ergänzen, wenn eine echte Aufbereitung und Rezeptverwendung vorgesehen ist.
- **MAT-022 – Magische Ressourcen und Essenzen** (`needs_lore_definition`): Alle drei vorerst getrennt halten. Die Lore muss definieren, ob Uressenz ein Rohstoff, eine Quelle oder eine konzentrierte Manifestation ist und wie sie sich von Vaeliths Essenz unterscheidet.
- **MAT-023 – Gesteine und mineralische Naturstoffe** (`source_review_required`): Vorläufig getrennt lassen. Für beide müssen Fundorte, Gewinnung und unterschiedliche Verwendungen festgelegt werden; andernfalls zusammenführen.
- **MAT-024 – Werkzeuge und Gegenstände** (`design_decision_required`): B5 als hergestelltes Seilmaterial behalten; D6-Seil nur als verbrauchbares Einsatzobjekt behalten, falls es beim Einsatz verbraucht wird. Wiederverwendbares Wurfseil als E8-Gegenstand führen.
- **MAT-025 – Katalogweite Datenarchitektur** (`architecture_proposal_defined`): Eine kanonische Item-Definition pro Heimatkatalog beibehalten. Einen automatisch generierten Registry-Index unter Items/Planning/ führen, der Item-ID, Name, Heimatkatalog, Quelldatei und Katalogversion enthält. Künftige Rezepte und Produktionsdaten referenzieren Items explizit über item_id. Bestehende sources/uses bleiben bis zu einer gesonderten Migration beschreibender Freitext.

## Grundsatz MAT-006

Metallhalbzeuge werden als materialneutrale Grundformen geführt. Die Metallart liegt als `material_variant_id` auf der konkreten Item-Instanz. Unterschiedliche Materialvarianten sind nicht stapelkompatibel. Rezeptzulässigkeit, Wertbildung und konkrete Formfreigaben werden in den Produktions- und Wirtschaftssystemen definiert.

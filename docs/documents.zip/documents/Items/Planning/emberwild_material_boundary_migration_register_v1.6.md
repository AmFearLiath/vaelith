# Emberwild – Materialabgrenzungs- und Migrationsregister

**Version:** 1.6  
**Stand:** MAT-001 bis MAT-028 bearbeitet  
**Grundlage:** `Emberwild-Items_complete_A1-A8_MAT-001-028_Production-Food_Tools-E6.zip`

## Statusübersicht

- MAT-001 bis MAT-027: vorherige Entscheidungen und Umsetzungen bleiben bestehen.
- MAT-028: Set-Referenz der Fischereiausrüstung auf Fischernetz korrigiert; Schreibfehler in der Beschreibung des Wurfnetzes berichtigt.

## MAT-028 – Jagd- und Fischereigeräte

**Entscheidung:** Fangnetz bleibt das Jagdgerät `tool.hunting.hunting_net`. Fischernetz bleibt das Fischereigerät `tool.fishing.fishing_net`. Die Fischereiausrüstung referenziert künftig Fischernetz. Keine Zusammenlegung und keine neuen Item-IDs.

**Zusätzliche Korrektur:** „Fischschwärfe“ in der Beschreibung des Wurfnetzes wurde zu „Fischschwärme“ berichtigt.

**Geänderte Katalogdatei:** `Items/Tools/emberwild_items_tools_hunting_fishing_animal_v0.3.json`

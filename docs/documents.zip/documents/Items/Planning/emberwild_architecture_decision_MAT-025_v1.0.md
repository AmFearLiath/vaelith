# Emberwild – Architekturentscheidung MAT-025
## Kanonische Item-Identität und katalogübergreifende Referenzen

**Dokumentversion:** 1.0.0  
**Status:** Architekturvorschlag für die weitere Katalogmigration  
**Entscheidungsschlüssel:** MAT-025  
**Grundlage:** `Emberwild-Items_complete_A1-A8_with_Material_Register.zip`

---

## 1. Ziel

Jedes physische Item bzw. jede bewusst definierte Verarbeitungsstufe soll im Emberwild-Datensystem genau einmal vollständig definiert sein. Andere Kataloge und Systeme dürfen dieses Item verwenden, sollen aber keine zweite, konkurrierende Definition desselben Gegenstands anlegen.

Die fachliche Gliederung A–E bleibt bestehen. Es wird kein monolithischer Gesamtkatalog eingeführt.

## 2. Bestandsbefund

Die aktuelle Bestandsprüfung verwendet für A1–A8 jeweils die neueste v0.2-Datei und für B1–B6, C1–C6, D1–D6 sowie E1–E8 die vorhandenen v0.1-Dateien.

- 34 aktive Katalogdateien
- 1.009 Item-Definitionen
- 1.009 unterschiedliche Item-IDs
- 0 ID-Kollisionen innerhalb dieser aktiven Auswahl
- 3 unterschiedliche Grundstrukturen der Katalogmetadaten

Wichtig: Das Gesamtarchiv enthält zusätzlich ältere v0.1-Stände der bereits aktualisierten A-Kataloge. Dieselbe ID in einer alten und einer neueren Version desselben Katalogs ist eine Versionswiederholung und keine katalogübergreifende ID-Kollision.

Die vorhandenen `sources`- und `uses`-Felder enthalten überwiegend beschreibende Texte. Sie sind derzeit keine verlässlichen maschinenlesbaren Item-Referenzen.

## 3. Architektur

### 3.1 Kanonische Item-Definition

Jedes Item besitzt genau eine vollständige Definition in genau einem Heimatkatalog.

Die bestehende `id` bleibt der globale, stabile Schlüssel. Die vorhandenen ID-Präfixe wie `res.`, `mat.`, `food.`, `consumable.` und `tool.` werden zunächst beibehalten.

Die vollständige Item-Definition bleibt in ihrer Katalogdatei. Der Heimatkatalog bestimmt, welcher Datensatz die maßgebliche Quelle ist.

### 3.2 Zentraler Item-Index

Datei: `Items/Planning/emberwild_item_registry_v1.0.json`

Der Index wird aus den aktiven Katalogen generiert. Er enthält nur die zur Auffindbarkeit nötigen Angaben:

- kanonische Item-ID
- Anzeigename
- Heimatkatalog
- Quelldatei
- Katalogversion
- Kennzeichnung `canonical`

Der Index enthält bewusst keine zweite vollständige Kopie von Beschreibung, Seltenheit, Qualität, Wert, Gewicht, Quellen oder Verwendungszwecken.

Der Index ist ein abgeleitetes Artefakt: Änderungen an Item-Definitionen werden zuerst im Heimatkatalog vorgenommen; anschließend wird der Index neu erzeugt. Er wird nicht unabhängig von den Katalogen bearbeitet.

### 3.3 Katalogübergreifende Verwendung

Ein anderes System verwendet die kanonische Item-ID. Es kopiert nicht den vollständigen Item-Datensatz.

Für künftige Rezept- und Produktionsdaten wird folgende Referenzform empfohlen:

```json
{
  "item_id": "res.animal.milk",
  "role": "input",
  "quantity": 2
}
```

`item_id` verweist auf die kanonische Definition. `role` und `quantity` beschreiben die Verwendung im jeweiligen Rezept und gehören nicht in die Item-Stammdaten.

Für Ausgaben kann entsprechend `role: "output"` verwendet werden. Weitere Felder wie Verlust, Nebenprodukt, Qualitätsergebnis oder alternative Inputs gehören in das jeweilige Produktionsschema.

Die bestehenden `sources`- und `uses`-Felder bleiben bis zu einer gesonderten Migration beschreibende Felder. Sie werden nicht automatisch in Referenzen umgedeutet.

### 3.4 Alias- und Migrationsregeln

Wenn zwei bestehende Items als dasselbe physische Item zusammengeführt werden:

1. Eine kanonische ID wird als Ziel festgelegt.
2. Die ersetzte ID wird im Migrationsregister als stillzulegender Altbezeichner dokumentiert.
3. Alle maschinenlesbaren Verwendungen werden auf die kanonische ID umgestellt.
4. Bestehende Spielstände oder externe Daten können über eine Alias-/Migrationstabelle aufgelöst werden.
5. Die alte ID wird nicht für einen anderen Gegenstand wiederverwendet.

Eine Alias-Tabelle ist nur erforderlich, wenn bereits gespeicherte Daten oder externe Systeme die alte ID verwenden. Für reine Entwurfsdaten genügt zunächst die dokumentierte Migration.

## 4. Heimatkatalog bestimmen

Der Heimatkatalog richtet sich nach der eigenständigen Identität und dem Zustand des Items:

- A: natürliche Ressource bzw. gewonnener Rohstoff in natürlicher Grundform
- B: mechanisch, thermisch, chemisch oder magisch verarbeitetes Material
- C: Lebensmittel oder Getränk mit eigener Lebensmittel- bzw. Verarbeitungsidentität
- D: einsatzfertiger Gegenstand, dessen Verwendung ihn verbraucht oder aufbraucht
- E: wiederverwendbares Werkzeug oder Gebrauchsobjekt

Ein Item gehört nicht allein deshalb in einen anderen Katalog, weil es dort verwendet wird. Rohmilch bleibt beispielsweise ein tierischer Rohstoff, auch wenn sie in einem Rezept als Lebensmittelzutat dient.

Ein verarbeitetes Produkt erhält nur dann eine eigene Item-ID, wenn es eine eigenständige Verarbeitungsstufe, Funktion, Haltbarkeit, Verwendung oder Handelsidentität besitzt.

## 5. Konsequenzen für die bestehenden JSON-Schemata

Die Kataloge verwenden derzeit unterschiedliche Metadatenstrukturen. Diese Unterschiede sollen nicht im Rahmen von MAT-025 durch eine große Schema-Umschreibung beseitigt werden.

Stattdessen:

- Bestehende Katalogdateien und Item-Felder bleiben zunächst unverändert.
- Der Registry-Generator liest die vorhandenen Varianten.
- Neue Rezept-/Produktionsdaten verwenden explizite `item_id`-Referenzen.
- Eine spätere Vereinheitlichung der Katalogschemas wird als eigener Arbeitsschritt geplant.
- `sources` und `uses` bleiben bis dahin lesbare Beschreibungsfelder.

## 6. Validierungsregeln

Bei jeder zukünftigen Katalogfreigabe sollen mindestens folgende Prüfungen laufen:

1. Jede aktive Item-ID ist global eindeutig.
2. Jedes Item hat genau einen Heimatkatalog.
3. Jeder Registry-Eintrag verweist auf eine vorhandene Quelldatei und eine dort vorhandene Item-ID.
4. Jede explizite `item_id`-Referenz zeigt auf ein existierendes kanonisches Item.
5. Keine Referenz zeigt auf eine stillgelegte ID, sofern sie nicht ausdrücklich als Alias aufgelöst wird.
6. Versionsarchive werden bei der globalen Eindeutigkeitsprüfung nicht mit aktiven Katalogständen vermischt.
7. Der generierte Registry-Index stimmt mit den aktiven Quelldateien überein.

## 7. Nicht Bestandteil dieser Entscheidung

MAT-025 entscheidet ausdrücklich noch nicht:

- welche der semantischen Dubletten aus MAT-001 bis MAT-024 zusammengeführt werden
- welche konkreten Item-IDs bei einer Zusammenführung erhalten bleiben
- wie Rezepte, Produktionsketten oder Marktplatztransaktionen im Detail modelliert werden
- wie gespeicherte Multiplayer-Spielstände migriert werden
- ob später alle Kataloge auf ein einheitliches JSON-Schema umgestellt werden

Diese Punkte werden in den jeweiligen Einzelentscheidungen behandelt.

## 8. Empfehlung

Die Architektur wird als Grundlage für die nächste Migrationsphase empfohlen:

**Ein Item – eine kanonische ID – ein Heimatkatalog – beliebig viele explizite Verwendungen.**

Der Registry-Index wird automatisch aus den aktiven Katalogen erzeugt. Die Kataloge bleiben die maßgebliche Datenquelle.

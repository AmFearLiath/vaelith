# Architekturentscheidung MAT-001 bis MAT-006 – Materialien und Werkstoffidentität

Version: 1.0.0  
Status: Beschlossene Katalog- und Architekturentscheidungen  
Grundlage: Emberwild-Items_complete_A1-A8_MAT-025.zip

## MAT-001 – Erstholz und Urholz

Die Materialkette wird in drei klar getrennte Stufen gegliedert:

1. A1 `res.wood.firstwood` – **Erstholz**, natürlicher Rohstoff.
2. B1 `mat.wood.primordial_timber` – **Bearbeitetes Erstholz**, mechanisch verarbeitetes Zwischenprodukt.
3. B6 `mat.enchanted.primordial_wood` – **Urholz**, durch eine eigenständige magische Behandlung stabilisiertes Endmaterial.

Die bestehenden IDs bleiben erhalten. Die genaue magische Wirkung und Herstellung des B6-Materials bleiben offen.

## MAT-002 – Resonanzstein

A2 `res.stone.resonance` bleibt **Resonanzstein** als natürliches, geflechtreaktives Gestein. B2 `mat.stone.resonance_stone` wird **Bearbeiteter Resonanzstein** genannt und beschreibt die mechanische Vorbereitung. Eine zusätzliche magische Abstimmung ist nicht Teil dieser B2-Stufe. Der B6-Resonanzkristall bleibt ein eigenständiger magisch bearbeiteter Werkstoff.

## MAT-003 – Zinkbarren

B3 erhält `mat.metal.zinc_ingot` – **Zinkbarren**. Die festgelegte Materialfolge lautet:

`res.ore.zinc` (A3 Zinkerz) → `mat.metal.zinc_ingot` (B3 Zinkbarren) → `mat.metal.brass_ingot` (B3 Messingbarren).

Die konkreten Mengen, Schmelzparameter, Verluste und alternativen Herstellungsverfahren werden im Produktionssystem festgelegt.

## MAT-004 – Dunkelstahl

Die Produktionsstufen werden wie folgt abgegrenzt:

- A3 Dunkelstahlerz: natürlicher Rohstoff.
- B3 Dunkelstahllegierung: metallurgisches Zwischenprodukt/Schmelze.
- B3 Dunkelstahlbarren: standardisierte Gussform und reguläres Metallhalbzeug.
- B6 Veredelter Dunkelstahl: zusätzlicher magischer Stabilisierungsschritt.

Die konkrete Legierungszusammensetzung und Rezeptur bleiben offen, bis Lore und Produktionsdesign feststehen.

## MAT-005 – Resonanzmetall, Herzmetall und Urmetall

A3 enthält die natürlichen Rohstoffe. Das Item `res.ore.primordial_metal` wird in **Urmetallerz** umbenannt; seine ID bleibt stabil. B3 enthält die gewonnenen Metalle als Barren mit ihren natürlichen Grundeigenschaften. B6 enthält ausschließlich gezielt magisch abgestimmte oder stabilisierte Varianten.

- Resonanzmetallbarren: natürliche Materialstruktur und gegebenenfalls natürliche Resonanz, keine gezielte Geflechtabstimmung.
- Herzmetallbarren: natürliche innere Stabilität, keine bereits erfolgte magische Verstärkung.
- Urmetallbarren: ursprüngliche natürliche Struktur, keine bereits erfolgte magische Stabilisierung.

Die B6-Stufen beschreiben jeweils die zusätzliche kontrollierte magische Behandlung. Herzmetall bleibt vom Herzstein aus A2 getrennt. Konkrete Effekte und Herstellungsverfahren bleiben offen.

## MAT-006 – Materialvarianten für Metallhalbzeuge

**Beschlossene Architektur:** materialneutrale Grundform plus Materialvariante auf der konkreten Item-Instanz. Es werden keine eigenen kanonischen Item-Definitionen für jede Kombination aus Halbzeugform und Metallart angelegt.

Beispiel:

- Grundform: `mat.metal.metal_plate`
- Materialvariante: `metal.darksteel`
- Darstellung: Dunkelstahlplatte

Die Variante wird über `material_variant_id` gespeichert. Die Materialvariante verweist auf das zugrunde liegende Metallitem, beispielsweise `mat.metal.darksteel_ingot`.

### Verbindliche Regeln

- Die kanonische Item-ID bezeichnet die Halbzeugform.
- Die konkrete Materialart wird als Instanzmerkmal gespeichert.
- Unterschiedliche Materialvarianten sind nicht stapelkompatibel.
- Rezepte können konkrete Varianten verlangen oder eine explizit definierte Variantenmenge akzeptieren.
- Handel und Wertberechnung berücksichtigen Grundform und Materialvariante.
- Nicht jede Materialvariante ist automatisch für jede Form zugelassen. Die Freigabe wird über Produktionsdefinitionen festgelegt.
- Materialvarianten werden nicht als separate kanonische Items in der Item-Registry geführt.

### Migration bestehender IDs

Die bisherigen spezifischen Halbzeug-IDs werden bei der Migration alter Bestände auf Grundform plus Materialvariante überführt:

| Alte ID | Neue Grundform | Materialvariante |
|---|---|---|
| `mat.metal.darksteel_plate` | `mat.metal.metal_plate` | `metal.darksteel` |
| `mat.metal.resonance_metal_plate` | `mat.metal.metal_plate` | `metal.resonance_metal` |

Die beiden alten Platten-IDs bleiben als dauerhafte Migrationsaliase auflösbar und werden nicht für neue Item-Definitionen wiederverwendet. `mat.metal.precious_metal_sheet` bleibt vorerst als bestehender Sonderfall erhalten, weil „Edelmetall“ keine konkrete Metallart festlegt; eine eindeutige Zuordnung zu Silber oder Gold wäre derzeit nicht belegt. `mat.metal.heart_metal_fittings` bleibt ein eigenständiges Item, da es eine spezifische Bauteilform und Funktion bezeichnet. `mat.metal.precious_metal_sheet` bleibt vorerst bestehen, weil die Bezeichnung keine konkrete Metallart (z. B. Silber oder Gold) festlegt und deshalb noch keiner eindeutigen Materialvariante zugeordnet werden kann.

### Umfang und Abgrenzung

Diese Entscheidung definiert das Datenmodell, führt aber noch keine Änderungen an Inventar-, Rezept-, Handels- oder Produktionsimplementierungen durch. Die konkrete technische Integration erfolgt in den jeweiligen Systemabschnitten. Basiswerte und Gewichte bleiben `null`; Balancing und Materialpreise werden nicht vorweggenommen.

## Versions- und Identitätsregeln

Bestehende kanonische IDs bleiben stabil. Umbenennungen ändern keine ID. Neue Items erhalten neue IDs. Die drei migrierten Halbzeug-IDs werden als Alias-Zuordnungen dokumentiert. Die zentrale Registry wird aus den aktiven Katalogdefinitionen neu generiert.

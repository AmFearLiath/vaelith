# Emberwild – Materialabgrenzungs- und Migrationsregister v1.2

- Version: 1.2.0
- Status: updated_after_mat_001_012
- Quelle: `Emberwild-Items_complete_A1-A8_MAT-001-012.zip`

## Grundregeln

- Ein physischer Gegenstand bzw. eine definierte Materialstufe soll nur eine kanonische Item-ID besitzen.
- Andere Kataloge dürfen kanonische Items referenzieren, ohne identische Items neu anzulegen.
- Rohstoff, Zwischenprodukt, Werkstoff, Verbrauchsgegenstand und Werkzeug sind getrennte Rollen.
- Eine neue Item-ID ist nur gerechtfertigt, wenn eine eigenständige Verarbeitungsstufe, Funktion oder Spielmechanik existiert.
- Keine Katalogänderung gilt als beschlossen, solange sie in diesem Register nur als Vorschlag geführt wird.

## MAT-001 – Holz und magische Holzwerkstoffe

- Priorität: high
- Status: `resolved_catalog_changes_applied`

**Befund:** Zwei unterschiedliche Items heißen Urholz. Das B1-Item ist bereits als verarbeitetes Holzmaterial beschrieben; das B6-Item als seltenes Holz aus ursprünglichen Geflechtstrukturen. A1 führt zusätzlich Erstholz als natürlichen Rohstoff.

**Ursprünglicher Vorschlag:** Eine dreistufige Kette prüfen: A1 Erstholz als Rohstoff; B1 bearbeitetes Erstholz als mechanisch verarbeitetes Material; B6 Urholz nur dann als eigene Stufe behalten, wenn eine eigenständige magische Behandlung mit zusätzlicher Funktion festgelegt wird.

**Entscheidung:** Erstholz (A1) -> Bearbeitetes Erstholz (B1) -> magisch stabilisiertes Urholz (B6); bestehende IDs beibehalten.

**Anmerkungen:** Vorgeschlagene Namen und Stufen sind noch nicht beschlossen. Entscheidung bestätigt und in Katalogen/Architekturdokumentation umgesetzt.

**Betroffene Items:**

- `res.wood.firstwood` – Erstholz (natürlicher Rohstoff) – `Items/Resources/emberwild_items_resources_wood_v0.2.json`
- `mat.wood.primordial_timber` – Urholz (verarbeitetes Holzmaterial) – `Items/Processed/emberwild_items_processed_wood_v0.2.json`
- `mat.enchanted.primordial_wood` – Urholz (magisches Holzmaterial) – `Items/Processed/emberwild_items_processed_enchanted_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "rename",
    "id": "mat.wood.primordial_timber",
    "suggested_name": "Bearbeitetes Erstholz"
  },
  {
    "type": "retain_or_redefine",
    "id": "mat.enchanted.primordial_wood",
    "condition": "B6-Item nur behalten, wenn es gegenüber B1 einen konkreten magischen Mehrwert besitzt"
  }
]
```

- Änderungen angewendet: Ja

## MAT-002 – Stein und Resonanzmaterialien

- Priorität: high
- Status: `resolved_catalog_changes_applied`

**Befund:** Gleicher Anzeigename, aber die Beschreibungen unterscheiden natürlichen Resonanzrohstoff und speziell bearbeiteten Stein.

**Ursprünglicher Vorschlag:** A2 als Resonanzstein belassen; B2 in Bearbeiteter Resonanzstein umbenennen und die konkrete Bearbeitungsstufe bzw. den Zweck in der Beschreibung festhalten.

**Entscheidung:** Natürlicher Resonanzstein (A2) und Bearbeiteter Resonanzstein (B2) werden über Anzeigenamen und Beschreibung unterschieden.

**Anmerkungen:** Keine automatische Gleichsetzung mit B6-Resonanzkristall. Entscheidung bestätigt und in Katalogen/Architekturdokumentation umgesetzt.

**Betroffene Items:**

- `res.stone.resonance` – Resonanzstein (natürliches Gestein) – `Items/Resources/emberwild_items_resources_stone_v0.2.json`
- `mat.stone.resonance_stone` – Resonanzstein (bearbeitetes Gestein) – `Items/Processed/emberwild_items_processed_stone_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "rename",
    "id": "mat.stone.resonance_stone",
    "suggested_name": "Bearbeiteter Resonanzstein"
  }
]
```

- Änderungen angewendet: Ja

## MAT-003 – Metalle und Legierungen

- Priorität: high
- Status: `resolved_catalog_changes_applied`

**Befund:** A3 enthält Zinkerz und B3 beschreibt Messing ausdrücklich als Kupfer-Zink-Legierung. Ein Zinkbarren ist im B3-Katalog nicht vorhanden.

**Ursprünglicher Vorschlag:** Zinkbarren als Zwischenprodukt ergänzen, sofern Messing in einer mehrstufigen Produktionskette hergestellt wird. Alternativ kann die Schmelze Zinkerz direkt verarbeiten; dann muss dies ausdrücklich im Rezeptmodell stehen.

**Entscheidung:** Zinkbarren mat.metal.zinc_ingot ergänzt; Produktionsstufe Zinkerz -> Zinkbarren -> Messingbarren festgelegt.

**Anmerkungen:** Noch keine Rezeptentscheidung; keine Änderung am Katalog vorgenommen. Entscheidung bestätigt und in Katalogen/Architekturdokumentation umgesetzt.

**Betroffene Items:**

- `res.ore.zinc` – Zinkerz (Erz) – `Items/Resources/emberwild_items_resources_ores_v0.3.json`
- `mat.metal.brass_ingot` – Messingbarren (Kupfer-Zink-Legierung) – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.metal.zinc_ingot` – Zinkbarren (gewonnenes Metall / Zwischenprodukt) – `Items/Processed/emberwild_items_processed_metals_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "add_candidate",
    "suggested_id": "mat.metal.zinc_ingot",
    "suggested_name": "Zinkbarren",
    "target_file": "Items/Processed/emberwild_items_processed_metals_v0.1.json"
  }
]
```

- Änderungen angewendet: Ja

## MAT-004 – Metalle und Legierungen

- Priorität: high
- Status: `resolved_catalog_changes_applied`

**Befund:** B3 beschreibt Dunkelstahllegierung als noch nicht abschließend definierte Legierung aus Unterweltmetallen und Dunkelstahlbarren als widerstandsfähige Legierung. B6 führt zusätzlich veredelten Dunkelstahl.

**Ursprünglicher Vorschlag:** Legierung als Zwischenprodukt, Barren als standardisierte Gussform und B6 als zusätzliche magische Stabilisierung definieren. Zusammensetzung und Rezeptbestandteile offenlassen, bis Lore und Produktionsdesign feststehen.

**Entscheidung:** Dunkelstahllegierung ist metallurgisches Zwischenprodukt; Dunkelstahlbarren standardisierte Gussform; B6-Veredelung ist zusätzlicher magischer Schritt. Zusammensetzung bleibt offen.

**Anmerkungen:** Entscheidung bestätigt und in Katalogen/Architekturdokumentation umgesetzt.

**Betroffene Items:**

- `res.ore.darksteel` – Dunkelstahlerz () – `Items/Resources/emberwild_items_resources_ores_v0.3.json`
- `mat.metal.darksteel_ore_alloy` – Dunkelstahllegierung () – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.metal.darksteel_ingot` – Dunkelstahlbarren () – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.enchanted.darksteel` – Veredelter Dunkelstahl () – `Items/Processed/emberwild_items_processed_enchanted_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "clarify_stage",
    "id": "mat.metal.darksteel_ore_alloy"
  },
  {
    "type": "retain_stage",
    "id": "mat.metal.darksteel_ingot"
  },
  {
    "type": "clarify_magical_stage",
    "id": "mat.enchanted.darksteel"
  }
]
```

- Änderungen angewendet: Ja

## MAT-005 – Metalle und Legierungen

- Priorität: high
- Status: `resolved_catalog_changes_applied`

**Befund:** B3 und B6 enthalten dieselben Materialnamen in unterschiedlichen IDs. B3-Beschreibungen enthalten bereits Eigenschaften wie Resonanzweiterleitung bzw. Lebensresonanz; B6 beschreibt gezielte magische Verfahren.

**Ursprünglicher Vorschlag:** B3 als gewonnenes Metall mit natürlichen Grundmerkmalen definieren. B6 nur für gezielt veränderte, kontrollierte oder stabilisierte magische Eigenschaften verwenden. B3-Beschreibungen und B6-Beschreibungen auf diese Grenze abstimmen.

**Entscheidung:** A3-Rohstoff heißt Urmetallerz; B3-Barren bewahren natürliche Grundeigenschaften; B6 enthält gezielte magische Abstimmung/Stabilisierung.

**Anmerkungen:** Beim Urmetall ist A3 bereits das Erz-/Rohstoffitem mit Anzeigename Urmetall; prüfen, ob der Name besser auf Urmetallerz geändert werden soll. Entscheidung bestätigt und in Katalogen/Architekturdokumentation umgesetzt.

**Betroffene Items:**

- `res.ore.resonance_metal` – Resonanzmetallerz () – `Items/Resources/emberwild_items_resources_ores_v0.3.json`
- `res.ore.heart_metal` – Herzmetallerz () – `Items/Resources/emberwild_items_resources_ores_v0.3.json`
- `res.ore.primordial_metal` – Urmetallerz () – `Items/Resources/emberwild_items_resources_ores_v0.3.json`
- `mat.metal.resonance_metal_ingot` – Resonanzmetallbarren () – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.metal.heart_metal_ingot` – Herzmetallbarren () – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.metal.primordial_metal_ingot` – Urmetallbarren () – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.enchanted.resonance_metal` – Resonanzmetall () – `Items/Processed/emberwild_items_processed_enchanted_v0.2.json`
- `mat.enchanted.heart_metal` – Herzmetall () – `Items/Processed/emberwild_items_processed_enchanted_v0.2.json`
- `mat.enchanted.primordial_metal` – Urmetall () – `Items/Processed/emberwild_items_processed_enchanted_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "clarify_description",
    "target": "B3 resonance/heart/primordial metal ingots"
  },
  {
    "type": "clarify_description",
    "target": "B6 resonance/heart/primordial metal"
  }
]
```

- Änderungen angewendet: Ja

## MAT-006 – Metalle und Halbzeuge

- Priorität: medium
- Status: `architecture_decision_defined_migration_specified`

**Befund:** B3 enthält allgemeine Halbzeuge ohne explizite Materialvariante. Gleichzeitig existieren spezifische Varianten wie Dunkelstahlplatte und Resonanzmetallplatte.

**Ursprünglicher Vorschlag:** Entscheiden, ob Halbzeuge materialneutral mit Materialeigenschaft/Variantendaten geführt werden oder ob je Metallart eigene Items entstehen. Die Entscheidung muss Inventar, Rezepte, Handel und Preisbildung berücksichtigen.

**Entscheidung:** Materialneutrale Halbzeug-Grunditems mit Materialvariante auf der Instanz. Zwei spezifische Halbzeug-IDs werden als Migrationsaliase abgebildet; Edelmetallblech bleibt bis zur Festlegung einer konkreten Metallart separat. Inventar-/Rezeptimplementierung bleibt später.

**Anmerkungen:** Entscheidung bestätigt und in Katalogen/Architekturdokumentation umgesetzt. Edelmetallblech bleibt vorerst separat, da die Bezeichnung keine konkrete Metallart festlegt.

**Betroffene Items:**

- `mat.metal.metal_plate` – Metallplatte () – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.metal.metal_sheet` – Metallblech () – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.metal.metal_rod` – Metallstange () – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.metal.metal_bar` – Metallprofil () – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.metal.metal_wire` – Metalldraht () – `Items/Processed/emberwild_items_processed_metals_v0.2.json`
- `mat.metal.darksteel_plate` – Dunkelstahlplatte (bisheriges materialspezifisches Halbzeug) – `Items/Processed/emberwild_items_processed_metals_v0.1.json`
- `mat.metal.resonance_metal_plate` – Resonanzmetallplatte (bisheriges materialspezifisches Halbzeug) – `Items/Processed/emberwild_items_processed_metals_v0.1.json`
- `mat.metal.precious_metal_sheet` – Edelmetallblech (Sonderfall ohne konkrete Metallart) – `Items/Processed/emberwild_items_processed_metals_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "system_design_decision",
    "topic": "material_variant_model"
  }
]
```

- Änderungen angewendet: Ja

## MAT-007 – Tierische Rohstoffe und Lebensmittel

- Priorität: high
- Status: `resolved_catalog_changes_applied`

**Befund:** A6 und C1 beschreiben dasselbe frische Speiseei. Die Katalogdefinition von A6 verweist Lebensmittel nach Bereich C; daher wird C1 als Heimatkatalog verwendet.

**Ursprünglicher Vorschlag:** A6-Ei als zentrale Item-ID verwenden und C1 auf dieselbe Ressource verweisen lassen. Falls C1 ein eigenständiges Lebensmittel-Objekt benötigt, sollte es eine Referenz/Verwendungsrolle statt einer zweiten Material-ID sein.

**Entscheidung:** C1 food.ingredient.egg ist die kanonische Definition des Speiseeis. Die doppelte A6-ID res.animal.egg wird als Alias aufgelöst; Zuchteier bleiben bei Bedarf ein später gesondert zu definierender Gegenstand oder Zustand.

**Anmerkungen:** Die Katalogbeschreibung von A6 ordnet Lebensmittel ausdrücklich Bereich C zu. Die C1-Definition wird inhaltlich präzisiert; A6-Dublette entfernt.

**Betroffene Items:**

- `res.animal.egg` – Ei (entfernte Dublette / Migrationsalias) – `Items/Resources/emberwild_items_resources_animal_v0.3.json`
- `food.ingredient.egg` – Ei (kanonischer Lebensmittelrohstoff) – `Items/Food/emberwild_items_food_raw_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "retain_canonical",
    "id": "food.ingredient.egg",
    "file": "Items/Food/emberwild_items_food_raw_v0.2.json"
  },
  {
    "type": "remove_duplicate",
    "id": "res.animal.egg",
    "alias_target": "food.ingredient.egg",
    "file": "Items/Resources/emberwild_items_resources_animal_v0.3.json"
  }
]
```

- Änderungen angewendet: Ja

## MAT-008 – Tierische Rohstoffe und Lebensmittel

- Priorität: high
- Status: `resolved_catalog_changes_applied`

**Befund:** A6, C1 und C5 führen dieselbe frisch gewonnene Milch. C1 ist Heimatkatalog; C5 bleibt für eigenständige Milchgetränke reserviert.

**Ursprünglicher Vorschlag:** res.animal.milk als zentrale Item-ID verwenden. Rohmilch kann direkt getrunken werden; C1/C5 sollen keine eigenständigen Dubletten erzeugen.

**Entscheidung:** C1 food.ingredient.milk ist die kanonische Definition der frisch gewonnenen Milch. res.animal.milk und food.drink.milk werden als Aliase auf diese ID aufgelöst. Die Milch kann direkt getrunken oder als Zutat verwendet werden.

**Anmerkungen:** Frische Milch ist eine einzige unverarbeitete Lebensmittelidentität. C5 enthält nur eigenständige zubereitete bzw. entstandene Milchgetränke wie Buttermilch, Honigmilch und Molke.

**Betroffene Items:**

- `res.animal.milk` – Rohmilch (entfernte Dublette / Migrationsalias) – `Items/Resources/emberwild_items_resources_animal_v0.3.json`
- `food.ingredient.milk` – Frische Milch (kanonischer Lebensmittelrohstoff und direkt trinkbares Lebensmittel) – `Items/Food/emberwild_items_food_raw_v0.2.json`
- `food.drink.milk` – Frische Milch (entfernte Dublette / Migrationsalias) – `Items/Food/emberwild_items_food_drinks_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "retain_canonical",
    "id": "food.ingredient.milk",
    "file": "Items/Food/emberwild_items_food_raw_v0.2.json"
  },
  {
    "type": "remove_duplicate",
    "id": "res.animal.milk",
    "alias_target": "food.ingredient.milk",
    "file": "Items/Resources/emberwild_items_resources_animal_v0.3.json"
  },
  {
    "type": "remove_duplicate",
    "id": "food.drink.milk",
    "alias_target": "food.ingredient.milk",
    "file": "Items/Food/emberwild_items_food_drinks_v0.2.json"
  }
]
```

- Änderungen angewendet: Ja

## MAT-009 – Tierische Rohstoffe und Lebensmittel

- Priorität: high
- Status: `resolved_catalog_changes_applied`

**Befund:** A6 und C1 beschreiben denselben geernteten Honig. C1 ist Heimatkatalog; die Honigwabe ist wegen ihrer Waben- und Wachsstruktur nicht identisch mit losem Honig.

**Ursprünglicher Vorschlag:** res.animal.honey als zentrale Item-ID verwenden; C1 referenziert diese Ressource. Spezialhonige in C6 bleiben eigenständige Items, sofern ihre besonderen Eigenschaften gewollt sind.

**Entscheidung:** C1 food.ingredient.honey ist die kanonische Definition des geernteten Honigs. res.animal.honey wird als Alias auf diese ID aufgelöst. Die Honigwabe bleibt als eigenständiger Gegenstand in C3 bestehen.

**Anmerkungen:** Honig ist ein unmittelbar verwendbarer Lebensmittelrohstoff. Die A6-Dublette wird entfernt; Honigwabe ist wegen des zusätzlichen Wachsanteils eine eigenständige Form.

**Betroffene Items:**

- `res.animal.honey` – Honig (entfernte Dublette / Migrationsalias) – `Items/Resources/emberwild_items_resources_animal_v0.3.json`
- `food.ingredient.honey` – Honig (kanonischer Lebensmittelrohstoff) – `Items/Food/emberwild_items_food_raw_v0.2.json`
- `food.processed.honeycomb` – Honigwabe (eigenständiges Lebensmittel mit Wachsanteil) – `Items/Food/emberwild_items_food_processed_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "retain_canonical",
    "id": "food.ingredient.honey",
    "file": "Items/Food/emberwild_items_food_raw_v0.2.json"
  },
  {
    "type": "remove_duplicate",
    "id": "res.animal.honey",
    "alias_target": "food.ingredient.honey",
    "file": "Items/Resources/emberwild_items_resources_animal_v0.3.json"
  },
  {
    "type": "retain_distinct_item",
    "id": "food.processed.honeycomb",
    "file": "Items/Food/emberwild_items_food_processed_v0.1.json"
  }
]
```

- Änderungen angewendet: Ja

## MAT-010 – Pflanzliche Rohstoffe und Lebensmittel

- Priorität: medium
- Status: `resolved_catalog_changes_applied`

**Befund:** A4 enthält bereits drei der fünf in C1 erneut geführten Kräuter. Petersilie und Thymian fehlten in A4 und wurden dort als natürliche Pflanzenressourcen ergänzt.

**Ursprünglicher Vorschlag:** A4 als führende Quelle für die geerntete Pflanze verwenden. C1 soll dieselben Pflanzen als Zutaten referenzieren. Technische ID res.plant.meadow_herb und Anzeigename Wiesenkerbel auf inhaltliche Übereinstimmung prüfen.

**Entscheidung:** A4 ist der Heimatkatalog geernteter botanischer Kräuter. Die fünf C1-Dubletten werden auf A4-IDs migriert. Für Petersilie und Thymian werden die fehlenden A4-Definitionen ergänzt.

**Anmerkungen:** Die bestehende A4-ID res.plant.meadow_herb bleibt für Wiesenkerbel kanonisch; food.herb.wild_chervil wird als Alias darauf abgebildet. Alle Kräuter bleiben als Lebensmittelzutaten verwendbar, ohne parallele Inventar-IDs.

**Betroffene Items:**

- `res.plant.meadow_herb` – Wiesenkerbel (kanonische Pflanzendefinition) – `Items/Resources/emberwild_items_resources_plants_v0.3.json`
- `res.plant.wild_mint` – Waldminze (kanonische Pflanzendefinition) – `Items/Resources/emberwild_items_resources_plants_v0.3.json`
- `res.plant.wild_garlic` – Wilder Knoblauch (kanonische Pflanzendefinition) – `Items/Resources/emberwild_items_resources_plants_v0.3.json`
- `res.plant.parsley` – Petersilie (neu ergänzte kanonische Pflanzendefinition) – `Items/Resources/emberwild_items_resources_plants_v0.3.json`
- `res.plant.thyme` – Thymian (neu ergänzte kanonische Pflanzendefinition) – `Items/Resources/emberwild_items_resources_plants_v0.3.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "retain_canonical",
    "ids": [
      "res.plant.meadow_herb",
      "res.plant.wild_mint",
      "res.plant.wild_garlic"
    ],
    "file": "Items/Resources/emberwild_items_resources_plants_v0.3.json"
  },
  {
    "type": "add",
    "ids": [
      "res.plant.parsley",
      "res.plant.thyme"
    ],
    "file": "Items/Resources/emberwild_items_resources_plants_v0.3.json"
  },
  {
    "type": "remove_duplicate",
    "aliases": [
      {
        "legacy_id": "food.herb.parsley",
        "target_item_id": "res.plant.parsley"
      },
      {
        "legacy_id": "food.herb.thyme",
        "target_item_id": "res.plant.thyme"
      },
      {
        "legacy_id": "food.herb.wild_mint",
        "target_item_id": "res.plant.wild_mint"
      },
      {
        "legacy_id": "food.herb.wild_chervil",
        "target_item_id": "res.plant.meadow_herb"
      },
      {
        "legacy_id": "food.herb.wild_garlic",
        "target_item_id": "res.plant.wild_garlic"
      }
    ],
    "file": "Items/Food/emberwild_items_food_raw_v0.2.json"
  }
]
```

- Änderungen angewendet: Ja

## MAT-011 – Lebensmittelverarbeitung

- Priorität: medium
- Status: `resolved_catalog_changes_applied`

**Befund:** C3 erklärt ausdrücklich, dass das generische Mehl kein zusätzliches Inventar-Item sein soll. Die fünf konkreten Sorten in C1 decken die tatsächlichen Gegenstände ab.

**Ursprünglicher Vorschlag:** Sortenmehle als konkrete Items behalten. Das allgemeine Mehl entweder als ausdrücklich definierte Mehlmischung spezifizieren oder als Dublette aus C3 entfernen.

**Entscheidung:** Die fünf sortenspezifischen Mehlsorten in C1 bleiben eigenständige Items. food.processed.flour wird aus C3 entfernt, da der Eintrag laut eigener Notiz nur eine nicht inventarisierbare Sammeldefinition und keine konkrete Mehlmischung darstellt.

**Anmerkungen:** Es wird kein Alias angelegt, weil der abstrakte Sammelbegriff keine einzelne kanonische Mehlsorte bezeichnet. Produktionsrezepte müssen eine konkrete Mehlsorte oder eine ausdrücklich definierte zulässige Auswahl verlangen.

**Betroffene Items:**

- `food.ingredient.flour_wheat` – Weizenmehl (kanonisches Sortenmehl) – `Items/Food/emberwild_items_food_raw_v0.2.json`
- `food.ingredient.flour_rye` – Roggenmehl (kanonisches Sortenmehl) – `Items/Food/emberwild_items_food_raw_v0.2.json`
- `food.ingredient.flour_barley` – Gerstenmehl (kanonisches Sortenmehl) – `Items/Food/emberwild_items_food_raw_v0.2.json`
- `food.ingredient.flour_corn` – Maismehl (kanonisches Sortenmehl) – `Items/Food/emberwild_items_food_raw_v0.2.json`
- `food.ingredient.flour_oat` – Hafermehl (kanonisches Sortenmehl) – `Items/Food/emberwild_items_food_raw_v0.2.json`
- `food.processed.flour` – Mehl (entfernte abstrakte Sammeldefinition; kein Inventar-Item) – `Items/Food/emberwild_items_food_processed_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "retain",
    "ids": [
      "food.ingredient.flour_wheat",
      "food.ingredient.flour_rye",
      "food.ingredient.flour_barley",
      "food.ingredient.flour_corn",
      "food.ingredient.flour_oat"
    ],
    "file": "Items/Food/emberwild_items_food_raw_v0.2.json"
  },
  {
    "type": "remove_non_inventory_definition",
    "id": "food.processed.flour",
    "file": "Items/Food/emberwild_items_food_processed_v0.2.json"
  },
  {
    "type": "clarify_recipe_input",
    "id": "food.processed.dough",
    "file": "Items/Food/emberwild_items_food_processed_v0.2.json"
  }
]
```

- Änderungen angewendet: Ja

## MAT-012 – Lebensmittelverarbeitung

- Priorität: medium
- Status: `resolved_catalog_changes_applied`

**Befund:** Butter und Frischkäse sind bereits verarbeitete Milchprodukte. Die Einträge werden nach C3 verschoben; Getränke wie Buttermilch und Molke bleiben aufgrund ihrer eigenständigen Getränkefunktion in C5.

**Ursprünglicher Vorschlag:** Butter, Frischkäse, Rahm, Joghurt und Käse als verarbeitete Lebensmittel in C3 bündeln. C1 bleibt für unverarbeitete Rohzutaten reserviert.

**Entscheidung:** Butter und Frischkäse werden aus C1 nach C3 verschoben; ihre IDs bleiben erhalten. Rahm, Joghurt, gereifter Käse und Hartkäse bleiben in C3. Buttermilch, Honigmilch und Molke bleiben als eigenständige Getränke in C5.

**Anmerkungen:** C1 bleibt für unverarbeitete Grundzutaten reserviert. C3 enthält verarbeitete Milchprodukte und Zwischenzutaten; C5 enthält trinkfertige Getränke bzw. flüssige Nebenprodukte mit eigener Getränkefunktion.

**Betroffene Items:**

- `food.ingredient.butter` – Butter (verschobenes verarbeitetes Milchprodukt / Zutat) – `Items/Food/emberwild_items_food_processed_v0.2.json`
- `food.ingredient.cheese` – Frischkäse (verschobenes verarbeitetes Milchprodukt) – `Items/Food/emberwild_items_food_processed_v0.2.json`
- `food.processed.cream` – Rahm (verarbeitete Milchzutat) – `Items/Food/emberwild_items_food_processed_v0.2.json`
- `food.processed.yogurt` – Joghurt (fermentiertes Milchprodukt) – `Items/Food/emberwild_items_food_processed_v0.2.json`
- `food.drink.buttermilk` – Buttermilch (eigenständiges Getränk) – `Items/Food/emberwild_items_food_drinks_v0.2.json`
- `food.drink.whey` – Molke (flüssiges Nebenprodukt mit Getränkefunktion) – `Items/Food/emberwild_items_food_drinks_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "move",
    "ids": [
      "food.ingredient.butter",
      "food.ingredient.cheese"
    ],
    "from": "C1",
    "to": "C3",
    "preserve_ids": true
  },
  {
    "type": "retain",
    "ids": [
      "food.processed.cream",
      "food.processed.yogurt",
      "food.processed.cheese",
      "food.processed.hard_cheese"
    ],
    "file": "Items/Food/emberwild_items_food_processed_v0.2.json"
  },
  {
    "type": "retain_beverage",
    "ids": [
      "food.drink.buttermilk",
      "food.drink.sweet_milk",
      "food.drink.whey"
    ],
    "file": "Items/Food/emberwild_items_food_drinks_v0.2.json"
  }
]
```

- Änderungen angewendet: Ja

## MAT-013 – Verbrauchsgüter und Gifte

- Priorität: high
- Status: `proposed_pending_approval`

**Befund:** Zwei Items mit identischem Namen und sehr ähnlicher Wirkung. D3 enthält darüber hinaus weitere Gegengifte.

**Ursprünglicher Vorschlag:** Einfaches Gegengift zentral in D3 führen. D1 bleibt medizinischen Verbänden, Salben und Wundversorgung vorbehalten.

**Betroffene Items:**

- `consumable.medicine.antidote_basic` – Einfaches Gegengift () – `Items/Consumables/emberwild_items_consumables_medicine_v0.1.json`
- `consumable.poison.basic_antidote` – Einfaches Gegengift () – `Items/Consumables/emberwild_items_consumables_poisons_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "merge_duplicate_candidate",
    "keep_id": "consumable.poison.basic_antidote",
    "retire_id": "consumable.medicine.antidote_basic"
  }
]
```


## MAT-014 – Werkzeuge und Gebrauchsgegenstände

- Priorität: high
- Status: `proposed_pending_approval`

**Befund:** Schaufel und Sichel sind jeweils doppelt mit nahezu identischen Beschreibungen vorhanden.

**Ursprünglicher Vorschlag:** Jeweils ein allgemeines Werkzeug behalten und in den passenden Unterkatalog verschieben oder eine klare Spezialisierung definieren. Keine zwei gleichartigen Basiswerkzeuge ohne funktionalen Unterschied.

**Betroffene Items:**

- `tool.agriculture.shovel` – Schaufel () – `Items/Tools/emberwild_items_tools_agriculture_v0.1.json`
- `tool.gathering.shovel` – Schaufel () – `Items/Tools/emberwild_items_tools_gathering_v0.1.json`
- `tool.agriculture.sickle` – Sichel () – `Items/Tools/emberwild_items_tools_agriculture_v0.1.json`
- `tool.gathering.sickle` – Sichel () – `Items/Tools/emberwild_items_tools_gathering_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "merge_duplicate_candidate",
    "pairs": [
      {
        "keep_id": "tool.agriculture.shovel",
        "retire_id": "tool.gathering.shovel"
      },
      {
        "keep_id": "tool.agriculture.sickle",
        "retire_id": "tool.gathering.sickle"
      }
    ]
  }
]
```


## MAT-015 – Werkzeuge und Gebrauchsgegenstände

- Priorität: medium
- Status: `design_decision_required`

**Befund:** B5 führt ein geflochtenes Netzmaterial bzw. Netzprodukt; E6 führt ein Netz als Fangwerkzeug. Die Beschreibungen unterscheiden Materialprodukt und funktionales Werkzeug, aber der Anzeigename ist identisch.

**Ursprünglicher Vorschlag:** B5-Item als hergestelltes Netzmaterial/Netzprodukt präzisieren (z. B. Netzgeflecht), E6 als fertiges, verwendbares Fischereigerät behalten.

**Betroffene Items:**

- `mat.net.fishing` – Fischernetz () – `Items/Processed/emberwild_items_processed_textiles_v0.1.json`
- `tool.fishing.fishing_net` – Fischernetz () – `Items/Tools/emberwild_items_tools_hunting_fishing_animal_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "rename",
    "id": "mat.net.fishing",
    "suggested_name": "Fischernetzgeflecht"
  }
]
```


## MAT-016 – Verbrauchsgüter und Werkzeuge

- Priorität: medium
- Status: `proposed_pending_approval`

**Befund:** D6 führt ein Set zum wiederholten Erzeugen von Funken; A2 führt den natürlichen Feuersteinrohstoff. Die frühere Vermutung einer Doppelung mit E8 ist nicht durch einen gleichnamigen E8-Eintrag belegt.

**Ursprünglicher Vorschlag:** Feuersteinset als wiederverwendbares Werkzeug nach E8 verschieben; Feuersteinrohstoff bleibt A2. Falls das Set bei Nutzung verbraucht wird, muss diese Verbrauchsmechanik ausdrücklich beschrieben sein.

**Betroffene Items:**

- `consumable.misc.fire_flint_kit` – Feuersteinset () – `Items/Consumables/emberwild_items_consumables_misc_v0.1.json`
- `res.stone.flint` – Feuerstein () – `Items/Resources/emberwild_items_resources_stone_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "move_candidate",
    "id": "consumable.misc.fire_flint_kit",
    "from": "D6",
    "to": "E8"
  }
]
```


## MAT-017 – Verbrauchsgüter und Werkzeuge

- Priorität: medium
- Status: `needs_mechanics_definition`

**Befund:** D6 führt einen Wasserfilter als einfachen Filter. Es ist nicht erkennbar, ob der Filterkörper wiederverwendbar ist oder bei der Reinigung verbraucht wird.

**Ursprünglicher Vorschlag:** Bei wiederverwendbarem Filterkörper nach E8 verschieben und verbrauchbares Filtermedium separat in D6 führen. Bei Einwegfilter bleibt ein D6-Item zulässig.

**Betroffene Items:**

- `consumable.misc.water_filter` – Wasserfilter () – `Items/Consumables/emberwild_items_consumables_misc_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "define_consumption_model",
    "id": "consumable.misc.water_filter"
  }
]
```


## MAT-018 – Verbrauchsgüter und Werkzeuge

- Priorität: medium
- Status: `needs_mechanics_definition`

**Befund:** D6 beschreibt Köder als vorbereitete Verbrauchsgegenstände zum Anlocken von Tieren und Kreaturen. Eine Verbrauchsmechanik ist naheliegend, aber noch nicht spezifiziert.

**Ursprünglicher Vorschlag:** In D6 belassen, wenn jeder Einsatz Köder verbraucht. Falls Köder mehrfach verwendet werden können, E6/E8 prüfen.

**Betroffene Items:**

- `consumable.misc.bait` – Köder () – `Items/Consumables/emberwild_items_consumables_misc_v0.1.json`
- `consumable.misc.special_bait` – Spezialköder () – `Items/Consumables/emberwild_items_consumables_misc_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "define_consumption_model",
    "ids": [
      "consumable.misc.bait",
      "consumable.misc.special_bait"
    ]
  }
]
```


## MAT-019 – Wachs, Harze und Naturstoffe

- Priorität: medium
- Status: `source_review_required`

**Befund:** A6 und A8 führen unterschiedliche natürliche Wachsrohstoffe; D6 führt aufbereitetes Siegelwachs als Verbrauchsgegenstand.

**Ursprünglicher Vorschlag:** Beide Rohwachse getrennt behalten. Siegelwachs als verarbeitetes Verbrauchsprodukt in D6 behalten, sofern es beim Versiegeln verbraucht wird; andernfalls B5 als Materialprodukt führen.

**Betroffene Items:**

- `res.animal.wax` – Bienenwachs () – `Items/Resources/emberwild_items_resources_animal_v0.2.json`
- `res.misc.earth_wax` – Erdwachs () – `Items/Resources/emberwild_items_resources_misc_v0.2.json`
- `consumable.misc.wax_seal` – Siegelwachs () – `Items/Consumables/emberwild_items_consumables_misc_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "define_consumption_model",
    "id": "consumable.misc.wax_seal"
  }
]
```


## MAT-020 – Öle und geologische Kohlenwasserstoffe

- Priorität: medium
- Status: `source_review_required`

**Befund:** A8 definiert Pflanzenöl als ungeklärtes Pressöl und Rohöl als unaufbereitetes Erdöl. D5 führt fertige Pflegeöle für Waffen.

**Ursprünglicher Vorschlag:** Rohstoffe in A8 belassen; Waffenöle als formulierte Wartungs-/Pflegeprodukte in D5 belassen. B5 nur ergänzen, wenn ein eigenständiges Zwischenprodukt wie raffiniertes Öl in Rezepten gebraucht wird.

**Betroffene Items:**

- `res.misc.plant_oil` – Pflanzenöl () – `Items/Resources/emberwild_items_resources_misc_v0.2.json`
- `res.misc.mineral_oil` – Rohöl () – `Items/Resources/emberwild_items_resources_misc_v0.2.json`
- `consumable.maintenance.weapon_oil` – Waffenöl () – `Items/Consumables/emberwild_items_consumables_maintenance_v0.1.json`
- `consumable.maintenance.premium_weapon_oil` – Hochwertiges Waffenöl () – `Items/Consumables/emberwild_items_consumables_maintenance_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "retain_with_stage_boundary",
    "ids": [
      "res.misc.plant_oil",
      "res.misc.mineral_oil",
      "consumable.maintenance.weapon_oil",
      "consumable.maintenance.premium_weapon_oil"
    ]
  }
]
```


## MAT-021 – Lebensmittel und Tierrohstoffe

- Priorität: medium
- Status: `needs_definition`

**Befund:** A6 definiert Tierfett als grob gereinigten Rohstoff, der auch für Lebensmittelverarbeitung dient. In den C-Katalogen muss geklärt werden, ob ein separates Speisefett-Produkt existiert und welche Verarbeitungsstufe es beschreibt.

**Ursprünglicher Vorschlag:** Tierfett als Rohstoff belassen. Verarbeitetes Speisefett nur als eigenes C3-Item ergänzen, wenn eine echte Aufbereitung und Rezeptverwendung vorgesehen ist.

**Betroffene Items:**

- `res.animal.tallow` – Tierfett () – `Items/Resources/emberwild_items_resources_animal_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "cross_catalog_check",
    "scope": "C1-C6",
    "term": "Tierfett/Speisefett/Talg"
  }
]
```


## MAT-022 – Magische Ressourcen und Essenzen

- Priorität: high
- Status: `needs_lore_definition`

**Befund:** A8 beschreibt Lebensfluid und Uressenz als natürliche Ressourcen. C6 beschreibt Essenz der Lebenskraft als einzigartige Erscheinungsform ursprünglicher Lebenskraft mit direktem Bezug zu Vaelith.

**Ursprünglicher Vorschlag:** Alle drei vorerst getrennt halten. Die Lore muss definieren, ob Uressenz ein Rohstoff, eine Quelle oder eine konzentrierte Manifestation ist und wie sie sich von Vaeliths Essenz unterscheidet.

**Betroffene Items:**

- `res.misc.lifefluid` – Lebensfluid () – `Items/Resources/emberwild_items_resources_misc_v0.2.json`
- `res.misc.primordial_essence` – Uressenz () – `Items/Resources/emberwild_items_resources_misc_v0.2.json`
- `food.special.vaelith_essence` – Essenz der Lebenskraft () – `Items/Food/emberwild_items_food_special_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "lore_decision",
    "ids": [
      "res.misc.lifefluid",
      "res.misc.primordial_essence",
      "food.special.vaelith_essence"
    ]
  }
]
```


## MAT-023 – Gesteine und mineralische Naturstoffe

- Priorität: medium
- Status: `source_review_required`

**Befund:** A8 beschreibt Naturbitumen als geologische bituminöse Substanz und natürlichen Teer als natürliche organische Ablagerung, ausdrücklich nicht als Holzteer.

**Ursprünglicher Vorschlag:** Vorläufig getrennt lassen. Für beide müssen Fundorte, Gewinnung und unterschiedliche Verwendungen festgelegt werden; andernfalls zusammenführen.

**Betroffene Items:**

- `res.misc.natural_bitumen` – Naturbitumen () – `Items/Resources/emberwild_items_resources_misc_v0.2.json`
- `res.misc.natural_tar` – Natürlicher Teer () – `Items/Resources/emberwild_items_resources_misc_v0.2.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "define_world_sources_and_uses",
    "ids": [
      "res.misc.natural_bitumen",
      "res.misc.natural_tar"
    ]
  }
]
```


## MAT-024 – Werkzeuge und Gegenstände

- Priorität: medium
- Status: `design_decision_required`

**Befund:** D6 führt ein allgemeines Seil und Wurfseil als Gegenstände. B5 führt zusätzlich ein hergestelltes Seilmaterial. Die tatsächliche Wiederverwendbarkeit und die Unterscheidung zwischen Material und einsatzfertigem Gegenstand sind nicht vollständig spezifiziert.

**Ursprünglicher Vorschlag:** B5 als hergestelltes Seilmaterial behalten; D6-Seil nur als verbrauchbares Einsatzobjekt behalten, falls es beim Einsatz verbraucht wird. Wiederverwendbares Wurfseil als E8-Gegenstand führen.

**Betroffene Items:**

- `consumable.misc.rope` – Seil () – `Items/Consumables/emberwild_items_consumables_misc_v0.1.json`
- `consumable.misc.grappling_rope` – Wurfseil () – `Items/Consumables/emberwild_items_consumables_misc_v0.1.json`
- `mat.rope.hemp` – Hanfseil (hergestelltes Seilprodukt) – `Items/Processed/emberwild_items_processed_textiles_v0.1.json`
- `mat.rope.flax` – Flachsseil (hergestelltes Seilprodukt) – `Items/Processed/emberwild_items_processed_textiles_v0.1.json`
- `mat.rope.jute` – Juteseil (hergestelltes Seilprodukt) – `Items/Processed/emberwild_items_processed_textiles_v0.1.json`
- `mat.rope.root_fiber` – Wurzelfaserseil (hergestelltes Seilprodukt) – `Items/Processed/emberwild_items_processed_textiles_v0.1.json`
- `mat.rope.deep_fiber` – Tiefenfaserseil (hergestelltes Seilprodukt) – `Items/Processed/emberwild_items_processed_textiles_v0.1.json`

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "define_item_role_and_durability",
    "ids": [
      "consumable.misc.rope",
      "consumable.misc.grappling_rope",
      "mat.rope.rope"
    ]
  }
]
```


## MAT-025 – Katalogweite Datenarchitektur

- Priorität: high
- Status: `architecture_proposal_defined`

**Befund:** Die aktive Bestandsauswahl umfasst 34 Katalogdateien und 1.009 Items mit 1.009 unterschiedlichen IDs. Es gibt keine ID-Kollisionen in den aktiven Katalogständen. Die Kataloge besitzen jedoch unterschiedliche Metadatenstrukturen; sources und uses sind überwiegend Freitext und keine maschinenlesbaren Referenzen.

**Ursprünglicher Vorschlag:** Eine kanonische Item-Definition pro Heimatkatalog beibehalten. Einen automatisch generierten Registry-Index unter Items/Planning/ führen, der Item-ID, Name, Heimatkatalog, Quelldatei und Katalogversion enthält. Künftige Rezepte und Produktionsdaten referenzieren Items explizit über item_id. Bestehende sources/uses bleiben bis zu einer gesonderten Migration beschreibender Freitext.

**Anmerkungen:** Die Architektur ist als Grundlage vorgeschlagen. Die tatsächlichen Dublettenentscheidungen MAT-001 bis MAT-024 bleiben davon getrennt.

**Aktionen / Migrationsentscheidungen:**

```json
[
  {
    "type": "architecture_document",
    "file": "Items/Planning/emberwild_architecture_decision_MAT-025_v1.0.md"
  },
  {
    "type": "generated_registry",
    "file": "Items/Planning/emberwild_item_registry_v1.0.json",
    "catalog_count": 34,
    "item_count": 1009
  },
  {
    "type": "defer_schema_unification",
    "reason": "Bestehende Kataloge nicht unnötig durch eine große Schemaänderung destabilisieren"
  }
]
```


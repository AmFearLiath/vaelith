# Emberwild – Produktionsarchitektur Lebensmittel und Getränke v1.0

## Ziel und Umfang

Dieser Abschnitt ergänzt die Produktionsgrundlage um die Verarbeitung und Zubereitung von Lebensmitteln. Er umfasst die aktiven C1–C6-Kataloge sowie benötigte Rohstoffe aus A4, A6 und A8. Ernte, Jagd, Tierhaltung und Fischfang bleiben Quellen-/Weltaktionen und werden nicht als Verarbeitungsrezepte modelliert.

## Kataloggrenzen

- C1: rohe pflanzliche Lebensmittel und Grundzutaten; Mehltypen, Speisesalz, Zucker, Honig, Ei, Milch und Speiseöl bleiben kanonische Lebensmittelzutaten.
- C2: rohes Fleisch, Fisch, Meeresfrüchte und tierische Lebensmittel-Zwischenprodukte. Tierfett in A6 wird erst durch Auslassen zu Speisefett in C2.
- C3: verarbeitete Lebensmittel, Teige, Backwaren, Konservate, Milchprodukte und haltbare Zutaten.
- C4: zubereitete Mahlzeiten und Speisen.
- C5: trinkfertige Getränke. Buttermilch und Molke entstehen als Nebenprodukte der Milchverarbeitung.
- C6: besondere und magische Lebensmittel. Lore- und essbarkeitsabhängige Rezepte bleiben Review.

## Produktionsketten

1. Getreide -> sortenreines Mehl -> Grundteig -> gegärter Teig -> Brot und Backwaren.
2. Fleisch/Fisch -> Braten, Trocknen, Räuchern, Pökeln und Wurst. Tierdarm aus A6 ist Zutat der Wurstherstellung.
3. Milch -> Rahm -> Butter (+ Buttermilch als Nebenprodukt); Milch -> Frischkäse (+ Molke als Nebenprodukt) -> gereifter Käse/Hartkäse. Joghurt und Frischkäse benötigen noch definierte Starter-/Gerinnungskulturen.
4. Früchte -> Saft -> Fruchtwein oder Sirup; Früchte -> Dörrobst/Marmelade.
5. Getreide/Hopfen/Wasser/Hefe -> Bier. Mälzung bleibt ein Prozessschritt, da Malz aktuell kein eigenes Item besitzt.
6. Rohzutaten -> Küche -> C4-Mahlzeiten.
7. Seltene Zutaten -> spezialisierte Küche -> C6-Speisen; unbestätigte Essbarkeit und Lore-Wirkung sperren die Aktivierung.

## Produktionsstätten

Mühle, Bäckerei, Küche, Fleischerei, Räucherei, Molkerei, Saftpresse, Brauerei, Gärkeller, Dörrhaus, Lebensmittelwerkstatt und spezialisierte Unterweltküche. Die Landwirtschaftsbetriebe, Tierhaltung und Fischereibetriebe bleiben als Quellenbetriebe im zentralen Facility-Seed enthalten.

## Mengen, Qualität und Wirtschaft

Alle Rezeptmengen, Ausbeuten, Produktionszeiten, Arbeitswerte, Verluste, Brennstoffbedarfe und Gebäudestufen bleiben `null` bzw. `pending_balance`. Es werden keine Basiswerte oder Verkaufspreise ergänzt. NPC-Produktion ist nur zielbestandsgesteuert und begrenzt vorgesehen; Rezepte erzeugen niemals direkt Gold.

## Herkunft und Premium

Zutatenherkunft, Qualität, Seltenheit und Premiumherkunft werden über alle Produktionsstufen erhalten. Ein Endprodukt wird als premiumfinanziert markiert, wenn mindestens ein tatsächlich verbrauchter Input Premiumherkunft besitzt. Werkzeuge und Katalysatoren werden nicht als verbrauchte Premiuminputs behandelt.

## Bewusst offene Punkte

- Malz als Zwischenprodukt oder reine Prozessstufe.
- Starterkulturen für Hefe, Sauerteig, Milchprodukte und Essig.
- Essbarkeit besonderer Blüten und Leuchtpilze.
- Unterweltgetreide, Unterwelt-Hefekultur und konkrete Unterweltzutaten.
- Alkoholbasis/Destillation für Kräuterlikör.
- Wasserquellen, Trinkwasseraufbereitung und Honigwaben-Ernte.

Diese offenen Punkte sind im `emberwild_food_production_dependency_backlog_v1.0.json` dokumentiert. Review-Rezepte sind Konzeptvorschläge und dürfen nicht als aktivierte Produktionsketten behandelt werden.

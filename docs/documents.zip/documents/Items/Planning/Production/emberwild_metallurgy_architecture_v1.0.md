# Emberwild – Produktionsarchitektur Metallurgie v1.0

**Status:** Konzept – Mengen, Ausbeuten, Zeiten und Prozessparameter offen  
**Grundlage:** A3 Erze und metallische Rohstoffe v0.3, B3 Metalle und Legierungen v0.3, B6 magisch veredelte Materialien v0.2, MAT-003 bis MAT-006, Produktionsgrundlage und Rezeptschema v1.1.

## 1. Geltungsbereich

Dieser Abschnitt definiert die erste zusammenhängende Metallverarbeitung: Erzverhüttung, Gewinnung von Metallbarren, Legierungsherstellung, Stahl- und Schmiedeeisenverarbeitung sowie die Herstellung generischer Metallhalbzeuge und ausgewählter Metallkomponenten. Der Abbau der Erze bleibt eine Welt-/Sammelaktion und wird nicht als Verarbeitungsrezept modelliert.

## 2. Verbindliche Datenregeln

- Alle Rezepte besitzen zunächst den Status `concept`.
- Mengen, Ausbeuten, Dauer, Arbeitsaufwand, Brennstoffbedarf, Kapazitäten und Verluste bleiben `null` mit `quantity_status: pending_balance`.
- Die Rezepte verwenden ausschließlich kanonische Item-IDs aus der Registry.
- Inputs mit derselben `alternative_group` sind Alternativen; pro Batch wird genau eine Option gewählt.
- Premiumherkunft, Materialherkunft, Qualität und Seltenheit werden über die gesamte Kette erhalten. Legierungen übernehmen die Provenienz aller eingesetzten Metallinputs.
- Die Herstellung eines Barrens oder Halbzeugs ist keine automatische magische Veredelung. B6 bleibt eine getrennte Prozessstufe.

## 3. Erzverhüttung

Die 18 natürlichen A3-Erzrohstoffe werden in kanonische Metallbarren überführt. Für Gluteisen, Tiefenkupfer und Leersilber wurden die fehlenden B3-Itemdefinitionen ergänzt, weil A3 diese Barren bereits ausdrücklich als vorgesehene Verwendungen aufführt.

Dunkelstahl besitzt eine zweistufige metallurgische Kette:

1. Dunkelstahlerz → Dunkelstahllegierung
2. Dunkelstahllegierung → Dunkelstahlbarren

Die genaue Zusammensetzung der Dunkelstahllegierung bleibt offen. Das Konzeptrezept ist daher ausdrücklich nicht aktivierbar, bis die erforderlichen Zusatzmetalle und Prozessbedingungen festgelegt sind.

## 4. Legierungen und Eisenveredelung

- Bronze: Kupferbarren + Zinnbarren → Bronzebarren.
- Messing: Kupferbarren + Zinkbarren → Messingbarren. Zinkerz wird nicht direkt in Messing verarbeitet (MAT-003).
- Stahl: Eisenbarren + Naturkohle als vorgesehener Kohlenstoffträger → Stahlbarren. Kohlenstoffübergang und Mengenverhältnis sind offen.
- Schmiedeeisen: mechanische Weiterverarbeitung von Eisenbarren in der Schmiede.

## 5. Metallhalbzeuge und MAT-006

Die Grundformen Metallplatte, starke Metallplatte, Metallblech, Metallstange, Metallprofil und Metalldraht bleiben jeweils genau ein kanonisches Item. Die konkrete Metallart wird als `material_variant_id` an der Item-Instanz gespeichert.

Die Rezeptausgabe übernimmt die Variante des ausgewählten Eingangs. Unterschiedliche Varianten sind nicht stapelkompatibel. Die Freigabeliste je Form ist in `emberwild_material_variant_model_MAT-006_v1.1.json` hinterlegt. Die Liste stellt eine Produktionsfreigabe dar und behauptet keine konkreten Materialwerte.

Edelmetallblech bleibt eine eigenständige Spezialform. Silber oder Gold werden über die Provenienz des ausgewählten Eingangs erhalten. Metallpulver bleibt vorerst generisch; ein separates Materialvariantenmodell für Pulver ist noch nicht beschlossen.

## 6. Metallkomponenten

Der Abschnitt enthält Konzeptrezepte für Metallnägel, Metallnieten, Metallbeschläge, Kettenglieder, Metallketten, Metallfedern, Metallgeflecht, Metallpulver, Edelmetallblech und Herzmetallbeschläge.

Bei Komponenten außerhalb der sechs MAT-006-Grundformen wird die Materialherkunft zunächst über die Produktionsprovenienz erhalten. Ein zusätzliches Komponenten-Variantenmodell wird nicht stillschweigend eingeführt. Metallfedern sind zunächst auf Stahldraht beschränkt, da B3 ausdrücklich geeignetes Federstahlmaterial oder eine entsprechende Legierung verlangt.

## 7. Produktionsstätten

- `facility.smeltery`: grundlegende Erzverhüttung und Barrenherstellung.
- `facility.specialized_smeltery`: seltene und anspruchsvolle Erzrohstoffe.
- `facility.alloy_furnace`: Bronze- und Messingherstellung.
- `facility.steelworks`: kontrollierte Stahlherstellung.
- `facility.blacksmith`: Schmiedeeisen, Stangen und Metallkomponenten.
- `facility.rolling_mill`: Platten, Bleche und Profile.
- `facility.wire_drawing_workshop`: Drahtzug und Metallgeflecht.
- `facility.metal_grinding_workshop`: Metallpulver.
- `facility.arcane_workshop`: spezialisierte Herzmetallbeschläge; keine automatische B6-Veredelung.

Alle Einrichtungen bleiben `concept`. Gebäudestufen, Berufe, Skills, Lagerkapazitäten, Produktionszyklen, Zielbestände und NPC-Obergrenzen sind noch nicht festgelegt.

## 8. Bewusst zurückgestellte Prozesse

| Prozess | Grund |
|---|---|
| Erzwaschen / Konzentrate | Es existieren keine eindeutig definierten Konzentrate oder Aufbereitungsitems. |
| Dunkelstahl-Zusatzmetalle | Zusammensetzung und Lore der Legierung sind offen. |
| Magische Metallveredelung | Gehört in separate B6-Rezepte und benötigt eigene magische Prozessregeln. |
| Äthermetall, Geflechtlegierung, Essenzlegierung | Die Rezepturen sind noch nicht ausreichend spezifiziert. |
| Metallpulver-Varianten | Materialidentität wird zunächst über Provenienz geführt; Variantenmodell offen. |
| Legierungsanteile und Kohlenstoffgehalt | Keine Mengen oder Materialwerte ohne Balancing festlegen. |

## 9. Balancing- und Designaufgaben

1. Erz- und Barrenmengen sowie metallurgische Ausbeuten festlegen.
2. Brennstoffe, Flussmittel, Schlacke und mögliche Nebenprodukte definieren.
3. Bronze-, Messing- und Stahlzusammensetzungen bestimmen.
4. Dunkelstahllegierung lore- und rezeptseitig vervollständigen.
5. Verarbeitungszeiten, Arbeitswerte, Gebäudestufen und Skillanforderungen festlegen.
6. Zulässige Varianten je Halbzeugform im Spielsystem implementieren.
7. Materialherkunft und Variantenidentität für fertige Komponenten verbindlich speichern.
8. NPC-Zielbestände, Eingangsreserven und Batch-Obergrenzen aus dem Siedlungsbedarf ableiten.

## 10. Enthaltene Rezepte

Die vollständigen Rezeptdatensätze befinden sich in `Recipes/Metallurgy/emberwild_recipes_metallurgy_v1.0.json`. Das Manifest enthält die vollständige Rezeptliste und die zugeordneten Produktionsstätten.

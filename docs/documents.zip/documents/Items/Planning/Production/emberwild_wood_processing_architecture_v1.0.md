# Emberwild – Produktionsarchitektur Holzverarbeitung v1.0

**Status:** Konzept – Produktionsmengen und Balancing offen  
**Grundlage:** Item-Kataloge A1 v0.2 und B1 v0.2, Produktionsgrundlage v1.0, MAT-001 bis MAT-025.

## 1. Geltungsbereich

Dieser Abschnitt definiert die erste zusammenhängende Verarbeitungskette für Holz und holzartige Werkstoffe. Er umfasst die mechanische Primärverarbeitung, ausgewählte Schreinerprodukte, die Köhlerei sowie besondere Unterwelt- und Geflechtmaterialien. Die Gewinnung von Holz in der Welt bleibt eine Sammel-/Forstaktion und wird nicht künstlich als Verarbeitungsrezept dargestellt.

## 2. Verbindliche Datenregeln

- Alle Rezepte haben zunächst den Status `concept`.
- Mengen, Ausbeuten, Dauer, Arbeitsaufwand, Kapazitäten und Verluste bleiben ausdrücklich offen. Sie werden als `quantity: null` mit `quantity_status: pending_balance` geführt.
- Dafür wurde `emberwild_recipe_schema_v1.1.json` ergänzt. Schema v1.0 bleibt unverändert erhalten.
- Inputs mit derselben `alternative_group` sind echte Alternativen: Pro Batch wird genau eine Alternative gewählt. Inputs ohne gemeinsame Gruppe werden zusammen benötigt.
- Generische Holzhalbzeuge bleiben kanonische B1-Items. Die konkrete Holzart wird über die Herkunfts-/Materialursprungsdaten der Item-Instanz erhalten.
- Die `material_variant_id` aus MAT-006 wird nicht für Holz verwendet; MAT-006 definiert ausdrücklich Metallhalbzeuge.
- Nebenprodukte wie Sägemehl und Holzspäne werden als eigene Outputs geführt, ihre Mengen bleiben offen.
- Premiumherkunft wird durch alle Produktionsstufen erhalten; ein Premiuminput macht das Ergebnis gemäß der bestehenden Herkunftsregel premium-finanziert.

## 3. Produktionsketten

### 3.1 Standardholz – Sägewerk

Geeignete Holzarten: Waldholz, Fichtenholz, Eichenholz, Birkenholz, Buchenholz, Eschenholz und Kiefernholz. Ausgewählte besondere Holzarten können für Bretter und Feinbretter zugelassen werden.

Produkte: Holzbretter, Holzbalken, Kantholz, Rundholz, Feinbretter und Holzfurnier. Sägemehl und Holzspäne werden als mögliche Nebenprodukte geführt.

### 3.2 Schreinerverarbeitung

Holzbretter und Kantholz können zu Holzleisten und Holzdübeln weiterverarbeitet werden. Holzplatten benötigen Holzbretter und Holzleim. Die Leimformulierung ist nicht Teil dieses Abschnitts.

### 3.3 Köhlerei

Gewöhnliche Holzkohle wird aus geeigneten Holzarten hergestellt. Hartholzkohle wird zunächst nur aus Eiche, Buche und Esche zugelassen. Reisig ist ein separater Anfeuerbrennstoff und nicht Teil der Kohleausbeute.

### 3.4 Besondere Werkstoffe

- Wurzelplatten: Wurzelholz oder Tiefenwurzelholz; Herkunft bleibt unterscheidbar.
- Pilzholzplatten: aus Pilzholz; Unterweltprozess.
- Kristallholzplatten: aus Kristallrinde; kein gewöhnliches Holzrezept.
- Geflechtbretter: aus Geflechtholz; natürliche Geflechtprägung bleibt erhalten, es findet keine zusätzliche magische Veredelung statt.
- Bearbeitetes Erstholz: mechanische Bearbeitung von Erstholz gemäß MAT-001; keine magische Stabilisierung.

## 4. Produktionsstätten

- `facility.sawmill`: Primärzuschnitt und mechanische Holzverarbeitung.
- `facility.carpentry_workshop`: Feinbearbeitung, Verbindung und Schreinerprodukte.
- `facility.charcoal_kiln`: kontrollierte Verkohlung.
- `facility.forestry_camp`: Forstwirtschaft und Sammelverwaltung; keine künstliche Verarbeitungsrezeptur für das Fällen/Sammeln.

Alle Einrichtungen bleiben `concept`. Gebäudestufen, Berufe, Skills, Lagerkapazitäten, Produktionszyklen und Obergrenzen sind noch nicht festgelegt. NPC-Produktion ist nur mit Zielbeständen, Eingangsreserven und Batch-Obergrenzen zulässig.

## 5. Bewusst zurückgestellte Prozesse

| Prozess / Item | Grund der Zurückstellung |
|---|---|
| Holzfasermasse (`mat.wood.wood_pulp`) | Aufschlussverfahren, Wasser-/Prozessmedien und Ausbeute fehlen. |
| Holzleim (`mat.wood.wooden_glue`) | Rohstoffformulierung und alternative Leimgrundlagen sind nicht definiert. |
| Imprägniertes Holz (`mat.wood.treated_timber`) | Schutzmittel, Rezeptur und Haltbarkeitswirkung müssen festgelegt werden. |
| Formholz (`mat.wood.bentwood`) | Dampf-/Feuchteprozess und Vorrichtung sind nicht im Rezeptmodell beschrieben. |
| Holzasche (`mat.wood.wood_ash`) | Entsteht durch vollständige Verbrennung, nicht als pauschales Nebenprodukt der Köhlerei. |
| Gerbrinde, Baumrinde, Baumharz, Höhlenharz | Gehören zu separaten Gerb-, Klebstoff-, Dichtungs- und Extraktionsketten. |
| Wurzelfasern, Moos, Flechten, Leuchtmoos | Natürliche Pflanzen-/Faserressourcen; keine Holzhalbzeuge. |

## 6. Balancing- und Designaufgaben

1. Batchgrößen und Mengenverhältnisse je Holzart und Produkt festlegen.
2. Schnittverluste, Sägemehl- und Holzspäneausbeute bestimmen.
3. Qualitätseinfluss von Holzart, Rohstoffqualität, Fachkenntnis und Gebäudestufe definieren.
4. Zulässige Holzarten für Balken, Feinbretter und Furnier endgültig bestätigen.
5. Prozesszeiten, Arbeitswerte, Brennstoffbedarf und Gebäudekapazitäten festlegen.
6. Besondere Eigenschaften von Wurzel-, Pilz-, Kristall-, Geflecht- und Erstholz loreseitig abstimmen.
7. NPC-Zielbestände und Produktionsobergrenzen aus dem späteren Siedlungsbedarf ableiten.

## 7. Enthaltene Rezepte

Die vollständigen Datensätze befinden sich in `emberwild_recipes_wood_v1.0.json`. Alle sind Konzeptrezepte mit offenen Mengen.

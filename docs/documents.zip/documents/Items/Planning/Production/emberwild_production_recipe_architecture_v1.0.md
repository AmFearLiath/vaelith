# Emberwild – Produktions- und Rezeptarchitektur

**Version:** 1.0.0  
**Status:** Architekturgrundlage / Entwurf  
**Grundlage:** `Emberwild-Items_complete_A1-A8_MAT-001-024.zip`, Item Registry v1.4, MAT-025 und MAT-006.

## 1. Zweck und Geltungsbereich

Diese Architektur legt fest, wie Produktionsrezepte, Produktionsstätten, Berufe, Skills, Ausbeuten und Nebenprodukte künftig beschrieben und miteinander verknüpft werden. Sie verändert keine bestehenden Item-Definitionen und behauptet keine Rezepte, deren Mengen oder Prozessdaten in den Katalogen nicht belegt sind.

Die aktive Registry enthält 34 Kataloge und 1.000 kanonische Item-Definitionen. Die vorhandenen `sources`- und `uses`-Felder sind beschreibender Freitext. Sie sind Hinweise für die spätere Rezeptanalyse, aber keine maschinenlesbaren Produktionsdefinitionen.

## 2. Verbindliche Grundsätze

1. **Eine Item-ID, eine Definition:** Rezepte referenzieren kanonische `item_id`-Werte aus der Item Registry. Item-Eigenschaften werden nicht in Rezepten dupliziert.
2. **Rezept und Item getrennt:** Ein Rezept beschreibt eine Transformation. Es ist kein Item und gehört nicht in einen A–E-Itemkatalog.
3. **Eingänge und Ausgänge explizit:** Zutaten, Brennstoffe, Katalysatoren, Werkzeuge, Ergebnisse und Nebenprodukte werden getrennt modelliert.
4. **Keine erfundenen Zahlen:** Mengen, Dauer, Verluste, Qualitätseinfluss und Produktionskosten bleiben offen, bis sie fachlich festgelegt sind.
5. **Materialvarianten beachten:** Metallhalbzeuge verwenden die Grundform als `item_id` und die konkrete Metallart als `material_variant_id` gemäß MAT-006.
6. **Produktion ist begrenzt:** NPC-Produktion braucht Zielbestände, Maximalbestände, begrenzte Batches und verfügbare Inputs. Keine passive endlose Geld- oder Warenproduktion.
7. **Herkunft bleibt erhalten:** Premium- und sonstige Herkunftsmerkmale werden durch Zwischen- und Endprodukte weitergetragen.
8. **Seltenheit und Wertigkeit bleiben getrennt:** Rezeptqualität kann beide beeinflussen, aber sie sind keine identische Eigenschaft.

## 3. Datenobjekte

### 3.1 Recipe

Ein Rezept beschreibt eine konkrete Produktionshandlung. Pflichtbestandteile: stabile `recipe_id`, Version, Status, Eingänge, Ausgänge, Prozessdefinition und Verfügbarkeit. Optionale Bestandteile: Nebenprodukte, Qualitätsregeln, Herkunftsregeln und wirtschaftliche Grenzen.

**Eingangsrollen:**
- `consumed`: wird verbraucht.
- `fuel`: wird als Brennstoff verbraucht.
- `catalyst`: wird eingesetzt, bleibt aber grundsätzlich erhalten.
- `tool`: wiederverwendbares Werkzeug; Verschleiß wird separat modelliert.
- `container`: Behälter, dessen Rückgabe-/Verlustregel separat festgelegt wird.

**Ausgänge:** Hauptprodukte und Nebenprodukte werden als getrennte Einträge geführt. Ausbeute und Verlust werden nicht aus dem Namen oder der Beschreibung abgeleitet.

### 3.2 Production Facility

Eine Produktionsstätte beschreibt Gebäude oder Betriebsstätte, ihre Stufen, unterstützte Berufe/Skills, Lagerkapazitäten, Arbeiterplätze und autonome Produktionsregeln. Ein Rezept referenziert die Stätte über `facility_id`.

Die beiliegende Kandidatenliste ist ausdrücklich ein Konzept. Die vorhandenen Item-Kataloge definieren keine verbindlichen Gebäude-IDs.

### 3.3 Profession und Skill

Berufe und Skills erhalten eigene stabile IDs (`profession.*`, `skill.*`). Rezepte können einen Beruf und Mindest-Skilllevel verlangen. Konkrete Berufsbäume, Levelgrenzen und Boni sind noch nicht festgelegt.

### 3.4 Materialvarianten

Für Metallhalbzeuge gilt MAT-006: `item_id` bezeichnet die kanonische Form (z. B. `mat.metal.metal_plate`), `material_variant_id` die Metallart (z. B. `metal.darksteel`). Varianten sind Instanzdaten, keine neuen kanonischen Items. Nicht jede Metallart ist automatisch für jede Halbzeugform zulässig.

## 4. Produktionsablauf

1. Rezept wird anhand seiner `recipe_id` geladen.
2. Alle Item-IDs werden gegen die kanonische Registry validiert.
3. Materialvarianten werden gegen MAT-006 und die spätere Formfreigabe geprüft.
4. Station, Gebäudestufe, Beruf und Skills werden geprüft.
5. Verbrauchsgüter und Brennstoffe werden abgezogen; Werkzeuge/Katalysatoren folgen ihren eigenen Erhaltungsregeln.
6. Prozessdauer und Kapazität werden angewendet.
7. Hauptprodukte und Nebenprodukte werden erzeugt.
8. Qualität, Seltenheit und Herkunft werden nach expliziten Rezeptregeln berechnet.
9. NPC-Lagerbestände, Zielmengen und Produktionslimits werden aktualisiert.

## 5. NPC- und Wirtschaftsregeln

- Autonome Produktion ist pro Produktionsstätte und Rezept freizugeben.
- Zielbestände und Maximalbestände werden pro Item kontrolliert.
- Produktion pausiert, wenn der Zielbestand erreicht ist oder Inputs fehlen.
- Maximalzahl von Batches je Zyklus und Produktionsrate begrenzen die Ausbringung.
- Spieler können Produktionsziele und Prioritäten setzen.
- Produktionsgebäude erzeugen nicht automatisch Gold. Verkäufe sind separate Markttransaktionen.
- NPC-Märkte benötigen begrenzte Budgets, Bestände und Nachfüllraten.
- Premiumressourcen bleiben separat bilanziert; wird mindestens ein Premiuminput verwendet, folgt das Produkt der beschlossenen Premium-Herkunftsregel.

## 6. Statusmodell

- `concept`: Idee, nicht implementierbar.
- `draft`: Datenstruktur angelegt, fachliche Angaben können fehlen.
- `review`: fachliche Prüfung läuft.
- `validated`: IDs, Inputs/Outputs und Prozessregeln geprüft.
- `active`: im Spiel freigegeben.
- `deprecated`: nicht mehr neu verwendbar; Migration bleibt dokumentiert.

Ein Rezept darf erst `active` werden, wenn alle Mengen und Einheiten, Ein-/Ausgänge, Station, Prozessdauer, Verfügbarkeit und Validierungsregeln festgelegt sind.

## 7. Versionierung und Migration

- `recipe_id` bleibt bei normalen Balance- und Mengenänderungen stabil.
- `version` wird bei jeder fachlich relevanten Änderung erhöht.
- Entfernte oder ersetzte Rezept-IDs werden mit Migrationshinweis dokumentiert.
- Rezeptänderungen dürfen die Item Registry nicht duplizieren oder verändern.
- Bestehende Spielstände benötigen bei geänderten Rezepten eine definierte Kompatibilitätsstrategie.

## 8. Quellenanalyse des aktuellen Bestands

Die begleitende Datei `emberwild_production_dependency_backlog_v1.0.json` erfasst die `sources`- und `uses`-Texte aller 1.000 aktiven Items. Nur exakte Anzeigenamen werden als mögliche Item-Referenz aufgelöst. Alle übrigen Angaben bleiben Freitext. Diese Analyse ist keine bestätigte Rezeptliste.

## 9. Bewusst noch nicht festgelegt

- Mengen und Ausbeuten einzelner Rezepte
- Prozessdauer, Brennstoffbedarf und Materialverluste
- Gebäude- und Berufsstufen
- konkrete Skillbäume und Produktionsboni
- Qualitätseinfluss und Seltenheitsvererbung
- Lagerkapazitäten, NPC-Zyklen und Marktnachfüllraten
- finale Premium-Währungsbezeichnung und konkrete Buchungsimplementierung

Diese Angaben werden erst in den jeweiligen Produktionsketten beschlossen.

# Emberwild – Architekturentscheidungen MAT-019 bis MAT-024

**Version:** 1.0  
**Status:** beschlossen / umgesetzt, soweit katalogseitig entscheidbar  
**Grundlage:** Emberwild-Items_complete_A1-A8_MAT-001-018.zip

## MAT-019 – Bienenwachs, Erdwachs und Siegelwachs

**Entscheidung**
- Bienenwachs (`res.animal.wax`) bleibt als tierischer Rohstoff in A6.
- Erdwachs (`res.misc.earth_wax`) bleibt als geologischer Rohstoff in A8.
- Siegelwachs (`consumable.misc.wax_seal`) bleibt in D6 als aufbereitetes Verbrauchsprodukt. Es wird beim Aufbringen einer Siegelmarke verbraucht.

**Begründung**  
Die beiden Rohwachse unterscheiden sich nach Herkunft. Siegelwachs ist ein verarbeitetes Produkt mit eigener Funktion und Verbrauchszeitpunkt. Eine Zusammenlegung wäre fachlich falsch.

## MAT-020 – Pflanzenöl, Rohöl und Waffenöl

**Entscheidung**
- Pflanzenöl (`res.misc.plant_oil`) bleibt in A8 als gepresster pflanzlicher Rohstoff.
- Rohöl (`res.misc.mineral_oil`) bleibt in A8 als unaufbereitetes geologisches Erdöl.
- Waffenöl (`consumable.maintenance.weapon_oil`) und hochwertiges Waffenöl (`consumable.maintenance.premium_weapon_oil`) bleiben in D5 als fertige Wartungs- und Pflegeverbrauchsgüter.
- Es wird kein separates raffiniertes Öl-Zwischenprodukt ergänzt, solange keine eigenständige Rezept- oder Spielmechanik dafür existiert.

**Begründung**  
Rohstoffe und formulierte Pflegeprodukte haben unterschiedliche Funktionen. D5-Produkte werden bei Anwendung verbraucht; A8-Öle sind Ausgangsmaterialien.

## MAT-021 – Tierfett und Speisefett

**Entscheidung**
- Tierfett (`res.animal.tallow`) bleibt in A6 als abgetrennter, grob gereinigter tierischer Rohstoff.
- Schmalz (`food.processed.lard`) wird neu in C3 angelegt. Es entsteht durch Ausschmelzen, Abseihen und gegebenenfalls Klären von Tierfett.

**Begründung**  
Die Verarbeitung erzeugt ein eigenständiges Speisefett. Damit sind Rohstoff und Lebensmittelprodukt sauber getrennt. Tierart und Qualitätsvarianten bleiben spätere Rezeptentscheidungen.

## MAT-022 – Lebensfluid, Uressenz und Essenz der Lebenskraft

**Entscheidung**
- Lebensfluid (`res.misc.lifefluid`) bleibt eine seltene, biologisch aktive Flüssigkeit in A8.
- Uressenz (`res.misc.primordial_essence`) bleibt eine einzigartige ursprüngliche Substanz in A8.
- Essenz der Lebenskraft (`food.special.vaelith_essence`) bleibt als nicht handelbare Lore-Ressource in C6.
- Die drei Items werden nicht zusammengelegt und nicht als austauschbare Stoffe behandelt.

**Offener Lore-Punkt**  
Die metaphysische Beziehung zwischen Lebensfluid, Uressenz und Vaeliths Essenz ist noch nicht festgelegt. Die C6-Zuordnung der Vaelith-Essenz bleibt eine dokumentierte Sonderzuordnung, da das Item ausdrücklich kein gewöhnliches Lebensmittel ist.

## MAT-023 – Naturbitumen und natürlicher Teer

**Entscheidung**
- Naturbitumen (`res.misc.natural_bitumen`) bleibt als geologischer Rohstoff aus Erdöl- und ölführenden Lagerstätten bestehen.
- Natürlicher Teer (`res.misc.natural_tar`) bleibt als organische natürliche Ablagerung bestehen. Er wird ausdrücklich von Holz durch trockene Destillation erzeugtem Teer unterschieden.

**Begründung und Vorbehalt**  
Die vorhandenen Beschreibungen unterscheiden die Herkunft. Die Anwendungsbereiche überschneiden sich jedoch. Die Trennung bleibt deshalb vorläufig an die spätere Definition eigenständiger Fundorte und Rezepte gebunden. Falls diese Unterschiede im Welt- und Produktionsdesign nicht bestehen, ist eine spätere Zusammenlegung sinnvoll.

## MAT-024 – Seilmaterial, Seil und Wurfseil

**Entscheidung**
- B5 behält Hanfseil, Flachsseil, Juteseil, Wurzelfaserseil, Tiefenfaserseil sowie Kordel- und Schnurprodukte als verarbeitete Materialprodukte.
- Das allgemeine Seil (`consumable.misc.rope`) wird nach E8 verschoben und als wiederverwendbarer Ausrüstungsgegenstand geführt.
- Das Wurfseil (`consumable.misc.grappling_rope`) wird ebenfalls nach E8 verschoben und als wiederverwendbares Expeditionsgerät geführt.
- Beide IDs bleiben aus Kompatibilitätsgründen unverändert; ihr historischer `consumable.misc`-Namespace wird dokumentiert.

**Begründung**  
B5-Produkte sind Materialinputs für Rezepte. Seil und Wurfseil sind einsatzfertige Gegenstände, die nach dem Einsatz geborgen und erneut verwendet werden können. Verbrauch oder Verlust tritt nur bei entsprechender Spielmechanik ein, nicht automatisch durch die Nutzung.

## Umgesetzte Katalogversionen

| Katalog | Neue Version | Änderung |
|---|---:|---|
| A6 Tierische Rohstoffe | 0.4 | Tierfett als Rohstoff präzisiert |
| A8 Sonstige natürliche Ressourcen | 0.3 | Öle, Wachse, Lebensfluid, Uressenz, Bitumen und Teer abgegrenzt |
| B5 Textilien und Seilmaterialien | 0.3 | Seil-/Schnurprodukte als verarbeitete Materialien präzisiert |
| C3 Verarbeitete Lebensmittel | 0.3 | Schmalz ergänzt |
| C6 Besondere Lebensmittel | 0.2 | Vaelith-Essenz als Lore-Ressource präzisiert |
| D5 Wartung und Pflege | 0.2 | Waffenöle als fertige Pflegeverbrauchsgüter präzisiert |
| D6 Sonstige Verbrauchsgüter | 0.3 | Siegelwachs präzisiert; Seil und Wurfseil verschoben |
| E8 Allgemeine Gebrauchsgegenstände | 0.3 | Seil und Wurfseil aufgenommen |

## Kompatibilität und Datenregeln

- Bestehende IDs bleiben erhalten.
- Die zwei verschobenen Seil-IDs behalten ihren historischen Namespace, um bestehende Referenzen nicht zu brechen.
- Basiswerte und Gewichte bleiben `null`.
- Katalogübergreifende Rezept- und Verwendungsreferenzen sollen die kanonische Item-ID verwenden.
- Der Registry-Index wird aus den aktiven Katalogen neu generiert und nicht separat gepflegt.

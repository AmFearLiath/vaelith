# Emberwild – Architekturentscheidung MAT-007 bis MAT-012

- Version: 1.0.0
- Status: Architekturentscheidung / Katalogänderungen umgesetzt
- Themenbereich: Lebensmittel und Rohzutaten

## Grundsatz

Jeder physische Gegenstand besitzt genau eine kanonische Item-ID und eine vollständige Definition in genau einem Heimatkatalog. Andere Kataloge dürfen den Gegenstand verwenden, aber keine zweite Inventaridentität dafür anlegen.

## MAT-007 – Ei

- Kanonische ID: `food.ingredient.egg`
- Heimatkatalog: C1 – Rohzutaten und Grundnahrungsmittel
- `res.animal.egg` wird als Migrationsalias auf `food.ingredient.egg` aufgelöst.
- Speiseeier sind Lebensmittel. Befruchtete Zuchteier benötigen bei Einführung einer Brutmechanik eine gesonderte Definition oder einen eigenen Zustand.

## MAT-008 – Frische Milch

- Kanonische ID: `food.ingredient.milk`
- Heimatkatalog: C1 – Rohzutaten und Grundnahrungsmittel
- `res.animal.milk` und `food.drink.milk` werden als Migrationsaliase auf `food.ingredient.milk` aufgelöst.
- Die Milch kann direkt getrunken und als Zutat verwendet werden. C5 enthält nur eigenständige Milchgetränke bzw. flüssige Erzeugnisse wie Buttermilch, Honigmilch und Molke.
- Kühlung, Haltbarkeit und mögliche spätere Behandlungsschritte bleiben Teil der Wirtschafts- und Produktionsdefinition.

## MAT-009 – Honig

- Kanonische ID: `food.ingredient.honey`
- Heimatkatalog: C1 – Rohzutaten und Grundnahrungsmittel
- `res.animal.honey` wird als Migrationsalias auf `food.ingredient.honey` aufgelöst.
- Honigwabe (`food.processed.honeycomb`) bleibt ein eigenständiger Gegenstand, da Wabe und Wachs zusätzliche Bestandteile darstellen.

## MAT-010 – Kräuter

- Heimatkatalog geernteter botanischer Kräuter: A4 – Pflanzen und Kräuter.
- Bestehende kanonische IDs: `res.plant.meadow_herb`, `res.plant.wild_mint`, `res.plant.wild_garlic`.
- Neu ergänzt: `res.plant.parsley`, `res.plant.thyme`.
- Die fünf C1-Dubletten werden als Aliase auf die A4-IDs migriert.
- Kräuter können in Rezepten als Zutaten verwendet werden, ohne eigene C1-Item-Definitionen zu benötigen.

## MAT-011 – Mehltypen

- Die fünf konkreten Sortenmehle in C1 bleiben kanonische Items: Weizenmehl, Roggenmehl, Gerstenmehl, Maismehl und Hafermehl.
- `food.processed.flour` wird entfernt. Die bisherige Beschreibung kennzeichnete den Eintrag ausdrücklich als abstrakte Sammeldefinition und nicht als zusätzliches Inventar-Item.
- Es wird kein Alias angelegt, da der Sammelbegriff keiner einzelnen Mehlsorte entspricht.
- Rezepte müssen eine konkrete Sorte oder eine später ausdrücklich definierte Auswahl zulässiger Sorten angeben.

## MAT-012 – Milchprodukte

- C1 bleibt auf unverarbeitete Grundzutaten ausgerichtet.
- Butter (`food.ingredient.butter`) und Frischkäse (`food.ingredient.cheese`) werden nach C3 verschoben; IDs bleiben erhalten.
- Rahm, Joghurt, gereifter Käse und Hartkäse bleiben in C3.
- Buttermilch, Honigmilch und Molke bleiben als eigenständige Getränke in C5.
- Herstellungsdetails wie Gerinnungsmittel, Milchkulturen und konkrete Fermentationsverfahren bleiben offen, wo sie im Katalog noch nicht definiert sind.

## Migration und Rückwärtskompatibilität

- Zusammengelegte IDs werden in der Item Registry als Aliase geführt.
- Verschobene Items behalten ihre IDs; nur der Heimatkatalog ändert sich.
- Der generische Mehl-Sammelbegriff wird als nicht inventarisierbare Definition stillgelegt und erhält keinen 1:1-Alias.
- Persistente Spielstände müssen alte IDs über die Alias-Auflösung auf die kanonischen IDs migrieren.
- `sources` und `uses` bleiben beschreibende Freitextfelder und sind keine maschinenlesbaren Rezeptreferenzen.

## Bewusst offen

- Befruchtete Zuchteier und Brutmechanik.
- Milchbehandlung, Kühlkette und Haltbarkeit.
- Lab/Gerinnungsmittel und Milchkulturen.
- Exakte Produktionsrezepte und Mengen.
- Basiswerte, Gewichte und wirtschaftliches Balancing.

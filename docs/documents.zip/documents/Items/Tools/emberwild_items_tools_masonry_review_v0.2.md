# Emberwild – E3 Stein- und Bauwerkzeuge v0.2

## Ergebnis

Der bestehende E3-Katalog wurde fachlich geprüft und als Version 0.2 fortgeführt. Der Katalog umfasst weiterhin 27 Items. Alle bestehenden Item-IDs bleiben stabil; es wurden keine Items gelöscht oder neu angelegt.

## Katalogumfang

- Steinbearbeitung: Hämmer, Fäustel, Meißel, Steinspalthammer, Steinmetzschlägel
- Oberflächenbearbeitung: Steinfeile und Steinpolierer
- Maurerarbeiten: Maurerkelle, Fugenkelle, Mörtelbrett, Ziegelzange, Ziegelschneider, Maurerhammer, Mörtelrührer
- Vermessung: Wasserwaage, Senklot, Messlatte und Richtscheit
- Spezialisierte Werkzeuge: Granitmeißel, Tiefensteinhammer, Kristallsteinmeißel, Steinmetzwerkzeugset und Tiefensteinmetzset

## Durchgeführte Änderungen

- `tool.masonry.stone_cutter`: Anzeigename von „Steinschlägel“ zu „Steinmetzschlägel“ präzisiert.
- `tool.masonry.deepstone_hammer`: Anzeigename von „Tiefensteinhämmer“ zu „Tiefensteinhammer“ korrigiert.
- Eindeutig vorhandene Quellmaterialien wurden auf kanonische Anzeigenamen vereinheitlicht: Metallstange, Metallblech, Holzbalken und Dunkelstahlbarren.
- Die Sammelbezeichnung „Messwerkzeuge“ im Steinmetzwerkzeugset wurde durch vorhandene E3-Werkzeuge ersetzt: Wasserwaage, Senklot, Messlatte und Richtscheit.
- Beschreibungen und Notizen wurden an den funktionalen Grenzen der Werkzeuge ausgerichtet.

## Abgrenzung zu anderen Werkzeugkatalogen

- E1: Abbau, Probenentnahme und Gewinnung natürlicher Ressourcen. E3: Bearbeitung und Formgebung von Stein sowie Bauarbeiten.
- E2: Holzverarbeitung und Zimmermannsarbeiten. E3-Messwerkzeuge beziehen sich auf Mauerwerk und Steinmetzarbeiten.
- E4: Metallbearbeitung. E3-Werkzeuge bearbeiten Stein und mineralische Bauteile.
- E7: Schmuck- und Spezialhandwerk. E3 umfasst Steinmetz- und Bauwerkzeuge.

Es wurden keine Dubletten festgestellt, die eine Zusammenlegung oder ID-Migration rechtfertigen.

## Offene Komponentenabhängigkeiten

Noch nicht als eigenständige kanonische Items vorhanden bzw. nicht eindeutig zuordenbar sind: Holzgriff, Metallgriff, Harter Schleifstein, Poliermaterial, Stahlkante, allgemeines Glas und Metallgewicht. Diese Begriffe bleiben vorerst als Quellenangaben bestehen. Insbesondere wird „Harter Schleifstein“ nicht automatisch mit dem D5-Schleifstein gleichgesetzt, da dessen Definition auf das Schärfen und Pflegen von Klingen ausgerichtet ist.

## Balancing und Produktionsdaten

Basiswerte und Gewichte bleiben `null`. Mengen, Haltbarkeit, Herstellungszeiten, Arbeitswerte und konkrete Rezeptmengen werden nicht vorweggenommen. Diese Daten gehören in die spätere Produktions- und Balancingplanung.

## Dateien

- `Items/Tools/emberwild_items_tools_masonry_v0.2.json`
- `Items/Tools/emberwild_items_tools_masonry_v0.2_migration_notes.json`
- `Items/Tools/emberwild_items_tools_masonry_source_dependency_report_v0.2.json`
- `Items/Planning/emberwild_item_registry_v1.7.json`

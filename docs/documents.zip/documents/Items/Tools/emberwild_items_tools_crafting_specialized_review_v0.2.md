# Emberwild – E7 Handwerks- und Spezialwerkzeuge

**Katalogversion:** 0.2  
**Status:** Draft / Review abgeschlossen  
**Ausgangsbasis:** E6-Gesamtarchiv, E7 v0.1 und Registry v2.0

## Prüfergebnis

- 36 Items geprüft und übernommen.
- 36 stabile Item-IDs; keine neuen IDs und keine Löschungen.
- Zwei Anzeigenamen präzisiert: `Sattlerwerkzeug` → `Sattlerwerkzeugset`; `Glasbläserwerkzeug` → `Glasbläserwerkzeugset`.
- Keine katalogübergreifenden Item-Dubletten in den aktiven Katalogdateien gefunden.
- Keine Migrationsaliase erforderlich.
- Keine Änderungen an Basiswerten, Gewichten, Seltenheit oder Qualität.

## Fachliche Abgrenzung

- **Textilhandwerk:** Stoffschere, Nähnadel, Nadelset, Maßband, Schneiderkreide, Webschiffchen und Handspindel erfüllen unterschiedliche Funktionen. Webschiffchen und Webstuhl bzw. Handspindel und stationäres Spinnrad bleiben Handwerkzeug und Betriebsausstattung.
- **Lederhandwerk:** Lederahle, Lederstanze, Lederhammer und Lederschneidmesser bleiben getrennt. Das Sattlerwerkzeugset bündelt ausgewählte Werkzeuge, ersetzt aber nicht deren Einzeldefinitionen.
- **Töpferei:** Töpferspachtel, Modellierwerkzeugset, Tonmesser und Töpferdraht bleiben eigenständige Werkzeuge. Brennen und stationäre Töpfereiausstattung sind nicht Bestandteil dieser Items.
- **Glasherstellung:** Glasbläserpfeife und Glasmacherzange dienen der Arbeit mit heißer Glasmasse; der Glasschneider bearbeitet abgekühlte Glasplatten. Das Glasbläserwerkzeugset ist ein transportables Bündel und keine Produktionsstätte.
- **Alchemie:** Mörser und Stößel, Destillierwerkzeugset, Retorte, Waage und Pipette bleiben funktional getrennt. Stationäre Heiz- und Auffangvorrichtungen sind nicht automatisch Teil der Werkzeuge.
- **Juwelierhandwerk:** Juwelierhammer, Fasszange, Edelsteinhalter und Polierwerkzeug haben unterschiedliche Bearbeitungsaufgaben.
- **Buchbinderei:** Falzbein, Buchbinderahle und Buchbinderpinsel bleiben getrennt. Die Buchbinderahle wird nicht mit der Lederahle zusammengelegt.
- **Spezialwerkzeuge:** Resonanzstimmwerkzeug, Essenzdosierer und Kristallspannhalter werden als Werkzeuge ohne behauptete eigenständige Magiewirkung geführt.

## Offene Abhängigkeiten

Neun `crafting_station.*`-Kennungen sind nicht durch einen verbindlichen Stationskatalog aufgelöst. Sie wurden nicht durch `facility.*`-Vorschläge ersetzt, da der Produktionsstätten-Seed ausdrücklich nur eine Planungsliste ist.

Verschleiß, Bruch, Reparatur, Werkzeugmaterialien, Qualitätswirkung, Skillanforderungen und Produktionswerte bleiben offen.

## Validierung

- JSON-Syntax aller neuen JSON-Dateien geprüft.
- Item-IDs auf Eindeutigkeit geprüft.
- Alle 36 E7-Items im Registry-Index abgeglichen.
- Basiswerte und Gewichte unverändert `null`.

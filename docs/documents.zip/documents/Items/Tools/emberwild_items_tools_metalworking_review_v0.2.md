# E4 – Metallbearbeitungswerkzeuge v0.2 – Review

## Ergebnis

Der bestehende Katalog mit 29 Items wurde vollständig geprüft. Alle 29 Item-IDs bleiben unverändert; es wurden keine Items hinzugefügt, entfernt oder zusammengeführt.

## Funktionale Abgrenzungen

- Hämmer: allgemeiner Schmiedehammer, leichter Handhammer, schwerer Schmiedehammer, Kreuzschlaghammer und Rundhammer erfüllen unterschiedliche Aufgaben.
- Zangen: Grund-Schmiedezange, Flachmaul-, Rundmaul-, Glüh- und Tiegelzange bleiben getrennt.
- Ambosse: stationärer Schmiedeamboss und kompakter Handamboss sind keine Dubletten.
- Schneidwerkzeuge: Metallmeißel, Metallsäge und Metallschere haben unterschiedliche Einsatzbereiche.
- Bohrwerkzeuge: Metallbohrer bezeichnet das Schneidwerkzeug, Handbohrmaschine das vollständige Gerät.
- Guss: Schmelztiegel, Metallgussform, Barrenform und Tiegelzange bleiben getrennte Werkzeuge.
- Finish: Metallfeile, Präzisionsfeilenset, Metallschaber und Metallpolierset bleiben getrennt.
- Spezialwerkzeuge: Dunkelstahl-, Resonanz- und ätherische Werkzeuge bleiben an ihre jeweiligen Material-/Technologiestufen gebunden.

## Offene Quellenabhängigkeiten

Die vollständige Liste einschließlich betroffener Item-IDs und Begründungen liegt in `emberwild_items_tools_metalworking_source_dependency_report_v0.2.json`. Besonders offen sind gehärteter Werkzeugstahl, Metallsägeblatt, Zahnräder, mineralische Zuschlagstoffe, Formmaterial, Poliermaterial und feinmechanische Komponenten. Resonanzkristall, Äthermetall und Tiefenwurzelholz wurden gegen den kanonischen Bestand bestätigt.

## Änderungen gegenüber v0.1

- Quellenbezeichnungen an vorhandene kanonische Materialien angeglichen, soweit eindeutig.
- Funktionsbeschreibungen und Abgrenzungen präzisiert.
- Stationärer Amboss und gebündeltes Schmiedewerkzeugset explizit eingeordnet.
- Keine Item-IDs geändert; keine Dubletten durch stillschweigende Zusammenlegung entfernt.
- `base_value` und `weight` bleiben `null`.

## Freigabestatus

`draft` – Katalogstruktur und Identitäten sind konsistent; einzelne Materialabhängigkeiten benötigen noch kanonische Definitionen oder Bestätigung.

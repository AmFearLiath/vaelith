# E8 – Allgemeine Gebrauchs- und Spezialgegenstände v0.3 – Review

## Ergebnis
- 59 Items geprüft und übernommen.
- Sämtliche Item-IDs unverändert.
- Die beiden E5-Migrationsziele sind vorhanden und kanonisch: `goods.general.wicker_basket` (Flechtkorb) und `goods.general.wooden_bucket` (Holzeimer).
- Keine ID-Kollisionen innerhalb des Katalogs oder im zentralen Registry-Index.
- Keine katalogübergreifenden Namensdopplungen mit E8-Beteiligung festgestellt.
- Keine zusätzlichen Aliase oder Dublettenmigrationen erforderlich.

## Katalog-Metadaten
Die Datei `emberwild_items_tools_general_goods_v0.3.json` und der Registry-Eintrag wiesen bereits Version 0.3 aus. Innerhalb der JSON-Datei standen `catalog_version` und `version` jedoch noch auf 0.2. Beide Metadaten wurden auf 0.3 korrigiert. Die 59 Itemdefinitionen wurden inhaltlich nicht verändert.

## Abgrenzung
Der Katalog führt allgemeine, wiederverwendbare Gebrauchsgegenstände, Behälter, Haushalts- und Reiseausstattung, Möbel, Transporthilfen sowie Expeditionsausrüstung. Verbrauchsgüter und Materialien bleiben eigenständige Items; wiederverwendbare Behälter und Ausrüstungsgegenstände werden nicht mit ihrem Inhalt oder Verbrauchsmaterial gleichgesetzt.

## Migrationsprüfung
- `tool.agriculture.harvesting_basket` → `goods.general.wicker_basket` (Flechtkorb): Ziel vorhanden.
- `tool.agriculture.water_bucket` → `goods.general.wooden_bucket` (Holzeimer): Ziel vorhanden.
- Die vorhandenen Alias-Einträge bleiben unverändert.
- Die E8-Übernahmen aus D6 für Feuersteinset, Seil und Wurfseil bleiben bestehen.

## Offene Abhängigkeiten
- 59 Itemdefinitionen enthalten insgesamt 80 Quellenreferenzen auf 18 unterschiedliche Quellenkennungen.
- Die Quellenkennungen sind nicht durch einen verbindlichen Stationskatalog vollständig aufgelöst.
- Fassungsvermögen, Lagerkapazitäten, Belastungsgrenzen, Traglast- und Inventarwirkungen bleiben offen.
- Wasserfilterfunktion und Filterwechsel, Behälterdichtigkeit und Lebensmitteleignung sowie Schlaf-, Licht- und Möbelinteraktionen benötigen spätere Systemdefinitionen.
- Herstellungsrezepte, Materialkomponenten und Produktionswerte bleiben unbalanciert.

## Versions- und Registry-Status
- E8: 0.3 (Entwurfsstatus)
- Zentrale Registry: 2.1.0 (unverändert)
- Die Registry enthält 59 E8-Items; alle stimmen mit dem Katalog überein.
- Keine Änderungen an Item-IDs, Aliases oder Registry-Einträgen erforderlich.

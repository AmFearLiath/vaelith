# Emberwild – E6 Jagd-, Fischerei- und Tierhaltungswerkzeuge

**Katalogversion:** 0.3  
**Status:** Entwurf / geprüft  
**Grundlage:** Gesamtarchiv E5, Registry v1.9.0 und Materialabgrenzungsregister v1.5

## 1. Prüfumfang

- Alle 36 Items aus E6 v0.2
- Bestehende Migration Notes zu MAT-015
- Katalogabgrenzung zu E1, E3, E4, E5, E7 und E8
- Bündelreferenzen innerhalb der Jagd-, Fischerei- und Tierhaltungsausrüstung
- Exakte kanonische Quellenauflösung anhand der aktiven Item Registry

## 2. Änderungen in v0.3

- `tool.fishing.fishing_tool_set`: Quellenreferenz `Fangnetz` durch `Fischernetz` ersetzt.
- `tool.fishing.cast_net`: Schreibfehler `Fischschwärfe` zu `Fischschwärme` korrigiert.
- Keine Item-IDs geändert.
- Keine Items hinzugefügt oder entfernt.
- Keine Alias-Zuordnungen erforderlich.

## 3. Katalogabgrenzung

### Jagd

Jagdmesser, Häutungsmesser, Fleischermesser, Knochensäge, Aufbrechset, Aufbrechhaken, Fährtenleserset und Fangvorrichtungen bleiben E6 zugeordnet. Die Katalogfunktion umfasst Jagd, Versorgung erlegter Tiere und spezialisierte Fangmethoden.

### Fischerei

Angelrute, verstärkte Angelrute, Angelhakenset, Fischernetz, Wurfnetz, Fischreuse, Fischspeer, Fischmesser und Fischschupper bleiben eigenständige Geräte. Netzgeflechte und Seile sind Materialkomponenten und keine fertigen Fanggeräte.

### Tierhaltung

Futtertrog, Wassertrog, Melkeimer, Melkschemel, Milchsieb, Tierpflegebürste, Wollschere, Klauenmesser, Tierführleine, Tierhalfter, Eiersammelkorb und Imkerwerkzeug bleiben tierhaltungsspezifische Werkzeuge bzw. Ausstattungsgegenstände.

### Abgrenzung zu anderen Katalogen

- E1: allgemeine Wildsammlung und Rohstoffgewinnung; E6 umfasst Jagd, Fischfang und tierbezogene Arbeit.
- E3/E4: Bau- und Metallbearbeitungswerkzeuge; E6 enthält fertige Spezialgeräte für Jagd, Fischerei und Tierhaltung.
- E5: Kulturpflege und Ernte von Nutzpflanzen; E6 enthält Tierhaltung und Fischerei.
- E7: allgemeine Handwerks- und Spezialwerkzeuge; E6-Geräte sind funktionsgebunden.
- E8: allgemeine Gebrauchsgegenstände. Der spezialisierte Melkeimer und der gepolsterte Eiersammelkorb behalten ihre eigene Funktion; allgemeine Behälter werden nicht dupliziert.

## 4. Set-Referenzen

- Jagdausrüstung referenziert Jagdmesser, Häutungsmesser, Aufbrechhaken und Fährtenleserset.
- Fischereiausrüstung referenziert Angelrute, Angelhakenset, Fischmesser und Fischernetz.
- Tierhaltungsausrüstung referenziert Tierpflegebürste, Futtertrog, Wassertrog und Tierführleine.

Sets sind Bündel bestehender Items und keine eigenständigen Material- oder Produktionsdefinitionen.

## 5. Quellenabhängigkeiten

Der begleitende Dependency Report löst Quellenbezeichnungen nur dann auf, wenn ein eindeutiger exakter Name in der aktiven Registry existiert. Nicht aufgelöste Komponentenbezeichnungen bleiben offen. Daraus werden keine Rezepte, Mengen, Materialvarianten oder Herstellungsprozesse abgeleitet.

## 6. Balance- und Datenregeln

- Alle 36 Item-IDs bleiben stabil.
- Basiswerte und Gewichte bleiben `null`.
- Haltbarkeit, Fangraten, Verbrauch, Produktionszeiten und Herstellkosten bleiben unbestimmt.
- Seltenheit und Qualität werden nicht neu balanciert.
- Die vorhandene E6-Migration zu MAT-015 bleibt gültig.

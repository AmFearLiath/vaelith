# E5 – Landwirtschafts- und Erntewerkzeuge v0.3 – Review

## Ergebnis

Der bestehende E5-Katalog mit 33 Items wurde vollständig geprüft. Zwei katalogübergreifende Doppeldefinitionen wurden aufgelöst; 31 kanonische E5-Items bleiben bestehen. Für beide entfernten E5-IDs wurden dauerhafte Registry-Aliase eingerichtet. Keine der verbleibenden E5-Item-IDs wurde geändert.

## Katalogübergreifende Abgrenzungen

- **E1 – Rohstoffgewinnung:** Die allgemeine Schaufel bleibt in E1 kanonisch; die historische E5-Schaufel-ID verweist weiterhin per Alias auf `tool.gathering.shovel`. Die Sichel bleibt in E5 kanonisch; die historische E1-Sichel-ID verweist per Alias auf `tool.agriculture.sickle`.
- **E1 – Wildsammlung:** Wurzelgabel und Pilzernte-Messer in E5 sind auf angebaute Wurzelgemüse und gezielt kultivierte Pilze begrenzt. Wurzelstecher, Sammelmesser und Tiefensammlermesser in E1 bleiben Werkzeuge zur Entnahme wild wachsender Ressourcen.
- **E3/E4 – Stein- und Metallbearbeitung:** E5 beschreibt den landwirtschaftlichen Einsatzzweck der Werkzeuge. Herstellung und Bearbeitung der Stein- und Metallkomponenten bleiben außerhalb von E5.
- **E6 – Jagd, Fischerei und Tierhaltung:** Mistgabel bleibt auf Stallpflege und das Ausbringen von Mist ausgerichtet. Tierpflege, Melken, Scheren und Fischerei bleiben E6 zugeordnet.
- **E8 – Allgemeine Gebrauchsgegenstände:** Der E5-Erntekorb wird auf den kanonischen E8-Flechtkorb abgebildet. Der E5-Wassereimer wird auf den kanonischen E8-Holzeimer abgebildet. Beide E8-Gegenstände decken die beschriebenen landwirtschaftlichen Verwendungen bereits ab.
- **E7 – Spezialhandwerk:** Keine identische Werkzeugfunktion oder zweite Definition festgestellt.

## Funktionale Abgrenzungen innerhalb E5

- **Bodenbearbeitung:** Holzhacke, Eisenhacke, Stahlhacke und Tiefenkulturhacke bilden unterschiedliche Material- und Einsatzstufen. Pflug und Handpflug unterscheiden sich durch Arbeitsfläche und Bedienung.
- **Pflanzarbeiten:** Pflanzspaten dient dem Umsetzen von Jungpflanzen mit Wurzelballen; Gartenkelle dient kleinen Pflanz- und Beetarbeiten.
- **Ernte:** Sichel ist das handgeführte Schneidwerkzeug; Sense ist für größere Mengen ausgelegt. Obstpflücker dient der schonenden Ernte höher gelegener Früchte.
- **Pflanzenpflege:** Gartenschere, Heckenschere, Veredelungsmesser und Wurzelnetzschere besitzen unterschiedliche Schnitt- und Pflegeaufgaben.
- **Bodenpflege:** Erdsieb bereitet Substrat auf; Saatgutsieb sortiert Saatgut. Kompostgabel wendet Kompost; Mistgabel dient Stall- und Düngearbeiten.
- **Unterweltkulturen:** Tiefenkulturhacke, Pilzernte-Messer und Wurzelnetzschere bleiben auf besondere Unterweltkulturen und deren Pflege begrenzt.
- **Resonanzernte:** Resonanz-Pflanzenmesser dient der kontrollierten Ernte empfindlicher resonanter Pflanzen und erzeugt keine zusätzlichen Ressourcen.
- **Werkzeugsets:** Erntewerkzeugset und Landwirtschaftswerkzeugset bündeln bestehende Items und erzeugen keine zusätzlichen Item-Identitäten.

## Aufgelöste Doppeldefinitionen

| E5-Legacy-ID | Kanonische Ziel-ID | Entscheidung |
|---|---|---|
| `tool.agriculture.harvesting_basket` | `goods.general.wicker_basket` | Erntekorb wird als Alias auf Flechtkorb geführt |
| `tool.agriculture.water_bucket` | `goods.general.wooden_bucket` | Wassereimer wird als Alias auf Holzeimer geführt |

Die beiden Legacy-IDs bleiben in der Registry als `migration_required: true` auflösbar. Die Ziel-Items verbleiben in E8.

## Offene Quellenabhängigkeiten

Der vollständige Bericht liegt in `emberwild_items_tools_agriculture_source_dependency_report_v0.3.json`. 22 Quellbezeichnungen konnten anhand exakter Itemnamen auf kanonische Items abgebildet werden. 20 Quell-/Bauteilbezeichnungen bleiben offen, darunter Zahnräder, Steinklinge, Klingen- und Griffbauteile, Rahmen, Gitter sowie materialbezogene Varianten wie Eisenblech und Dunkelstahl.

Diese offenen Bezeichnungen werden nicht durch angenommene Item-IDs ersetzt. Die betreffenden Komponenten benötigen eine spätere Material- oder Bauteilentscheidung.

## Änderungen gegenüber v0.2

- Erntekorb und Wassereimer aus E5 entfernt und als Legacy-Aliase auf E8-Flechtkorb bzw. E8-Holzeimer abgebildet.
- Referenzen in Erntewerkzeugset und Landwirtschaftswerkzeugset auf kanonische Gegenstände umgestellt.
- Wurzelgabel und Pilzernte-Messer von der Wildsammlung in E1 abgegrenzt.
- Pflanzspaten und Gartenkelle sowie Kompostgabel und Mistgabel funktional präzisiert.
- Metallstangen auf den kanonischen Materialnamen Metallstange vereinheitlicht.
- Keine neuen Item-IDs angelegt; 31 bestehende E5-IDs unverändert beibehalten.
- `base_value` und `weight` bleiben `null`.

## Freigabestatus

`draft` – Die kanonischen Item-Identitäten und Kataloggrenzen sind konsistent. Die offenen Bauteil- und Materialabhängigkeiten bleiben dokumentiert; Werte und Produktionsdaten sind weiterhin nicht balanciert.

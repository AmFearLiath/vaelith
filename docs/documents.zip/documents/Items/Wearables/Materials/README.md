# Emberwild – Material-Katalog 1.0.0

## Zweck
Zentrale, ID-basierte Materialbibliothek für Waffen, Schilde, Rüstungen, Schmuck, Munition, Edelsteine, Verzauberungen und Herstellungsrezepte.

## Inhalt
- `materials.json`: 35 Rohstoffe und verarbeitete Komponenten.
- `material_groups.json`: Materialgruppen und Familien.
- `material_processing.json`: Regeln und Referenzmuster für Verarbeitung.
- `material_rules.json`: Materialdimensionen, Seltenheit, Profile und Qualitätsinteraktion.
- `equipment_quality.json`: Referenz auf das gemeinsame 7-Stufen-Qualitätssystem.
- `manifest.json`: Version, Dateiliste, ID-Schema und zentrale Referenzen.
- `validation_report.json`: Struktur- und Integritätsprüfung.

## Materialgruppen
- Holz
- Erze und Metalle
- Gestein und Mineralien
- Häute
- Fasern und Textilien
- Knochen und organische Werkstoffe
- Alchemistische und magische Reagenzien
- Verarbeitete Komponenten

## Wichtige Trennungen
- **Seltenheit ist keine Qualität.** Ein seltenes Material erzeugt nicht automatisch ein hochwertiges Endprodukt.
- **Rohstoff ist nicht Komponente.** Beispielsweise sind Eisenerz und Eisenbarren eigenständige Materialdefinitionen.
- **Magische Affinität ist kein Zauberwert.** Sie beschreibt eine relative Resonanz und wird erst durch Rezepte oder zentrale Eigenschaftssysteme ausgewertet.
- **Materialprofile überschreiben keine Itemwerte.** Das jeweilige Rezept entscheidet, wie Härte, Flexibilität, Dichte, Affinität und Materialqualität einfließen.
- **Qualität bleibt deterministisch.** Identische Rezepte, Materialeingaben und NPC-Voraussetzungen ergeben identische Ergebnisse.

## IDs
Material-IDs folgen dem Schema `material.{canonical_path}.{stable_suffix}`. Die ID bleibt nach Registrierung unverändert. Umbenennung oder Umklassifizierung ändert die ID nicht.

## Werte
Physische Profile und magische Affinität sind relative Ausgangswerte (0–100), keine direkten Prozentwerte und keine finalen Schadens- oder Widerstandswerte. Ihre Wirkung wird durch Rezepte und die zentralen Item-/Eigenschaftssysteme bestimmt.

## Abgrenzung
Dieses Paket definiert Materialien und Verarbeitungsgrundlagen. Vollständige Mengen, Ausbeuten, Produktionszeiten, Kosten und konkrete Verarbeitungsschritte gehören in den späteren Rezeptkatalog.

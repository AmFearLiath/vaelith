# Emberwild – Waffen-Katalog 1.0.0

## Inhalt
- `weapons.json`: 24 konkrete Waffen-Definitionen.
- `weapon_families.json`: Waffenfamilien und Untertypen.
- `weapon_proficiency.json`: Familien- und Untertyp-Proficiency.
- `weapon_techniques.json`: Basis- und fortgeschrittene Waffentechniken.
- `combat_rules.json`: Gemeinsame Kampfgrundsätze.
- `equipment_quality.json`: Verbindliche sieben Qualitätsstufen.
- `validation_report.json`: Struktur- und Referenzprüfung.
- `manifest.json`: Version, Dateiliste, ID-Regeln und externe Katalogschlüssel.

## Festgelegte Systemregeln
- Freie Waffenwahl; Attribute beeinflussen Effektivität, sperren Waffen aber nicht pauschal.
- Proficiency besteht aus Waffenfamilie und Untertyp.
- Proficiency wächst durch Verwendung und zusätzliches Training.
- Grundtechniken werden über Proficiency freigeschaltet; fortgeschrittene Techniken werden gezielt erlernt.
- Kampf ist ein Hybrid aus freien Aktionen und Kombinationsfolgen.
- Ausweichen ist grundsätzlich verfügbar; Blocken und Parieren sind waffen-/schildabhängig.
- Waffen und Magie können zu kombinierten Techniken verbunden werden.
- Stamina- und Manakosten sind aktions-/technikabhängig.
- Haltbarkeit ist standardmäßig aktiv, kann aber pro Gegenstandsdefinition deaktiviert werden.
- Qualität, Material, Seltenheit, Verzauberung, Sockel und Aufwertung bleiben getrennte Dimensionen.

## Werte und Balancing
`base_damage`, `attack_speed`, `reach`, `precision`, `stamina_cost_multiplier` und `critical_potential` sind relative Basiseinheiten. Die Werte bilden eine konkrete Startbasis und müssen im späteren Combat-Balancing getestet werden.

## Externe Kataloge
Munition, Attribute und Magiedomänen werden in eigenen Katalogpaketen geliefert. Bis dahin verwenden Waffen stabile `catalog_key`-Verweise statt vorgetäuschter Item-IDs.

## ID-Format
`weapon.{hand_usage}.{family}.{subtype}.{stable_suffix}`

Der Suffix ist deterministisch aus dem kanonischen Pfad gebildet. Die ID wird vor Registrierung erzeugt und bleibt danach unveränderlich.

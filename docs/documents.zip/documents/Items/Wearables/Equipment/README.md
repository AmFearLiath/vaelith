# Emberwild – Rezepte und Ausrüstungssets 1.0.0

## Inhalt
- `crafting_recipes.json`: 14 konkrete Ausrüstungsrezepte.
- `equipment_sets.json`: 3 Ausrüstungssets mit 2-/3-/5-Teile-Boni.
- `quality_calculation.json`: deterministisches Qualitätsprofil mit sieben Stufen.
- `equipment_set_rules.json`: Setzählung, Aktivierung und Bonusregeln.
- `equipment_service_integrations.json`: Schnittstellenverträge für Herstellung, Reparatur, Aufwertung, Verzauberung und Sockeldienstleistungen.
- `catalog_import_references.json`: Katalogversionen und exakte IDs der referenzierten Definitionen.
- `manifest.json`: Version, Dateiliste und ID-Regeln.
- `validation_report.json`: Referenz- und Integritätsprüfung.

## Herstellung
- Herstellung schlägt nicht fehl. Es gibt keine zufälligen Fehlschläge und keinen Materialverlust durch fehlgeschlagene Herstellung.
- Qualität wird deterministisch aus Rezept, Materialeingaben und NPC-Fähigkeiten berechnet.
- Identische Eingaben und identischer NPC-Zustand ergeben identische Qualität.
- Materialseltenheit ist nicht gleich Herstellungsqualität.
- Rezepte definieren Materialkompatibilität, Mengen, Produktionsstation, Schwierigkeit und erreichbare Qualitätsobergrenze.
- Zusätzliche Eigenschaften sind nur möglich, wenn Rezept, Material, Qualität oder NPC-Fähigkeiten sie ausdrücklich erlauben.

## Qualitätsberechnung
Der Score setzt sich aus Rezeptbasis, Materialbeitrag und NPC-Beiträgen zusammen: Profession, Erfahrung, Spezialisierung, individuelle Fähigkeiten und Eigenschaften. Die sieben Qualitätsstufen entsprechen dem gemeinsamen System: Einfach, Normal, Gut, Hervorragend, Hervorragend+, Meisterhaft und Meisterhaft+. Schwellen und Basiswerte sind erste Kalibrierungswerte und müssen später balanciert werden. Die rezeptabhängige Qualitätsobergrenze bleibt verbindlich.

## Ausrüstungssets
- Setstücke werden über exakte Item-IDs referenziert.
- Nur ausgerüstete Instanzen zählen; jede gültige Instanz zählt einzeln.
- Setboni werden bei Ausrüstungsänderungen neu berechnet.
- Setboni addieren sich vollständig mit anderen Quellen.
- Sets erzeugen keine Klassen- oder Rollenbeschränkungen.

## NPC-Integration
Das bereits bestehende NPC-Entwicklungs- und Dienstleistungssystem bleibt maßgeblich. Dieses Paket definiert nur Integrationsverträge und baut keine NPC-Professionen oder NPC-Entwicklung neu auf. Spieler beauftragen NPCs; Spezialarbeiten werden nicht vom Spieler selbst ausgeführt.

## Umfang
Die 14 Rezepte bilden einen konkreten Startbestand repräsentativer Waffen-, Schild-, Rüstungs- und Schmucktypen. Sie behaupten nicht, bereits jedes Item des Gesamtkatalogs craftbar zu machen. Weitere Rezepte können ergänzt werden, ohne bestehende Item-IDs zu verändern.

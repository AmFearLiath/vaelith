# Emberwild – Schild-Katalog 1.0.0

## Inhalt
- `shields.json`: 10 konkrete Schilddefinitionen.
- `shield_families.json`: Schildfamilien und Untertypen.
- `shield_proficiency.json`: Familien- und Untertyp-Proficiency.
- `shield_techniques.json`: Basis- und fortgeschrittene Schildtechniken.
- `shield_combat_rules.json`: Schild- und Handhabungsregeln sowie Wertebedeutung.
- `equipment_quality.json`: Referenz auf das gemeinsame 7-Stufen-Qualitätssystem.
- `validation_report.json`: Struktur- und Referenzprüfung.
- `manifest.json`: Version, Dateiliste, ID-Regeln und Katalogreferenzen.

## Systemregeln
- Schilde belegen die zweite Hand und keinen separaten Rüstungsslot.
- Schilde sind grundsätzlich mit geeigneten Einhandwaffen kombinierbar.
- Zweihandwaffen und Dual Wield sind grundsätzlich nicht mit einem Schild kombinierbar.
- Blocken, Parieren, Schildstoß, Deckung und Verankerung sind unterschiedliche Einsatzweisen.
- Schild-Proficiency ist getrennt von Waffen-Proficiency.
- Attribute beeinflussen die Effektivität, führen aber nicht zu pauschalen Ausrüstungssperren.
- Haltbarkeit ist standardmäßig aktiv und pro Definition abschaltbar.
- Qualität, Material, Seltenheit, Verzauberung, Sockel und Aufwertung bleiben getrennte Dimensionen.

## Werte
Alle Werte sind relative Basiseinheiten. `coverage` ist ausdrücklich kein direkter Schadensreduktions-Prozentsatz. Die Werte dienen als konsistente Startbasis und müssen im späteren Combat-Balancing getestet werden.

## IDs
`shield.off_hand.{family}.{subtype}.{stable_suffix}`

Der Suffix wird deterministisch aus dem kanonischen Pfad gebildet. Registrierte IDs bleiben unveränderlich.

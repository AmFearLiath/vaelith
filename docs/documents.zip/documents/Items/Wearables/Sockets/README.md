# Emberwild – Edelsteine und Sockelgegenstände 1.0.0

## Inhalt
- `socketables.json`: 24 zentrale Socketable-Definitionen.
- `socket_types.json`: fünf Sockeltypen und zuständige NPC-Service-Referenzen.
- `socketable_families.json`: Typen, Familien und Untertypen.
- `socket_rules.json`: Kompatibilitäts-, Einsetz- und Entnahmeregeln.
- `equipment_quality.json`: Referenz auf das zentrale Qualitätssystem.
- `manifest.json`: Version, IDs, Dateiliste und zentrale Referenzen.
- `validation_report.json`: Struktur- und Referenzprüfung.

## Enthaltene Typen
- Edelsteine
- Runen
- Kristalle
- Fragmente
- Seelensteine

## Sockelregeln
Die Anzahl, Positionen, erlaubten Typen sowie Gesamt- und Typgrenzen werden ausschließlich durch das Sockellayout des jeweiligen Gegenstands bestimmt. Dieses Paket definiert keine pauschale Sockelanzahl für Waffen, Rüstungen oder Schmuck.

Ein Socketable darf nur eingesetzt werden, wenn Sockeltyp und Kompatibilitätsregeln des Gegenstands erfüllt sind.

## NPC-Dienstleistungen
Einsetzen und Entfernen erfordern einen qualifizierten NPC. Spieler können diese Arbeiten nicht selbst durchführen. Die zuständige Profession oder Spezialisierung richtet sich nach Sockeltyp und Trägergegenstand. Kosten und mögliche Folgen der Entfernung werden durch Dienstleistungsregeln und Rezepte festgelegt.

## Bonusverhalten
- Modifikatoren sind typisierte Ausgangswerte.
- Gleichartige Boni addieren sich vollständig.
- Es gibt keine automatische abnehmende Wirkung und keinen globalen Bonusdeckel.
- Die endgültige Auswertung erfolgt durch zentrale Attribut-, Ressourcen-, Kampf-, Magie- und Widerstandssysteme.

## Abgrenzung
Socketables sind unabhängig von Seltenheit und Herstellungsqualität des Trägergegenstands. Verzauberungen, klassische Aufwertungen, Materialeigenschaften und Setboni bleiben separate Systeme.

## Balancing
Die Werte sind konkrete Startwerte für einen späteren Balancing-Durchlauf. Sie sind keine abschließend getesteten Kampfwerte.

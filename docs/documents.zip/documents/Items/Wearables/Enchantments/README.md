# Emberwild – Verzauberungen und Eigenschaften 1.0.0

## Zweck
Zentrale Bibliothek für wiederverwendbare Eigenschaften, Modifikatoren, Effekte, Statuszustände sowie konkrete Verzauberungsdefinitionen. Eigenschaften werden einmal definiert und in Items, Socketables, Verzauberungen und Fähigkeiten über IDs referenziert.

## Inhalt
- `properties.json`: zentrale Definitionen für Attribute, Ressourcen, Kampfwerte, Magie, Widerstände, Trigger-Effekte und Statuszustände.
- `enchantments.json`: konkrete Verzauberungen mit Kompatibilitäts- und Dienstleistungsregeln.
- `effect_execution_rules.json`: Ausführungs-, Trigger- und Statusregeln.
- `enchantment_compatibility.json`: Regeln für Kompatibilität, Slots, Austausch und NPC-Dienstleistungen.
- `property_categories.json`: Kategorien und Typisierung.
- `equipment_quality.json`: Referenz auf das zentrale Qualitätssystem.
- `manifest.json`: Version, ID-Schema und zentrale Referenzen.
- `validation_report.json`: Integritätsprüfung.

## Trennung der Ebenen
- **Eigenschaft:** wiederverwendbare Definition eines Wertes oder Verhaltens, z. B. Manaregeneration oder Feuerwiderstand.
- **Effekt:** beschreibt eine ausgelöste Wirkung, z. B. Verbrennung bei Treffer.
- **Status:** zentral definierter Zustand, z. B. Brennend, Vergiftet oder Gestärkt.
- **Verzauberung:** konkrete, auf einen Gegenstand angewendete Zusammenstellung von Eigenschaften und/oder Effekten.

Die Definition einer Eigenschaft wird nicht in jeder Verzauberung kopiert. Verzauberungen referenzieren die zentrale Property-ID und führen nur ihre konkreten Parameter.

## Verzauberungsregeln
- Kompatibilität richtet sich nach Gegenstandstyp, Material, vorhandenen Eigenschaften, freien Verzauberungsplätzen und individuellen Gegenstandsregeln.
- Die Anzahl der Verzauberungsplätze wird durch die Itemdefinition und das Rezept festgelegt. Sie wird nicht aus Seltenheit, Qualität oder Sockelanzahl abgeleitet.
- Anwenden, Entfernen und Modifizieren erfordern qualifizierte NPCs.
- Verzauberungen sind unabhängig von Qualität, Material, klassischen Aufwertungen und Sockelgegenständen.

## Stapelung und Ressourcen
- Gleichartige Boni addieren sich vollständig.
- Keine automatische abnehmende Wirkung und kein pauschaler globaler Bonusdeckel.
- Reine Zauber kosten Mana; körperliche Aktionen kosten Ausdauer; kombinierte Techniken können beides kosten.
- Magische Überanstrengung verursacht zusätzlichen Manaverlust, keine zufälligen Nebenwirkungen oder körperlichen Schäden.

## Werte und Balancing
Die Werte sind konkrete Startwerte für den späteren Balancing-Durchlauf. Triggerchance, Dauer, Stärke und Abklingzeit werden durch die jeweilige Verzauberung oder Quelle festgelegt. Die endgültige Berechnung erfolgt durch die zentralen Attribut-, Ressourcen-, Kampf-, Magie- und Statussysteme.

## Import und Versionierung
Neue Definitionen werden zunächst in einer Staging-Phase geprüft. Erst nach erfolgreicher Validierung und expliziter Freigabe werden sie registriert. IDs bleiben nach Registrierung unverändert; Änderungen erzeugen neue Definitionversionen und einen nachvollziehbaren Änderungsverlauf.

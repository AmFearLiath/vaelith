# Emberwild – Rüstungs-Katalog 1.0.0

## Inhalt
- `armor.json`: 15 konkrete Rüstungsdefinitionen.
- `armor_slots.json`: Die fünf verbindlichen Rüstungsslots.
- `armor_profiles.json`: Leichte, mittlere und schwere Rüstungsprofile.
- `armor_proficiency.json`: Profil- und Untertyp-Proficiency.
- `armor_combat_rules.json`: Schutz-, Beweglichkeits- und Ausdauerregeln.
- `equipment_quality.json`: Referenz auf das gemeinsame 7-Stufen-Qualitätssystem.
- `validation_report.json`: Struktur- und Referenzprüfung.
- `manifest.json`: Version, Dateiliste, ID-Regeln und Katalogreferenzen.

## Verbindliche Slots
1. Helm
2. Brust (Schulterschutz integriert)
3. Handschuhe (Unterarmschutz integriert)
4. Hose
5. Schuhe

Es gibt keine separaten Schulter- oder Unterarmslots.

## Rüstungsprofile
- **Leicht:** hohe Beweglichkeit, geringere Schutzwerte.
- **Mittel:** ausgewogener Schutz und moderate Auswirkungen auf die Handhabung.
- **Schwer:** hohe Schutzwerte und Abdeckung, stärkere Auswirkungen auf Beweglichkeit und Ausdauerkosten.

Die Profile sind keine starre Klassenbindung und erzeugen keinen separaten Belastungs-/Gewichtsmesser.

## Schutzwerte
Physischer Schutz, Impulsschutz, Elementarresistenz und arkane Resistenz werden getrennt geführt. Abdeckung ist ein relativer Wert für die geschützte Körperzone und kein direkter Schadensreduktions-Prozentsatz.

## Weitere Regeln
- Attribute beeinflussen die Handhabung, sperren Rüstung aber nicht pauschal.
- Haltbarkeit ist standardmäßig aktiv und pro Definition abschaltbar.
- Rüstungs-Proficiency ist getrennt von Waffen-Proficiency.
- Qualität, Material, Seltenheit, Verzauberung, Sockel, Aufwertung und Setboni bleiben getrennte Dimensionen.
- Rüstungssets und Setboni werden im späteren Set-Katalog definiert.

## Werte und Balancing
Die Zahlen sind konkrete relative Ausgangswerte für den ersten Balancing-Durchlauf. Sie müssen im Combat-System getestet und bei Bedarf über Versionierung angepasst werden.

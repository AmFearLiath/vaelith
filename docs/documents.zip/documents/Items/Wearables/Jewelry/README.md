# Emberwild – Schmuck-Katalog 1.0.0

## Inhalt
- `jewelry.json`: 15 konkrete Schmuckdefinitionen.
- `jewelry_slots.json`: Eine Kette und zwei unabhängige Ringpositionen.
- `jewelry_families.json`: Schmuckfamilien und Untertypen.
- `jewelry_proficiency.json`: Familien- und Untertyp-Proficiency.
- `jewelry_rules.json`: Slot-, Bonus-, Stapel- und Haltbarkeitsregeln.
- `equipment_quality.json`: Referenz auf das gemeinsame 7-Stufen-Qualitätssystem.
- `validation_report.json`: Struktur- und Referenzprüfung.
- `manifest.json`: Version, Dateiliste, ID-Regeln und zentrale Katalogreferenzen.

## Verbindliche Slots
- **Kette:** genau ein Slot. Amulette, Anhänger, Relikte und Talismane sind Untertypen dieses Slots.
- **Ringe:** genau zwei unabhängige Positionen. Beide Positionen können grundsätzlich dieselbe Itemdefinition aufnehmen, sofern später keine individuelle Ausnahme festgelegt wird.

## Bonusregeln
- Boni werden typisiert geführt und durch die jeweiligen zentralen Systeme ausgewertet.
- Gleichartige Boni addieren sich vollständig.
- Es gibt keine automatische abnehmende Wirkung und keinen pauschalen globalen Bonusdeckel.
- Manaregeneration ist als Beitrag pro globalem Ressourcentick angegeben; die Dauer des Ticks legt das Ressourcensystem fest.
- Widerstände und Schadensboni werden durch das zentrale Combat-System ausgewertet.

## Weitere Regeln
- Schmuck hat standardmäßig keine Haltbarkeit; einzelne Definitionen können Haltbarkeit aktivieren.
- Proficiency ist getrennt von Waffen-, Schild- und Rüstungs-Proficiency.
- Passive Schmuckboni setzen keine Proficiency voraus, um den Gegenstand auszurüsten.
- Qualität, Material, Seltenheit, Verzauberung, Sockel, Aufwertung und Setboni bleiben getrennte Dimensionen.

## Werte und Balancing
Die Boni sind konkrete Ausgangswerte für den ersten Balancing-Durchlauf. Ihre finale Wirkung wird durch die referenzierten Attribut-, Ressourcen-, Magie-, Widerstands- und Combat-Systeme bestimmt.

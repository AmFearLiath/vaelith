# Migration Notes – C1 – MAT-007 bis MAT-012

- Datei: `emberwild_items_food_raw_v0.2.json`
- Version: 0.1 → 0.2

## retain_canonical
- IDs: `food.ingredient.egg`, `food.ingredient.milk`, `food.ingredient.honey`
- Grund: Ei, Frische Milch und Honig werden als kanonische Lebensmittelrohstoffe in C1 geführt; A6- und C5-Dubletten werden als Aliase migriert.

## remove_duplicate
- IDs: `food.herb.parsley`, `food.herb.thyme`, `food.herb.wild_mint`, `food.herb.wild_chervil`, `food.herb.wild_garlic`
- Grund: Die geernteten Kräuter werden botanisch in A4 kanonisch geführt; die C1-Dubletten werden auf die A4-IDs migriert.

## move
- IDs: `food.ingredient.butter`, `food.ingredient.cheese`
- Grund: Butter und Frischkäse sind bereits verarbeitete Milchprodukte und werden in C3 geführt. IDs bleiben erhalten.

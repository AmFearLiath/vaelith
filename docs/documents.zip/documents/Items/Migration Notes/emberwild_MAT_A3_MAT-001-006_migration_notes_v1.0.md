# Migration Notes – A3 – MAT-001 bis MAT-006

Datei: emberwild_items_resources_ores_v0.3.json
Version: 0.2.0 → 0.3.0

- **rename**
  - ID: `res.ore.primordial_metal`
  - Alt: Urmetall
  - Neu: Urmetallerz
  - Grund: Die A3-Definition beschreibt den natürlichen Erz-/Rohstoffzustand; Urmetall als gewonnenes Metall ist B3.

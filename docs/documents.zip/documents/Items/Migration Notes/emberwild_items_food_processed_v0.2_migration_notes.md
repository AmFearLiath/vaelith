# Migration Notes – C3 – MAT-007 bis MAT-012

- Datei: `emberwild_items_food_processed_v0.2.json`
- Version: 0.1 → 0.2

## remove_non_inventory_definition
- IDs: `food.processed.flour`
- Grund: Der generische Eintrag Mehl war ausdrücklich nur eine Sammeldefinition und sollte kein eigenständiges Inventar-Item sein. Die fünf konkreten Mehlsorten bleiben in C1.

## move_in
- IDs: `food.ingredient.butter`, `food.ingredient.cheese`
- Grund: Butter und Frischkäse werden als verarbeitete Milchprodukte in C3 geführt; IDs bleiben erhalten.

## clarify
- IDs: `food.processed.dough`, `food.processed.cheese`, `food.processed.hard_cheese`, `food.processed.yogurt`, `food.processed.cream`
- Grund: Produktionsquellen und die Verwendung sortenspezifischer Mehle bzw. kanonischer Frischmilch werden präzisiert.

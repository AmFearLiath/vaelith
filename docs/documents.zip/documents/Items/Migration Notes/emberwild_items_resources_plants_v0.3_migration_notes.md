# Migration Notes – A4 – MAT-007 bis MAT-012

- Datei: `emberwild_items_resources_plants_v0.3.json`
- Version: 0.2 → 0.3

## add
- IDs: `res.plant.parsley`, `res.plant.thyme`
- Grund: Petersilie und Thymian werden als botanische Rohstoffe in A4 ergänzt; die bisherigen C1-Dubletten werden auf diese kanonischen IDs migriert.

## clarify
- IDs: `res.plant.meadow_herb`, `res.plant.wild_mint`, `res.plant.wild_garlic`
- Grund: A4 ist die kanonische Quelle der geernteten botanischen Kräuter; C1 führt keine parallelen Item-Definitionen derselben Kräuter mehr.

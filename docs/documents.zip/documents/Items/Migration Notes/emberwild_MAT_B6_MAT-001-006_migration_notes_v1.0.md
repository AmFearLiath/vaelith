# Migration Notes – B6 – MAT-001 bis MAT-006

Datei: emberwild_items_processed_enchanted_v0.2.json
Version: 0.1 → 0.2

- **clarify**
  - IDs: `mat.enchanted.darksteel`, `mat.enchanted.resonance_metal`, `mat.enchanted.heart_metal`, `mat.enchanted.primordial_metal`, `mat.enchanted.primordial_wood`
  - Grund: B6 bezeichnet eine eigenständige gezielte magische Stabilisierung/Abstimmung nach der regulären mechanischen oder metallurgischen Verarbeitung.

# Migration Notes – B1 – MAT-001 bis MAT-006

Datei: emberwild_items_processed_wood_v0.2.json
Version: 0.1.0 → 0.2.0

- **rename**
  - ID: `mat.wood.primordial_timber`
  - Alt: Urholz
  - Neu: Bearbeitetes Erstholz
  - Grund: Trennung der mechanischen Verarbeitung in B1 von der magischen Stabilisierung in B6.
- **clarify**
  - ID: `mat.wood.primordial_timber`
  - Grund: Beschreibung, Quellen, Verwendungen und Notizen grenzen B1 als mechanisch bearbeitetes Zwischenprodukt ab.

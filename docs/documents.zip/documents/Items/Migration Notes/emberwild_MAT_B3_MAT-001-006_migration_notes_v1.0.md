# Migration Notes – B3 – MAT-001 bis MAT-006

Datei: emberwild_items_processed_metals_v0.2.json
Version: 0.1.0 → 0.2.0

- **add**
  - ID: `mat.metal.zinc_ingot`
  - Name: Zinkbarren
  - Grund: Eigenständige Zwischenstufe zwischen Zinkerz und Messingherstellung.
- **clarify_stage**
  - IDs: `mat.metal.darksteel_ore_alloy`, `mat.metal.darksteel_ingot`
  - Grund: Legierung als metallurgisches Zwischenprodukt; Barren als standardisierte Gussform.
- **clarify**
  - IDs: `mat.metal.resonance_metal_ingot`, `mat.metal.heart_metal_ingot`, `mat.metal.primordial_metal_ingot`
  - Grund: B3 enthält nur gewonnenes Metall mit natürlichen Grundeigenschaften; gezielte magische Veredelung bleibt B6.
- **migrate_to_variant_model**
  - Legacy IDs: `mat.metal.darksteel_plate`, `mat.metal.resonance_metal_plate`
  - Grund: Spezifische Metallhalbzeug-IDs werden als Migrationsaliase auf Grundform + Materialvariante abgebildet. Herzmetallbeschläge bleiben eigenständig, da sie eine andere Bauteilform/Funktion darstellen.

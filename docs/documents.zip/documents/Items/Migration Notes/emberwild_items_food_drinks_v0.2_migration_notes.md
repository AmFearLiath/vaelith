# Migration Notes – C5 – MAT-007 bis MAT-012

- Datei: `emberwild_items_food_drinks_v0.2.json`
- Version: 0.1 → 0.2

## remove_duplicate
- IDs: `food.drink.milk`
- Grund: Frische Milch ist bereits als kanonisches Lebensmittel in C1 definiert und kann dort auch als Getränk verwendet werden. Buttermilch, Honigmilch und Molke bleiben eigenständige Getränke in C5.

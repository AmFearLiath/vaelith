# Migrationsnotizen – Metalle und Legierungen v0.3

**Quelle:** `Items/Processed/emberwild_items_processed_metals_v0.2.json`  
**Ziel:** `Items/Processed/emberwild_items_processed_metals_v0.3.json`

## Änderungen

- Katalogversion auf `0.3.0` erhöht.
- `mat.metal.glow_iron_ingot` – Gluteisenbarren ergänzt.
- `mat.metal.deep_copper_ingot` – Tiefenkupferbarren ergänzt.
- `mat.metal.voidsilver_ingot` – Leersilberbarren ergänzt.
- Veralteten Zink-Hinweis beim Messingbarren entfernt.
- Schatteneisen-Schreibweise korrigiert.
- Beschreibungen der sechs kanonischen Metallhalbzeugformen an MAT-006 angepasst.
- Hinweis zur noch nicht beschlossenen Variantenidentität von Metallpulver ergänzt.

## Identität und Datenbestand

- Alle 36 bestehenden Item-IDs bleiben erhalten.
- Drei neue Item-IDs ergänzen die fehlenden Outputs, die A3 bereits als vorgesehene Verwendungen aufführt.
- Keine Items entfernt oder umbenannt.
- `base_value` und `weight` bleiben bei allen drei neuen Items `null`.
- Keine Materialeigenschaften, Kampfwerte oder konkreten Ausbeuten werden vorweggenommen.

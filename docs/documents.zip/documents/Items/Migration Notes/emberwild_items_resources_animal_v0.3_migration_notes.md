# Migration Notes – A6 – MAT-007 bis MAT-012

- Datei: `emberwild_items_resources_animal_v0.3.json`
- Version: 0.2 → 0.3

## remove_duplicate
- IDs: `res.animal.egg`, `res.animal.milk`, `res.animal.honey`
- Grund: Ei, Frische Milch und Honig besitzen eine unmittelbare Lebensmittelidentität und werden gemäß der Katalogabgrenzung in C1 kanonisch geführt. Die bisherigen A6-IDs werden als Migrationsaliase auf die C1-IDs aufgelöst.

# Emberwild – Materialabgrenzungs- und Migrationsregister

**Version:** 1.0.0  
**Status:** Arbeitsregister – Vorschläge, keine beschlossenen Katalogänderungen  
**Grundlage:** `Emberwild-Items_complete_A1-A8.zip`

## Zweck und Regeln

Dieses Register sammelt katalogübergreifende Überschneidungen, mögliche Dubletten, unklare Verarbeitungsstufen und notwendige Architekturentscheidungen. Es verändert keine bestehenden Katalogdateien.

1. Ein physischer Gegenstand bzw. eine definierte Materialstufe soll nur eine kanonische Item-ID besitzen.
2. Andere Kataloge dürfen kanonische Items referenzieren, ohne identische Items neu anzulegen.
3. Rohstoff, Zwischenprodukt, Werkstoff, Verbrauchsgegenstand und Werkzeug sind getrennte Rollen.
4. Eine neue Item-ID ist nur gerechtfertigt, wenn eine eigenständige Verarbeitungsstufe, Funktion oder Spielmechanik existiert.
5. Alle Vorschläge bleiben offen, bis sie ausdrücklich beschlossen werden.

## Übersicht

| ID | Gruppe | Priorität | Status | Kernthema |
|---|---|---:|---|---|
| MAT-001 | Holz und magische Holzwerkstoffe | high | proposed_pending_approval | Zwei unterschiedliche Items heißen Urholz |
| MAT-002 | Stein und Resonanzmaterialien | high | proposed_pending_approval | Gleicher Anzeigename, aber die Beschreibungen unterscheiden natürlichen Resonanzrohstoff und speziell bearbeiteten Stein |
| MAT-003 | Metalle und Legierungen | high | proposed_pending_approval | A3 enthält Zinkerz und B3 beschreibt Messing ausdrücklich als Kupfer-Zink-Legierung |
| MAT-004 | Metalle und Legierungen | high | needs_definition | B3 beschreibt Dunkelstahllegierung als noch nicht abschließend definierte Legierung aus Unterweltmetallen und Dunkelstahlbarren als widerstandsfähige Legierung |
| MAT-005 | Metalle und Legierungen | high | needs_definition | B3 und B6 enthalten dieselben Materialnamen in unterschiedlichen IDs |
| MAT-006 | Metalle und Halbzeuge | medium | design_decision_required | B3 enthält allgemeine Halbzeuge ohne explizite Materialvariante |
| MAT-007 | Tierische Rohstoffe und Lebensmittel | high | proposed_pending_approval | Gleicher Name, beide Beschreibungen führen frisches Ei aus Tierhaltung als Lebensmittelzutat |
| MAT-008 | Tierische Rohstoffe und Lebensmittel | high | proposed_pending_approval | A6 führt Rohmilch als verderblichen tierischen Ausgangsstoff |
| MAT-009 | Tierische Rohstoffe und Lebensmittel | high | proposed_pending_approval | A6 beschreibt geernteten Honig ausdrücklich als direkt verwendbaren Nahrungsrohstoff und Ausgangsstoff für weitere Lebensmittel |
| MAT-010 | Pflanzliche Rohstoffe und Lebensmittel | medium | proposed_pending_approval | Mehrere Kräuter stehen sowohl als Pflanzenrohstoff in A4 als auch als Lebensmittelzutat in C1 |
| MAT-011 | Lebensmittelverarbeitung | medium | proposed_pending_approval | C1 enthält fünf sortenspezifische Mehle |
| MAT-012 | Lebensmittelverarbeitung | medium | proposed_pending_approval | C1 bezeichnet Butter und Frischkäse als Zutaten, obwohl die Beschreibungen bereits eine Verarbeitung aus Rahm bzw |
| MAT-013 | Verbrauchsgüter und Gifte | high | proposed_pending_approval | Zwei Items mit identischem Namen und sehr ähnlicher Wirkung |
| MAT-014 | Werkzeuge und Gebrauchsgegenstände | high | proposed_pending_approval | Schaufel und Sichel sind jeweils doppelt mit nahezu identischen Beschreibungen vorhanden |
| MAT-015 | Werkzeuge und Gebrauchsgegenstände | medium | design_decision_required | B5 führt ein geflochtenes Netzmaterial bzw |
| MAT-016 | Verbrauchsgüter und Werkzeuge | medium | proposed_pending_approval | D6 führt ein Set zum wiederholten Erzeugen von Funken; A2 führt den natürlichen Feuersteinrohstoff |
| MAT-017 | Verbrauchsgüter und Werkzeuge | medium | needs_mechanics_definition | D6 führt einen Wasserfilter als einfachen Filter |
| MAT-018 | Verbrauchsgüter und Werkzeuge | medium | needs_mechanics_definition | D6 beschreibt Köder als vorbereitete Verbrauchsgegenstände zum Anlocken von Tieren und Kreaturen |
| MAT-019 | Wachs, Harze und Naturstoffe | medium | source_review_required | A6 und A8 führen unterschiedliche natürliche Wachsrohstoffe; D6 führt aufbereitetes Siegelwachs als Verbrauchsgegenstand |
| MAT-020 | Öle und geologische Kohlenwasserstoffe | medium | source_review_required | A8 definiert Pflanzenöl als ungeklärtes Pressöl und Rohöl als unaufbereitetes Erdöl |
| MAT-021 | Lebensmittel und Tierrohstoffe | medium | needs_definition | A6 definiert Tierfett als grob gereinigten Rohstoff, der auch für Lebensmittelverarbeitung dient |
| MAT-022 | Magische Ressourcen und Essenzen | high | needs_lore_definition | A8 beschreibt Lebensfluid und Uressenz als natürliche Ressourcen |
| MAT-023 | Gesteine und mineralische Naturstoffe | medium | source_review_required | A8 beschreibt Naturbitumen als geologische bituminöse Substanz und natürlichen Teer als natürliche organische Ablagerung, ausdrücklich nicht als Holzteer |
| MAT-024 | Werkzeuge und Gegenstände | medium | design_decision_required | D6 führt ein allgemeines Seil und Wurfseil als Gegenstände |
| MAT-025 | Katalogweite Datenarchitektur | high | design_decision_required | Die Kataloge sind in fachliche Bereiche aufgeteilt |

## Einzelregister

### MAT-001 – Holz und magische Holzwerkstoffe

**Priorität:** high  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_wood_v0.2.json` | `res.wood.firstwood` | Erstholz | natürlicher Rohstoff |
| `Items/Processed/emberwild_items_processed_wood_v0.1.json` | `mat.wood.primordial_timber` | Urholz | verarbeitetes Holzmaterial |
| `Items/Processed/emberwild_items_processed_enchanted_v0.1.json` | `mat.enchanted.primordial_wood` | Urholz | magisches Holzmaterial |

**Befund:** Zwei unterschiedliche Items heißen Urholz. Das B1-Item ist bereits als verarbeitetes Holzmaterial beschrieben; das B6-Item als seltenes Holz aus ursprünglichen Geflechtstrukturen. A1 führt zusätzlich Erstholz als natürlichen Rohstoff.

**Vorschlag:** Eine dreistufige Kette prüfen: A1 Erstholz als Rohstoff; B1 bearbeitetes Erstholz als mechanisch verarbeitetes Material; B6 Urholz nur dann als eigene Stufe behalten, wenn eine eigenständige magische Behandlung mit zusätzlicher Funktion festgelegt wird.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "rename", "id": "mat.wood.primordial_timber", "suggested_name": "Bearbeitetes Erstholz"}`
- `{"type": "retain_or_redefine", "id": "mat.enchanted.primordial_wood", "condition": "B6-Item nur behalten, wenn es gegenüber B1 einen konkreten magischen Mehrwert besitzt"}`

> Hinweis: Vorgeschlagene Namen und Stufen sind noch nicht beschlossen.

### MAT-002 – Stein und Resonanzmaterialien

**Priorität:** high  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_stone_v0.2.json` | `res.stone.resonance` | Resonanzstein | natürliches Gestein |
| `Items/Processed/emberwild_items_processed_stone_v0.1.json` | `mat.stone.resonance_stone` | Resonanzstein | bearbeitetes Gestein |

**Befund:** Gleicher Anzeigename, aber die Beschreibungen unterscheiden natürlichen Resonanzrohstoff und speziell bearbeiteten Stein.

**Vorschlag:** A2 als Resonanzstein belassen; B2 in Bearbeiteter Resonanzstein umbenennen und die konkrete Bearbeitungsstufe bzw. den Zweck in der Beschreibung festhalten.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "rename", "id": "mat.stone.resonance_stone", "suggested_name": "Bearbeiteter Resonanzstein"}`

> Hinweis: Keine automatische Gleichsetzung mit B6-Resonanzkristall.

### MAT-003 – Metalle und Legierungen

**Priorität:** high  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_ores_v0.2.json` | `res.ore.zinc` | Zinkerz | Erz |
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.brass_ingot` | Messingbarren | Kupfer-Zink-Legierung |

**Befund:** A3 enthält Zinkerz und B3 beschreibt Messing ausdrücklich als Kupfer-Zink-Legierung. Ein Zinkbarren ist im B3-Katalog nicht vorhanden.

**Vorschlag:** Zinkbarren als Zwischenprodukt ergänzen, sofern Messing in einer mehrstufigen Produktionskette hergestellt wird. Alternativ kann die Schmelze Zinkerz direkt verarbeiten; dann muss dies ausdrücklich im Rezeptmodell stehen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "add_candidate", "suggested_id": "mat.metal.zinc_ingot", "suggested_name": "Zinkbarren", "target_file": "Items/Processed/emberwild_items_processed_metals_v0.1.json"}`

> Hinweis: Noch keine Rezeptentscheidung; keine Änderung am Katalog vorgenommen.

### MAT-004 – Metalle und Legierungen

**Priorität:** high  
**Status:** `needs_definition`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_ores_v0.2.json` | `res.ore.darksteel` | Dunkelstahlerz |  |
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.darksteel_ore_alloy` | Dunkelstahllegierung |  |
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.darksteel_ingot` | Dunkelstahlbarren |  |
| `Items/Processed/emberwild_items_processed_enchanted_v0.1.json` | `mat.enchanted.darksteel` | Veredelter Dunkelstahl |  |

**Befund:** B3 beschreibt Dunkelstahllegierung als noch nicht abschließend definierte Legierung aus Unterweltmetallen und Dunkelstahlbarren als widerstandsfähige Legierung. B6 führt zusätzlich veredelten Dunkelstahl.

**Vorschlag:** Legierung als Zwischenprodukt, Barren als standardisierte Gussform und B6 als zusätzliche magische Stabilisierung definieren. Zusammensetzung und Rezeptbestandteile offenlassen, bis Lore und Produktionsdesign feststehen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "clarify_stage", "id": "mat.metal.darksteel_ore_alloy"}`
- `{"type": "retain_stage", "id": "mat.metal.darksteel_ingot"}`
- `{"type": "clarify_magical_stage", "id": "mat.enchanted.darksteel"}`

### MAT-005 – Metalle und Legierungen

**Priorität:** high  
**Status:** `needs_definition`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_ores_v0.2.json` | `res.ore.resonant_metal` | Resonanzmetallerz |  |
| `Items/Resources/emberwild_items_resources_ores_v0.2.json` | `res.ore.heart_metal` | Herzmetallerz |  |
| `Items/Resources/emberwild_items_resources_ores_v0.2.json` | `res.ore.primordial_metal` | Urmetall |  |
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.resonance_metal_ingot` | Resonanzmetallbarren |  |
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.heart_metal_ingot` | Herzmetallbarren |  |
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.primordial_metal_ingot` | Urmetallbarren |  |
| `Items/Processed/emberwild_items_processed_enchanted_v0.1.json` | `mat.enchanted.resonance_metal` | Resonanzmetall |  |
| `Items/Processed/emberwild_items_processed_enchanted_v0.1.json` | `mat.enchanted.heart_metal` | Herzmetall |  |
| `Items/Processed/emberwild_items_processed_enchanted_v0.1.json` | `mat.enchanted.primordial_metal` | Urmetall |  |

**Befund:** B3 und B6 enthalten dieselben Materialnamen in unterschiedlichen IDs. B3-Beschreibungen enthalten bereits Eigenschaften wie Resonanzweiterleitung bzw. Lebensresonanz; B6 beschreibt gezielte magische Verfahren.

**Vorschlag:** B3 als gewonnenes Metall mit natürlichen Grundmerkmalen definieren. B6 nur für gezielt veränderte, kontrollierte oder stabilisierte magische Eigenschaften verwenden. B3-Beschreibungen und B6-Beschreibungen auf diese Grenze abstimmen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "clarify_description", "target": "B3 resonance/heart/primordial metal ingots"}`
- `{"type": "clarify_description", "target": "B6 resonance/heart/primordial metal"}`

> Hinweis: Beim Urmetall ist A3 bereits das Erz-/Rohstoffitem mit Anzeigename Urmetall; prüfen, ob der Name besser auf Urmetallerz geändert werden soll.

### MAT-006 – Metalle und Halbzeuge

**Priorität:** medium  
**Status:** `design_decision_required`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.metal_plate` | Metallplatte |  |
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.metal_sheet` | Metallblech |  |
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.metal_rod` | Metallstange |  |
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.metal_bar` | Metallprofil |  |
| `Items/Processed/emberwild_items_processed_metals_v0.1.json` | `mat.metal.metal_wire` | Metalldraht |  |

**Befund:** B3 enthält allgemeine Halbzeuge ohne explizite Materialvariante. Gleichzeitig existieren spezifische Varianten wie Dunkelstahlplatte und Resonanzmetallplatte.

**Vorschlag:** Entscheiden, ob Halbzeuge materialneutral mit Materialeigenschaft/Variantendaten geführt werden oder ob je Metallart eigene Items entstehen. Die Entscheidung muss Inventar, Rezepte, Handel und Preisbildung berücksichtigen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "system_design_decision", "topic": "material_variant_model"}`

### MAT-007 – Tierische Rohstoffe und Lebensmittel

**Priorität:** high  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_animal_v0.2.json` | `res.animal.egg` | Ei | tierischer Rohstoff |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.ingredient.egg` | Ei | Lebensmittel |

**Befund:** Gleicher Name, beide Beschreibungen führen frisches Ei aus Tierhaltung als Lebensmittelzutat. A6 definiert es bereits als tierischen Rohstoff.

**Vorschlag:** A6-Ei als zentrale Item-ID verwenden und C1 auf dieselbe Ressource verweisen lassen. Falls C1 ein eigenständiges Lebensmittel-Objekt benötigt, sollte es eine Referenz/Verwendungsrolle statt einer zweiten Material-ID sein.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "merge_duplicate_candidate", "keep_id": "res.animal.egg", "retire_id": "food.ingredient.egg"}`

### MAT-008 – Tierische Rohstoffe und Lebensmittel

**Priorität:** high  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_animal_v0.2.json` | `res.animal.milk` | Rohmilch |  |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.ingredient.milk` | Frische Milch |  |
| `Items/Food/emberwild_items_food_drinks_v0.1.json` | `food.drink.milk` | Frische Milch |  |

**Befund:** A6 führt Rohmilch als verderblichen tierischen Ausgangsstoff. C1 und C5 führen Frische Milch mit nahezu identischer Beschreibung als Zutat bzw. Getränk.

**Vorschlag:** res.animal.milk als zentrale Item-ID verwenden. Rohmilch kann direkt getrunken werden; C1/C5 sollen keine eigenständigen Dubletten erzeugen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "merge_duplicate_candidate", "keep_id": "res.animal.milk", "retire_ids": ["food.ingredient.milk", "food.drink.milk"]}`

### MAT-009 – Tierische Rohstoffe und Lebensmittel

**Priorität:** high  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_animal_v0.2.json` | `res.animal.honey` | Honig |  |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.ingredient.honey` | Honig |  |

**Befund:** A6 beschreibt geernteten Honig ausdrücklich als direkt verwendbaren Nahrungsrohstoff und Ausgangsstoff für weitere Lebensmittel. C1 führt denselben Stoff erneut.

**Vorschlag:** res.animal.honey als zentrale Item-ID verwenden; C1 referenziert diese Ressource. Spezialhonige in C6 bleiben eigenständige Items, sofern ihre besonderen Eigenschaften gewollt sind.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "merge_duplicate_candidate", "keep_id": "res.animal.honey", "retire_id": "food.ingredient.honey"}`

### MAT-010 – Pflanzliche Rohstoffe und Lebensmittel

**Priorität:** medium  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_plants_v0.2.json` | `res.plant.wild_mint` | Waldminze |  |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.herb.wild_mint` | Waldminze |  |
| `Items/Resources/emberwild_items_resources_plants_v0.2.json` | `res.plant.wild_garlic` | Wilder Knoblauch |  |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.herb.wild_garlic` | Wilder Knoblauch |  |
| `Items/Resources/emberwild_items_resources_plants_v0.2.json` | `res.plant.meadow_herb` | Wiesenkerbel |  |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.herb.wild_chervil` | Wiesenkerbel |  |

**Befund:** Mehrere Kräuter stehen sowohl als Pflanzenrohstoff in A4 als auch als Lebensmittelzutat in C1. Die Beschreibungen überschneiden sich stark; bei Wiesenkerbel weicht die technische ID vom Anzeigenamen ab.

**Vorschlag:** A4 als führende Quelle für die geerntete Pflanze verwenden. C1 soll dieselben Pflanzen als Zutaten referenzieren. Technische ID res.plant.meadow_herb und Anzeigename Wiesenkerbel auf inhaltliche Übereinstimmung prüfen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "merge_duplicate_candidate", "keep_ids": ["res.plant.wild_mint", "res.plant.wild_garlic", "res.plant.meadow_herb"], "retire_ids": ["food.herb.wild_mint", "food.herb.wild_garlic", "food.herb.wild_chervil"]}`

### MAT-011 – Lebensmittelverarbeitung

**Priorität:** medium  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.ingredient.flour_wheat` | Weizenmehl |  |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.ingredient.flour_rye` | Roggenmehl |  |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.ingredient.flour_barley` | Gerstenmehl |  |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.ingredient.flour_corn` | Maismehl |  |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.ingredient.flour_oat` | Hafermehl |  |
| `Items/Food/emberwild_items_food_processed_v0.1.json` | `food.processed.flour` | Mehl |  |

**Befund:** C1 enthält fünf sortenspezifische Mehle. C3 enthält zusätzlich ein allgemeines Mehl, dessen Beschreibung alle Getreidemehle zusammenfasst.

**Vorschlag:** Sortenmehle als konkrete Items behalten. Das allgemeine Mehl entweder als ausdrücklich definierte Mehlmischung spezifizieren oder als Dublette aus C3 entfernen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "clarify_or_retire", "id": "food.processed.flour"}`

### MAT-012 – Lebensmittelverarbeitung

**Priorität:** medium  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.ingredient.butter` | Butter |  |
| `Items/Food/emberwild_items_food_raw_v0.1.json` | `food.ingredient.cheese` | Frischkäse |  |
| `Items/Food/emberwild_items_food_processed_v0.1.json` | `food.processed.cream` | Rahm |  |
| `Items/Food/emberwild_items_food_processed_v0.1.json` | `food.processed.yogurt` | Joghurt |  |
| `Items/Food/emberwild_items_food_processed_v0.1.json` | `food.processed.cheese` | Gereifter Käse |  |

**Befund:** C1 bezeichnet Butter und Frischkäse als Zutaten, obwohl die Beschreibungen bereits eine Verarbeitung aus Rahm bzw. Milch voraussetzen. C3 enthält weitere verarbeitete Milchprodukte.

**Vorschlag:** Butter, Frischkäse, Rahm, Joghurt und Käse als verarbeitete Lebensmittel in C3 bündeln. C1 bleibt für unverarbeitete Rohzutaten reserviert.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "move_candidate", "ids": ["food.ingredient.butter", "food.ingredient.cheese"], "from": "C1", "to": "C3"}`

### MAT-013 – Verbrauchsgüter und Gifte

**Priorität:** high  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Consumables/emberwild_items_consumables_medicine_v0.1.json` | `consumable.medicine.antidote_basic` | Einfaches Gegengift |  |
| `Items/Consumables/emberwild_items_consumables_poisons_v0.1.json` | `consumable.poison.basic_antidote` | Einfaches Gegengift |  |

**Befund:** Zwei Items mit identischem Namen und sehr ähnlicher Wirkung. D3 enthält darüber hinaus weitere Gegengifte.

**Vorschlag:** Einfaches Gegengift zentral in D3 führen. D1 bleibt medizinischen Verbänden, Salben und Wundversorgung vorbehalten.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "merge_duplicate_candidate", "keep_id": "consumable.poison.basic_antidote", "retire_id": "consumable.medicine.antidote_basic"}`

### MAT-014 – Werkzeuge und Gebrauchsgegenstände

**Priorität:** high  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Tools/emberwild_items_tools_agriculture_v0.1.json` | `tool.agriculture.shovel` | Schaufel |  |
| `Items/Tools/emberwild_items_tools_gathering_v0.1.json` | `tool.gathering.shovel` | Schaufel |  |
| `Items/Tools/emberwild_items_tools_agriculture_v0.1.json` | `tool.agriculture.sickle` | Sichel |  |
| `Items/Tools/emberwild_items_tools_gathering_v0.1.json` | `tool.gathering.sickle` | Sichel |  |

**Befund:** Schaufel und Sichel sind jeweils doppelt mit nahezu identischen Beschreibungen vorhanden.

**Vorschlag:** Jeweils ein allgemeines Werkzeug behalten und in den passenden Unterkatalog verschieben oder eine klare Spezialisierung definieren. Keine zwei gleichartigen Basiswerkzeuge ohne funktionalen Unterschied.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "merge_duplicate_candidate", "pairs": [{"keep_id": "tool.agriculture.shovel", "retire_id": "tool.gathering.shovel"}, {"keep_id": "tool.agriculture.sickle", "retire_id": "tool.gathering.sickle"}]}`

### MAT-015 – Werkzeuge und Gebrauchsgegenstände

**Priorität:** medium  
**Status:** `design_decision_required`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Processed/emberwild_items_processed_textiles_v0.1.json` | `mat.net.fishing` | Fischernetz |  |
| `Items/Tools/emberwild_items_tools_hunting_fishing_animal_v0.1.json` | `tool.fishing.fishing_net` | Fischernetz |  |

**Befund:** B5 führt ein geflochtenes Netzmaterial bzw. Netzprodukt; E6 führt ein Netz als Fangwerkzeug. Die Beschreibungen unterscheiden Materialprodukt und funktionales Werkzeug, aber der Anzeigename ist identisch.

**Vorschlag:** B5-Item als hergestelltes Netzmaterial/Netzprodukt präzisieren (z. B. Netzgeflecht), E6 als fertiges, verwendbares Fischereigerät behalten.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "rename", "id": "mat.net.fishing", "suggested_name": "Fischernetzgeflecht"}`

### MAT-016 – Verbrauchsgüter und Werkzeuge

**Priorität:** medium  
**Status:** `proposed_pending_approval`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Consumables/emberwild_items_consumables_misc_v0.1.json` | `consumable.misc.fire_flint_kit` | Feuersteinset |  |
| `Items/Resources/emberwild_items_resources_stone_v0.2.json` | `res.stone.flint` | Feuerstein |  |

**Befund:** D6 führt ein Set zum wiederholten Erzeugen von Funken; A2 führt den natürlichen Feuersteinrohstoff. Die frühere Vermutung einer Doppelung mit E8 ist nicht durch einen gleichnamigen E8-Eintrag belegt.

**Vorschlag:** Feuersteinset als wiederverwendbares Werkzeug nach E8 verschieben; Feuersteinrohstoff bleibt A2. Falls das Set bei Nutzung verbraucht wird, muss diese Verbrauchsmechanik ausdrücklich beschrieben sein.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "move_candidate", "id": "consumable.misc.fire_flint_kit", "from": "D6", "to": "E8"}`

### MAT-017 – Verbrauchsgüter und Werkzeuge

**Priorität:** medium  
**Status:** `needs_mechanics_definition`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Consumables/emberwild_items_consumables_misc_v0.1.json` | `consumable.misc.water_filter` | Wasserfilter |  |

**Befund:** D6 führt einen Wasserfilter als einfachen Filter. Es ist nicht erkennbar, ob der Filterkörper wiederverwendbar ist oder bei der Reinigung verbraucht wird.

**Vorschlag:** Bei wiederverwendbarem Filterkörper nach E8 verschieben und verbrauchbares Filtermedium separat in D6 führen. Bei Einwegfilter bleibt ein D6-Item zulässig.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "define_consumption_model", "id": "consumable.misc.water_filter"}`

### MAT-018 – Verbrauchsgüter und Werkzeuge

**Priorität:** medium  
**Status:** `needs_mechanics_definition`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Consumables/emberwild_items_consumables_misc_v0.1.json` | `consumable.misc.bait` | Köder |  |
| `Items/Consumables/emberwild_items_consumables_misc_v0.1.json` | `consumable.misc.special_bait` | Spezialköder |  |

**Befund:** D6 beschreibt Köder als vorbereitete Verbrauchsgegenstände zum Anlocken von Tieren und Kreaturen. Eine Verbrauchsmechanik ist naheliegend, aber noch nicht spezifiziert.

**Vorschlag:** In D6 belassen, wenn jeder Einsatz Köder verbraucht. Falls Köder mehrfach verwendet werden können, E6/E8 prüfen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "define_consumption_model", "ids": ["consumable.misc.bait", "consumable.misc.special_bait"]}`

### MAT-019 – Wachs, Harze und Naturstoffe

**Priorität:** medium  
**Status:** `source_review_required`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_animal_v0.2.json` | `res.animal.wax` | Bienenwachs |  |
| `Items/Resources/emberwild_items_resources_misc_v0.2.json` | `res.misc.earth_wax` | Erdwachs |  |
| `Items/Consumables/emberwild_items_consumables_misc_v0.1.json` | `consumable.misc.wax_seal` | Siegelwachs |  |

**Befund:** A6 und A8 führen unterschiedliche natürliche Wachsrohstoffe; D6 führt aufbereitetes Siegelwachs als Verbrauchsgegenstand.

**Vorschlag:** Beide Rohwachse getrennt behalten. Siegelwachs als verarbeitetes Verbrauchsprodukt in D6 behalten, sofern es beim Versiegeln verbraucht wird; andernfalls B5 als Materialprodukt führen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "define_consumption_model", "id": "consumable.misc.wax_seal"}`

### MAT-020 – Öle und geologische Kohlenwasserstoffe

**Priorität:** medium  
**Status:** `source_review_required`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_misc_v0.2.json` | `res.misc.plant_oil` | Pflanzenöl |  |
| `Items/Resources/emberwild_items_resources_misc_v0.2.json` | `res.misc.mineral_oil` | Rohöl |  |
| `Items/Consumables/emberwild_items_consumables_maintenance_v0.1.json` | `consumable.maintenance.weapon_oil` | Waffenöl |  |
| `Items/Consumables/emberwild_items_consumables_maintenance_v0.1.json` | `consumable.maintenance.premium_weapon_oil` | Hochwertiges Waffenöl |  |

**Befund:** A8 definiert Pflanzenöl als ungeklärtes Pressöl und Rohöl als unaufbereitetes Erdöl. D5 führt fertige Pflegeöle für Waffen.

**Vorschlag:** Rohstoffe in A8 belassen; Waffenöle als formulierte Wartungs-/Pflegeprodukte in D5 belassen. B5 nur ergänzen, wenn ein eigenständiges Zwischenprodukt wie raffiniertes Öl in Rezepten gebraucht wird.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "retain_with_stage_boundary", "ids": ["res.misc.plant_oil", "res.misc.mineral_oil", "consumable.maintenance.weapon_oil", "consumable.maintenance.premium_weapon_oil"]}`

### MAT-021 – Lebensmittel und Tierrohstoffe

**Priorität:** medium  
**Status:** `needs_definition`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_animal_v0.2.json` | `res.animal.tallow` | Tierfett |  |

**Befund:** A6 definiert Tierfett als grob gereinigten Rohstoff, der auch für Lebensmittelverarbeitung dient. In den C-Katalogen muss geklärt werden, ob ein separates Speisefett-Produkt existiert und welche Verarbeitungsstufe es beschreibt.

**Vorschlag:** Tierfett als Rohstoff belassen. Verarbeitetes Speisefett nur als eigenes C3-Item ergänzen, wenn eine echte Aufbereitung und Rezeptverwendung vorgesehen ist.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "cross_catalog_check", "scope": "C1-C6", "term": "Tierfett/Speisefett/Talg"}`

### MAT-022 – Magische Ressourcen und Essenzen

**Priorität:** high  
**Status:** `needs_lore_definition`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_misc_v0.2.json` | `res.misc.lifefluid` | Lebensfluid |  |
| `Items/Resources/emberwild_items_resources_misc_v0.2.json` | `res.misc.primordial_essence` | Uressenz |  |
| `Items/Food/emberwild_items_food_special_v0.1.json` | `food.special.vaelith_essence` | Essenz der Lebenskraft |  |

**Befund:** A8 beschreibt Lebensfluid und Uressenz als natürliche Ressourcen. C6 beschreibt Essenz der Lebenskraft als einzigartige Erscheinungsform ursprünglicher Lebenskraft mit direktem Bezug zu Vaelith.

**Vorschlag:** Alle drei vorerst getrennt halten. Die Lore muss definieren, ob Uressenz ein Rohstoff, eine Quelle oder eine konzentrierte Manifestation ist und wie sie sich von Vaeliths Essenz unterscheidet.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "lore_decision", "ids": ["res.misc.lifefluid", "res.misc.primordial_essence", "food.special.vaelith_essence"]}`

### MAT-023 – Gesteine und mineralische Naturstoffe

**Priorität:** medium  
**Status:** `source_review_required`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Resources/emberwild_items_resources_misc_v0.2.json` | `res.misc.natural_bitumen` | Naturbitumen |  |
| `Items/Resources/emberwild_items_resources_misc_v0.2.json` | `res.misc.natural_tar` | Natürlicher Teer |  |

**Befund:** A8 beschreibt Naturbitumen als geologische bituminöse Substanz und natürlichen Teer als natürliche organische Ablagerung, ausdrücklich nicht als Holzteer.

**Vorschlag:** Vorläufig getrennt lassen. Für beide müssen Fundorte, Gewinnung und unterschiedliche Verwendungen festgelegt werden; andernfalls zusammenführen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "define_world_sources_and_uses", "ids": ["res.misc.natural_bitumen", "res.misc.natural_tar"]}`

### MAT-024 – Werkzeuge und Gegenstände

**Priorität:** medium  
**Status:** `design_decision_required`

**Betroffene Items**

| Quelldatei | Item-ID | Anzeigename | Rolle |
|---|---|---|---|
| `Items/Consumables/emberwild_items_consumables_misc_v0.1.json` | `consumable.misc.rope` | Seil |  |
| `Items/Consumables/emberwild_items_consumables_misc_v0.1.json` | `consumable.misc.grappling_rope` | Wurfseil |  |
| `Items/Processed/emberwild_items_processed_textiles_v0.1.json` | `mat.rope.hemp` | Hanfseil | hergestelltes Seilprodukt |
| `Items/Processed/emberwild_items_processed_textiles_v0.1.json` | `mat.rope.flax` | Flachsseil | hergestelltes Seilprodukt |
| `Items/Processed/emberwild_items_processed_textiles_v0.1.json` | `mat.rope.jute` | Juteseil | hergestelltes Seilprodukt |
| `Items/Processed/emberwild_items_processed_textiles_v0.1.json` | `mat.rope.root_fiber` | Wurzelfaserseil | hergestelltes Seilprodukt |
| `Items/Processed/emberwild_items_processed_textiles_v0.1.json` | `mat.rope.deep_fiber` | Tiefenfaserseil | hergestelltes Seilprodukt |

**Befund:** D6 führt ein allgemeines Seil und Wurfseil als Gegenstände. B5 führt zusätzlich ein hergestelltes Seilmaterial. Die tatsächliche Wiederverwendbarkeit und die Unterscheidung zwischen Material und einsatzfertigem Gegenstand sind nicht vollständig spezifiziert.

**Vorschlag:** B5 als hergestelltes Seilmaterial behalten; D6-Seil nur als verbrauchbares Einsatzobjekt behalten, falls es beim Einsatz verbraucht wird. Wiederverwendbares Wurfseil als E8-Gegenstand führen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "define_item_role_and_durability", "ids": ["consumable.misc.rope", "consumable.misc.grappling_rope", "mat.rope.rope"]}`

### MAT-025 – Katalogweite Datenarchitektur

**Priorität:** high  
**Status:** `design_decision_required`

**Betroffene Items**
- Katalogweite Architekturentscheidung; keine einzelne Item-ID.

**Befund:** Die Kataloge sind in fachliche Bereiche aufgeteilt. Mehrere gleiche Rohstoffe werden aktuell in mehreren Katalogen als eigene Item-IDs geführt, obwohl die Beschreibung denselben physischen Gegenstand meint.

**Vorschlag:** Ein kanonisches Item erhält eine eindeutige ID und einen Heimatkatalog. Andere Systeme (Lebensmittel, Rezepte, Berufe, Handel, Werkzeuge) referenzieren diese ID über Verwendungs- oder Rezeptdaten, statt Kopien anzulegen.

**Vorgesehene Aktionen (noch nicht ausgeführt):**
- `{"type": "architecture_decision", "topic": "canonical_item_identity_and_cross_catalog_references"}`

> Hinweis: Das setzt eine Referenzstruktur voraus; die bestehenden JSON-Schemata müssen vor der Umsetzung geprüft und ggf. gezielt erweitert werden.

## Reihenfolge für die Umsetzung

1. Architekturentscheidung zu kanonischen Item-IDs und Katalogreferenzen (MAT-025).
2. Eindeutige Dubletten und Mehrfachdefinitionen bereinigen (MAT-007 bis MAT-010, MAT-013, MAT-014).
3. Verarbeitungsstufen und Materialvarianten festlegen (MAT-001 bis MAT-006, MAT-011 bis MAT-024).
4. Erst danach Katalogdateien versionieren, Migrationen dokumentieren und alle Referenzen validieren.

## Wichtige Einschränkung

Die Kataloge B, C, D und E liegen im geprüften Archiv weiterhin überwiegend in Version 0.1 vor. Dieses Register ist deshalb eine Prüfung des vorhandenen Datenbestands, keine abschließende Produktions- oder Lore-Spezifikation. Wo Fundorte, Rezepte, Verbrauchsverhalten oder magische Verfahren nicht aus den Dateien hervorgehen, ist die Entscheidung ausdrücklich als offen markiert.

**Es wurden keine bestehenden Item-Kataloge verändert.**
# Migration Notes – B2 – MAT-001 bis MAT-006

Datei: emberwild_items_processed_stone_v0.2.json
Version: 0.1.0 → 0.2.0

- **rename**
  - ID: `mat.stone.resonance_stone`
  - Alt: Resonanzstein
  - Neu: Bearbeiteter Resonanzstein
  - Grund: Abgrenzung zum natürlichen Resonanzstein aus A2.
- **clarify**
  - ID: `mat.stone.resonance_stone`
  - Grund: Mechanische Bearbeitung wird von zusätzlicher magischer Abstimmung unterschieden.

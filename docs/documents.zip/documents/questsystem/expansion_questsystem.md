# Importanweisung – Emberwild Quest Schema v2

## 1. Quest Definition



Bearbeiten

&#x20;Feld: `questline`



- Grund: Eindeutige Referenzierung und Vermeidung mehrfach verwendeter Anzeigenamen.
- Art der Änderung: Ergänzen.
- Änderung:
  - `questline` als eindeutige ID definieren.
  - Anzeigenamen separat mehrsprachig verwalten.



Beibehalten

&#x20;Felder: `id`, `kind`, `act`, `chapter`, `order`, `civilization`, `minLevel`, `recommendedLevel`, `giver`, `turnIn`, `area`



\- Keine Änderung.

## 2. Quest Conditions



Erweitern

&#x20;Felder: `requires`, `unlockTrigger`



- Grund: Unterstützung komplexer Freischaltbedingungen und dynamischer Voraussetzungen.
- Art der Änderung: Erweitern und vereinheitlichen.
- Änderungen:
  - `requires` für Questabhängigkeiten beibehalten.
  - `unlockTrigger` um verschachtelte Bedingungen erweitern.
  - AND-, OR- und NOT-Verknüpfungen unterstützen.
  - Bedingungen für Queststatus, Items, Level, Resonanz, Wissen, NPC-Zustände, Fraktionen und World States ermöglichen.
  - Operatoren wie `==`, `!=`, `>`, `>=`, `<`, `<=` unterstützen.
  - Itembedingungen um Besitzprüfung und Verbrauchsverhalten ergänzen.

## 3. Objective System



Erweitern

&#x20;Bereich: `objectives`



- Grund: Unterstützung komplexer Aufgabenverläufe und alternativer Lösungswege.
- Art der Änderung: Erweitern.
- Änderungen:
  - Objective-Abhängigkeiten über `dependsOn` ermöglichen.
  - Gruppierungen über `objectiveGroups` ermöglichen.
  - AND-, OR- und SEQUENCE-Verknüpfungen unterstützen.
  - Optionale Objectives beibehalten.
  - Alternative Objective-Lösungen ermöglichen.
  - Bedingungen für einzelne Objectives ergänzen.
  - Objective-Typen erweitern:

| Typ           | Funktion                     |
| ------------- | ---------------------------- |
| `talk`        | NPC-Gespräch                 |
| `kill`        | Gegner besiegen              |
| `collect`     | Gegenstände sammeln          |
| `interact`    | Objekt interagieren          |
| `discover`    | Gebiet entdecken             |
| `investigate` | Hinweise untersuchen         |
| `deliver`     | Gegenstände überbringen      |
| `craft`       | Gegenstände herstellen       |
| `gather`      | Ressourcen sammeln           |
| `escort`      | NPC begleiten                |
| `protect`     | NPC oder Objekt schützen     |
| `survive`     | Zeit oder Ereignis überleben |
| `reach`       | Position erreichen           |
| `activate`    | Mechanismus aktivieren       |
| `choose`      | Entscheidung treffen         |
| `reputation`  | Rufanforderung erfüllen      |
| `knowledge`   | Wissen erlangen              |
| `world_state` | Weltzustand erreichen        |

## 4. Decision System



Neu hinzufügen

&#x20;Bereich: `decisions`



- Grund: Unterstützung verzweigter Questverläufe und dauerhafter Spielerentscheidungen.
- Art der Änderung: Neuen Bereich hinzufügen.
- Änderungen:
  - Mehrere Entscheidungen pro Quest ermöglichen.
  - Mehrere Auswahlmöglichkeiten pro Entscheidung ermöglichen.
  - Entscheidungsbedingungen unterstützen.
  - Individuelle Konsequenzen je Auswahlmöglichkeit definieren.
  - Entscheidungen dauerhaft im Spielerzustand speichern.
  - Konsequenzen für Folgequests, NPCs, Fraktionen, Wissen und Weltzustände ermöglichen.
  - Bereits getroffene Entscheidungen für spätere Quests abrufbar machen.

## 5. Rewards



Bearbeiten

&#x20;Bereich: `rewards`



- Grund: Einheitliche Verarbeitung und Unterstützung bedingter Belohnungen.
- Art der Änderung: Struktur vereinheitlichen und erweitern.
- Änderungen:
  - `item` in `items` integrieren.
  - Sämtliche Gegenstandsbelohnungen über ein einheitliches Array verwalten.
  - Bedingte Belohnungen ermöglichen.
  - Wahlbelohnungen ermöglichen.
  - Wiederholbare Belohnungen gesondert definieren.
  - Bestehende Belohnungstypen beibehalten:
    - XP
    - Gold
    - Gegenstände
    - Materialien
    - Vaelith-Resonanz
    - Buffs
    - Lore
    - Baupläne
    - Gebietsfreischaltungen

## 6. World Changes



Bearbeiten

&#x20;Bereich: `worldChanges`



- Grund: Zentrale Verwaltung komplexer Weltveränderungen und Vermeidung doppelter Logik.
- Art der Änderung: Struktur beibehalten, Verarbeitung auslagern.
- Änderungen:
  - Bestehende World-Change-IDs beibehalten.
  - World Changes als Referenzen auf zentral definierte Weltaktionen behandeln.
  - Weltaktionen zentral verwalten.
  - Mehrere Aktionen pro World Change unterstützen.
  - Bedingungen für einzelne Weltaktionen ermöglichen.
  - Auswirkungen auf NPCs, Fraktionen, Regionen, Beziehungen und Ereignisse unterstützen.
  - Einmalige Ausführung und Wiederholungsschutz gewährleisten.

## 7. World State System



Neu hinzufügen

&#x20;Eigenständiger Systembereich: `World State`



- Grund: Globale Verfügbarkeit und systemübergreifende Nutzung von Weltzuständen.
- Art der Änderung: Neues zentrales System hinzufügen.
- Änderungen:
  - Zustände für NPCs verwalten.
  - Zustände für Regionen verwalten.
  - Zustände für Fraktionen verwalten.
  - Beziehungen zwischen Spieler und NPCs verwalten.
  - Globale Ereignisse verwalten.
  - Questübergreifende Zustandsabfragen ermöglichen.
  - Zustandsänderungen durch Quests und andere Spielsysteme ermöglichen.
  - Dauerhafte und temporäre Zustände unterstützen.

## 8. Knowledge System



Neu hinzufügen

&#x20;Eigenständiger Systembereich: `Knowledge`



- Grund: Unterstützung von Erkenntnissen, Hinweisen, historischen Informationen und widersprüchlichen Überlieferungen.
- Art der Änderung: Neues zentrales System hinzufügen.
- Änderungen:
  - Wissenseinträge verwalten.
  - Quellen und Herkunft dokumentieren.
  - Erkenntnisse und Hinweise speichern.
  - Bestätigte und unbestätigte Informationen unterscheiden.
  - Widersprüchliche Informationen verknüpfen.
  - Wissen als Questvoraussetzung verwenden.
  - Wissen für Dialoge und NPC-Reaktionen bereitstellen.

## 9. Dialog System



Auslagern

&#x20;Felder: `completeText`, `description`, `summary`



- Grund: Trennung von Questinformationen und dynamischen NPC-Dialogen.
- Art der Änderung: Dialogverarbeitung auslagern und erweitern.
- Änderungen:
  - Dialogdefinitionen eigenständig verwalten.
  - Dialogverzweigungen unterstützen.
  - Spielerantworten ermöglichen.
  - Bedingte Dialogoptionen ermöglichen.
  - Dialogaktionen unterstützen.
  - NPC-Reaktionen anhand von Entscheidungen, Wissen und Beziehungen ermöglichen.
  - Mehrsprachigkeit für sämtliche Dialoginhalte gewährleisten.
  - `completeText` mehrsprachig ergänzen.

## 10. Quest Runtime / Event Engine



Neu hinzufügen

&#x20;Eigenständiger Systembereich: `Quest Runtime`



- Grund: Zentrale Verarbeitung sämtlicher Questereignisse und Fortschritte.
- Art der Änderung: Neues zentrales System hinzufügen.
- Änderungen:
  - Questdefinitionen einlesen und validieren.
  - Queststatus und Fortschritt verwalten.
  - Ereignisse aus anderen Spielsystemen entgegennehmen.
  - Objectives anhand eingehender Ereignisse aktualisieren.
  - Conditions auswerten.
  - Questfreischaltungen verarbeiten.
  - Entscheidungen speichern.
  - Belohnungen und Weltaktionen ausführen.
  - Mehrfachausführungen verhindern.
  - Questabbrüche und Scheitern verwalten.
  - Wiederholbare Quests unterstützen.

## 11. Quest Lifecycle



Erweitern

&#x20;Bereich: Queststatus und Lifecycle



- Grund: Vollständige Verwaltung unterschiedlicher Questzustände.
- Art der Änderung: Neue Status und Eigenschaften ergänzen.
- Änderungen:
  - Queststatus definieren:
    - `locked`
    - `available`
    - `active`
    - `completed`
    - `failed`
    - `abandoned`
  - `replayAllowed` beibehalten.
  - `abandonable` ergänzen.
  - `failureConditions` ergänzen.
  - `timeLimit` ergänzen.
  - `repeatCooldown` ergänzen.
  - Einmalige und wiederholbare Belohnungen unterscheiden.
  - Questabschluss und Questwiederholung getrennt verwalten.

## 12. Quest Definition – Zusätzliche Metadaten



Erweitern

&#x20;Bereich: Quest-Metadaten



- Grund: Bessere Verwaltung, Kategorisierung und langfristige Pflege der Questbibliothek.
- Art der Änderung: Felder ergänzen.
- Änderungen:
  - `tags` beibehalten.
  - `version` beibehalten.
  - `author` beibehalten.
  - `reviewed` beibehalten.
  - `lastModified` beibehalten.
  - `priority` ergänzen.
  - `visibility` ergänzen.
  - `ending` beibehalten.
  - `boardPos` als Editor-Metadatum behandeln.

## 13. Player Quest State



Neu hinzufügen

&#x20;Eigenständiger Systembereich: `Player Quest State`



- Grund: Trennung statischer Questdefinitionen vom individuellen Spielfortschritt.
- Art der Änderung: Neues persistentes Datensystem hinzufügen.
- Änderungen:
  - Aktive Quests speichern.
  - Abgeschlossene Quests speichern.
  - Gescheiterte Quests speichern.
  - Objective-Fortschritt speichern.
  - Getroffene Entscheidungen speichern.
  - Erhaltene Belohnungen dokumentieren.
  - Questbezogene Weltaktionen dokumentieren.
  - Wiederholungsstatus speichern.
  - Individuelle Questzustände dauerhaft erhalten.

## 14. Schema und Validierung



Erweitern

&#x20;Datei: `quest_schema_v2.json`



- Grund: Sicherstellung der strukturellen Konsistenz sämtlicher Questdefinitionen.
- Art der Änderung: Schema erweitern.
- Änderungen:
  - Neue Questfelder aufnehmen.
  - Neue Objective-Typen validieren.
  - Condition-Strukturen validieren.
  - Decision-Strukturen validieren.
  - Reward-Strukturen validieren.
  - Referenzen auf World Changes validieren.
  - Referenzen auf Dialoge und Wissenseinträge validieren.
  - Pflichtfelder und Datentypen definieren.
  - Veraltete Feldstrukturen kennzeichnen.
  - Schema-Versionierung ermöglichen.



Nicht entfernen

&#x20;Bestehende Questdefinitionen und Daten



- Bestehende Quest-IDs erhalten.
- Bestehende Questlinien erhalten.
- Bestehende Objective-IDs erhalten.
- Bestehende Belohnungsdaten erhalten.
- Bestehende World-Change-Referenzen erhalten.
- Bestehende Übersetzungen erhalten.
- Bestehende Questverknüpfungen erhalten.
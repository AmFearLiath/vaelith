# 07. Umsetzungs-Roadmap & Code-Architektur
## Der modulare Implementierungsplan für Emberwild

**Dokument-Status:** Verbindliches, eigenständiges Fachkonzept  
**Bereich:** Technische Architektur, Roadmap, Dateizuordnung & Performance-Budget  
**Zielcode:** `src/worldsys/`, `src/ui/`, `src/entities/`, `src/data/`  

---

## 1. Übersicht & Architektur-Leitlinien

Alle im Konzeptdossier definierten Systeme werden **schrittweise, wohlüberlegt und ohne Geschwindigkeitsdruck** in die bestehende Codebase von Emberwild integriert. 

### Die drei Architektur-Grundsätze
1. **Modulare ES-Module:**  
   Systeme werden sauber über das globale Service-Register `G` und den Event-Bus `G.events` entkoppelt. Keine zirkulären Abhängigkeiten, keine unkontrollierten Singletons.
2. **Tickrate-Budgetierung (Sim-LOD):**  
   * **LOD 2 (Aktives UI & Meister):** Tickrate $10\text{ Hz}$ (reaktive GUI-Aktualisierung).
   * **LOD 1 (Dorf-Arbeiter & Tiere im Nahbereich):** Tickrate $1\text{ Hz}$ (Pfadfindung, Weiden, Arbeits-Ticks).
   * **LOD 0 (Provinzen, Bilanzen, Karawanen):** Tickrate $0.1\text{ Hz}$ (alle 10 Sekunden ein Aggregations-Tick).
3. **Strikte Verifikation vor jedem Commit:**  
   Syntax-Prüfung (`node -c`), Validierung aller Sprachschlüssel (`verify_i18n.mjs`), Testen im Spiel.

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              MODUL- & DATEI-ARCHITEKTUR                                │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   KERNEL & CORE                  WORLDSYS & SIMULATION        USER INTERFACE           │
│   ┌──────────────────────────┐   ┌────────────────────────┐   ┌────────────────────┐   │
│   │ src/core/G.js            │   │ src/worldsys/          │   │ src/ui/            │   │
│   │ • Global Service Locator │   │ • settlement.js        │   │ • buildingWindow.js│   │
│   │ src/core/i18n.js         │   │ • settlementWorkers.js │   │ • settlementPanel  │   │
│   │ • Mehrsprachigkeit       │   │ • economy.js (Neu)     │   │ • worldMap.js      │   │
│   │ src/core/events.js       │   │ • director.js (Neu)    │   │ • breedingPanel.js │   │
│   │ • Event-Bus              │   │ • crisis.js            │   │ • crisisBanner.js  │   │
│   └──────────────────────────┘   └────────────────────────┘   └────────────────────┘   │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Der modulare 6-Phasen-Entwicklungsplan

### Phase 1: Meister- & Vorarbeiter-System (PILOTPROJEKT – ABGESCHLOSSEN)
*Status: Vollendet und getestet.*
* Hinzufügen des Meister-Katalogs in [`settlementWorkers.js`](file:///f:/Emberwild/src/worldsys/settlementWorkers.js) mit Traits, Hoftiteln und Porträts.
* Meister-Zuweisung und Fokus-Leiste in [`buildingWindow.js`](file:///f:/Emberwild/src/ui/buildingWindow.js).
* Filter-Umschalter `[Nur Fachkräfte]` vs. `[Alle Bürger]`.
* Beseitigung aller Emojis und native Tooltips; Anbindung an `i18n.js` (`de.js` & `en.js`).

---

### Phase 2: Karriere-Progression & Erfahrungs-System (NÄCHSTER SCHRITT)
*Fokus: Langzeit-Motivation für Bürgerzuweisungen.*
1. **XP-Tracking:** Arbeiter erhalten bei jedem Produktionszyklus Erfahrung in ihrem ausgeübten Handwerk.
2. **Aufstiegs-Logik:**
   * Hilfskraft ($0\text{ XP}$) $\rightarrow$ Lehrling ($500\text{ XP}$) $\rightarrow$ Geselle ($2.500\text{ XP}$) $\rightarrow$ Meister ($10.500\text{ XP}$).
3. **UI-Visualisierung:**
   * Fortschrittsbalken in der Arbeiterzeile von `buildingWindow.js`.
   * Beförderungs-Schaltfläche bei Erreichen des Schwellenwerts.

---

### Phase 3: Die vier Kernbedürfnisse & die Siedlungsmoral
*Fokus: Wirtschaftliche Konsequenzen von Nahrung und Sicherheit.*
1. **Verbrauchs-Simulation:**
   * Bürger verbrauchen täglich $1$ Getreide/Brot aus dem Vorratslager.
   * Fehlt Nahrung, sinkt der Sättigungswert $S$.
2. **Moral-Multiplikator:**
   * Siedlungsmoral berechnet sich aus Sättigung, Erholung (Betten in Wohnhäusern), Wachen und Taverne.
   * Multiplikator ($50\% - 150\%$) fließt dynamisch in den Ausstoß aller Werkstätten ein.
3. **UI:** Moralanzeige im oberen Siedlungsbanner (`settlementPanel.js`).

---

### Phase 4: Vertieftes Reittier- & Genetik-System (Lite)
*Fokus: Das Königliche Gestüt und Zuchterfolge.*
1. **Allel-Datenstruktur:** Erweiterung des Reittier-Objekts um vererbbare Gene (`SPD`, `STA`, `SIZ`, `COR`, `COL`, `GLW`).
2. **Zuchtstation-Update:**
   * Zucht-Ergebnis berechnet sich aus dem 2-Chromosomen-Mendel-Modell.
   * Zuchtkatalysatoren aus der Alchemie (Glutessenz für feurige Mähne).
3. **Visuelle Darstellung:** Reittier-Modell passt Partikeleffekte und Texturfarbe an den Phänotyp an.

---

### Phase 5: Physische Provinz-Karawanen auf der Weltkarte
*Fokus: Verknüpfung der 294 Provinzen mit der Hauptstadt.*
1. **Karawanen-Routen:**
   * Befreite Außenposten entsenden periodisch Karawanen nach Emberwatch.
   * Karawanen-Marker bewegen sich über Straßen auf der Weltkarte (`src/ui/worldMap.js`).
2. **Überfall-Risiko & Geleitschutz:**
   * Aschedichte und Gefahrenstufe bestimmen das Überfallrisiko.
   * Notsignal im HUD: Spieler kann per Wegstein zur Provinz reisen und die Karawane im ARPG-Kampf retten.

---

### Phase 6: Der Asche-Direktor & Emergente Krisen
*Fokus: Lebendige, unvorhersehbare Spielwelt.*
1. **Sensoren-Architektur:**
   * System-Sensoren erfassen Nahrungsmangel, ungesühnte Schreine, Wolfshunger und Aschedichte.
2. **Krisen-Stufen:**
   * Organisches Auslösen der 4 Stufen (vom dezenten Toast bis zur Stadt-Invasion).
3. **Verteidigungsschlacht von Emberwatch:**
   * Vollwertiges 3-Wellen-Verteidigungsevent mit Torsicherung und Bosskampf.

---

## 3. Dateizuordnung (Code-Landkarte)

| System-Komponente | Relevante Quelldateien | Status |
|---|---|---|
| **Meister & Vorarbeiter** | `src/worldsys/settlementWorkers.js`, `src/worldsys/settlement.js`, `src/ui/buildingWindow.js` | **Fertiggestellt & Verifiziert** |
| **Karriere & Jobränge** | `src/worldsys/settlementWorkers.js`, `src/ui/buildingWindow.js` | Phase 2 (Bereit zur Umsetzung) |
| **Siedlungsmoral & Bedürfnisse** | `src/worldsys/settlement.js`, `src/ui/settlementPanel.js` | Phase 3 |
| **Genetik- & Zuchtsystem** | `src/mounts/`, `src/ui/breedingPanel.js`, `src/entities/animals/` | Phase 4 |
| **Karawanen & Logistik** | `src/worldsys/economy.js`, `src/ui/worldMap.js` | Phase 5 |
| **Asche-Direktor & Krisen** | `src/worldsys/crisis.js`, `src/worldsys/director.js` | Phase 6 |
| **Lokalisierung (i18n)** | `src/core/i18n.js`, `src/data/locales/de.js`, `src/data/locales/en.js` | Laufend synchronisiert |


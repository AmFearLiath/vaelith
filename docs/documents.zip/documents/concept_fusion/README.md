# Konzept-Dossier: Emberwild (Living Kingdoms Fusion)
## Vollständig eigenständige, adaptierte Konzeptdokumentation für Emberwild

**Projekt:** Emberwild (ARPG & Siedlungs-Simulation)  
**Status:** Verbindliche Entwürfe & System-Spezifikationen  
**Autarkie-Garantie:** Alle Dokumente in diesem Ordner sind **100% in sich geschlossen**. Es werden keinerlei externe Projektordner, Pfade oder fremde Repositories referenziert. Sämtliche Formeln, Datenstrukturen, Wertetabellen, Verhaltensmuster und Lore-Elemente sind direkt hier für Emberwild und den Kontinent Aethelgard ausgearbeitet.

---

### Inhaltsverzeichnis der Fachkonzepte

1. [`00_GESAMTVIZION_UND_SYSTEMARCHITEKTUR.md`](00_GESAMTVIZION_UND_SYSTEMARCHITEKTUR.md)  
   *Die Verschmelzung von Hack-and-Slay Combat mit organischer Koloniesimulation. Die 5 Kernsäulen, Leitprinzipien und Systeminteraktionen.*

2. [`01_ASCHE_OEKOLOGIE_KREATUREN_UND_GENETIK.md`](01_ASCHE_OEKOLOGIE_KREATUREN_UND_GENETIK.md)  
   *Das atmende Ökosystem von Aethelgard: Fauna-Klassifikation, Lotka-Volterra-Populationsformeln, Nahrungsketten, Überjagungskonsequenzen, das Genetik-Lite-Modell für Reittiere & Nutztiere, Zuchtkatalysatoren und Asche-Mutanten.*

3. [`02_WIRTSCHAFT_PRODUKTIONSKETTEN_UND_KARAWANEN.md`](02_WIRTSCHAFT_PRODUKTIONSKETTEN_UND_KARAWANEN.md)  
   *Das 4-Stufen-Warenwirtschaftssystem: Rohstoffe, primäre Werkstoffe, Fertigungsgüter und Meistergüter. Siedlungslogistik, physische Karawanen auf den 294 Provinzen, Überfallrisiken und Goldkreisläufe.*

4. [`03_NPC_SIMULATION_MEISTER_UND_DORFLEBEN.md`](03_NPC_SIMULATION_MEISTER_UND_DORFLEBEN.md)  
   *Bewohner-Simulation und Werkstattleiter: Dreistufige Sim-LOD-Architektur, vollständiger Meisterkatalog, Meisterprägungen und Berichte, 4-Stufen-Karriereleiter (Hilfskraft bis Meister), XP-Gewinn, die 4 Kernbedürfnisse und Siedlungsmoral.*

5. [`04_EMERGENTE_EREIGNISSE_UND_ASCHE_DIREKTOR.md`](04_EMERGENTE_EREIGNISSE_UND_ASCHE_DIREKTOR.md)  
   *Organische, zustandsgetriebene Krisen statt Zufallstimer: Sensoren-Architektur, 4 Schweregrade, vollständiger Ereigniskatalog (ökologisch, ökonomisch, sozial, Asche-Invasion) und Dramaturgie-Pacing.*

6. [`05_AETHELGARD_WELT_UND_PROVINZ_STRATEGIE.md`](05_AETHELGARD_WELT_UND_PROVINZ_STRATEGIE.md)  
   *Die 294 Provinzen des Kontinents: Die 5 Großregionen, prozedurale Zonen, Points of Interest, Schrein-Befriedung, Korruptionsmechanik, Signaltürme und Straßeninfrastruktur.*

7. [`06_UI_UX_DESIGN_UND_IMMERSION.md`](06_UI_UX_DESIGN_UND_IMMERSION.md)  
   *Visuelle Richtlinien: Null Emojis als Icons, Custom Dark-Fantasy-Tooltips, SVG-Sternenfortschritt, Aufbau des BuildingWindow, Barrierefreiheit und Audio-Feedback.*

8. [`07_UMSETZUNGS_ROADMAP_UND_CODE_ARCHITEKTUR.md`](07_UMSETZUNGS_ROADMAP_UND_CODE_ARCHITEKTUR.md)  
   *Modulare 6-Phasen-Roadmap für die Implementierung in Emberwild, Sim-LOD-Performancebudget (60 FPS), Code-Landkarte und Verifikations-Leitlinien.*


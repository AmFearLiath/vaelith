# 05. Aethelgard-Welt & Provinz-Strategie
## Die 294 Provinzen des Kontinents als makro-ökonomischer Schauplatz

**Dokument-Status:** Verbindliches, eigenständiges Fachkonzept  
**Bereich:** Kontinent-Geografie, Provinzen, Außenposten, Schrein-Befriedung & Welthandel  
**Zielcode in Emberwild:** `src/ui/worldMap.js`, `src/world/areas/provinceZone.js`, `src/ui/travelModal.js`, `tools/compile_worldmap.js`  

---

## 1. Übersicht & Kontinent-Architektur

In herkömmlichen ARPGs ist eine Weltkarte oft nur ein glorifiziertes Teleport-Menü mit Hintergrundbild.

**In Emberwild ist Aethelgard ein lebendiges, vernetztes Reich:**
* Der Kontinent umfasst **294 einzeln kartografierte Provinzen**, unterteilt in 5 monumentale Kultur- und Klimazonen.
* Jede Provinz besitzt eine eigene **ökologische Signatur** (dominante Flora, Tierwelt und Mineralienvorkommen) sowie eine **Gefahrenstufe (Tier 1 bis 5)**.
* Befreite Provinzen können durch den Bau von **Vorposten, Minencamps und Signaltürmen** befestigt werden, um kontinuierlich Ressourcen per Karawane nach Emberwatch zu liefern.

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              DIE 5 GROSSREGIONEN VON AETHELGARD                        │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   REGION 1: DIE ASCHEN-KERNLANDE (Tier 1 / Sicherer Hafen)                             │
│   • Das Umland von Emberwatch, lichte Kiefernwälder, Flussauen, Wildweiden             │
│   • Primärressourcen: Bauholz, Granit, Weizen, Flachs, Grundwildbret                   │
│                                                                                        │
│   REGION 2: DIE GRAUEN FELDER & DAS TRÜMMERLAND (Tier 2 / Moderat)                     │
│   • Uralte Schlachtfelder, nebelverhangene Gräberhügel, Ruinen alter Klöster           │
│   • Primärressourcen: Schiefer, Lehm, Wermutkraut, Knochenkohle, Wolfspelze            │
│                                                                                        │
│   REGION 3: DIE EISENSCHLUCHT & DER SCHMELZKAMM (Tier 3 / Gefährlich)                  │
│   • Zerklüftete Canyons, aufgegebene Zwergenstollen, Schwefelquellen                   │
│   • Primärressourcen: Hochwertiges Roheisen, Steinkohle, Basaltquader, Silbererz       │
│                                                                                        │
│   REGION 4: DAS BRENNENDE HOCHLAND & VARKHULS THRON (Tier 4 / Tödlich)                 │
│   • Basaltwüsten, erstarrte Lavaströme, Aschenritter-Festungen                         │
│   • Primärressourcen: Glutstahl-Erz, Schwefelblüte, Obsidian, Phönixgeweih             │
│                                                                                        │
│   REGION 5: DER VERSUNKENE ZIRKEL & DIE OBSIDIAN-KÜSTE (Tier 5 / Albtraum)             │
│   • Giftige Tiefenlagunen, versunkene Zitadellen, Titanen-Skelette                     │
│   • Primärressourcen: Natur-Quintessenz, Drachenknochen, Sternenmetall                 │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Die Provinz-Anatomie (Prozedurale Zonen)

Jede der 294 Provinzen generiert beim Betreten ein prozedurales 2.5D-Areal mit strategischen Points of Interest (POIs):

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              AUFBAU EINER PROVINZZONE                                  │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   [WEGSTEIN] ─────────────── [KARAWANEN-STRASSE] ─────────────── [AUSSENPOSTEN]        │
│   (Teleport-Punkt             (Reitweg für Pferde              (Befestigtes Lager,    │
│    des Helden)                 und Karawanen)                   Kommando-Zelt)         │
│                                                                        │               │
│                                ┌───────────────────────────────────────┘               │
│                                ▼                                                       │
│   ┌────────────────────────────────────────────────────────────────────────┐           │
│   │ PUNKTE VON STRATEGISCHEM INTERESSE (POIs)                              │           │
│   │ • Der Provinz-Schrein: Senkt Asche-Korruption bei Reinigung um -40%    │           │
│   │ • Die Ressourcen-Lagerstätte: z.B. Reiche Eisenader oder Holzschlag     │           │
│   │ • Der Kerker / Die Krypta: Unterirdischer Dungeon mit Boss-Begegnung   │           │
│   │ • Das Banditen- / Aschelager: Muss geräumt werden für Routensicherheit │           │
│   └────────────────────────────────────────────────────────────────────────┘           │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2.1 Provinz-Typen & Spezialisierungen

| Provinz-Typ | Hauptnutzen | Errichtbare Außenposten | Karawanen-Fracht |
|---|---|---|---|
| **Forst-Provinz** | Holz & Harz | Holzfäller-Palisade, Sägemühle | Hartholzbalken, Harzfässer |
| **Berg- & Erz-Provinz** | Eisen, Kohle, Stein | Minen-Bollwerk, Schmelzofen | Roheisen, Steinkohle, Werkstein |
| **Fruchtbare Marsch** | Nahrung & Textil | Wehrbauernhof, Mühlenwehre | Getreidesäcke, Flachsballen |
| **Magischer Hain** | Alchemie & Zucht | Druidenklause, Heilerposten | Seltene Kräuter, Natur-Essenz |
| **Grenzfeste** | Militärischer Schutz | Signalturm, Wacht-Bastion | Keine Fracht; senkt Überfallrisiko um $60\%$ |

---

## 3. Schrein-Befriedung & Asche-Korruption

Jede Provinz leidet unter einem variablen **Asche-Korruptionsgrad (0 bis 100%)**:

$$K_{prov} = \text{Basis-Korruption} + \left(0.5 \times \text{Tage ohne Schreinopfer}\right) - \left(30 \times \text{Gereinigte Schreine}\right)$$

### 3.1 Auswirkungen hoher Korruption ($K_{prov} > 60\%$)
1. **Aggressive Fauna:** Tiere mutieren häufiger zu Aschebestien; Fluchtradius sinkt, Angriffslust steigt.
2. **Straßengefahr:** Überfallrisiko für Karawanen steigt um $+25\%$.
3. **Schleichender Schaden:** Der Held erleidet bei Aschestürmen kontinuierlichen Lebenspunkteverlust, sofern er keinen Schutztrank konsumiert.

### 3.2 Die Schrein-Reinigungs-Zeremonie
* Der Held muss 3 Wellen verdammter Wächter am Altar bezwingen.
* Nach dem Sieg wird **Natur-Essenz** am Schrein geopfert.
* **Effekt:** Die Provinz erstrahlt in goldenem Licht, Korruption sinkt sofort auf $0\%$, und ein permanenter Reisesegen gewährt $+15\%$ Reittempo im gesamten Gebiet.

---

## 4. Das Befestigungs- und Signalturm-Netzwerk

Um Karawanen über weite Strecken sicher nach Emberwatch zu geleiten, kann der Spieler in befreiten Provinzen Infrastruktur errichten:

1. **Signaltürme (Leuchtfeuer):**  
   *Kosten:* 80 Bauholz, 40 Stein, 50 Gold.  
   *Nutzen:* Verhindert Überraschungsüberfälle auf Karawanen. Gibt dem Helden 3 Minuten Vorwarnzeit, um bei Angriffen einzugreifen.
2. **Straßenpflasterung (Steinmetzarbeit):**  
   *Kosten:* 150 Werkstein.  
   *Nutzen:* Beschleunigt Karawanen und Reittiere auf der Hauptachse um $+30\%$; verhindert Feststecken im Schlamm.
3. **Miliz-Wachhäuser:**  
   *Kosten:* 100 Holz, 60 Eisen, 2 zugewiesene Gesellen.  
   *Nutzen:* Entsendet automatisch 2 Wachen zur Begleitung jeder durchreisenden Karawane.


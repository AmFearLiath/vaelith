# 00. Gesamtvision & Systemarchitektur
## Die Fusion von ARPG-Combat & Lebendiger Koloniesimulation

**Projekt:** Emberwild  
**Dokumenten-Status:** Verbindliches, eigenständiges Konzept (100% autark)  
**Welt:** Aethelgard (Das Königreich der Asche)  
**Hauptsitz:** Die Feste Emberwatch  
**Datum:** November 2026  

---

## 1. Die Kernvision: "The Crown & The Wild" in Emberwild

Bisherige Action-RPGs behandeln die Welt oft als statische Kulisse: Monster stehen in der Einöde und warten darauf, vom Helden erschlagen zu werden; Werkstätten sind bloße Menüs ohne Leben; Rohstoffe existieren nur als abstrakte Zähler im Inventar.

**Emberwild bricht mit dieser Konvention.**  
Wir verschmelzen packendes **Dark-Fantasy-Hack-and-Slay** mit einer **organisch simulierten, reaktiven Spielwelt**:

1. **Die Krone ("The Crown"):** Die Zivilisation, vertreten durch die wiederauflebende Zuflucht **Emberwatch**, ihre Werkstätten, Meisterhandwerker, Vorarbeiter, Bürger, Minen und Karawanen.
2. **Die Wildnis ("The Wild"):** Das ungezähmte Land **Aethelgard** mit seinen 294 Provinzen, lebendigen Tierherden, Nahrungsketten, Aschestürmen und mutierten Aschebestien, die auf das Vorrücken der Menschen reagieren.

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                DIE EMBERWILD-SYNTHESE                                  │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   ┌───────────────────────────┐                      ┌─────────────────────────────┐   │
│   │         THE CROWN         │                      │          THE WILD           │   │
│   │   (Zivilisation & Bau)    │                      │     (Ökologie & Gefahr)     │   │
│   ├───────────────────────────┤                      ├─────────────────────────────┤   │
│   │ • Meister & Gesellen      │                      │ • Lebendige Nahrungskette   │   │
│   │ • Werkstätten & Ausbau    │◄─── Ressourcen ─────┤ • Tierherden & Raubtiere    │   │
│   │ • 4-Stufen-Warenwirtschaft│                      │ • Asche-Mutationen & Zucht  │   │
│   │ • Provinz-Karawanen       │───── Expansion ────►│ • Schreine, Ruinen & Höhlen │   │
│   │ • Siedlungsmoral & Bürger │                      │ • 294 Provinzen Aethelgards │   │
│   └─────────────┬─────────────┘                      └──────────────┬──────────────┘   │
│                 │                                                   │                  │
│                 └─────────────────────┐       ┌─────────────────────┘                  │
│                                       ▼       ▼                                        │
│                           ┌───────────────────────────────┐                            │
│                           │        DER ASCHE-HELD         │                            │
│                           │     (ARPG-Spielerfigur)       │                            │
│                           ├───────────────────────────────┤                            │
│                           │ • Flüssiges ARPG-Combat       │                            │
│                           │ • Talentbäume & Klassen       │                            │
│                           │ • Reittiere & Zucht           │                            │
│                           │ • Schutz der Siedler          │                            │
│                           │ • Klärung emergenter Krisen   │                            │
│                           └───────────────────────────────┘                            │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Die fünf Säulen des Gesamtsystems

Jede Säule ist in einem eigenen, voll ausgearbeiteten Dokument in diesem Verzeichnis spezifiziert:

### Säule 1: Asche-Ökologie, Kreaturen & Genetik
*Dokument:* `01_ASCHE_OEKOLOGIE_KREATUREN_UND_GENETIK.md`  
* Tiere sind keine Dummy-Spawns, sondern Teil einer lebendigen Nahrungskette (Pflanzenfresser weiden, Raubtiere jagen im Rudel).
* Überjagung treibt hungrige Raubtiere an die Zäune der Vorposten und Karawanenwege.
* Tiefe Genetik-Lite-Mechanik für Reittiere und Nutztiere: Vererbbare Merkmale (Größe, Tempo, Ausdauer, Fellfarbe, Schuppenglanz) und rezessive Gene.
* Asche-Mutationen: In korrumpierten Provinzen entstehen seltene Monstrositäten (Glutwolf, Basaltbär, Phönixhirsch), die gezähmt oder für legendäre Handwerkszutaten gejagt werden können.

### Säule 2: Wirtschaft, Produktionsketten & Karawanen
*Dokument:* `02_WIRTSCHAFT_PRODUKTIONSKETTEN_UND_KARAWANEN.md`  
* Ein hierarchisches 4-Stufen-Wirtschaftssystem: Von Rohstoffen (Holz, Erz, Lehm, Getreide) über verarbeitete Güter (Balken, Barren, Mehl) und Fertigungsgüter (Werkzeuge, Waffen, Bier, Rüstungen) bis zu Meister- & Kultgütern (Glutstahl-Klingen, Elixiere).
* Physische Logistik: Träger und Karren transportieren Waren innerhalb der Siedlung; Provinz-Karawanen verbinden eroberte Außenposten auf der 294-Provinzen-Weltkarte mit Emberwatch.
* Karawanen können überfallen werden – der Spieler erhält dynamische Notrufe und Geleitschutz-Missionen.

### Säule 3: NPC-Simulation, Meister & Dorfleben
*Dokument:* `03_NPC_SIMULATION_MEISTER_UND_DORFLEBEN.md`  
* Drei-Stufen-Simulations-LOD für maximale Browser-Performance (LOD 0 im Hintergrund, LOD 1 für normale Arbeiter, LOD 2 für benannte Meisterpersönlichkeiten).
* Das Meister-System: Werkstätten werden von Meistern geführt (z.B. Großschmiedemeister Aldric Venn). Meister besitzen einzigartige Traits, Zitate, Statusberichte und schalten Spezialrezepte frei.
* Karriereleiter für alle Bürger: Hilfskraft → Lehrling → Geselle → Meister.
* Vier greifbare Kernbedürfnisse: Sättigung, Erholung/Wohnraum, Sicherheit, Moral/Hoffnung.

### Säule 4: Emergente Ereignisse & Der Asche-Direktor
*Dokument:* `04_EMERGENTE_EREIGNISSE_UND_ASCHE_DIREKTOR.md`  
* Keine willkürlichen 10-Minuten-Timer, sondern **organisch aus dem Spielzustand entstehende Krisen**.
* Reagiert auf Nahrungsmangel, unbewachte Grenzen, ungesühnte Schreine oder Überjagung.
* Vier Schweregrade: Gering (Hinweis), Moderat (Aufgabe/Quest), Schwer (Siedlungsalarm / Verteidigung), Katastrophal (Asche-Invasion / Riss-Bruch).

### Säule 5: Aethelgard-Makrostrategie & Provinzen
*Dokument:* `05_AETHELGARD_WELT_UND_PROVINZ_STRATEGIE.md`  
* Die 294 Provinzen des Kontinents als vernetztes Territorium mit fünf Gefahrenstufen, variablen Biomen und strategischen Ressourcen.
* Vorposten-Bollwerke, Leuchttürme und Minencamps zur Sicherung der Handelsrouten.

---

## 3. Grundsätze für Design & Immersion

1. **Vollständige Selbstständigkeit:**  
   Dieses Konzeptdossier ist zu 100% eigenständig. Alle Formeln, Wertetabellen, Verhaltensmuster und Schnittstellen sind direkt in den Dokumenten dieses Ordners definiert.
2. **Keine Emojis als Icons:**  
   In der Spielwelt und im User Interface existieren keine Emojis. Symbole werden ausschließlich als hochqualitative SVGs, Wappen, Medaillons oder Texturen dargestellt.
3. **Browser-Tauglichkeit & 60 FPS:**  
   Alle Systeme sind so mathematisch formuliert, dass sie auf modernen JavaScript-Engines und Three.js bei minimalem CPU-Overhead laufen (strikte LOD-Trennung, Vektorisierung, Event-Dispatching).
4. **Respekt für das ARPG-Tempo:**  
   Die Koloniesimulation soll das Hack-and-Slay-Erlebnis bereichern, nicht durch endlose Mikromanagement-Formulare lähmen. Meister automatisieren Betriebe, Karawanen fahren autonom, Krisen bieten spannende Kampfanlässe.

---

## 4. Inhaltsverzeichnis des Konzeptdossiers

1. `00_GESAMTVIZION_UND_SYSTEMARCHITEKTUR.md` *(Dieses Dokument)*
2. `01_ASCHE_OEKOLOGIE_KREATUREN_UND_GENETIK.md`
3. `02_WIRTSCHAFT_PRODUKTIONSKETTEN_UND_KARAWANEN.md`
4. `03_NPC_SIMULATION_MEISTER_UND_DORFLEBEN.md`
5. `04_EMERGENTE_EREIGNISSE_UND_ASCHE_DIREKTOR.md`
6. `05_AETHELGARD_WELT_UND_PROVINZ_STRATEGIE.md`
7. `06_UI_UX_DESIGN_UND_IMMERSION.md`
8. `07_UMSETZUNGS_ROADMAP_UND_CODE_ARCHITEKTUR.md`


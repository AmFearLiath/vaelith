# 03. NPC-Simulation, Meister & Dorfleben
## Das autonome Vorarbeiter- und Karrieresystem von Emberwild

**Dokument-Status:** Verbindliches, eigenständiges Fachkonzept  
**Bereich:** Bewohner-Simulation, Meister-System, Berufsaufstiege, Bedürfnisse & Siedlungsmoral  
**Zielcode in Emberwild:** `src/worldsys/settlement.js`, `src/worldsys/settlementWorkers.js`, `src/ui/buildingWindow.js`, `src/npcs/`  

---

## 1. Übersicht & Design-Philosophie

Bürger in Emberwild sind keine gesichtslosen Ziffern in einem Excel-Menü. Sie sind **lebendige Bewohner der Zuflucht**, die persönliche Geschichten, Fähigkeiten, Karriereambitionen und Stimmungen besitzen:

1. **Simulations-LOD:** Eine dreistufige Architektur stellt sicher, dass hunderte Arbeiter simuliert werden können, ohne die 60-FPS-Grenze im Web-Browser zu gefährden.
2. **Meister & Vorarbeiter ("Building Managers"):** Jede Werkstatt wird von einem erfahrenen Meister geführt (z.B. Großschmiedemeister *Aldric Venn*). Meister verleihen Betrieben einzigartige Prägungen, Statusberichte und Spezialrezepte.
3. **Karriere-Leiter:** Vom Tagelöhner über den Lehrling und Gesellen bis zum Meister – Arbeiter sammeln Erfahrung durch geleistete Arbeitsstunden.
4. **Die vier Grundbedürfnisse:** Anstelle unübersichtlicher Psychologie-Menüs steuern vier klare Faktoren die Siedlungsmoral: **Sättigung, Erholung, Sicherheit und Hoffnung**.

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              DIE DREISTUFIGE SIM-LOD-ARCHITEKTUR                       │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   LOD 2: SCHLÜSSEL-NPCS & WERKSTATT-MEISTER (12–20 Individuen)                         │
│   ┌─────────────────────────────────────────────────────────────────────────────┐      │
│   │ • Detailliertes Porträt, individuelle Meisterprägung, Hoftitel              │      │
│   │ • Dynamische Status-Zitate & situative Sprachausgaben                       │      │
│   │ • Volles Interaktionsfenster (BuildingWindow) mit Ernennung & Entlassung   │      │
│   │ • Persönliche Mini-Quests (z.B. Suche nach seltenem Schmelzkohle-Flöz)      │      │
│   └──────────────────────────────────────┬──────────────────────────────────────┘      │
│                                          │ Führt & beaufsichtigt                       │
│                                          ▼                                             │
│   LOD 1: SICHTBARE SIEDLUNGS-ARBEITER (30–60 Dorfbewohner)                             │
│   ┌─────────────────────────────────────────────────────────────────────────────┐      │
│   │ • Feste Tagesabläufe (Hütte ──► Werkstatt ──► Brunnen ──► Taverne)         │      │
│   │ • Sichtbare Animationen (Holz sägen, Amboss schlagen, Karren ziehen)       │      │
│   │ • Reagieren auf Wetter (suchen bei Aschesturm Schutz in der Feste)         │      │
│   │ • Sprechblasen ("Das Erz ist heute spröde, Meister Aldric!")               │      │
│   └──────────────────────────────────────┬──────────────────────────────────────┘      │
│                                          │ Speist aggregierte Daten in                 │
│                                          ▼                                             │
│   LOD 0: HINTERGRUND-KOLONISTEN & PROVINZ-MINEN (Hunderte Einheiten)                   │
│   ┌─────────────────────────────────────────────────────────────────────────────┐      │
│   │ • Reine mathematische Bilanzrechnung (Ertrag pro Stunde)                    │      │
│   │ • Berechnet ferne Vorposten, Holzfällercamps und reisende Karawanen         │      │
│   │ • Null 3D-Drawcalls, kein Animations-Overhead                               │      │
│   └─────────────────────────────────────────────────────────────────────────────┘      │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Das Meister-System ("Workshop Overseers")

Jeder Betrieb in Emberwatch kann ab Stufe 1 von einem **Meister** geleitet werden. Der Meister repräsentiert die Seele der Werkstatt.

### 2.1 Der vollständige Meister-Katalog von Emberwatch

| Werkstatt | Standard-Meister | Titel & Rang | Meisterprägung (Trait) | Bonus-Wirkung |
|---|---|---|---|---|
| **Schmiede & Arkanesse** | **Aldric Venn** | Erzschmied von Emberwatch | *Ewige Esse* | $+25\%$ Veredelungstempo; $+15\%$ Haltbarkeit aller geschmiedeten Waffen |
| **Sägewerk & Zimmermannshof** | **Kael** | Oberster Holzfällermeister | *Waldspürer* | $+20\%$ Chance auf Hartholz; $-15\%$ Axt- und Sägeblattverschleiß |
| **Steinmetzgilde** | **Boran Felsbrecher** | Vorarbeiter der Steinbrüche | *Adernblick* | $+15\%$ Roheisen- und Silberbeifang beim Brechen von Werkstein |
| **Königliches Gestüt** | **Garrick** | Roßarzt & Zuchtmeister | *Meisterzüchter* | $-25\%$ Zuchtabklingzeit; $+10\%$ Basis-Attribute bei Neugeborenen |
| **Große Taverne** | **Elise Lindt** | Wirtin zur Aschekrone | *Herzliche Gastfreundschaft* | $+20\%$ schnellere Moral-Erholung; Taverne zieht mehr Wanderer an |
| **Wach-Bastion** | **Torin Eisenflanke** | Schildmeister der Bastion | *Eiserne Wacht* | $+25\%$ Verteidigungswert gegen Asche-Invasionen; Wachen fliehen nie |
| **Ember-Kornhof** | **Gerwin Halm** | Älterer Kornmeister | *Goldene Ähren* | $+30\%$ Getreideertrag bei sonnigem Wetter; Mehltau-Resistenz |
| **Gewürz-Plantage** | **Veda Seidenhand** | Kräuter- und Flachsbäuerin | *Ertragsschub* | $+25\%$ Ernte seltene Alchemie-Pflanzen (Aschenwurz, Glutlilie) |
| **Alchemie-Laboratorium**| **Lyra Nachtschatten**| Hohe Trankmeisterin | *Quintessenz* | $-20\%$ Reagenzienkosten bei der Herstellung hochrangiger Elixiere |

### 2.2 Dynamische Meister-Statusberichte
Wenn der Spieler die Werkstatt öffnet ([`buildingWindow.js`](file:///f:/Emberwild/src/ui/buildingWindow.js)), analysiert der Meister den Gesamtzustand des Betriebs und liefert einen situativen Bericht:

1. **Optimaler Betrieb (Volle Besetzung & Rohstoffe):**  
   *„Die Essen glühen im Takt, Herr! Darin und die Gesellen schlagen den Stahl ohne Rast. Die Waffenkammer füllt sich!“*
2. **Personalmangel (Keine Gesellen zugewiesen):**  
   *„Ich stehe allein am Amboss. Meine Hammerschläge genügen kaum für die Hufeisen der Wache. Weist mir Gesellen zu!“*
3. **Rohstoffmangel (Lager leer):**  
   *„Ohne Roheisen aus den Minen erkalten die Feuer. Schafft Erz heran, sonst müssen wir Schlacke hämmern.“*
4. **Niedrige Ausbaustufe (Werkstatt auf Stufe 1):**  
   *„Diese Esse reicht für Heugabeln, nicht für Runenklingen. Baut die Schmiede aus, wenn Ihr Aschenstahl wollt!“*

---

## 3. Die 4-Stufen-Karriereleiter

Jeder Bürger startet als einfacher Tagelöhner und steigt durch geleistete Arbeitsstunden im Rang auf:

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              DIE ARBEITER-KARRIERELEITER                               │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   STUFE 0: HILFSKRAFT / TAGELÖHNER                                                     │
│   • Benötigte XP: 0                                                                    │
│   • Funktion: Einfache Handlangerarbeiten, Materialtransport                          │
│   • Produktivitäts-Multiplikator: 1.00x (+0% Bonus)                                    │
│                                                                                        │
│                                           │                                            │
│                                           ▼ 500 Arbeits-Ticks                          │
│                                                                                        │
│   STUFE 1: LEHRLING                                                                    │
│   • Benötigte XP: 500                                                                  │
│   • Funktion: Selbstständige Vorbereitung von Werkstoffen                              │
│   • Produktivitäts-Multiplikator: 1.15x (+15% Bonus); 10% weniger Rohstoffabfall       │
│                                                                                        │
│                                           │                                            │
│                                           ▼ 2.000 Arbeits-Ticks                        │
│                                                                                        │
│   STUFE 2: GESELLE (FACHKRAFT)                                                         │
│   • Benötigte XP: 2.500                                                                │
│   • Funktion: Volle Veredelung, schaltet Fachkraft-Plakette im Werkstattfenster frei   │
│   • Produktivitäts-Multiplikator: 1.35x (+35% Bonus); kann Vorposten leiten            │
│                                                                                        │
│                                           │                                            │
│                                           ▼ 8.000 Arbeits-Ticks + Meisterstück         │
│                                                                                        │
│   STUFE 3: MEISTER                                                                     │
│   • Benötigte XP: 10.500 + Quest/Meisterstück                                          │
│   • Funktion: Kann eine Werkstatt leiten; aktiviert Meisterprägung & Spezialrezepte    │
│   • Produktivitäts-Multiplikator: 1.60x (+60% Bonus für die gesamte Werkstatt)        │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.1 Die Erfahrungs-Formel (XP-Gewinn)
Bei jedem abgeschlossenen Produktionszyklus der Werkstatt erhält jeder zugewiesene Arbeiter Erfahrungspunkte:

$$\Delta XP = \text{Basis-XP} \times \text{Werkstatt-Effizienz} \times \left(1 + \text{Meister-Mentor-Bonus}\right)$$

* Besitzt der amtierende Meister die Eigenschaft *Mentor*, verdoppelt sich der Zuwachs ($\times 2.0$).
* Erreicht ein Arbeiter eine neue Stufe, erscheint eine dezente Benachrichtigung im HUD:  
  *„Darin Eisenarm hat den Rang eines Meisterschmieds erreicht!“*

---

## 4. Die vier Kernbedürfnisse & die Siedlungsmoral

Anstelle unübersichtlicher Psychologie-Attribute besitzt die Bevölkerung von Emberwatch **vier greifbare Lebensbedürfnisse**:

```
                              ┌────────────────────┐
                              │  SIEDLUNGSMORAL    │
                              │    (0 bis 100%)    │
                              └─────────┬──────────┘
                                        │
           ┌─────────────────┬──────────┴──────────┬─────────────────┐
           ▼                 ▼                     ▼                 ▼
     ┌───────────┐     ┌───────────┐         ┌───────────┐     ┌───────────┐
     │ SÄTTIGUNG │     │ ERHOLUNG  │         │SICHERHEIT │     │ HOFFNUNG  │
     │(Nahrung)  │     │(Wohnraum) │         │(Wachen)   │     │(Taverne)  │
     └───────────┘     └───────────┘         └───────────┘     └───────────┘
```

### 4.1 Die vier Säulen im Detail

1. **Sättigung ($S$):**
   * Berechnet sich aus der täglichen Nahrungsversorgung pro Kopf.
   * *Nahrungs-Vielfalt:* Gibt es neben einfachem Brot auch Wildfleisch, Fisch und Gemüse, steigt der Wert auf $100\%$ ($+15\%$ Arbeitsmoral).
   * *Hungersnot:* Fällt das Kornlager auf 0, sinkt $S$ rapide auf $0\%$.
2. **Erholung & Wohnraum ($E$):**
   * Verhältnis von gebauten Betten in Wohnhäusern zur Gesamteinwohnerzahl.
   * Genügend Brennholz im Winter/bei Nacht sichert Wärme.
3. **Sicherheit ($W$):**
   * Besetzung der Wachtürme, Zustand der Befestigungswälle und Bedrohungsgrad umliegender Provinzen.
   * Aschestürme oder unbereinigte Schreine senken das Sicherheitsgefühl.
4. **Hoffnung & Gemeinschaft ($H$):**
   * Bier- und Metversorgung in der Großen Taverne.
   * Gereinigte Schreine in der Provinz spenden Segen und Vertrauen in die Zukunft.

### 4.2 Die Gesamtmoral-Formel

$$M_{ges} = 0.35 \cdot S + 0.25 \cdot E + 0.20 \cdot W + 0.20 \cdot H$$

### 4.3 Auswirkungen der Gesamtmoral auf das Spielgeschehen

| Moral-Bereich | Zustand | Auswirkung auf Siedlung & Werkstätten |
|---|---|---|
| **$90 - 100\%$** | **Hochmotiviert (Goldenes Zeitalter)** | $+25\%$ Gesamtproduktions-Bonus; Elite-Handwerker wandern zu; keine Unruhen |
| **$70 - 89\%$** | **Zufrieden (Normalbetrieb)** | $+0\%$ Standard-Ausstoß; stabiler Siedlungsalltag |
| **$50 - 69\%$** | **Besorgt (Gedämpft)** | $-15\%$ Produktion; Gehilfen ermüden schneller |
| **$30 - 49\%$** | **Mürrisch / Unruhig** | $-35\%$ Produktion; Streikdrohungen; erste Bürger verlassen die Stadt |
| **$< 30\%$** | **Aufruhr & Hungerrevolte** | Werkstätten stellen Arbeit ein; Plünderung von Getreidespeichern; Krisen-Event |

---

## 5. Der Tagesablauf eines Siedlers (Stundenplan)

Um lebendige Kulissen zu schaffen, folgen sichtbare Arbeiter (LOD 1) einem festen Rhythmus:

* **06:00 – 07:00 Uhr (Morgendämmerung):** Erwachen in den Wohnhäusern; Weg zur Arbeitsstätte.
* **07:00 – 12:00 Uhr (Vormittagsschicht):** Intensives Arbeiten am Amboss, Sägebock oder Feld.
* **12:00 – 13:00 Uhr (Mittagspause):** Treffen am Dorfbrunnen, Verzehr von Brotrationen, Austausch von Neuigkeiten.
* **13:00 – 18:00 Uhr (Nachmittagsschicht):** Fertigstellung von Werkstücken, Einlagerung im Vorratslager.
* **18:00 – 22:00 Uhr (Abenddämmerung):** Feierabend; Bürger strömen in die Große Taverne, Musiker spielen, Bier fließt.
* **22:00 – 06:00 Uhr (Nachtruhe):** Straßen leeren sich; Fackeln erlöschen; Nachtwachen patrouillieren auf den Mauern.


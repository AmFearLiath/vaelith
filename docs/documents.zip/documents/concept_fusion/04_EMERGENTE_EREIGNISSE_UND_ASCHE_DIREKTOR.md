# 04. Emergente Ereignisse & Der Asche-Direktor
## Das organische Krisen- und Verteidigungssystem von Emberwild

**Dokument-Status:** Verbindliches, eigenständiges Fachkonzept  
**Bereich:** Asche-Direktor, Zustandssensoren, Krisenstufen, Verteidigungsschlachten  
**Zielcode in Emberwild:** `src/worldsys/crisis.js`, `src/worldsys/director.js`, `src/ui/crisisBanner.js`, `src/quests/`  

---

## 1. Übersicht & Design-Philosophie

Viele Spiele nutzen simple, stumpfe Zufallstimer (*„Alle 15 Minuten spawnt ein Überfall“*). Dies bricht die Immersion und fühlt sich willkürlich an.

**In Emberwild entstehen Ereignisse ORGANISCH aus dem Zustand der Welt:**
* Ein Wolfsrudel greift die Stadt nicht an, weil ein Timer abläuft, sondern **weil der Wald überjagt wurde und die Raubtiere hungern**.
* Die Mine stürzt nicht zufällig ein, sondern **weil über Wochen Holz zur Schachtabstützung gespart wurde**.
* Aschebestien brechen nicht ohne Grund hervor, sondern **weil ein alter Schrein in einer Nachbarprovinz vernachlässigt wurde und seine Verderbnis ausufert**.

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              DER SENSOR-BASIERTE ASCHE-DIREKTOR                        │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   DIE SPIELZUSTANDS-SENSOREN (Echtzeit-Überwachung)                                    │
│   ┌─────────────────────┐  ┌─────────────────────┐  ┌──────────────────────────────┐   │
│   │ ÖKOLOGIE-SENSOR     │  │ WIRTSCHAFTS-SENSOR  │  │ MORAL- & SOZIAL-SENSOR       │   │
│   │ • Beutetier-Dichte  │  │ • Getreidevorrat    │  │ • Siedlungsmoral             │   │
│   │ • Asche-Korruption  │  │ • Werkzeugbestand   │  │ • Wohnraum / Bettenmangel    │   │
│   │ • Schrein-Zustand   │  │ • Karawanen auf Weg │  │ • Wachen auf den Mauern      │   │
│   └──────────┬──────────┘  └──────────┬──────────┘  └──────────────┬───────────────┘   │
│              │                        │                            │                   │
│              └────────────────────────┼────────────────────────────┘                   │
│                                       ▼                                                │
│   ┌────────────────────────────────────────────────────────────────────────────────┐   │
│   │                    DER ASCHE-DIREKTOR (Evaluations-Engine)                     │   │
│   │   • Prüft Schwellenwerte, Spannungslevel & Pacing-Kurve                        │   │
│   │   • Wählt passendes Ereignis aus & warnt den Spieler graduell vor              │   │
│   └───────────────────────────────────┬────────────────────────────────────────────┘   │
│                                       │                                                │
│                                       ▼                                                │
│   ┌────────────────────────────────────────────────────────────────────────────────┐   │
│   │                         4-STUFEN-EREIGNIS-AUSLÖSUNG                            │   │
│   │   Stufe I: GERING     ──► Dezente Toast-Notiz & Weltveränderung                │   │
│   │   Stufe II: MODERAT   ──► Warn-Mitteilung & Tagebuch-Auftrag (1–2 Tage Zeit)   │   │
│   │   Stufe III: SCHWER   ──► Horn-Signal, Siedlungsalarm & Verteidigungskampf     │   │
│   │   Stufe IV: KATASTROPHE ► Vollbild-Krise, Asche-Invasion & Boss-Erscheinung    │   │
│   └────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Die vier Schweregrade eines Ereignisses

| Schweregrad | Visuelle / Akustische Ankündigung | Dringlichkeit | Auswirkungen bei Misserfolg |
|---|---|---|---|
| **Stufe I: Gering** | Dezent schwebende Toast-Nachricht; kein Ton | Niedrig (kann ignoriert werden) | Geringe Einbuße (z.B. $-5\%$ Tagesausbeute eines Betriebs) |
| **Stufe II: Moderat** | Wappen-Mitteilung oben im HUD; kurzer Glockenton | Mittel (binnen $24$ Ingame-Stunden) | Werkstatt stoppt, Karawane verliert Ladung, Moral sinkt um $10\%$ |
| **Stufe III: Schwer** | Alarmhorn der Feste; roter Puls am Bildschirmrand | Hoch (sofortige Reaktion des Helden) | Gebäude brennen, Wachen fallen, Bürger fliehen aus der Stadt |
| **Stufe IV: Katastrophe** | Aschesturm-Verdunkelung; Schicksals-Gong | Höchste Priorität (Kampf um Emberwatch) | Zerstörung von Gebäudestufen; Verlust von Vorräten; Heldentod |

---

## 3. Der vollständige Krisen-Katalog

### 3.1 Ökologische & Wildnis-Ereignisse

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│ EVENT 1: DAS HUNGERNDE RUDEL (Stufe II / Moderat)                                      │
├────────────────────────────────────────────────────────────────────────────────────────┤
│ Sensor-Bedingung: Herbivoren-Dichte in Umlandprovinz < 20% + Wolfspopulation > 8       │
│ Ankündigung:     "Heulen hallt durch die Dämmerung. Die Wölfe finden kein Wild mehr..."│
│ Physische Welt:  Ein Rudel aus 6 Grauwölfen umstellt die Schafweide von Emberwatch.   │
│ Lösungswege:     1. ARPG-Kampf: Der Held erschlägt die Leittiere vor den Zäunen.       │
│                  2. Alchemie/Jäger: Auslegen von präpariertem Köderfleisch im Wald.     │
│ Belohnung:       Wertvolle Wolfsfelle, Rettung der Schafe, +15 Siedlungsmoral.        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

* **Aschenwurm im Steinbruch (Stufe II):**  
  *Sensor:* Steinbruch produziert 3 Tage ununterbrochen auf Stufe Akkord.  
  *Wirkung:* Eine unterirdische Riesenkreatur bricht im Steinbruch durch den Boden; Bergleute fliehen. Steinproduktion $= 0$.  
  *Lösung:* Held steigt in den Steinbruch hinab und bezwingt das Ungetüm.
* **Blutmond über den Grauen Feldern (Stufe III):**  
  *Sensor:* Zwei oder mehr Schreine in den Nachbarprovinzen sind ungesühnt.  
  *Wirkung:* Verdammte Seelen wandeln über die Felder, Aschenebel hüllt Emberwatch ein. Bürger weigern sich nachts zu arbeiten.  
  *Lösung:* Held reitet zu den Schreinen und entzündet die Weihefeuer mit Natur-Essenz.

### 3.2 Wirtschafts- & Logistik-Ereignisse

* **Stolleneinsturz in der Eisenschlucht (Stufe II):**  
  *Sensor:* Vorratsbestand an Bauholz sinkt unter 30 Einheiten bei voller Minenbesetzung.  
  *Wirkung:* Ein Stollen bricht ein, drei Bergleute sind verschüttet.  
  *Lösung:* 50 Bauholz und 20 Werksteine binnen 10 Minuten spenden oder persönlich mit dem Erdspalter-Skill den Schutt freiräumen.
* **Überfall auf die Gold-Karawane (Stufe III):**  
  *Sensor:* Karawane transportiert $> 200$ Gold/Erz über eine Straße mit Gefahrenstufe $\ge 3$.  
  *Wirkung:* Aschebanditen kappen die Brücke und belagern den Tross. Notsignal im HUD.  
  *Lösung:* Schnellreise per Reittier zum Wegpunkt; Banditenführer im Duell bezwingen.
* **Feuer im Kornspeicher (Stufe II):**  
  *Sensor:* Trockenzeit / Sommerwetter $+ 100\%$ volles Getreidelager ohne Brunnen in der Nähe.  
  *Wirkung:* Funkenflug entzündet das Strohdach; Bürger bilden eine Eimerkette.  
  *Lösung:* Held nutzt Frost- oder Schockwellen-Fähigkeiten zum Ersticken der Flammen oder stellt 3 Gehilfen zur Brandbekämpfung ab.

### 3.3 Soziale & Zivil-Ereignisse

* **Hungerrevolte der Tagelöhner (Stufe III):**  
  *Sensor:* Sättigungs-Wert $< 20\%$ für mehr als 24 Spielstunden.  
  *Wirkung:* Arbeiter legen Werkzeuge nieder, versammeln sich protestierend vor dem Rathaus und blockieren die Schmiede.  
  *Lösung:* Spende von 60 Broten oder Besänftigung durch Freibier in der Großen Taverne.
* **Ankunft der Ascheflüchtlinge (Stufe I):**  
  *Sensor:* Held befreit eine Provinzburg auf der Weltkarte.  
  *Wirkung:* Eine Karawane aus 15 frierenden Zivilisten erreicht das Tor.  
  *Lösung:* Aufnahme gewährt 15 neue Arbeitskräfte (erfordert freie Betten in Wohnhäusern).
* **Der reisende Meisterschmied (Stufe I):**  
  *Sensor:* Zufallsfund bei hoher Tavernenmoral ($> 80\%$).  
  *Wirkung:* Ein legendärer Zwergenschmied kehrt für 3 Tage in die Taverne ein.  
  *Lösung:* Tausche seltene Erze gegen einzigartige Waffen-Schmiedebaupläne.

### 3.4 Emergenz-Invasionen: Der Schicksals-Angriff (Stufe IV)

Wenn die **Asche-Spannung** des Kontinents ihr Maximum erreicht (z.B. nach Vernachlässigung der Grenzfeste oder bei Fortschritt der Haupt-Saga), startet ein **Emergenz-Verteidigungsevent** in Emberwatch:

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              ABLAUF EINER ASCHE-INVASION                               │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   PHASE 1: DIE WARNUNG (2 Minuten Vorbereitung)                                        │
│   • Das Horn von Emberwatch ertönt dreimal mit tiefem, vibrierendem Schall             │
│   • Dorfbewohner rennen in die befestigte Feste; Werkstätten schließen                 │
│   • Stadtwachen besetzen Zinnen und Barrikaden am West- und Südtor                    │
│                                                                                        │
│   PHASE 2: DER STURM (Wellen-Angriff)                                                  │
│   • Welle 1: 15 Aschehunde und Kriecher überrennen die Palisaden                       │
│   • Welle 2: Gepanzerte Aschesoldaten und Aschenbogenschützen                          │
│   • Welle 3 (Apex): Der "Schlackenschlund-Koloss" attackiert das Haupttor             │
│                                                                                        │
│   PHASE 3: DER TRIUMPH ODER DIE NIEDERLAGE                                             │
│   • Sieg: Koloss fällt ──► Legendäre Beute, +500 Siedlungsruf, Ruhmesfest in Taverne │
│   • Niederlage: Tor bricht ──► Vorratslager geplündert, Werkstätten beschädigt        │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Die mathematische Spannungs-Kurve (Director-Pacing)

Damit der Spieler weder gelangweilt noch durch pausenlose Angriffe frustriert wird, folgt der Asche-Direktor einer **Dramaturgie-Pacing-Kurve**:

```
Spannung (Tension)
   ▲
100│                  [KRISEN-PEAK]
   │                      /\
 75│        [AUFBAU]     /  \
   │          /\        /    \     [ERHOLUNG]
 50│         /  \  /\  /      \   (Cooldown 15 Min.)
   │        /    \/  \/        \───────────────
 25│  _____/                                   \_____
  0└──────────────────────────────────────────────────► Zeit
```

1. **Aufbau-Phase (Build-Up):** Kleinere Ereignisse der Stufe I (Gerüchte, Spuren im Schnee).
2. **Kompression (Stress-Test):** Ein moderates Ereignis bindet Aufmerksamkeit.
3. **Klimax (Crisis Peak):** Das Haupt-Ereignis (Stufe III oder IV) bricht los.
4. **Erholungs-Pause (Grace Period):** Nach erfolgreicher Lösung schaltet der Direktor für mindestens 15 Echtzeit-Minuten auf Ruhe, damit der Spieler ungestört bauen, craften und die Welt erkunden kann.


# 02. Wirtschaft, Produktionsketten & Karawanen
## Das Waren- und Logistiksystem von Emberwild

**Dokument-Status:** Verbindliches, eigenständiges Fachkonzept  
**Bereich:** Warenwirtschaft, Verarbeitungsstufen, Siedlungslogistik & Provinzkarawanen  
**Zielcode in Emberwild:** `src/worldsys/settlement.js`, `src/worldsys/economy.js`, `src/ui/buildingWindow.js`, `src/ui/worldMap.js`  

---

## 1. Übersicht & Design-Philosophie

In Emberwild existiert keine abstrakte "Magie-Ökonomie", bei der Ressourcen aus dem Nichts entstehen. Das Wirtschaftssystem verbindet das **physische Warentransport-Prinzip der Siedler-Tradition** mit der **übergeordneten Provinzerweiterung eines ARPGs**:

1. **Vierstufige Veredelungshierarchie:** Rohstoffe werden stufenweise zu edlen Gütern, Werkzeugen und Waffen verarbeitet.
2. **Siedlungseffizienz durch Werkzeuge:** Höhere Veredelungsstufen (z.B. geschmiedete Werkzeuge, Mehl, Bier) fließen direkt als Effizienz-Multiplikatoren zurück in die Werkstätten.
3. **Physische Provinz-Karawanen:** Ausgebaute Außenposten auf der Weltkarte senden planmäßige Karawanen nach Emberwatch.
4. **Logistisches Risiko:** Gefahrenstufe, Wetter und Raubtierdichte bestimmen das Risiko von Karawanenüberfällen, die der Held im Gefecht abwehren kann.

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              DER 4-STUFIGE WARENKREISLAUF                              │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   TIER 1: ROHSTOFFE (Gewinnung in Wald, Steinbruch, Minen & Provinzen)                 │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────┐  │
│   │     HOLZ     │  │    STEIN     │  │   ROHEISEN   │  │   GETREIDE   │  │  FELL  │  │
│   └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └───┬────┘  │
│          │                 │                 │                 │              │       │
│          ▼                 ▼                 ▼                 ▼              ▼       │
│   TIER 2: VEREDELTE WERKSTOFFE (Sägewerk, Steinmetz, Schmelze, Mühle, Gerberei)       │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────┐  │
│   │   BAUHOLZ    │  │  WERKSTEIN   │  │ EISENBARREN  │  │     MEHL     │  │ LEDER  │  │
│   └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └───┬────┘  │
│          │                 │                 │                 │              │       │
│          ▼                 ▼                 ▼                 ▼              ▼       │
│   TIER 3: FERTIGUNGSGÜTER (Schmiede, Rüstkammer, Bäckerei, Brauerei, Schreinerei)     │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────┐  │
│   │  WERKZEUGE   │  │    WAFFEN    │  │  RÜSTUNGEN   │  │ BROT & BIER  │  │MÖBEL/  │  │
│   │  (+Ausstoß)  │  │ (Wachen/Held)│  │ (Schutz)     │  │ (Dorfmoral)  │  │WÄGEN   │  │
│   └──────┬───────┘  └──────────────┘  └──────────────┘  └──────┬───────┘  └───┬────┘  │
│          │                                                     │              │       │
│          ▼                                                     ▼              ▼       │
│   TIER 4: MEISTER- & PRESTIGEWAREN (Großschmiede, Alchemielabor, Ritusaltar)          │
│   ┌─────────────────────────┐  ┌───────────────────────────┐  ┌────────────────────┐  │
│   │   GLUTSTAHL-KLINGEN     │  │   ALCHEMIE-ELIXIERE       │  │  KULTBANNER &      │  │
│   │ (Legendäre Waffen & Mun)│  │(Permanente Status-Boosts) │  │  RELIQUIEN         │  │
│   └─────────────────────────┘  └───────────────────────────┘  └────────────────────┘  │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Die 4-Stufen-Ressourcenmatrix

### Tier 1: Primäre Rohstoffe (Ernte & Schürfen)

| Ressource | Primäre Quelle | Zweitquelle (Provinzen) | Max. Lager (Basis) | Verwendung |
|---|---|---|---|---|
| **Holz** | Sägewerk-Umland | Waldprovinzen (Kiefernforst) | 1.000 | Gebäude, Brennstoff, Karren |
| **Stein** | Steinbruch | Granithügel, Graue Felder | 1.000 | Mauern, Schmelzöfen, Wege |
| **Roheisen** | Bergwerk | Eisenschlucht, Schmelzkamm | 500 | Verhüttung zu Eisenbarren |
| **Kohle** | Köhlerei / Tiefmine | Aschegruben | 500 | Brennstoff für Schmelzöfen |
| **Getreide** | Siedlungsfelder | Sonnenhügel, Kornmarschen | 800 | Müllerei, Futter für Gestüt |
| **Kräuter & Pilze** | Sammelhütte | Nebelmoor, Waldschreine | 300 | Alchemie, Heilsalben |
| **Rohleder & Felle** | Jagdhütte | Tierherden aller Zonen | 400 | Gerberei, Satteltaschen |
| **Natur-Essenz** | Heilige Schreine | Schrein-Reinigungen | 250 | Ritus-Bau, Magische Härtung |

### Tier 2: Primäre Werkstoffe (Mechanische Veredelung)

| Werkstoff | Gebäude / Werkstatt | Benötigte Input-Rohstoffe | Veredelungs-Dauer | Verwendung |
|---|---|---|---|---|
| **Bauholz / Balken** | Sägewerk | 3x Holz + 1x Arbeitskraft | 8s pro Bündel | Ausbaustufen II & III, Karrenbau |
| **Werkstein** | Steinmetzgilde | 3x Stein + 1x Meißel | 10s pro Quader | Befestigungen, Stiftungen, Brunnen |
| **Eisenbarren** | Schmelze | 2x Roheisen + 1x Kohle | 12s pro Barren | Schmiede, Waffen, Rüstungen |
| **Mehl** | Mühle | 2x Getreide | 5s pro Sack | Bäckerei (Brot), Rationen |
| **Gegerbtes Leder** | Gerberei | 2x Rohfell + 1x Wasser | 10s pro Stück | Leichte Rüstungen, Zaumzeug |
| **Ziegel** | Ziegelei | 2x Lehm + 1x Kohle | 12s pro Charge | Wohnhäuser Stufe 2, Schornsteine |

### Tier 3: Fertigungsgüter (Funktionaler Nutzen)

| Fertigungsgut | Werkstatt | Rezept | Funktionaler Spiel-Effekt |
|---|---|---|---|
| **Handwerks-Werkzeuge** | Schmiede | 2x Eisenbarren + 1x Bauholz | **+20% Ausstoß** in Betrieben mit Werkzeugbestand |
| **Kriegswaffen (Standard)**| Waffenschmied | 3x Eisenbarren + 1x Leder | Rüstet Wachen aus; schützt Karawanen |
| **Plattenpanzer** | Rüstkammer | 4x Eisenbarren + 2x Leder | Senkt Wachen-Verluste bei Krisen um 50% |
| **Frisches Bauernbrot** | Bäckerei | 2x Mehl + 1x Quellwasser | Erfüllt **Sättigung** von 4 Bürgern pro Tag |
| **Stout-Bier** | Brauerei | 2x Getreide + 1x Quellwasser | Hebt **Siedlungsmoral** um +15 Punkte in Taverne |
| **Satteltaschen** | Sattler / Gestüt | 3x Leder + 1x Eisenbarren | Erweitert Mount-Inventar um +6 Slots |

### Tier 4: Meister- & Prestigegüter

| Meistergut | Werkstatt / Meister | Rezept | Legendärer Effekt |
|---|---|---|---|
| **Glutstahl-Klinge** | Großschmied Aldric Venn | 2x Eisenbarren + 1x Glutessenz + 1x Basalt | Beste Waffenbasis des Helden; +35% Feuerschaden |
| **Asche-Elixier** | Alchemistin Lyra | 3x Kräuter + 1x Pestdrüse + 1x Essenz | Permanente Attributspunkte oder Schutztränke |
| **Kriegsharnisch** | Gestütmeister Garrick | 5x Eisenbarren + 3x Leder + 2x Glutsehne | Reittier erleidet keinen Betäubungsrückstoß |
| **Hoheitsbanner** | Weberin / Taverne | 3x Wolle + 1x Gold + 1x Farbkraut | Zieht wandernde Elite-Handwerker nach Emberwatch |

---

## 3. Siedlungs-Logistik: Träger, Lager & Transportwege

### 3.1 Das physische Trägersystem
Ressourcen spawnen am Produktionsort und müssen transportiert werden:
1. **Laufwege-Effizienz:** Werkstätten, die nahe beieinander stehen (z.B. Getreidefeld $\rightarrow$ Mühle $\rightarrow$ Bäckerei), arbeiten bis zu $40\%$ schneller, da Gehzeiten der Träger minimiert werden.
2. **Handkarren:** Ab Werkstattstufe 2 nutzen Hilfskräfte Handkarren (transportieren 5 Einheiten statt 1 Einheit pro Gang).
3. **Lagerkapazitäten:** Ist das Vorratslager voll, stoppt der Betrieb automatisch (*"Lager voll"*). Überschüsse können an durchreisende Händler verkauft werden.

---

## 4. Das Inter-Provinzen-Karawanensystem

Jede der 294 Provinzen Aethelgards, die vom Spieler befreit und mit einem Vorposten gesichert wurde, produziert regionsspezifische Güter (z.B. die *Granitminen von Varkhul* oder das *Holzfällercamp von Silberforst*).

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              PROVINZ-KARAWANEN-ROUTEN                                  │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   PROVINZ AUSTEN (Gefahr 2)             PROVINZ HOCHBRUCK (Gefahr 4)                   │
│   ┌───────────────────────────┐         ┌───────────────────────────┐                  │
│   │ Minen-Außenposten Varkhul │         │ Holzfällercamp Silberwald │                  │
│   │ Ertrag: 40 Eisen / Stunde │         │ Ertrag: 80 Hartholz / Std.│                  │
│   └─────────────┬─────────────┘         └─────────────┬─────────────┘                  │
│                 │                                     │                                │
│                 │ Startet alle 30 Min.                │ Startet alle 45 Min.           │
│                 ▼                                     ▼                                │
│       [ Maultier-Karawane ]                 [ Gepanzerte Asche-Karawane ]              │
│       • Fracht: 80 Roheisen                 • Fracht: 120 Hartholz + 30 Harz           │
│       • Geleitschutz: 2 Wachen              • Geleitschutz: 4 schwere Lanzenträger     │
│                 │                                     │                                │
│                 │ Sichere Straße (Risiko: 5%)         │ Aschesturm-Passage (Risiko: 35%)│
│                 ▼                                     ▼                                │
│   ┌────────────────────────────────────────────────────────────────────────┐           │
│   │                       DAS TOR VON EMBERWATCH                           │           │
│   │  Warenentladung -> Aufteilung in Vorratslager & Werkstätten            │           │
│   └────────────────────────────────────────────────────────────────────────┘           │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

### 4.1 Karawanen-Klassen

| Karawanen-Typ | Kapazität | Reisetempo | Begleitschutz | Baukosten im Gestüt | Empfohlene Route |
|---|---|---|---|---|---|
| **Leichter Packesel** | 60 Einheiten | $140\%$ Basis | 1 Milizsoldat | 100 Holz, 50 Gold | Gefahrenstufe 1–2, kurze Wege |
| **Maultier-Tross** | 160 Einheiten | $100\%$ Basis | 2 Stadtwachen | 200 Holz, 100 Eisen, 150 Gold | Gefahrenstufe 2–3, mittlere Distanzen |
| **Gepanzerte Asche-Karawane**| 350 Einheiten | $75\%$ Basis | 4 Elite-Wachen | 400 Bauholz, 250 Eisen, 300 Gold | Gefahrenstufe 4–5, Vulkangebiete |

### 4.2 Die Risiko- und Überfall-Formel

Bei jedem Reise-Abschnitt einer Karawane über eine Provinzgrenze wird das Überfall-Risiko $R_{ambush}$ berechnet:

$$R_{ambush} = \left( \text{TierLevel}_{prov} \times 0.08 \right) + \text{Aschedichte} - \left( \text{Wachstärke} \times 0.05 \right) - \text{Straßenausbau}$$

* **Überfall-Eintritt ($R_{ambush} > 0.30$):**
  1. Die Karawane sendet ein Notsignal an den Spieler (Audio-Gong & Bildschirmpanier).
  2. Auf der Weltkarte erscheint ein pulsierender Überfall-Wegpunkt.
  3. **Spieler-Entscheidung:**
     * **Sofortige Hilfe:** Der Spieler reitet hin, wechselt in die Kampfzone und vernichtet die Banditen/Aschewölfe. Belohnung: Volle Fracht gerettet $+ 50$ Ruf $+ 150$ Gold-Kopfgeld.
     * **Ignorieren:** Begleitschutz kämpft automatisch. Karawane verliert $40-100\%$ der Fracht; Wachen können fallen.

---

## 5. Markt, Steuern & Gold-Kreisläufe

Emberwatch benötigt eine funktionierende Münzwirtschaft, um Söldner zu bezahlen und Bauvorhaben zu finanzieren:

### 5.1 Einnahmequellen der Siedlung
1. **Wochensteuer:** Jeder zufriedene Bürger zahlt basierend auf seiner Wohnstufe $2 - 8$ Goldmünzen pro Tag.
2. **Marktzoll:** Auswärtige Karawanen und fahrende Händler zahlen $10\%$ Zoll auf verkaufte Waren.
3. **Beute-Verkauf:** Der Spieler verkauft erbeutete Monsterteile und Waffen an den Stadtladen.

### 5.2 Ausgaben & Gold-Sinks (Geldabflüsse)
1. **Gebäudeausbauten:** Jede Ausbaustufe kostet Gold neben Baumaterialien.
2. **Wachsoldaten-Sold:** Wachtürme verbrauchen 5 Gold pro Wache pro Tag.
3. **Meister-Berufungen:** Die Ernennung eines Gesellen zum Meister erfordert ein einmaliges Antrittsgeld (50–150 Gold).
4. **Werkzeugreparaturen:** Kontinuierlicher Verschleiß erfordert regelmäßiges Nachgießen von Eisen.


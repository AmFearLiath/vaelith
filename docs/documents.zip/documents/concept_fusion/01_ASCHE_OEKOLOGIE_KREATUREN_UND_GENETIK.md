# 01. Asche-Ökologie, Kreaturen & Genetik
## Das lebendige Tier- und Zuchtsystem von Aethelgard

**Dokument-Status:** Verbindliches, eigenständiges Fachkonzept  
**Bereich:** Ökologie, Tierverhalten, Genetik, Zucht & Reittiere  
**Zielcode in Emberwild:** `src/entities/animals/`, `src/mounts/`, `src/ui/breedingPanel.js`, `src/world/areas/provinceZone.js`  

---

## 1. Übersicht & Zielsetzung

In vielen Spielen dient Fauna als statische Staffage: Rehe stehen auf der Wiese, Wölfe warten an Wegrändern. In **Emberwild** ist die Tierwelt ein **atmendes, mathematisch balanciertes Ökosystem**, das organisch auf die Handlungen des Spielers und den Einfluss des Aschefluchs reagiert:

1. **Ökologisches Gleichgewicht:** Herbivoren weiden an der Flora, Karnivoren jagen Herbivoren im Rudel.
2. **Emergente Bedrohung durch Überjagung:** Rotten Spieler oder Jäger die Beutetiere in einer Provinz aus, hungern die Raubtiere und greifen Außenposten, Weidevieh oder Karawanen an.
3. **Genetik- & Zuchtsystem (Lite):** Reittiere und Nutztiere besitzen vererbbare Gene (Größe, Schnelligkeit, Ausdauer, Fellfarbe, Ascheglut). Gezielte Zucht erzeugt legendäre Tiere.
4. **Asche-Mutationen:** Provinzen mit hohem Asche-Gefahrenlevel gebären mutierte Apex-Prädatoren mit besonderen Alchemie-Ressourcen und exotischem Reittier-Potenzial.

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              DER ÖKOSYSTEM-KREISLAUF                                   │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│     ┌────────────────────────────────────────────────────────────────────────────┐     │
│     │                       VEGETATION & ASCHE-FLORA                             │     │
│     │       (Grasland, Pilzwald, Farngebüsch, Aschenkraut, Beerensträucher)       │     │
│     └─────────────────────────────────────┬──────────────────────────────────────┘     │
│                                           │ Weiden (Nahrung)                           │
│                                           ▼                                            │
│     ┌────────────────────────────────────────────────────────────────────────────┐     │
│     │                       HERBIVOREN & WEIDETIERE                              │     │
│     │          (Hirsche, Rehe, Waldhasen, Mufflons, Auerochsen, Wildpferde)      │     │
│     └──────────────────────┬───────────────────────────────┬─────────────────────┘     │
│                            │                               │                           │
│              Jagen (Rudel) │                               │ Jagd durch Spieler        │
│                            ▼                               ▼                           │
│     ┌─────────────────────────────┐             ┌─────────────────────────────┐        │
│     │         PREDATOREN          │             │     SIEDLUNG & SPIELER      │        │
│     │  (Wölfe, Bären, Luchse)     │             │     (Fleisch, Leder, Zucht) │        │
│     └──────────────┬──────────────┘             └──────────────┬──────────────┘        │
│                    │                                           │                       │
│                    │ Bei Nahrungsmangel (Überjagung)           │ Zähmung & Zucht       │
│                    ▼                                           ▼                       │
│     ┌─────────────────────────────┐             ┌─────────────────────────────┐        │
│     │    ANGRIFF AUF NUTZTIERE    │             │   KÖNIGLICHES GESTÜT        │        │
│     │  (Schafe, Karawanen, Hütten)│             │   (Reittiere & Kriegsrösser)│        │
│     └─────────────────────────────┘             └─────────────────────────────┘        │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Die Arten-Klassifikation von Aethelgard

### 2.1 Wildtiere (Normalfauna)

| Spezies | Kategorie | Verhalten & Sinne | Flucht / Kampf | Beute / Nutzen |
|---|---|---|---|---|
| **Waldhirsch** | Herbivore | Weidet in Rudeln (3–6), hohe Witterung | Flieht ab 18m Radius | Wildbret, Zähes Leder, Horn |
| **Feldhase** | Herbivore | Schnell, versteckt sich im Gras | Zickzack-Flucht ab 12m | Zartfleisch, Weichfell |
| **Schwarzwild (Eber)** | Omnivore | Durchwühlt Erdreich, territorial | Wehrt sich bei Bedrängnis | Schmalz, Schwarte, Hauer |
| **Grauwolf** | Karnivore | Rudeljäger (3–5), kreist Beute ein | Jagd auf Wild; Flieht vor Feuer | Wolfspelz, Raubtierzahn, Sehnen |
| **Hochlandbär** | Karnivore/Apex | Einzelgänger, schläft in Höhlen | Starker Prankenhieb, wütend | Bärenfell, Bärenfett, Dickleder |
| **Rotfuchs** | Karnivore | Scheu, jagt Hasen und Vögel | Schnelle Flucht | Rotpelz (Handelsgut) |
| **Wildpferd** | Weidetier | Sehr scheu, hohe Schnelligkeit | Schnelle Flucht in Herde | Zähmbar zu Reittier |

### 2.2 Asche-Mutanten & Apex-Bestien (Gefahrenstufe 3 bis 5)

Wenn der Aschefluch ein Tier über Generationen durchdringt oder es nahe an ungesühnten Schreinen lebt, mutieren seine Genome:

| Mutierte Kreatur | Basis-Art | Visuelle Merkmale | Kampffähigkeiten | Spezielle Beute & Zucht-Potential |
|---|---|---|---|---|
| **Glutwolf** | Wolf | Schwarzer Balg, glimmende Rückenadern | Entzündet Ziele bei Biss, Rudelgeheul (+30% Tempo) | **Glutsehne** (für Kriegsbögen), zähmbar zu schnellem Reittier |
| **Basaltbär** | Bär | Verwachsene Fels- und Obsidianplatten | 60% Schadensresistenz, Erdbeben-Stampfer | **Basaltplatte** (für schwere Plattenrüstungen) |
| **Phönix-Hirsch** | Hirsch | Gold-glühendes Geweih, Funkenstaub | Feuerschweif bei Flucht, blendet Verfolger | **Heilig-Horn** (Alchemie-Elixiere), züchtet edle Reittiere |
| **Stachelsau** | Wildschwein | Verknöcherte Dornenpanzerung | Rammbock-Sturmlauf mit Betäubungseffekt | **Knochendornen** (Barrikaden-Bau) |
| **Pestkröte** | Sumpffauna | Giftpusteln, Säureglanz | Spuckt Säurepfützen, explodiert bei Tod | **Toxindrüse** (Klingengift & Alchemie) |
| **Schlackenschwinge**| Rabe/Greif | Pechschwarze Schwingen mit Glutkanten | Sturzflug-Attacken auf Augen & Gesicht | **Aschenfeder** (Prestige-Pfeile) |

---

## 3. Die mathematische Ökosystem-Simulation

Um ohne CPU-Überlastung hunderte Tiere in Echtzeit und tausende im Hintergrund zu berechnen, nutzen wir das **Lotka-Volterra-Populationsmodell** mit Tragekapazität:

### 3.1 Populations-Dynamik

Für jede Provinz wird stündlich (oder beim Betreten der Zone) der Populationsvektor aktualisiert:

$$P_{herb}(t+1) = P_{herb}(t) + r_h \cdot P_{herb}(t) \cdot \left(1 - \frac{P_{herb}(t)}{K_{flora}}\right) - \alpha \cdot P_{herb}(t) \cdot P_{pred}(t) - H_{player}$$

$$P_{pred}(t+1) = P_{pred}(t) + \beta \cdot \alpha \cdot P_{herb}(t) \cdot P_{pred}(t) - d_p \cdot P_{pred}(t) - H_{pred\_player}$$

* **$K_{flora}$ (Tragekapazität):** Maximale Pflanzenfresser pro Hektar (abhängig von Bodenfruchtbarkeit und Aschegrad).
* **$r_h$:** Natürliche Reproduktionsrate der Herbivoren ($0.08$ pro Spieltag).
* **$\alpha$:** Prädations-Effizienz der Raubtiere ($0.005$).
* **$\beta$:** Energie-Konversionsrate von Beute in Raubtiernachwuchs ($0.25$).
* **$d_p$:** Natürliche Sterblichkeit der Prädatoren ($0.04$).
* **$H_{player}$:** Durch den Spieler oder Jäger erlegte Tiere.

### 3.2 Das Überjagungs- und Krisenprotokoll

Fällt die Herbivoren-Dichte unter einen Schwellenwert:

$$\frac{P_{herb}(t)}{K_{flora}} < 0.20 \quad \text{(Kritischer Nahrungsmangel)}$$

Aktiviert der Asche-Direktor die **Hungerrudel-Reaktion**:
1. Raubtiere verlassen den Tiefenwald und patrouillieren an Provinzstraßen und Karawanenrouten.
2. Angriffswahrscheinlichkeit auf Siedlungsweiden von Emberwatch steigt um $+40\%$.
3. Ein dynamisches Event (*"Wolfsrudel bedroht die Schafweide"*) wird getriggert.

---

## 4. Das Genetik-System (Lite) für Reittiere & Nutztiere

Zucht in Emberwild ist keine simple Würfeltabelle, sondern basiert auf einem **2-Chromosomen-Allel-Modell**. Jedes Tier trägt für jedes Merkmal zwei Allele (eines vom Vater, eines von der Mutter).

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              DAS ALLEL-VERERBUNGSMODELL                                │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│     VATERTISCH (Männlich)                          MUTTERTISCH (Weiblich)              │
│     Chromosom 1:  [ Speed: 0.85 (D) ]             Chromosom 1:  [ Speed: 0.60 (d) ]    │
│     Chromosom 2:  [ Speed: 0.70 (d) ]             Chromosom 2:  [ Speed: 0.75 (D) ]    │
│                                                                                        │
│                                           │                                            │
│                                           ▼ Meiose & Rekombination                     │
│                                                                                        │
│     NACHKOMME (Fohlen / Welpe)                                                         │
│     Erbt zufällig je 1 Allel von Vater und Mutter:                                     │
│     Allel V: 0.85 (D)  +  Allel M: 0.75 (D)                                            │
│                                                                                        │
│     PHÄNOTYP-BERECHNUNG:                                                               │
│     Basiswert = max(Allel_1, Allel_2) * 0.7 + min(Allel_1, Allel_2) * 0.3              │
│     Zufallsvarianz (Mutation): ± 0.05                                                  │
│     Finaler Speed-Phänotyp: 0.85 * 0.7 + 0.75 * 0.3 = 0.82 (+- Jitter)                 │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

### 4.1 Die 8 Kern-Loci (Gen-Merkmale)

| Locus | Merkmal | Bereich | Phänotypische Auswirkung im Spiel |
|---|---|---|---|
| `SPD` | Geschwindigkeit | $0.20 - 1.00$ | Grundlauftempo des Reittiers (bis zu $+45\%$ Reittempo) |
| `STA` | Ausdauer | $0.20 - 1.00$ | Maximale Sprintdauer und Erholungszeit der Ausdauerleiste |
| `SIZ` | Körpergröße | $0.70 - 1.35$ | 3D-Modell-Skalierung, Trefferpunkte $+/- 25\%$, Kollisionsmasse |
| `COR` | Mut / Disziplin | $0.00 - 1.00$ | Wahrscheinlichkeit, dass Reittier bei Feindnähe scheut |
| `COL` | Fell-Grundfarbe | $0 - 7$ | Visuelle Textur (Rappe, Schimmel, Fuchs, Aschgrau, Obsidian) |
| `GLW` | Ascheglut | $0.00 - 1.00$ | Helligkeit von Glüh-Partikeln an Hufen und Mähne |
| `RES` | Hitzeresistenz | $0.00 - 1.00$ | Schutz gegen Lava- und Hitzeschaden in Vulkan-Provinzen |
| `STR` | Tragkraft | $0.20 - 1.00$ | Anzahl zusätzlicher Inventar-Slots in den Satteltaschen |

### 4.2 Mutationen & Zuchtkatalysatoren

Bei jeder Paarung besteht eine Basis-Mutationschance:

$$P_{mut} = 0.05 + 0.03 \cdot \text{Inzuchtgrad} + C_{catalyst} + C_{prov\_corruption}$$

* **Katalysatoren aus der Alchemie:**
  * *Glutessenz:* Verleiht dem Nachkommen eine $30\%$-Chance auf feurige Mähne (`GLW > 0.8`) und Hitzeresistenz.
  * *Obsidian-Extrakt:* Erhöht `SIZ` und Knochenhärte (erhöht Reittier-Lebenspunkte um $+30\%$).
  * *Schlankwurzel:* Forciert Spitzenwerte in `SPD`, senkt aber `STR`.

---

## 5. Zähmung & Haltung im Königlichen Gestüt

### 5.1 Zähmungs-Ablauf in der Wildnis
1. **Pürsch:** Anschleichen gegen die Windrichtung (überprüft Spieler-Geschwindigkeit und Witterungswinkel).
2. **Köderung:** Auslegen von Spezialfuttermitteln aus der Taverne/Alchemie (*Honigäpfel* für Pferde/Hirsche, *Dörrfleisch mit Baldrian* für Wölfe/Luchse).
3. **Betäubung oder Beruhigungs-Minispiel:** Spieler interagiert sanft, bis die *Zähmungsleiste* $100\%$ erreicht.
4. **Heimführung:** Gezähmt transferiert das Tier in das Stallungs-Register von Emberwatch.

### 5.2 Gebäude-Synergie mit dem Gestüt (`royal_stables`)
* **Stufe 1:** Bietet Platz für bis zu 4 Tiere.
* **Stufe 2:** Schaltet Zuchtkammern frei; Meister *Garrick* überwacht Trächtigkeit und senkt Abklingzeiten um $25\%$.
* **Stufe 3:** Rüstmeister fertigen gepanzerte Pferdeharnische und vergrößerte Satteltaschen.

---

## 6. Tier-KI Verhaltens-Zustandsautomat

Jedes aktive Tier im Nahbereich des Spielers (LOD 1) durchläuft folgende Zustände:

```
                  ┌──────────────┐
                  │   SCHLAFEN   │ (Nacht / Dämmerung)
                  └──────┬───────┘
                         │
        Aufwachen        ▼       Erschöpfung
       ┌──────────► ┌──────────┐ ──────────┐
       │            │  WEIDEN  │           │
       │            │ (Suchen) │           │
       │            └────┬─────┘           │
       │                 │                 │
       │ Raubtier nah    │ Raubtier greift │
       │                 ▼                 ▼
┌──────────────┐   ┌───────────┐   ┌──────────────┐
│    FLUCHT    │◄──┤  WARNUNG  ├──►│ VERTEIDIGUNG │
│ (Volltempo)  │   │  (Drohen) │   │ (Nur Alpha)  │
└──────────────┘   └───────────┘   └──────────────┘
```

* **Flucht-Reaktionszeit:** Herbivoren prüfen im Radius von $20\text{m}$ akustische und optische Reize.
* **Rudel-Koordination:** Wölfe greifen nicht frontal an, sondern schwärmen aus, um die Beute von Fluchtwegen abzuschneiden.
* **Gedächtnis (Memory):** Tiere merken sich Gebiete mit Fallen oder hohem Spielerbeschuss und meiden diese für 2 Ingame-Tage.


# 06. UI/UX-Design & Immersion
## Die visuellen und ergonomischen Gestaltungsrichtlinien von Emberwild

**Dokument-Status:** Verbindliches, eigenständiges Fachkonzept  
**Bereich:** Benutzeroberfläche, Typografie, Immersion, Werkstatt-Fenster, Tooltips & Audio  
**Zielcode in Emberwild:** `src/ui/`, `src/ui/styles/`, `src/ui/buildingWindow.js`, `src/core/i18n.js`  

---

## 1. Design-Philosophie: Dunkle Fantasy & Physische Eleganz

Emberwild kombiniert die raue Atmosphäre von *Diablo* und *Gothic* mit der Klarheit moderner Strategiespiele:

1. **Keine Emojis als Icons:**  
   Emojis (`⚒️`, `👑`, `📦`, `🌲`) zerstören die düstere Immersion eines mittelalterlichen Dark-Fantasy-Spiels. Sie sind im gesamten UI, in Dialogen, Fenstertiteln und Benachrichtigungen **vollständig untersagt**.  
   Stattdessen nutzen wir handgezeichnete Texturen, SVG-Vektoren, geprägte Siegel und edle Serif-Schriften.
2. **Keine nativen Browser-Tooltips (`title="..."`):**  
   Hässliche gelb-graue Standard-Tooltips des Betriebssystems und Mauszeiger mit Fragezeichen brechen die vierte Wand. Alle Tooltips werden über das interne Custom-Tooltip-System gerendert.
3. **Klare visuelle Hierarchie:**  
   Wichtige Meisterberichte und Status-Zahlen sind sofort erfassbar; sekundäre Ausbau-Details verstecken sich hinter wohlstrukturierten Reitern oder kompakten Auswahlelementen.

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              DAS FARB- & MATERIAL-KONZEPT                              │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   HINTERGRÜNDE: Obsidian, verbrannte Eiche, raues Pergament                            │
│   • Basis-Hintergrund: #0d0a08 bis #181310 (Tiefes Holzkohle-Schwarz)                  │
│   • Radial-Licht: rgba(70, 45, 20, 0.28) (Warmer Feuerschein der Esse)                │
│                                                                                        │
│   RAHMEN & KANTEN: Geschmiedetes Eisen und gealtertes Hofgold                          │
│   • Standard-Border: #7c582c (Gekerbtes Bronze-Braun)                                  │
│   • Goldkante (Meister / Tier 3): #ffd87a bis #d49b4b (Glühender Aschenstahl)          │
│                                                                                        │
│   TYPOGRAFIE: Antike Pracht & gestochen scharfe Lesbarkeit                             │
│   • Titel & Wappen: "Cinzel", "Palatino Linotype", Georgia, serif                      │
│   • Fließtext & Zahlen: #efe0cb (Gebleichtes Leinen), #baa48a (Aschenbeige)           │
│   • Bonuswerte / Formeln: #92e078 (Smaragdgrün) oder #ffd87a (Goldgelb)                │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Der Werkstatt- und Gebäude-Standard (`BuildingWindow`)

Das Werkstattfenster dient als Referenz-Design für alle künftigen Management-Panels in Emberwild:

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│ [WAPPEN] SCHMIEDE & ARKANESSE                      [ ★ ★ ☆ ]  [ ✕ ]                    │
│ Veredelung & Rüstbau · Stufe 2 von 3               (Ausbaustufe) (Esc)                  │
├────────────────────────────────────────────────────────────────────────────────────────┤
│ ┌────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ [PORTRÄT]  ALDRIC VENN · Erzschmied von Emberwatch                    Moral: 96%   │ │
│ │ (Goldrand) Meisterprägung: Ewige Esse (+25% Barrentempo)              [████████░░] │ │
│ │ "Die Essen glühen im Takt, mein Lord. Schafft uns Roheisen heran!"   ● In Betrieb  │ │
│ └────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                        │
│ PRODUKTIONS-FOKUS: [ Dropdown: Qualitäts-Arbeit ▼ ] ──► +25% Goldertrag auf Waffen    │
│                                                                                        │
│ ARBEITSKRÄFTE ZUWEISEN (1 / 2 Plätze)                  +25% Ertrag pro Handwerker      │
│ ┌───────────────────────────────────────┐  ┌─────────────────────────────────────────┐ │
│ │ AKTUELL IM BETRIEB:                   │  │ BÜRGER & GESELLEN: [Nur Fachkr.] [Alle] │ │
│ │ • Darin Eisenarm (Geselle)   [Abziehen│  │ • Kaelen Glutwächter [Fachkr.] [Zuweisen│ │
│ │   +30% Eisen · Schmiedegeselle        │  │ • Boran Felsbrecher  [Hilfskr.] [Zuweisen│ │
│ └───────────────────────────────────────┘  └─────────────────────────────────────────┘ │
├────────────────────────────────────────────────────────────────────────────────────────┤
│ Nächste Stufe erfordert: 80 Bauholz · 50 Werkstein · 40 Eisen        [ Ausbauen (Lv 3) ]│
└────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2.1 Die Komponenten des Werkstattfensters
1. **Header mit SVG-Sternen:**  
   Die Ausbaustufe wird rechts oben durch **drei animierte SVG-Sterne** dargestellt. Volle Stufen leuchten mit `@keyframes starPulsate` in warmem Gold.
2. **Die Meister-Karte:**  
   Großes Porträt mit Goldrand, `MEISTER`-Plakette, Hoftitel, persönlicher Meisterprägung, situativem Zitat und Arbeitsmoral-Balken.
3. **Kompakte Fokus-Leiste:**  
   Ersetzt große klobige Kacheln durch ein schlankes Dropdown-Menü mit direkt danebenstehender Ertragsvorschau.
4. **Verfügbare Handwerker mit Filter-Umschalter:**  
   * *[Nur Fachkräfte]:* Zeigt ausschließlich Bürger an, deren Handwerksberuf zur Werkstatt passt.
   * *[Alle Bürger]:* Listet alle Bewohner auf. Fachkräfte stehen oben mit goldener `Fachkraft`-Plakette; normale Bürger erhalten die subtile `Hilfskraft`-Plakette.
5. **Autonomer Footer:**  
   Wird das Gebäude auf Stufe 3 (Maximum) vollendet, **blendet sich der Footer vollständig aus**, um maximale Bildschirmhöhe für die Handwerkerzuweisung freizugeben.

---

## 3. Das Custom-Tooltip-System (`#bw-custom-tooltip`)

Strikte Vorgabe für alle Buttons, Plaketten, Ressourcen und Porträts:

```
┌─────────────────────────────────────────────────────────┐
│ Meisterprägung: Ewige Esse                              │ ──► Goldener Titel (Cinzel, 12.5px)
├─────────────────────────────────────────────────────────┤
│ Erhöht das Veredelungstempo der Esse um +25% und        │ ──► Ausführlicher Fließtext
│ verleiht allen Klingen 15% zusätzliche Schärfe.         │     (#efe0cb, Georgia)
├─────────────────────────────────────────────────────────┤
│ Bonus-Effekt: +25% Glutstahl-Effizienz                  │ ──► Hervorgehobene Sub-Zeile
└─────────────────────────────────────────────────────────┘     (Goldener Glanz, Consolas)
```

* **Positionierung:** Berechnet automatisch den optimalen Ankerpunkt oberhalb oder unterhalb des Ziels, inklusive Bildschirmschutz (*View-Bound-Clamping*).
* **Mauszeiger:** Bleibt stets der standardmäßige Spiele-Cursor (`cursor: default` oder `cursor: pointer`), niemals der Windows-Hilfezeiger mit Fragezeichen.

---

## 4. Internationalisierung (i18n-Architektur)

Emberwild wird zweisprachig (Deutsch als Hauptsprache, Englisch als Fallback) betrieben:

* Alle UI-Strings müssen über `t('domain.key', params)` bezogen werden.
* Kein einziger Text darf hardcoded in Skriptdateien stehen.
* Wörterbuch-Dateien liegen in `src/data/locales/de.js` und `src/data/locales/en.js`.

---

## 5. Audio-Feedback-Katalog

Jede Benutzeraktion wird von dezentem, authentischem Audio-Feedback untermalt:

| Audio-Event | Sound-Datei | Anlass |
|---|---|---|
| `ui_open` | Pergament-Rauschen & Riegel | Öffnen eines Fensters (`E`, `V`, Klick) |
| `ui_close` | Sanfter Holzklack | Schließen per `Esc` oder ✕ |
| `ui_confirm` | Amboss-Klingeln / Klick | Zuweisung eines Arbeiters, Fokuswechsel |
| `loot_drop_rare` | Sakraler Gong | Ernennung eines Meisters, Ausbau auf neue Stufe |
| `siren_alarm` | Tiefes Kriegshorn | Ausbruch eines schweren Krisenevents |

